# MASTER SKILL SYSTEM SPECIFICATION — DIMRAETH: THE SHATTERED OATH

This document defines the complete, zero-duplicate tactical combat skill system implemented in `src/game/rules.ts`, `src/components/SkillIcons.tsx`, `src/App.tsx`, and `src/components/UnitInspectPanel.tsx`, with 22 standalone vector icon assets in `public/assets/icons/skills/`.

---

## 1. Global Combat & Scaling Rules

All abilities operate strictly within the existing tactical turn-based combat ruleset—no unsupported mana, stamina, or rage pools are introduced:

- **Action Point Economy**: Every unit begins its turn with `2 / 2 AP` and `1 Movement Phase` (`movedThisTurn = false`). Moving up to `moveRange` tiles costs `0 AP` (consumes `movedThisTurn`), while skills cost `1 AP` or `2 AP`.
- **Attack Roll Formula**: `1d20 + floor((PrimaryStat - 10) / 2) + 2 (Proficiency) + HighGround (+2 / -1) + Flanking (+2) + CompanionBond (-1 to +3) + Blessed (+2)` vs `Target Effective AC` (`Base AC - 2 [Sundered] + 2 [Warded]`).
- **Upgrade & Scaling Behavior (Universal)**:
  - **Companion Bond Tiers**: *Comrade* (`+1 Hit / +1 DMG`), *Trusted* (`+2 Hit / +2 DMG / Crit 19–20`), *Sworn Bond* (`+3 Hit / +4 DMG / Crit 18–20`).
  - **Elevation Advantage**: Attacking from High Ground (`elevation 1` → `0`) grants `+2 Hit` and `+2 Bonus DMG`.
  - **World Reactivity Scaling**: Unleashing `blood_weave_unleashed` adds `+3 DMG` to all party offensive skills; swearing `oathAlignment === 'Mercy'` adds `+3 HP` to all allied healing skills; `sanctum_purified` grants `+6 Max HP`.

---

## 2. Mechanical Uniqueness Audit (Zero-Duplicate Verification)

Previously, all 6 subclasses in `CHARACTER_SUBCLASSES` shared `id: 'searing_smite'` and relied on generic `Damage + Push 1 + Sunder/Root` templates. Those overlaps were **rejected and redesigned** so every skill owns a distinct central mechanic and player decision:

| # | Skill ID | Name | Owner (Class / Subclass) | Central Unique Mechanic | Distinct Player Decision | Standalone Icon |
|---|---|---|---|---|---|---|
| 1 | `sunblade_cleave` | **Sunblade Cleave** | Paladin `[1]` | **Sweeping Vanguard Arc** (`5 Fire DMG + Burn` to mutually adjacent secondary foe) + `Push 1` | Step where 2 frontline foes touch both you and each other | `sunblade_cleave.svg` |
| 2 | `dawnbreaker_judgment` | **Dawnbreaker Judgment** | Paladin · *Dawn Warden* `[2]` | **5-Tile Solar Cross Consecration** (`+` shape purifies tiles + heals allies in cross `+6 HP` & `Blessed`) | Strike an enemy engaged next to allies to sunder + AoE heal simultaneously | `dawnbreaker_judgment.svg` |
| 3 | `searing_smite` | **Oathbreaker Smite** | Paladin · *Vengeance Knight* `[2]` | **Range-2 Gap-Close Leap** + **`+6` Execution DMG (`≤50% HP`)** + **`+1 AP` Refund on KO** | Hold until a target is bloodied to leap in, execute, and refund AP | `searing_smite.svg` |
| 4 | `lay_on_hands` | **Dawnlight Mending** | Paladin `[3]` | **Full Affliction Purge** (`burning`, `rooted`, `sundered`) + `14 HP` Heal + Sanctify Tile | Emergency single-target debuff cleanse & sanctuary creation | `lay_on_hands.svg` |
| 5 | `aegis_bulwark` | **Sovereign Aegis** | Paladin `[4]` | **`+8` Self Temp HP** + **Radius-2 Squad Phalanx (`+4 Temp HP` & Burn Extinguish)** | Group within 2 tiles of teammates before absorbing telegraphed enemy burst | `aegis_bulwark.svg` |
| 6 | `astral_bolt` | **Astral Lance** | Arcanist (Kaelen) `[1]` | **Linear Piercing Starlight Ray** (`5 Arcane DMG` up to 2 tiles behind target) + `Push 1` | Align sightlines down rows/columns to pierce backline targets | `astral_bolt.svg` |
| 7 | `astral_soul_blade` | **Astral Soul-Blade** | Arcanist (Commander) `[1]` | **Mid-Range Piercing Fire-Ray** (`5 Fire DMG + Burn` behind target + Oil Ignition) + `Push 1` | Skirmish at Range 4 to pierce lines and ignite oil slicks behind the vanguard | `astral_soul_blade.svg` |
| 8 | `crimson_tempest` | **Crimson Singularity** | Arcanist (Kaelen) `[2]` | **`3×3` Chebyshev Blast** (`6 Fire DMG` secondary) + **`+5` Thermal Resonance vs Burning** | Prime foes with Burning/Oil first to cash in Resonance + `3×3` AoE | `crimson_tempest.svg` |
| 9 | `searing_blood_nova` | **Searing Blood-Nova** | Arcanist · *Crimson Savant* `[2]` | **High-Intensity `3×3` Pyromantic Supernova** (`16–23` Base + `+5` Resonance + Cask Chain) | Commit 2 AP onto clustered/burning packs for maximum AoE burst | `searing_blood_nova.svg` |
| 10 | `chrono_rift_collapse` | **Chrono-Rift Collapse** | Arcanist · *Rift Chronomancer* `[2]` | **Radius-2 Gravitational Vacuum Pull Inward** (`+4 Warp DMG`) + Epicenter `Rooted` | Vacuum scattered enemies together to set up allied AoE combos | `chrono_rift_collapse.svg` |
| 11 | `gravity_shackle` | **Rift Singularity Bind** | Arcanist `[3]` | **Telekinetic Caster-Tether Pull (`1 Tile` Toward Caster)** + `Rooted` + `+4` Drop/Hazard Shear | Yank enemy archers/casters off High Ground or onto Rift hazards | `gravity_shackle.svg` |
| 12 | `arcane_conduit` | **Weave Transfusion** | Arcanist `[4]` | **Ley-Line Movement Phase Reset (`movedThisTurn = false`)** + `+5 Temp HP` + Root Break | Slingshot an ally who already moved so they reposition twice in one round | `arcane_conduit.svg` |
| 13 | `heartseeker_shot` | **Heartseeker Arrow** | Warden (Thorne) `[1]` | **Deadeye Distance Scaling (`+3 Sniper DMG` at `≥4` Tiles)** + `Push 1` | Maintain `4–6` tile sniper spacing and High Ground angles | `heartseeker_shot.svg` |
| 14 | `briarfang_strike` | **Briarfang Strike** | Warden (Commander) `[1]` | **Predator Affliction Exploit (`+4 DMG` vs `Rooted`/`Sundered`)** + Underfoot Briar Seed | Sequence after snares or armor-breaks without pushing prey out of hazards | `briarfang_strike.svg` |
| 15 | `heart_briar_volley` | **Heart-Briar Volley** | Warden · *Gloom-Briar Stalker* `[2]` | **`+5` Isolated Prey Ambush** + **3-Tile Perpendicular Living Briar Wall** | Snipe isolated backliners or wall off narrow 3-tile corridors | `heart_briar_volley.svg` |
| 16 | `ironwood_tempest` | **Ironwood Tempest** | Warden · *Ironbough Sentinel* `[2]` | **Orthogonal Seismic Shockwave (`5 DMG`)** + **Self `Warded (+2 AC)` & `+5 Temp HP`** | Dive into frontline packs to cleave and self-fortify simultaneously | `ironwood_tempest.svg` |
| 17 | `bramble_snare` | **Briar-Thorn Volley** | Warden `[2]` | **Proactive Empty-Tile or Enemy Trap Placement** (`bramble_snare` choke point) | Pre-mine approaches and bastion stairs before melee rushers arrive | `bramble_snare.svg` |
| 18 | `viper_twinshot` | **Tempest Twin-Barrage** | Warden `[3]` | **Twin Fire Armor-Shred (`Sundered`)** + **Automatic 1-Tile Evasive Backstep Vault** | Disengage from melee flankers while shredding AC and igniting oil | `viper_twinshot.svg` |
| 19 | `warden_salve` | **Sylvan Wild-Balm** | Warden `[4]` | **Extinguish `Burning` + Repair `Sundered` (`+4 Net AC` Swing w/ `Warded`)** + Moss Restore | Patch armor-broken/burning tanks and neutralize fire/rift ground | `warden_salve.svg` |
| 20 | `inquisitor_mace` | **Obsidian Halberd Crush** | Enemy · *Inquisitor* `[1]` | **Vanguard Armor-Crack (`Sundered`)** + `Push 1` | Punishes unwarded high-HP frontliners | `inquisitor_mace.svg` |
| 21 | `void_barrage` | **Abyssal Rift Volley** | Enemy · *Weaver* `[1]` | **High-Ground Void Artillery (`Burning` + Oil Ignition)** | Pressures party from elevated perches until displaced | `void_barrage.svg` |
| 22 | `shadow_lunge` | **Shadowstep Twin-Dagger** | Enemy · *Stalker* `[1]` | **Opportunist Backstab (`+3 DMG` vs `≤60% HP` or `Burning`/`Sundered`)** | Hunts wounded or debuffed backline companions | `shadow_lunge.svg` |

---

## 3. Class 1 — Oathbreaker Paladin (`paladin`)

### 3.1 `sunblade_cleave` — Sunblade Cleave
- **Class & Subclass Ownership**: Oathbreaker Paladin (Core Slot `[1]`, shared by Dawn Warden & Vengeance Knight)
- **Skill Category**: Martial Vanguard Cleave (`martial_cleave`)
- **Tactical Purpose**: AP-efficient melee crowd control, object shoving, oil ignition, and 2-target frontline arc pressure.
- **Full Gameplay Description**: Sweep a dawnfire-infused greatsword across the vanguard, dealing `8–13` Fire DMG to the primary target, shoving them `1 tile` backward (`+4 Impact DMG` if blocked), igniting connected oil pools, and scorching any secondary enemy adjacent to both caster and target for `5 Fire DMG` + `Burning (2t)`.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `0 Turns` (At-Will)
- **Range & Targeting Rules**: Range `2` (Manhattan); targets `enemy` units, intact pushable objects, or `oil_pool` tiles.
- **Area of Effect & Shape**: `sweeping_arc` — Primary tile + mutually adjacent (`chebyshevDistance <= 1` to both caster & target) enemy arc.
- **Damage Formula & Scaling**: `1d6 + 7` (`8–13` Fire) + Synergy (`0..+4`) + High Ground (`+2`) + Blood-Weave (`+3`); Hit scales with `STR`. Secondary arc deals flat `5 Fire DMG`.
- **Status Effects & Duration**: Inflicts `Burning` (`-3 HP/turn`, `2 turns`) on secondary arc targets and oil-ignited units.
- **Movement & Positioning Effects**: Shoves primary unit or pushable object `1 tile` away along primary axis.
- **Terrain & Environmental Interactions**: Ignites `oil_pool` chains (`+6 Fire DMG`), detonates `oil_barrel` / `runic_brazier` (`8 Fire DMG`), or shoves `runestone_block` onto `hazard_rift` to seal it.
- **Conditions, Restrictions, & Failure Cases**: Requires `1 AP` and `manhattanDistance <= 2`. Natural `1` or roll `< Effective AC` misses (no knockback or arc splash).
- **Upgrade / Scaling Behavior**: Scales with STR hit modifier, Seraphina Bond Tier (up to `18–20` Crit & `+4 DMG`), and High Ground.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Lowers shoulder into a grounded half-sword stance as solar embers run up the fuller.
  - *Weapon / Body*: Wide `180°` horizontal figure-eight slash from right hip to left shoulder.
  - *Trajectory*: Crescent ribbon of molten gold-amber flame hugging waist height.
  - *Impact*: Bright metallic spark shower and diagonal fire-scar decal across flagstones.
  - *Particles & Environment*: Swirling orange cinders (`#F97316`) and instant chain-ignition across adjacent oil slicks.
  - *Enemy Reaction*: Heavy backward stagger (`1 tile` slide) or jarring wall-slam recoil.
  - *Camera Feedback*: Crisp lateral micro-shake (`120ms`).
  - *Sound Effects*: Tempered steel ring layered with a bellows-flame whoosh (`playMeleeHit`).
  - *Recovery*: Smooth guard reset with rising heat shimmer from the blade tip.
- **Icon Asset**: `public/assets/icons/skills/sunblade_cleave.svg` — Diagonal blazing greatsword carving a sweeping golden crescent with knockback chevron.

### 3.2 `dawnbreaker_judgment` — Dawnbreaker Judgment
- **Class & Subclass Ownership**: Oathbreaker Paladin — **Oath of the Dawn Warden** Signature (`[2]`)
- **Skill Category**: Cruciform Consecration & Hybrid Judgment (`consecration_judgment`)
- **Tactical Purpose**: Frontline zone conversion—simultaneously sunders an enemy tank, purifies hazardous ground in a 5-tile cross, and mends/blesses engaged melee allies.
- **Full Gameplay Description**: Call down a cruciform pillar of unbroken dawnlight (`15–22` Radiant DMG + `Sundered -2 AC` for 2 turns). Consecrates all walkable tiles in a 5-tile Manhattan cross (`+`) into `sanctified_pool` and restores `+6 HP` + `Blessed (+2 Hit, 2t)` (while extinguishing `Burning`) to all conscious party allies inside the cross.
- **Action Point Cost**: `2 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `3` (Manhattan); targets `enemy` unit or contested ground tile.
- **Area of Effect & Shape**: `solar_cross` — 5-tile orthogonal cross (`(x,z)`, `(x±1,z)`, `(x,z±1)`).
- **Damage Formula & Scaling**: `1d8 + 14` (`15–22` Radiant) + Synergy + High Ground + Blood-Weave; Hit scales with `STR`; Cross ally heal is flat `+6 HP`.
- **Status Effects & Duration**: Primary enemy: `Sundered` (`-2 AC`, `2 turns`). Allies in cross: `Blessed` (`+2 Attack`, `2 turns`) + cleanses `Burning`.
- **Movement & Positioning Effects**: Zero knockback by design—pins the sundered enemy inside your newly consecrated melee zone.
- **Terrain & Environmental Interactions**: Purifies `hazard_rift` → `stone` and converts `oil_pool`, `fire_pool`, and `bramble_snare` across all 5 cross tiles into `sanctified_pool` (`+4 HP` on step).
- **Conditions, Restrictions, & Failure Cases**: Costs `2 AP`, `2-turn` cooldown. Unwalkable `pillar` tiles inside the cross are skipped cleanly.
- **Upgrade / Scaling Behavior**: Scales with `STR` accuracy, Bond Crit range, and compounds with `sanctum_purified` frontline sustain.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Raises warhammer/greatsword vertically with both gauntlets as a solar halo forms overhead.
  - *Weapon / Body*: Drives pommel downward in a solemn gavel strike.
  - *Trajectory*: Vertical zenith beam descending onto the target and splitting along 4 cardinal stone seams.
  - *Impact*: Cruciform golden shock-glyph etched into the 5 tiles.
  - *Particles & Environment*: Ascending ivory motes (`#FDE047`) and shimmering cathedral light columns.
  - *Enemy Reaction*: Drops to one knee under radiant weight as armor plates fracture.
  - *Camera Feedback*: Vertical impact thud (`160ms`).
  - *Sound Effects*: Resonant sanctuary bell chord over thunderous radiant impact (`playMeleeHit(true)` + `playHealBless`).
  - *Recovery*: Steadfast shield-forward vigil stance.
- **Icon Asset**: `public/assets/icons/skills/dawnbreaker_judgment.svg` — Descending solar gavel beam illuminating a 5-tile golden cross.

### 3.3 `searing_smite` — Oathbreaker Smite
- **Class & Subclass Ownership**: Oathbreaker Paladin — **Oath of Shattered Vengeance** Signature & Default Seraphina `[2]`
- **Skill Category**: Execution Gap-Closer (`execution_gapcloser`)
- **Tactical Purpose**: Relentless gap-closing assassination of wounded (`≤50% HP`) targets with AP-refund snowballs on kill.
- **Full Gameplay Description**: Vault across a 2-tile gap into melee and bring down fractured astral judgment (`16–24` Radiant DMG on Vengeance Knight; `14–21` base) that inflicts `Sundered (-2 AC, 2t)`. Deals **`+6` Bloodied Execution DMG** if target `HP <= 50% Max HP`, and **refunds `+1 AP` immediately if the strike KOs the target**.
- **Action Point Cost**: `2 AP` (`Net 1 AP` on lethal execution!)
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `2` (Manhattan); targets `enemy` unit.
- **Area of Effect & Shape**: `single` — Focused single-target execution pillar + caster leap into adjacent tile.
- **Damage Formula & Scaling**: `1d8 + 15` (`16–24` Radiant, or `1d8 + 13` base) + `+6` (if target `HP <= 50%`) + Synergy + High Ground + Blood-Weave; Hit scales with `STR`.
- **Status Effects & Duration**: `Sundered` (`-2 AC`, `2 turns`).
- **Movement & Positioning Effects**: `selfReposition: 'leap_adjacent'` — If cast from distance `2` (and caster is not `Rooted`), Paladin leaps into the nearest open walkable tile adjacent to the target.
- **Terrain & Environmental Interactions**: Purifies `oil_pool`, `fire_pool`, or `hazard_rift` on the target's tile into `sanctified_pool`; updates Paladin's `elevation` if leaping onto a bastion.
- **Conditions, Restrictions, & Failure Cases**: Leap does not occur if caster is `Rooted` or all 4 orthogonal tiles around the target are obstructed (damage still resolves). `+1 AP` refund triggers strictly on `targetKO === true`.
- **Upgrade / Scaling Behavior**: Critical hits double base weapon dice before adding `+6` Bloodied Execution, creating lethal boss-finishing thresholds.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Reverses grip into an overhead executioners' poise as fractured crimson-gold runes crackle along the blade.
  - *Weapon / Body*: Explosive forward leap followed by a two-handed vertical guillotine cleave.
  - *Trajectory*: Steep parabolic comet arc from Paladin's origin to adjacent melee tile.
  - *Impact*: Shattered covenant halo bursts outward with jagged gold-violet shards.
  - *Particles & Environment*: Fractured rune splinters (`#FDE047` / `#F59E0B`) and purified stone glow.
  - *Enemy Reaction*: Violent armor-buckling crumple; dramatic collapse if executed.
  - *Camera Feedback*: Heavy zoom-punch & vertical shake (`200ms`).
  - *Sound Effects*: Metallic oath-chain snap + thunderous radiant anvil strike.
  - *Recovery*: Wrenching blade free from the flagstone; golden AP pip flare on kill.
- **Icon Asset**: `public/assets/icons/skills/searing_smite.svg` — Fractured oath-halo split vertically by a descending radiant blade.

### 3.4 `lay_on_hands` — Dawnlight Mending
- **Class & Subclass Ownership**: Oathbreaker Paladin (Core Slot `[3]`)
- **Skill Category**: Single-Target Triage & Affliction Purge (`cleansing_mend`)
- **Tactical Purpose**: Ranged emergency healing, complete negative-status cleansing, and single-tile sanctuary creation.
- **Full Gameplay Description**: Channel silver-gold grace to an ally within `4 tiles`, restoring `14 HP` (`17 HP` under Mercy Oath), **purging all negative afflictions (`Burning`, `Rooted`, `Sundered`)**, granting `Blessed (+2 Hit, 2t)`, and consecrating their tile into `sanctified_pool`.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `4` (Manhattan); Auto-Hit on any conscious `ally` (including self).
- **Area of Effect & Shape**: `single` — Target ally + target's ground tile.
- **Damage Formula & Scaling**: `2d4 + 9` Fixed Equivalent = `14 HP` (`+3 HP` with `Mercy` Oath Alignment).
- **Status Effects & Duration**: Cleanses `burning`, `rooted`, `sundered`; grants `Blessed` (`+2 Attack`, `2 turns`).
- **Movement & Positioning Effects**: Restores target's full `moveRange` immediately if they were `Rooted`.
- **Terrain & Environmental Interactions**: Converts target tile (`none`, `oil_pool`, `fire_pool`, `bramble_snare`, or `hazard_rift`) into `sanctified_pool` (`stone` base if rift).
- **Conditions, Restrictions, & Failure Cases**: Cannot target enemies or KO'd units; HP capped at `maxHp`.
- **Upgrade / Scaling Behavior**: Scales directly with `Mercy` Oath (`+3 HP`) and `sanctum_purified` (`+6 Max HP` ceiling).
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Presses gauntlet to silver reliquary over heart, then extends open palm toward ally.
  - *Weapon / Body*: Graceful upward lifting gesture.
  - *Trajectory*: Arching ribbon of warm ivory-gold light linking caster and ally.
  - *Impact*: Spiraling lotus of golden feathers dissolving dark chains/flames around the ally.
  - *Particles & Environment*: Rising golden motes and consecrated floor sigil beneath the ally.
  - *Enemy Reaction*: N/A (Allied support).
  - *Camera Feedback*: Gentle warm bloom pulse (no shake).
  - *Sound Effects*: Harmonic choir chime & cleansing bell (`playHealBless`).
  - *Recovery*: Calm hand-lowering breath.
- **Icon Asset**: `public/assets/icons/skills/lay_on_hands.svg` — Open gauntleted palm cradling a rising eight-point dawn star.

### 3.5 `aegis_bulwark` — Sovereign Aegis
- **Class & Subclass Ownership**: Oathbreaker Paladin (Core Slot `[4]`)
- **Skill Category**: Defensive Bastion & Squad Phalanx Aura (`bastion_aura`)
- **Tactical Purpose**: Proactive damage mitigation against enemy telegraphs via self `Warded` AC + squad-wide Temp HP shielding.
- **Full Gameplay Description**: Plant a covenant kite shield to recover `6 HP` (`+3` Mercy), gain **`+8 Temp HP`** and `Warded (+2 AC, 2t)`, and project a **Radius-2 Phalanx Aura** granting **`+4 Temp HP`** (and extinguishing `Burning`) to all conscious allies within `2 tiles`.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `1` (`targetType: 'self'`); click active Paladin to invoke.
- **Area of Effect & Shape**: `bastion_aura` — Caster + `manhattanDistance <= 2` allied diamond aura.
- **Damage Formula & Scaling**: `6 HP` Self-Heal (`+3` Mercy) + `8 Self Temp HP` + `4 Ally Temp HP`.
- **Status Effects & Duration**: Self: `Warded` (`+2 AC`, `2 turns`). Allies within 2 tiles: cleanses `Burning`.
- **Movement & Positioning Effects**: Rewards tight phalanx positioning (`<= 2` tiles) prior to ending turn.
- **Terrain & Environmental Interactions**: Extinguishes `Burning` on nearby allies caught near fire hazards.
- **Conditions, Restrictions, & Failure Cases**: Allies beyond `2` Manhattan tiles do not receive the `+4 Temp HP` aura. Self Temp HP refreshes to `8` rather than infinitely stacking on self.
- **Upgrade / Scaling Behavior**: Combines multiplicatively with high AC (`17–18 Effective AC` makes enemy attacks miss while Temp HP absorbs breakthroughs).
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Braces rear boot and slams shield rim onto the stone.
  - *Weapon / Body*: Shield lock crouch with weapon poised over top rim.
  - *Trajectory*: Expanding hexagonal golden dome rippling `2 tiles` outward.
  - *Impact*: Translucent runic shield facets lock around caster and nearby companions.
  - *Particles & Environment*: Metallic gold-cyan ward glyphs orbiting waist height.
  - *Enemy Reaction*: Subsequent enemy strikes spark off translucent barrier plates.
  - *Camera Feedback*: Subtle low-frequency bass lock (`90ms`).
  - *Sound Effects*: Heavy bronze shield lock + crystalline barrier hum (`playHealBless`).
  - *Recovery*: Elevated guard posture.
- **Icon Asset**: `public/assets/icons/skills/aegis_bulwark.svg` — Crowned tower kite shield framed by concentric bastion ward arcs.

---

## 4. Class 2 — Blood-Weave Arcanist (`arcanist`)

### 4.1 `astral_bolt` & `astral_soul_blade` — Astral Lance / Astral Soul-Blade
- **Class & Subclass Ownership**: Arcanist `[1]` (`astral_bolt` on Kaelen at Range `6`; `astral_soul_blade` on Arcanist Commander at Range `4`)
- **Skill Category**: Linear Vector Piercing Ray (`piercing_ray`)
- **Tactical Purpose**: Long-axis multi-hit alignment, ranged object shoving, and backline piercing.
- **Full Gameplay Description**: Project a spear (`7–12` Arcane, Range 6) or condensed spellblade (`8–13` Fire-Arcane, Range 4) that shoves the primary target `1 tile` backward and **lances up to `2 tiles` directly behind the target along the ray vector**, dealing `5 DMG` (`+ Burning` for *Soul-Blade*) to aligned secondary foes.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `0 Turns` (At-Will)
- **Range & Targeting Rules**: Range `6` (`astral_bolt`) / Range `4` (`astral_soul_blade`); targets `enemy` or pushable objects.
- **Area of Effect & Shape**: `piercing_ray` — Primary target + `1–2` tiles directly behind along `(stepX, stepZ)`.
- **Damage Formula & Scaling**: `1d6 + 6` (`7–12`, `+3` w/ `blood_weave_unleashed`) or `1d6 + 7` (`8–13`) + Synergy + High Ground; Hit scales with `INT`. Pierced targets take `5 DMG`.
- **Status Effects & Duration**: `astral_soul_blade` inflicts `Burning` (`2 turns`) on pierced targets and ignites oil.
- **Movement & Positioning Effects**: Pushes primary target or object `1 tile` backward (`+4 DMG` on collision).
- **Terrain & Environmental Interactions**: Shoves `runestone_block`, `oil_barrel`, or `runic_brazier` from long range; `astral_soul_blade` ignites `oil_pool`.
- **Conditions, Restrictions, & Failure Cases**: Secondary pierce resolves strictly along the primary orthogonal ray vector (`computePushVector`).
- **Upgrade / Scaling Behavior**: Scales with `INT` (`21 INT` = `+5` stat mod on Crimson Savant!), Kaelen Bond Tier, and `blood_weave_unleashed` (`+6` total spell bonus on Kaelen!).
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Traces a glowing starlight triangle in midair (`astral_bolt`) or draws a fiery astral saber from the palm (`astral_soul_blade`).
  - *Weapon / Body*: Sharp fencer's thrust forward with staff/free hand.
  - *Trajectory*: High-velocity laser-straight needle beam piercing through the target tile and `2 tiles` beyond.
  - *Impact*: Concentric arcane ripple rings at entry and exit points.
  - *Particles & Environment*: Violet-cyan starlight shards (`#A855F7` / `#38BDF8`) or crimson-violet sparks.
  - *Enemy Reaction*: Jerked backward `1 tile` while rear enemy flinches from through-beam.
  - *Camera Feedback*: Fast directional snap (`100ms`).
  - *Sound Effects*: Crystalline ley-line whip crack (`playArcaneCast`).
  - *Recovery*: Coils floating runes back around fingertips.
- **Icon Assets**: `public/assets/icons/skills/astral_bolt.svg` (piercing starlight spear through twin rings) & `public/assets/icons/skills/astral_soul_blade.svg` (curved rune spellblade with twin starlight waves).

### 4.2 `crimson_tempest` & `searing_blood_nova` — Crimson Singularity / Searing Blood-Nova
- **Class & Subclass Ownership**: Arcanist `[2]` (`crimson_tempest` on Kaelen; `searing_blood_nova` on **Crimson Savant** Subclass)
- **Skill Category**: `3×3` Pyromantic Detonation & Thermal Resonance (`pyromantic_detonation`)
- **Tactical Purpose**: High-yield `3×3` area devastation, volatile barrel chain-detonation, and `+5` Resonance cash-out on `Burning` foes.
- **Full Gameplay Description**: Detonate a `3×3` Blood-Weave firestorm (`13–19` Fire on *Singularity*; `16–23` Fire on *Blood-Nova*), inflicting `Burning (2t)`, dealing **`+5` Thermal Resonance DMG if the primary target is already `Burning`**, scorching all secondary enemies in the `3×3` square (`chebyshevDistance <= 1`) for `6 Fire DMG + Burning`, and chain-igniting all connected `oil_pool` tiles and volatile casks!
- **Action Point Cost**: `2 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `5` (Manhattan); targets `enemy` unit, `oil_pool` tile, or volatile object.
- **Area of Effect & Shape**: `chebyshev_3x3` (`aoeRadius: 1`) — Full 9-tile `3×3` square.
- **Damage Formula & Scaling**: `2d4 + 11` (`13–19`) or `1d8 + 15` (`16–23`) + `+5` (Thermal Resonance if `Burning`) + Synergy + High Ground + Blood-Weave; Secondary AoE: `6 Fire DMG`. Hit scales with `INT`.
- **Status Effects & Duration**: `Burning` (`-3 HP/turn`, `2 turns`) on primary and all secondary `3×3` enemies.
- **Movement & Positioning Effects**: None—punishes tightly grouped or vacuum-pulled formations.
- **Terrain & Environmental Interactions**: BFS chain-ignition of all 8-way connected `oil_pool` tiles (`+6 Fire DMG`) and instant detonation of `oil_barrel` / `runic_brazier` (`+8 Fire DMG`).
- **Conditions, Restrictions, & Failure Cases**: `2 AP`, `2-turn` cooldown. Note: Party allies are shielded from the arcane blast weave, though stepping onto resulting `fire_pool` tiles later deals surface burn.
- **Upgrade / Scaling Behavior**: Combines with `blood_weave_unleashed` and Thermal Resonance for the highest AoE ceiling in the game.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Levitates grimoire open as a miniature crimson sun compresses between both hands.
  - *Weapon / Body*: Clenches fist to implode the sphere, then thrusts upward.
  - *Trajectory*: Condensed blood-ember orb arcs to epicenter and implodes before erupting outward.
  - *Impact*: `3×3` crimson-gold shockwave pillar with rising ash vortex.
  - *Particles & Environment*: Intense ember storm (`#F97316` / `#F43F5E`) and spreading liquid fire across oil tiles.
  - *Enemy Reaction*: Shielding face against blast wave as clothes/armor catch alchemical flame.
  - *Camera Feedback*: Heavy radial screen shake (`220ms`).
  - *Sound Effects*: Sub-bass implosion vacuum followed by roaring pyromantic detonation (`playArcaneCast`).
  - *Recovery*: Lowers smoking fingertips as grimoire pages settle.
- **Icon Assets**: `public/assets/icons/skills/crimson_tempest.svg` (swirling blood-fire vortex core) & `public/assets/icons/skills/searing_blood_nova.svg` (eight-point crimson supernova burst).

### 4.3 `chrono_rift_collapse` — Chrono-Rift Collapse
- **Class & Subclass Ownership**: Blood-Weave Arcanist — **Rift Chronomancer** Signature (`[2]`)
- **Skill Category**: Spacetime Vacuum Implosion (`spacetime_implosion`)
- **Tactical Purpose**: Multi-enemy clustering & AoE combo setup—pulls scattered enemies inward toward a Rooted anchor.
- **Full Gameplay Description**: Collapse spacetime on a target within `5 tiles` (`14–21` Arcane DMG + `Rooted 2t`) and generate a **Radius-2 Gravitational Vacuum** that drags all other conscious enemies within `chebyshevDistance <= 2` inward `1 tile` toward the epicenter, dealing `4 Arcane Warp DMG` to each pulled foe.
- **Action Point Cost**: `2 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `5` (Manhattan); targets `enemy` unit or ground epicenter.
- **Area of Effect & Shape**: `vacuum_implosion` (`aoeRadius: 2`) — `5×5` Chebyshev capture zone pulling inward toward `(targetX, targetZ)`.
- **Damage Formula & Scaling**: `1d8 + 13` (`14–21` Arcane) + Synergy + High Ground + Blood-Weave; Hit scales with `INT`. Vacuumed secondary enemies suffer `4 Arcane DMG`.
- **Status Effects & Duration**: Primary target: `Rooted` (`0 Move`, `2 turns`).
- **Movement & Positioning Effects**: Pulls all secondary enemies within Chebyshev `2` inward `1 tile` into open walkable tiles closer to the epicenter.
- **Terrain & Environmental Interactions**: Can drag enemies off High Ground bastions (`elevation 1` → `0`) or onto adjacent hazards.
- **Conditions, Restrictions, & Failure Cases**: If all inward tiles for a secondary enemy are obstructed, they remain on their tile and still suffer the `4 Arcane Warp DMG`.
- **Upgrade / Scaling Behavior**: Sets up devastating cross-class wombo-combos with `searing_blood_nova`, `crimson_tempest`, `sunblade_cleave`, and `ironwood_tempest`.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Rotates hands like turning giant clockwork gears as an astral hourglass glyph materializes.
  - *Weapon / Body*: Twists wrists `90°` inward to fracture the timepiece.
  - *Trajectory*: Instantaneous spatial distortion lens at target coordinates.
  - *Impact*: Inverted dark-violet event horizon sucking light and debris inward.
  - *Particles & Environment*: Clockwork arc fragments and inward-streaking violet-teal dust (`#A855F7`).
  - *Enemy Reaction*: Dragged skidding across stone toward the singularity core.
  - *Camera Feedback*: Brief inward FOV pinch & shudder (`180ms`).
  - *Sound Effects*: Reversed glass chime + deep gravitational bass hum (`playArcaneCast`).
  - *Recovery*: Smooth temporal afterimage fade on caster's cloak.
- **Icon Asset**: `public/assets/icons/skills/chrono_rift_collapse.svg` — Fractured astral hourglass with four inward-pulling gravity arrows.

### 4.4 `gravity_shackle` — Rift Singularity Bind
- **Class & Subclass Ownership**: Blood-Weave Arcanist (Core Slot `[3]`)
- **Skill Category**: Telekinetic Caster-Tether Pull (`telekinetic_tether`)
- **Tactical Purpose**: Single-target anti-perch extraction—yanks enemy ranged units off High Ground or drags targets onto hazards, then locks them `Rooted`.
- **Full Gameplay Description**: Hook an enemy within `5 tiles` (`6–10` Arcane DMG), **pull them `1 tile` directly toward the Arcanist**, and lock them in place with `Rooted (2t)`. Deals **`+4` Gravitational Shear DMG** if yanked off High Ground (`elevation 1 → 0`) or pulled onto a `hazard_rift`, `fire_pool`, or `bramble_snare`.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `5` (Manhattan); targets `enemy` unit.
- **Area of Effect & Shape**: `tether_pull` — Single target + `1-tile` inward pull vector toward caster.
- **Damage Formula & Scaling**: `1d4 + 5` (`6–10` Arcane) + Synergy + High Ground + Blood-Weave + `+4` Shear (on elevation drop or hazard entry); Hit scales with `INT`.
- **Status Effects & Duration**: `Rooted` (`0 Move`, `2 turns`); adds `Burning` if pulled into `fire_pool`.
- **Movement & Positioning Effects**: `pullDistance: 1` — Opposite of knockback; moves target `1 tile` closer to Arcanist.
- **Terrain & Environmental Interactions**: Hard-counters High Ground bastions (`weaver` loses `+2 Hit / +2 DMG` elevation bonus AND takes `+4 Shear DMG`) and Weaponizes `hazard_rift` / `bramble_snare` tiles between caster and foe.
- **Conditions, Restrictions, & Failure Cases**: If the tile directly in front of the target toward the caster is unwalkable or occupied, target stays on current tile and still suffers primary damage + `Rooted`.
- **Upgrade / Scaling Behavior**: `1 AP` cost lets Arcanist pull an enemy onto an oil pool (`1 AP`) and detonate `Astral Soul-Blade` (`1 AP`) on the exact same turn!
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Extends clawed fingers forward, conjuring a violet tether chain.
  - *Weapon / Body*: Sharp backward yank of the forearm.
  - *Trajectory*: Glowing arcane grappling chain latching onto target's torso.
  - *Impact*: Anchoring gravity shackles clamp around the target's ankles at destination tile.
  - *Particles & Environment*: Violet chain links and downward gravity rings.
  - *Enemy Reaction*: Yanked off balance `1 tile` forward, then pinned to the stone.
  - *Camera Feedback*: Crisp directional tug (`110ms`).
  - *Sound Effects*: Arcane chain latch + heavy stone anchor lock (`playArcaneCast`).
  - *Recovery*: Dismisses excess chain links with a flick of the wrist.
- **Icon Asset**: `public/assets/icons/skills/gravity_shackle.svg` — Arcane shackle cuff around a dark singularity orb with downward pull vector.

### 4.5 `arcane_conduit` — Weave Transfusion
- **Class & Subclass Ownership**: Blood-Weave Arcanist (Core Slot `[4]`)
- **Skill Category**: Tactical Phase Mobility & Temp-Shield Conduit (`phase_transfusion`)
- **Tactical Purpose**: Action-economy force multiplier—grants an ally a **second full movement phase** in the same round while shielding and un-rooting them.
- **Full Gameplay Description**: Channel ley-line momentum into an ally within `5 tiles`: restore `11 HP` (`+3` Mercy), grant **`+5 Temp HP`**, cleanse `Rooted`, apply `Blessed (+2 Hit, 2t)`, **and reset `movedThisTurn = false`** so an ally who already moved this round can move again!
- **Action Point Cost**: `1 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `5` (Manhattan); Auto-Hit on any conscious `ally`.
- **Area of Effect & Shape**: `single` — Target ally + local rift/bramble stabilization.
- **Damage Formula & Scaling**: `11 HP` Heal (`+3` Mercy) + `5 Temp HP`.
- **Status Effects & Duration**: Cleanses `Rooted` (note: does *not* cleanse `Burning` or `Sundered`, preserving Paladin/Warden support niches); grants `Blessed` (`2 turns`).
- **Movement & Positioning Effects**: `resetTargetMove: true` — Refreshes target's `movedThisTurn` flag to `false`.
- **Terrain & Environmental Interactions**: Stabilizes `hazard_rift` → `stone` and clears `bramble_snare` → `none` beneath the ally so they can stride out freely.
- **Conditions, Restrictions, & Failure Cases**: If target has not moved yet this round, they still gain the `11 HP` heal, `+5 Temp HP`, `Blessed`, and `Rooted` break.
- **Upgrade / Scaling Behavior**: Enables unmatched map-wide rotations (e.g., Paladin moves `4 tiles`, Arcanist casts *Weave Transfusion*, Paladin moves another `4 tiles` to reach a distant objective!).
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Draws an infinity ley-line glyph with staff tip.
  - *Weapon / Body*: Sweeps open hand forward in a wind-beckoning arc.
  - *Trajectory*: Twin intertwined streams of violet-cyan starlight spiraling into the ally.
  - *Impact*: Phase-shift afterimage shimmer around the ally's boots and shoulders.
  - *Particles & Environment*: Cyan-violet phase diamonds (`#A855F7` / `#38BDF8`).
  - *Enemy Reaction*: N/A (Allied mobility conduit).
  - *Camera Feedback*: Subtle speed-ripple pulse.
  - *Sound Effects*: Shimmering harmonic warp chime (`playHealBless`).
  - *Recovery*: Staff butt taps stone lightly.
- **Icon Asset**: `public/assets/icons/skills/arcane_conduit.svg` — Twin ley-line infinity spirals feeding a luminous phase crystal.

---

## 5. Class 3 — Sylvan Warden (`warden`)

### 5.1 `heartseeker_shot` — Heartseeker Arrow
- **Class & Subclass Ownership**: Sylvan Warden (Thorne Core Slot `[1]`)
- **Skill Category**: Long-Range Sniper & Kinetic Knockback (`deadeye_snipe`)
- **Tactical Purpose**: Rewards maintaining sniper distance (`4–6` tiles) and elevated perches while controlling spacing with `Push 1`.
- **Full Gameplay Description**: Loose a heavy ironwood broadhead at up to Range `6` for `8–13` Physical DMG + `Push 1`, gaining **`+3` Deadeye Sniper Bonus DMG whenever fired from `4 or more` Manhattan tiles away**.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `0 Turns` (At-Will)
- **Range & Targeting Rules**: Range `6` (Manhattan); targets `enemy` unit or pushable object.
- **Area of Effect & Shape**: `single` — Precision single-target projectile.
- **Damage Formula & Scaling**: `1d6 + 7` (`8–13` Physical) + `+3` (if `manhattanDistance >= 4`) + Synergy + High Ground + Blood-Weave; Hit scales with `DEX`.
- **Status Effects & Duration**: Conditional knockback hazard application (`Burning` if pushed into fire/rift; `Rooted` if pushed into brambles).
- **Movement & Positioning Effects**: Pushes hit target or object `1 tile` away (`+4 DMG` if obstructed).
- **Terrain & Environmental Interactions**: Punches enemies into pre-planted `bramble_snare` traps or shoves `runic_brazier` / `oil_barrel` into enemy formations from 6 tiles away.
- **Conditions, Restrictions, & Failure Cases**: Shots at distance `1–3` lose the `+3` Deadeye bonus, incentivizing kiting and `Tempest Twin-Barrage` backsteps.
- **Upgrade / Scaling Behavior**: From a High Ground bastion (`+2 DMG`) at `4+` tiles (`+3 DMG`) with Sworn Bond (`+4 DMG`), a `1 AP` *Heartseeker Arrow* hits for `17–22` non-crit!
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Full-draw anchor to cheek on recurve ironwood bow, squinting for windage.
  - *Weapon / Body*: Crisp bowstring release with zero torso sway.
  - *Trajectory*: Flat, ultra-fast emerald-fletched shaft cutting a wind-tunnel vapor line.
  - *Impact*: Deep armor-punching thud that knocks target backward a full step.
  - *Particles & Environment*: Splintered ironwood sparks and wind-shear rings (`#F59E0B`).
  - *Enemy Reaction*: Chest recoil and `1-tile` backward slide.
  - *Camera Feedback*: Sharp micro-recoil along arrow vector (`90ms`).
  - *Sound Effects*: Heavy bowstring twang + high-velocity whistle + armor punch (`playMeleeHit`).
  - *Recovery*: Fluidly nocks next shaft from hip quiver.
- **Icon Asset**: `public/assets/icons/skills/heartseeker_shot.svg` — Emerald-fletched broadhead arrow piercing a golden deadeye reticle.

### 5.2 `briarfang_strike` — Briarfang Strike
- **Class & Subclass Ownership**: Sylvan Warden (Warden Commander Core Slot `[1]`)
- **Skill Category**: Affliction-Exploit Skirmish Thrust (`predator_strike`)
- **Tactical Purpose**: Mid-range combo follow-up that cashes in `+4 DMG` on `Rooted` or `Sundered` prey while keeping them pinned in thorns.
- **Full Gameplay Description**: Lunge with an ironwood spear-fang up to `3 tiles` away (`9–14` Nature DMG), dealing **`+4` Predator Bonus DMG against `Rooted` or `Sundered` targets**, and sprouting an entangling `bramble_snare` surface beneath the target.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `0 Turns` (At-Will)
- **Range & Targeting Rules**: Range `3` (Manhattan); targets `enemy` unit or walkable ground tile.
- **Area of Effect & Shape**: `single` — Single target + target's ground surface.
- **Damage Formula & Scaling**: `1d6 + 8` (`9–14` Nature) + `+4` (if target is `Rooted` or `Sundered`) + Synergy + High Ground + Blood-Weave; Hit scales with `DEX`.
- **Status Effects & Duration**: Overgrows tile into `bramble_snare`, inflicting `Rooted (2t)` via surface reaction.
- **Movement & Positioning Effects**: Zero push—deliberately keeps afflicted prey trapped on the thorn tile!
- **Terrain & Environmental Interactions**: Converts `none`, `oil_pool`, `sanctified_pool`, or `hazard_rift` (`→ moss`) into `bramble_snare`.
- **Conditions, Restrictions, & Failure Cases**: Shorter range (`3`) than *Heartseeker Arrow* (`6`), requiring active skirmishing.
- **Upgrade / Scaling Behavior**: Self-combos across turns: Strike 1 plants briars & roots (`9–14`), Strike 2 immediately triggers `+4` Predator Exploit (`13–18`)!
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Coils low like a stalking lynx, twirling thorn-bladed spear.
  - *Weapon / Body*: Explosive lunging thrust with vine-whip extension.
  - *Trajectory*: Verdant fang-shaped energy thrust reaching `3 tiles`.
  - *Impact*: Wicked green briars erupt upward around the target's greaves.
  - *Particles & Environment*: Razor leaves and emerald sap droplets (`#4ADE80`).
  - *Enemy Reaction*: Wince and ankle-snare struggle.
  - *Camera Feedback*: Snappy forward thrust impulse (`100ms`).
  - *Sound Effects*: Whipping vine snap + piercing spear strike.
  - *Recovery*: Springs back into balanced skirmisher guard.
- **Icon Asset**: `public/assets/icons/skills/briarfang_strike.svg` — Curved ironwood spear-fang entwined with razor briar thorns.

### 5.3 `heart_briar_volley` — Heart-Briar Volley
- **Class & Subclass Ownership**: Sylvan Warden — **Gloom-Briar Stalker** Signature (`[2]`)
- **Skill Category**: Isolated Ambush & Multi-Tile Terrain Barricade (`briar_barricade`)
- **Tactical Purpose**: Punishes isolated backline targets (`+5 DMG`) while erecting a **3-tile perpendicular wall of thorns** to seal corridors and choke points.
- **Full Gameplay Description**: Loose a fan of living Heart-Briar shafts up to `5 tiles` (`15–22` Nature DMG + `Rooted 2t`). Deals **`+5` Ambush DMG if no other enemy is adjacent (`chebyshevDistance <= 1`) to the target**, and raises a **3-tile perpendicular wall of `bramble_snare` tiles** centered on the target (`4 Nature DMG + Rooted` to secondary foes on the wall).
- **Action Point Cost**: `2 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `5` (Manhattan); targets `enemy` unit or corridor tile.
- **Area of Effect & Shape**: `briar_wall_3` — `1×3` perpendicular line orthogonal to the caster-to-target vector.
- **Damage Formula & Scaling**: `1d8 + 14` (`15–22` Nature) + `+5` (Isolated Ambush) + Synergy + High Ground + Blood-Weave; Hit scales with `DEX`. Secondary wall targets take `4 Nature DMG`.
- **Status Effects & Duration**: `Rooted` (`0 Move`, `2 turns`) across all enemies on the 3-tile briar wall.
- **Movement & Positioning Effects**: Creates a 3-tile movement-stopping barrier (`3 Nature DMG + Rooted` on step) that splits the battlefield.
- **Terrain & Environmental Interactions**: Overgrows up to 3 walkable tiles into `bramble_snare` and purifies `hazard_rift` → `moss`.
- **Conditions, Restrictions, & Failure Cases**: Unwalkable `pillar` tiles on either wing of the `1×3` wall are skipped without failing the remaining tiles.
- **Upgrade / Scaling Behavior**: Hard-counters Enemy `weaver` units (who stay isolated on High Ground) for `20–27` base Nature DMG before modifiers!
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Nocks three thorn-barbed arrows simultaneously at a tilted angle.
  - *Weapon / Body*: High parabolic sky-shot release.
  - *Trajectory*: Three emerald-trailed shafts fanning out in midair to land in a crisp `1×3` line.
  - *Impact*: Instantaneous eruption of gnarled iron-thorn hedges across 3 tiles.
  - *Particles & Environment*: Floating spore motes and twisting emerald-crimson vines (`#4ADE80`).
  - *Enemy Reaction*: Tangled mid-stride by erupting root cages.
  - *Camera Feedback*: Crisp ground-rumble shudder (`160ms`).
  - *Sound Effects*: Triple bow twang + creaking rapid-growth timber burst.
  - *Recovery*: Lowers bow into cloaked crouch.
- **Icon Asset**: `public/assets/icons/skills/heart_briar_volley.svg` — Three converging sylvan arrows sprouting a horizontal wall of thorns.

### 5.4 `ironwood_tempest` — Ironwood Tempest
- **Class & Subclass Ownership**: Sylvan Warden — **Ironbough Sentinel** Signature (`[2]`)
- **Skill Category**: Seismic Bruiser Cleave & Self-Fortification (`seismic_glaive`)
- **Tactical Purpose**: Frontline brawler commit—sunders and shoves a primary foe, batters orthogonal neighbors with a shockwave, and grants self `Warded (+2 AC)` + `+5 Temp HP`.
- **Full Gameplay Description**: Swing a heavy ironwood glaive (`15–22` Physical DMG + `Sundered -2 AC` + `Push 1`), unleash an **orthogonal seismic shockwave (`5 Physical DMG` to adjacent enemies)**, and harden your own barkskin for **`Warded (+2 AC, 2t)` + `+5 Temp HP`**.
- **Action Point Cost**: `2 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `3` (Manhattan); targets `enemy` unit.
- **Area of Effect & Shape**: `shockwave_ring` — Primary target + 4 orthogonal neighbor tiles (`manhattanDistance === 1`) + Self buff.
- **Damage Formula & Scaling**: `1d8 + 14` (`15–22` Physical) + Synergy + High Ground + Blood-Weave; Hit scales with `DEX` (or `STR` if allocated higher). Shockwave deals `5 Physical DMG`.
- **Status Effects & Duration**: Primary enemy: `Sundered` (`-2 AC`, `2 turns`). Caster: `Warded` (`+2 AC`, `2 turns`) + `+5 Temp HP`.
- **Movement & Positioning Effects**: Pushes primary target `1 tile` away (`+4 DMG` if slammed into pillar/unit).
- **Terrain & Environmental Interactions**: Can shove primary foe into hazards while holding contested chokepoints with `16+ Effective AC`.
- **Conditions, Restrictions, & Failure Cases**: Self `Warded` & `+5 Temp HP` require hitting the target (or resolving on ground shockwave).
- **Upgrade / Scaling Behavior**: Turns a Wood-Kin Ironbough Sentinel (`16 Base AC + 2 Warded = 18 AC`, `46 HP + 5 Temp HP`) into an unbreakable secondary tank.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Spins ironwood glaive overhead, gathering swirling autumn leaves and stone dust.
  - *Weapon / Body*: `360°` advancing rotary slam into the ground.
  - *Trajectory*: Circular shockwave ring + forward kinetic blast.
  - *Impact*: Radial stone cracks around target while interlocking oak-bark plates encase the Sentinel's shoulders.
  - *Particles & Environment*: Amber oak leaves, stone chips, and emerald bark-ward sheen.
  - *Enemy Reaction*: Primary target hurled back `1 tile`; orthogonal foes staggered by ground tremor.
  - *Camera Feedback*: Heavy seismic thud (`190ms`).
  - *Sound Effects*: Oaken timber crash + earthen tremor (`playMeleeHit(true)`).
  - *Recovery*: Plants glaive butt firmly beside boot.
- **Icon Asset**: `public/assets/icons/skills/ironwood_tempest.svg` — Ironwood glaive blade encircled by swirling bark-plates and oak leaves.

### 5.5 `bramble_snare` — Briar-Thorn Volley
- **Class & Subclass Ownership**: Sylvan Warden (Thorne Core Slot `[2]`)
- **Skill Category**: Proactive Ground-or-Unit Choke-Point Trap (`trap_snare`)
- **Tactical Purpose**: Low-cost (`1 AP`) zone denial—either roots an enemy directly OR mines an empty walkable tile ahead of advancing melee enemies.
- **Full Gameplay Description**: Fire a seed-pod shaft up to `5 tiles` at an enemy (`9–14` Nature DMG + `Rooted 2t`) **or directly onto an empty walkable tile** to grow a persistent `bramble_snare` hazard (`3 Nature DMG + Rooted 2t` when entered) and convert `hazard_rift` into `moss`.
- **Action Point Cost**: `1 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `5` (Manhattan); dual-mode targeting (`enemy` unit OR walkable `ground` tile).
- **Area of Effect & Shape**: `trap_tile` — `1×1` persistent surface hazard.
- **Damage Formula & Scaling**: Direct hit: `1d6 + 8` (`9–14` Nature) + Synergy + High Ground + Blood-Weave (`DEX`). Trap step trigger: `3 Nature DMG` + `Rooted`.
- **Status Effects & Duration**: `Rooted` (`0 Move`, `2 turns`).
- **Movement & Positioning Effects**: Halts enemy advances when placed on choke points or bastion approaches.
- **Terrain & Environmental Interactions**: Overwrites `oil_pool` or `hazard_rift` (`→ moss`) with `bramble_snare`; flammable if later struck by fire? (Remains `bramble_snare` unless purified by Radiant or cleared).
- **Conditions, Restrictions, & Failure Cases**: Cannot plant traps on unwalkable `pillar` tiles or tiles currently burning (`fire_pool`).
- **Upgrade / Scaling Behavior**: Pairs with `Heartseeker Arrow` (`1 AP` Snare behind enemy + `1 AP` Heartseeker Push into the Snare on the same turn!).
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Draws an arrow tipped with a pulsing emerald briar bulb.
  - *Weapon / Body*: Quick snap-shot arc.
  - *Trajectory*: Medium-arc green-trailed projectile.
  - *Impact*: Bulb bursts into a coiled ring of thorny vines gripping the tile.
  - *Particles & Environment*: Verdant vine tendrils and spore puffs (`#4ADE80`).
  - *Enemy Reaction*: Ankles bound in living thorns (`0 Move`).
  - *Camera Feedback*: Light crisp thud (`80ms`).
  - *Sound Effects*: Bow twang + snapping vine coils.
  - *Recovery*: Smooth step-and-aim reset.
- **Icon Asset**: `public/assets/icons/skills/bramble_snare.svg` — Coiled ring of interlocking emerald thorns around an arrow shaft.

### 5.6 `viper_twinshot` — Tempest Twin-Barrage
- **Class & Subclass Ownership**: Sylvan Warden (Core Slot `[3]`)
- **Skill Category**: Armor-Shredding Fire Finisher & Evasive Vault (`evasive_barrage`)
- **Tactical Purpose**: Kiting & self-peel finisher—shreds enemy armor, ignites oil, and automatically vaults the Warden `1 tile` away from danger.
- **Full Gameplay Description**: Loose two rapid alchemical-fire shafts up to `6 tiles` (`15–22` Fire DMG + `Sundered -2 AC, 2t`), igniting `oil_pool` surfaces and volatile barrels, **while the Warden automatically backsteps `1 tile` away from the target** into an open walkable tile.
- **Action Point Cost**: `2 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `6` (Manhattan); targets `enemy` unit or flammable object/oil tile.
- **Area of Effect & Shape**: `single` + `1-tile` caster retreat vector.
- **Damage Formula & Scaling**: `1d8 + 14` (`15–22` Fire) + Synergy + High Ground + Blood-Weave; Hit scales with `DEX`.
- **Status Effects & Duration**: `Sundered` (`-2 AC`, `2 turns`); `Burning` (`2 turns`) if target stands on ignited oil.
- **Movement & Positioning Effects**: `selfReposition: 'backstep_1'` — Moves caster `1 tile` away from `(targetX, targetZ)` without consuming `movedThisTurn`!
- **Terrain & Environmental Interactions**: Ignites connected `oil_pool` tiles and detonates `oil_barrel` / `runic_brazier`; backstep updates `elevation` if vaulting onto a bastion.
- **Conditions, Restrictions, & Failure Cases**: **Restriction**: If the Warden is `Rooted`, the damage and oil ignition still fire, **but the 1-tile Evasive Vault is prevented** (verified by unit test!). Also skipped if all retreat tiles are blocked.
- **Upgrade / Scaling Behavior**: Re-establishes `4+` tile spacing so next turn's `Heartseeker Arrow` regains its `+3` Deadeye Sniper bonus!
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Nocks twin fire-tipped shafts between index and ring fingers while crouching to spring backward.
  - *Weapon / Body*: Double-release mid-backflip/backstep vault.
  - *Trajectory*: Twin parallel blazing orange-gold arrow streaks toward target while caster vaults `1 tile` back.
  - *Impact*: Double armor-piercing fire burst cracking target's breastplate.
  - *Particles & Environment*: Twin ember trails (`#F97316`) and dust puff at landing tile.
  - *Enemy Reaction*: Armor plates split (`-2 AC`) as target staggers backward in flames.
  - *Camera Feedback*: Crisp double-pulse impact (`140ms`).
  - *Sound Effects*: Rapid double bow-twang + twin alchemical flare pops.
  - *Recovery*: Lands on one knee in sniper stance `1 tile` further back.
- **Icon Asset**: `public/assets/icons/skills/viper_twinshot.svg` — Twin parallel blazing arrows with rear wind-vault chevrons.

### 5.7 `warden_salve` — Sylvan Wild-Balm
- **Class & Subclass Ownership**: Sylvan Warden (Core Slot `[4]`)
- **Skill Category**: Armor-Repair Poultice & Ground Restoration (`barkskin_poultice`)
- **Tactical Purpose**: Anti-burn & anti-sunder defensive triage—creates a `+4 Net AC` swing on `Sundered` allies while neutralizing hazardous ground beneath them.
- **Full Gameplay Description**: Toss an herbal ironbark poultice to an ally within `4 tiles`, restoring `12 HP` (`+3` Mercy), **extinguishing `Burning` and repairing `Sundered` armor**, granting **`Warded (+2 AC, 2t)`**, and restoring hazardous ground (`fire_pool`, `oil_pool`, `hazard_rift`) beneath the ally to safe `moss` (`surface: 'none'`).
- **Action Point Cost**: `1 AP`
- **Cooldown**: `2 Turns`
- **Range & Targeting Rules**: Range `4` (Manhattan); Auto-Hit on any conscious `ally`.
- **Area of Effect & Shape**: `single` — Target ally + ally's tile restoration.
- **Damage Formula & Scaling**: `12 HP` Heal (`+3` Mercy).
- **Status Effects & Duration**: Cleanses `Burning` and `Sundered` (does *not* cleanse `Rooted`, preserving Paladin/Arcanist niches); grants `Warded` (`+2 AC`, `2 turns`).
- **Movement & Positioning Effects**: Stabilizes burning/rift ground under a frontline ally so they don't have to abandon a choke point.
- **Terrain & Environmental Interactions**: Neutralizes `fire_pool`, `oil_pool`, and `hazard_rift` into `moss` (`surface: 'none'`)—and **never** sprouts hostile brambles under an ally.
- **Conditions, Restrictions, & Failure Cases**: Cannot target enemies or KO'd units.
- **Upgrade / Scaling Behavior**: Directly counters Enemy `inquisitor` (`Sundered`) and Enemy `weaver` (`Burning` + `fire_pool`) in a single `1 AP` action.
- **Visual, Animation & Audio Spec**:
  - *Prep & Cast*: Crushes glowing emerald Vale-leaf vial in palm.
  - *Weapon / Body*: Underhand herbal flask toss.
  - *Trajectory*: Gentle emerald arc bursting into soothing mist over the ally.
  - *Impact*: Living bark-scales knit over cracked armor while cool moss extinguishes floor flames.
  - *Particles & Environment*: Emerald leaf motes (`#4ADE80`) and verdant moss bloom on stone.
  - *Enemy Reaction*: N/A (Allied restoration).
  - *Camera Feedback*: Calm verdant pulse.
  - *Sound Effects*: Glass phial chime + soothing foliage rustle (`playHealBless`).
  - *Recovery*: Returns hand to bow grip.
- **Icon Asset**: `public/assets/icons/skills/warden_salve.svg` — Herbal apothecary flask crowned with living oak leaves and bark-shield crest.

---

## 6. Enemy Archetype Counter-Play Abilities

1. **`inquisitor_mace` — Obsidian Halberd Crush** (*Inquisitor*, `1 AP`, Rng `2`, `7–11` Physical, `Push 1` + `Sundered`): Advances on highest-HP vanguard; countered by `warden_salve` (repairs Sunder + grants Warded) and `bramble_snare` choke points. Icon: `public/assets/icons/skills/inquisitor_mace.svg`.
2. **`void_barrage` — Abyssal Rift Volley** (*Weaver*, `1 AP`, Rng `5`, `6–10` Fire, `Burning` + Oil Ignition): Seeks High Ground (`elevation 1`); countered by Arcanist `gravity_shackle` (yanks off High Ground for `+4` Shear DMG) and Warden `heart_briar_volley` (`+5` Isolated Ambush DMG). Icon: `public/assets/icons/skills/void_barrage.svg`.
3. **`shadow_lunge` — Shadowstep Twin-Dagger** (*Stalker*, `1 AP`, Rng `2`, `6–10` Physical, **`+3` Opportunist Backstab vs `≤60% HP` or `Burning`/`Sundered`**): Hunts wounded backliners; countered by Paladin `aegis_bulwark` (`+4` Squad Temp HP) and Warden `viper_twinshot` (1-tile Evasive Backstep Vault). Icon: `public/assets/icons/skills/shadow_lunge.svg`.

---

## 7. Balance & Verification Summary

- **Action Economy Parity**: Every `1 AP` skill provides `~8–14` single-target output + 1 focused tactical hook (arc splash, ray pierce, deadeye range, predator bonus, pull, trap, triage, or squad shield), while every `2 AP` subclass signature (`CD 2`) delivers `~14–24` primary output + a battlefield-shaping multi-tile or action-economy effect (`5-tile solar cross`, `gap-close + KO AP refund`, `3×3 resonance blast`, `radius-2 vacuum implosion`, `3-tile briar wall`, or `shockwave + self ward`).
- **Automated Verification (`src/game/rules.test.ts`)**: All **19 automated test suites pass (`0` failures)**, validating individual class mechanics, status restrictions (e.g., `Rooted` blocking leaps/vaults), cross-class combo chains (`Chrono-Rift Collapse` → `Crimson Singularity` → `Oathbreaker Smite`), enemy archetype matchups, and standalone SVG icon presence for all 22 skill IDs.
