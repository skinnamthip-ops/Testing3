const fs = require('fs');
const path = require('path');

const ICONS_DIR = path.resolve(__dirname, '../public/assets/icons/progression-skills');

// Helper to construct dark-fantasy icon frame
function makeIconSvg(id, palette, innerSvgContent, subjectComment) {
  const { bgDark, bgLight, border, stroke, glow, accent } = palette;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128" fill="none">
  <defs>
    <radialGradient id="bg_${id}" cx="50%" cy="46%" r="62%">
      <stop offset="0%" stop-color="${bgLight}"/>
      <stop offset="100%" stop-color="${bgDark}"/>
    </radialGradient>
    <radialGradient id="aura_${id}" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="${glow}" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="${glow}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <!-- Background Plate -->
  <rect width="128" height="128" fill="url(#bg_${id})"/>
  <rect x="2" y="2" width="124" height="124" rx="4" fill="none" stroke="${border}" stroke-width="1.8" opacity="0.6"/>
  <!-- Corner Inset Flourishes -->
  <g opacity="0.45" stroke="${stroke}" stroke-width="1.2">
    <path d="M6 16L16 6M122 16L112 6M6 112L16 122M122 112L112 122"/>
    <circle cx="16" cy="16" r="2" fill="${accent}"/>
    <circle cx="112" cy="16" r="2" fill="${accent}"/>
    <circle cx="16" cy="112" r="2" fill="${accent}"/>
    <circle cx="112" cy="112" r="2" fill="${accent}"/>
  </g>
  <!-- Ambient Center Aura -->
  <circle cx="64" cy="64" r="50" fill="url(#aura_${id})"/>
  <!-- ${subjectComment} -->
  ${innerSvgContent.trim()}
</svg>`;
}

// Palettes
const P_WARRIOR = { bgLight: '#2C2016', bgDark: '#130E0A', border: '#785A3C', stroke: '#C27438', glow: '#C27438', accent: '#E8A366' };
const P_MAGE = { bgLight: '#221936', bgDark: '#0D0917', border: '#5C4382', stroke: '#8752DE', glow: '#8752DE', accent: '#B78FF5' };
const P_ROGUE = { bgLight: '#182026', bgDark: '#0B0F13', border: '#3B4D5C', stroke: '#38BDF8', glow: '#22C55E', accent: '#4ADE80' };
const P_PALADIN = { bgLight: '#2A2214', bgDark: '#120E06', border: '#8A7038', stroke: '#F59E0B', glow: '#F59E0B', accent: '#FDE047' };
const P_RANGER = { bgLight: '#19281C', bgDark: '#0A120C', border: '#446648', stroke: '#65A30D', glow: '#22C55E', accent: '#84CC16' };

const CORE_ICONS = {};

// ==========================================
// WARRIOR (12)
// ==========================================

CORE_ICONS['sundering_strike'] = {
  palette: P_WARRIOR,
  comment: 'Sundering Strike: Heavy Broadsword Cleaving Cracked Armor Plate',
  svg: `
  <!-- Broadsword blade cleaving diagonally -->
  <path d="M26 102L96 32L104 40L34 110Z" fill="#C27438" stroke="#E8A366" stroke-width="1.8"/>
  <path d="M96 32L108 20L116 28L104 40Z" fill="#E8A366" stroke="#7A451D" stroke-width="1.5"/>
  <line x1="22" y1="106" x2="38" y2="90" stroke="#7A451D" stroke-width="4" stroke-linecap="round"/>
  <!-- Broken Shield Plate beneath blade -->
  <path d="M48 42L76 46L68 76L42 70Z" fill="#1E1914" stroke="#785A3C" stroke-width="2"/>
  <!-- Sunder Impact Jagged Fissures -->
  <path d="M64 64L50 82L38 80M64 64L78 78L88 74M64 64L66 48" stroke="#F59E0B" stroke-width="2.2" stroke-linecap="round"/>
  <circle cx="64" cy="64" r="5" fill="#FEF08A"/>
  `
};

CORE_ICONS['guarded_stance'] = {
  palette: P_WARRIOR,
  comment: 'Guarded Stance: Reinforced Studded Iron Heater Shield',
  svg: `
  <!-- Heater Shield Body -->
  <path d="M34 28C64 24 64 24 94 28C96 66 84 94 64 106C44 94 32 66 34 28Z" fill="#1C1713" stroke="#C27438" stroke-width="3"/>
  <!-- Central Boss & Cross Reinforcements -->
  <path d="M64 26V104" stroke="#E8A366" stroke-width="2"/>
  <path d="M36 50H92" stroke="#E8A366" stroke-width="2"/>
  <circle cx="64" cy="50" r="10" fill="#2C2016" stroke="#E8A366" stroke-width="2.5"/>
  <circle cx="64" cy="50" r="4" fill="#F59E0B"/>
  <!-- Iron Studs -->
  <circle cx="44" cy="36" r="2.5" fill="#E8A366"/>
  <circle cx="84" cy="36" r="2.5" fill="#E8A366"/>
  <circle cx="42" cy="68" r="2.5" fill="#E8A366"/>
  <circle cx="86" cy="68" r="2.5" fill="#E8A366"/>
  <circle cx="64" cy="88" r="2.5" fill="#E8A366"/>
  `
};

CORE_ICONS['whirlwind_assault'] = {
  palette: P_WARRIOR,
  comment: 'Whirlwind Assault: 360 Degree Spinning Razor Blade Cyclone',
  svg: `
  <!-- Triple Curved Whirling Blades -->
  <path d="M64 20C88 20 106 38 106 62C106 50 96 36 78 36Z" fill="#E8A366" stroke="#C27438" stroke-width="1.5"/>
  <path d="M108 64C108 88 90 106 66 106C78 106 92 96 92 78Z" fill="#E8A366" stroke="#C27438" stroke-width="1.5"/>
  <path d="M64 108C40 108 22 90 22 66C22 78 32 92 50 92Z" fill="#E8A366" stroke="#C27438" stroke-width="1.5"/>
  <path d="M20 64C20 40 38 22 62 22C50 22 36 32 36 50Z" fill="#E8A366" stroke="#C27438" stroke-width="1.5"/>
  <!-- Circular Slipstream Rings -->
  <circle cx="64" cy="64" r="32" fill="none" stroke="#F59E0B" stroke-width="2" stroke-dasharray="8 6"/>
  <circle cx="64" cy="64" r="14" fill="#C27438" stroke="#FEF08A" stroke-width="2"/>
  <circle cx="64" cy="64" r="5" fill="#FEF08A"/>
  `
};

CORE_ICONS['driving_assault'] = {
  palette: P_WARRIOR,
  comment: 'Driving Assault: Spiked Ram Shoulder Plate with Impact Waves',
  svg: `
  <!-- Spiked Heavy Pauldron -->
  <path d="M30 44C44 32 72 32 86 44L92 68C84 84 56 88 38 80Z" fill="#241B14" stroke="#C27438" stroke-width="2.5"/>
  <!-- Ram Horn Spikes -->
  <path d="M68 40L104 36L86 52Z" fill="#E8A366" stroke="#7A451D" stroke-width="1.5"/>
  <path d="M72 58L108 62L82 72Z" fill="#E8A366" stroke="#7A451D" stroke-width="1.5"/>
  <!-- Kinetic Impact Shock Arcs -->
  <path d="M102 24C114 42 114 84 102 102" fill="none" stroke="#F59E0B" stroke-width="3" stroke-linecap="round"/>
  <path d="M112 36C120 50 120 76 112 90" fill="none" stroke="#FEF08A" stroke-width="2" stroke-linecap="round"/>
  `
};

CORE_ICONS['weapon_parry'] = {
  palette: P_WARRIOR,
  comment: 'Weapon Parry: Crossed Longsword & Parrying Dagger Deflection Burst',
  svg: `
  <!-- Primary Longsword -->
  <path d="M24 104L98 30L106 38L32 112Z" fill="#C27438" stroke="#E8A366" stroke-width="1.8"/>
  <!-- Crossing Dagger -->
  <path d="M36 28L100 92L92 100L28 36Z" fill="#785A3C" stroke="#C27438" stroke-width="1.8"/>
  <!-- Central Deflection Spark Burst -->
  <polygon points="64,48 68,60 80,64 68,68 64,80 60,68 48,64 60,60" fill="#FEF08A"/>
  <circle cx="64" cy="64" r="8" fill="none" stroke="#F59E0B" stroke-width="2"/>
  <line x1="52" y1="52" x2="44" y2="44" stroke="#FEF08A" stroke-width="2"/>
  <line x1="76" y1="52" x2="84" y2="44" stroke="#FEF08A" stroke-width="2"/>
  <line x1="52" y1="76" x2="44" y2="84" stroke="#FEF08A" stroke-width="2"/>
  <line x1="76" y1="76" x2="84" y2="84" stroke="#FEF08A" stroke-width="2"/>
  `
};

CORE_ICONS['crippling_blow'] = {
  palette: P_WARRIOR,
  comment: 'Crippling Blow: Barbed War Flail / War Pick Hooking An Armored Leg Greave',
  svg: `
  <!-- Armored Greave Outline -->
  <path d="M46 30C58 28 70 28 82 30L78 86L64 96L50 86Z" fill="#1C1814" stroke="#785A3C" stroke-width="2.5"/>
  <!-- Fractured Greave Center Crack -->
  <path d="M64 42L58 56L68 68L60 84" stroke="#F59E0B" stroke-width="2.4" stroke-linecap="round"/>
  <!-- Hooked Warpick Strike -->
  <path d="M96 34L68 54L74 62L102 42Z" fill="#C27438" stroke="#E8A366" stroke-width="1.5"/>
  <path d="M68 54L54 58L62 68Z" fill="#E8A366"/>
  <!-- Impact Burst Points -->
  <circle cx="56" cy="57" r="4" fill="#FEF08A"/>
  <line x1="48" y1="52" x2="38" y2="48" stroke="#F59E0B" stroke-width="2" stroke-linecap="round"/>
  <line x1="52" y1="66" x2="42" y2="72" stroke="#F59E0B" stroke-width="2" stroke-linecap="round"/>
  `
};

CORE_ICONS['unbreakable_resolve'] = {
  palette: P_WARRIOR,
  comment: 'Unbreakable Resolve: Roaring Lion Helm with Snapping Iron Chains',
  svg: `
  <!-- Roaring Lion Greathelm -->
  <path d="M40 36C52 24 76 24 88 36L92 70C88 88 74 94 64 96C54 94 40 88 36 70Z" fill="#281E15" stroke="#C27438" stroke-width="2.5"/>
  <!-- Glowing Eye Slits -->
  <polygon points="46,52 58,54 56,58 48,58" fill="#FEF08A"/>
  <polygon points="82,52 70,54 72,58 80,58" fill="#FEF08A"/>
  <!-- Lion Forehead Crest -->
  <path d="M56 36L64 24L72 36L64 44Z" fill="#E8A366"/>
  <!-- Broken Chains Left and Right -->
  <path d="M22 62C26 58 32 60 34 66" stroke="#C27438" stroke-width="3" fill="none"/>
  <path d="M14 68C18 64 24 66 26 72" stroke="#785A3C" stroke-width="2.5" fill="none"/>
  <path d="M106 62C102 58 96 60 94 66" stroke="#C27438" stroke-width="3" fill="none"/>
  <path d="M114 68C110 64 104 66 102 72" stroke="#785A3C" stroke-width="2.5" fill="none"/>
  `
};

CORE_ICONS['earthsplitter'] = {
  palette: P_WARRIOR,
  comment: 'Earthsplitter: Greatsword Plunged Into Fissured Bedrock with Erupting Slabs',
  svg: `
  <!-- Ground Baseline & Jagged Fissure -->
  <path d="M14 86L48 84L60 92L68 84L114 86" stroke="#785A3C" stroke-width="2.5"/>
  <polygon points="56,88 64,118 72,88 64,94" fill="#0E0B08" stroke="#F59E0B" stroke-width="1.8"/>
  <!-- Upright Greatsword Plunged In Center -->
  <path d="M61 24H67L66 88H62Z" fill="#C27438" stroke="#E8A366" stroke-width="1.5"/>
  <path d="M50 36H78V40H50Z" fill="#E8A366"/>
  <circle cx="64" cy="20" r="4" fill="#E8A366"/>
  <!-- Erupting Stone Chunks -->
  <polygon points="36,68 44,60 50,72 40,78" fill="#3B2A1D" stroke="#C27438" stroke-width="1.5"/>
  <polygon points="92,66 84,58 78,70 88,76" fill="#3B2A1D" stroke="#C27438" stroke-width="1.5"/>
  <!-- Radial Shock Lines -->
  <line x1="64" y1="88" x2="38" y2="102" stroke="#FEF08A" stroke-width="2"/>
  <line x1="64" y1="88" x2="90" y2="102" stroke="#FEF08A" stroke-width="2"/>
  `
};

CORE_ICONS['relentless_pursuit'] = {
  palette: P_WARRIOR,
  comment: 'Relentless Pursuit: Armored Boot Stride with Kinetic Slipstream Lines',
  svg: `
  <!-- Armored Greave & Sabaton Boot in Stride -->
  <path d="M42 28L60 56L50 78L88 88L94 100H48L36 78L44 48Z" fill="#241B13" stroke="#C27438" stroke-width="2.5"/>
  <path d="M50 78L88 88L84 94L48 94Z" fill="#785A3C"/>
  <circle cx="50" cy="78" r="4" fill="#E8A366"/>
  <!-- Speed Slipstream Trails -->
  <path d="M18 42H38M12 56H42M16 70H34" stroke="#F59E0B" stroke-width="2.5" stroke-linecap="round"/>
  <path d="M22 84H42M28 98H46" stroke="#FEF08A" stroke-width="2" stroke-linecap="round"/>
  <!-- Trailing Sparks -->
  <circle cx="96" cy="84" r="2" fill="#FEF08A"/>
  <circle cx="104" cy="92" r="2.5" fill="#F59E0B"/>
  `
};

CORE_ICONS['iron_reprisal'] = {
  palette: P_WARRIOR,
  comment: 'Iron Reprisal: Spiked Gauntlet Catching Shattered Blade with Counter-Thrust',
  svg: `
  <!-- Spiked Armored Gauntlet Fist -->
  <rect x="36" y="58" width="40" height="34" rx="6" fill="#221A13" stroke="#C27438" stroke-width="2.5"/>
  <!-- Gauntlet Knuckle Spikes -->
  <polygon points="40,58 44,48 48,58" fill="#E8A366"/>
  <polygon points="52,58 56,46 60,58" fill="#E8A366"/>
  <polygon points="64,58 68,48 72,58" fill="#E8A366"/>
  <!-- Counter-thrust Blade Rising From Fist -->
  <path d="M54 48L64 16L74 48Z" fill="#C27438" stroke="#FEF08A" stroke-width="2"/>
  <!-- Shattered Enemy Blade Shards -->
  <polygon points="86,40 98,34 92,48" fill="#785A3C" stroke="#C27438" stroke-width="1.2"/>
  <polygon points="26,44 38,36 34,50" fill="#785A3C" stroke="#C27438" stroke-width="1.2"/>
  <circle cx="64" cy="48" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['battlefield_commander'] = {
  palette: P_WARRIOR,
  comment: 'Battlefield Commander: Tattered Heraldic War Banner & Curved Horn',
  svg: `
  <!-- Spear Polearm Shaft -->
  <line x1="38" y1="18" x2="38" y2="110" stroke="#785A3C" stroke-width="3" stroke-linecap="round"/>
  <polygon points="38,12 43,26 33,26" fill="#E8A366"/>
  <!-- Flowing Tattered War Pennant Banner -->
  <path d="M40 24C68 28 88 18 106 28L98 64C80 54 60 62 40 56Z" fill="#8B2515" stroke="#C27438" stroke-width="2"/>
  <circle cx="68" cy="42" r="8" fill="#E8A366" opacity="0.8"/>
  <!-- Brass War Horn -->
  <path d="M52 82C66 70 88 74 94 88L102 84L104 98L90 94L94 88C88 78 70 76 56 86Z" fill="#D97706" stroke="#FEF08A" stroke-width="1.5"/>
  `
};

CORE_ICONS['last_stand'] = {
  palette: P_WARRIOR,
  comment: 'Last Stand: Winged Greathelm with Radiant Solar Halo & Defiant Heart',
  svg: `
  <!-- Defiant Winged Greathelm -->
  <path d="M46 44C54 32 74 32 82 44L86 78C76 90 64 92 64 92C64 92 52 90 42 78Z" fill="#1C1610" stroke="#E8A366" stroke-width="2.5"/>
  <!-- T-Shape Visor with Blazing Amber Light -->
  <path d="M50 56H78V62H68V80H60V62H50Z" fill="#FEF08A"/>
  <!-- Heraldic Helm Wings -->
  <path d="M44 46C30 38 20 50 18 64C28 62 36 56 42 54Z" fill="#785A3C" stroke="#C27438" stroke-width="1.5"/>
  <path d="M84 46C98 38 108 50 110 64C100 62 92 56 86 54Z" fill="#785A3C" stroke="#C27438" stroke-width="1.5"/>
  <!-- Radial Aura Corona -->
  <circle cx="64" cy="60" r="38" fill="none" stroke="#F59E0B" stroke-width="1.8" stroke-dasharray="6 4"/>
  `
};

// ==========================================
// MAGE (12)
// ==========================================

CORE_ICONS['arcane_bolt'] = {
  palette: P_MAGE,
  comment: 'Arcane Bolt: Astral Starlight Crystal Arrow with Orbiting Nebula Rings',
  svg: `
  <!-- Central Crystal Arrowhead -->
  <polygon points="64,18 78,54 64,48 50,54" fill="#B78FF5" stroke="#38BDF8" stroke-width="1.8"/>
  <polygon points="64,48 72,96 64,90 56,96" fill="#8752DE" stroke="#5C4382" stroke-width="1.5"/>
  <!-- Trailing Astral Cosmic Tail -->
  <line x1="64" y1="90" x2="64" y2="112" stroke="#38BDF8" stroke-width="2.5" stroke-linecap="round"/>
  <!-- Orbiting Nebula Rings -->
  <ellipse cx="64" cy="54" rx="36" ry="12" fill="none" stroke="#8752DE" stroke-width="2" transform="rotate(-25 64 54)"/>
  <ellipse cx="64" cy="54" rx="36" ry="12" fill="none" stroke="#38BDF8" stroke-width="1.8" transform="rotate(25 64 54)"/>
  <circle cx="64" cy="36" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['ley_line_sense'] = {
  palette: P_MAGE,
  comment: 'Ley-Line Sense: Glowing Open Palm over Intersecting Runic Meridians',
  svg: `
  <!-- Intersecting Geometric Ley-Line Lattice -->
  <circle cx="64" cy="64" r="42" fill="none" stroke="#5C4382" stroke-width="1.8"/>
  <polygon points="64,22 100,64 64,106 28,64" fill="none" stroke="#8752DE" stroke-width="1.8"/>
  <!-- Diamond Ley-line nodes -->
  <polygon points="64,18 68,22 64,26 60,22" fill="#38BDF8"/>
  <polygon points="104,64 100,68 96,64 100,60" fill="#38BDF8"/>
  <polygon points="64,110 68,106 64,102 60,106" fill="#38BDF8"/>
  <polygon points="24,64 28,68 32,64 28,60" fill="#38BDF8"/>
  <!-- Mystical Open Palm Silhouette -->
  <path d="M54 50V40C54 38 56 38 58 40V48M58 48V34C58 32 60 32 62 34V48M62 48V36C62 34 64 34 66 36V48M66 48V42C66 40 68 40 70 42V56C70 66 68 76 60 82C54 76 50 68 50 56V50C50 48 54 48 54 50Z" fill="#1A1228" stroke="#B78FF5" stroke-width="1.8"/>
  <circle cx="62" cy="60" r="5" fill="#38BDF8"/>
  `
};

CORE_ICONS['gravity_well'] = {
  palette: P_MAGE,
  comment: 'Gravity Well: Spacetime Singularity Vortex Pulling Orbital Asteroids',
  svg: `
  <!-- Swirling Spacetime Gravitational Spirals -->
  <path d="M64 24C86 24 104 42 104 64C104 80 90 94 74 94C62 94 52 84 52 72C52 64 58 58 64 58C68 58 70 62 70 64" fill="none" stroke="#8752DE" stroke-width="2.5" stroke-linecap="round"/>
  <path d="M64 104C42 104 24 86 24 64C24 48 38 34 54 34C66 34 76 44 76 56" fill="none" stroke="#38BDF8" stroke-width="2" stroke-linecap="round"/>
  <!-- Central Dense Singularity Core -->
  <circle cx="64" cy="64" r="14" fill="#06040A" stroke="#B78FF5" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="5" fill="#38BDF8"/>
  <!-- Orbiting Asteroid Matter -->
  <circle cx="34" cy="46" r="3" fill="#B78FF5"/>
  <circle cx="94" cy="42" r="3.5" fill="#B78FF5"/>
  <circle cx="86" cy="88" r="2.5" fill="#38BDF8"/>
  <circle cx="42" cy="86" r="3" fill="#38BDF8"/>
  `
};

CORE_ICONS['astral_step'] = {
  palette: P_MAGE,
  comment: 'Astral Step: Dimensional Doorway Phase Blink with Starlight Shards',
  svg: `
  <!-- Astral Archway / Dimensional Portal -->
  <path d="M42 104V48C42 34 52 24 64 24C76 24 86 34 86 48V104" fill="none" stroke="#8752DE" stroke-width="2.5"/>
  <!-- Portal Event Horizon -->
  <path d="M46 104V48C46 38 54 30 64 30C74 30 82 38 82 48V104Z" fill="#140D22"/>
  <!-- Shimmering Phase Displace Silhouette -->
  <path d="M64 42C68 42 70 46 70 50C70 54 66 58 64 58C62 58 58 54 58 50C58 46 60 42 64 42ZM54 84C54 68 62 62 64 62C66 62 74 68 74 84Z" fill="#B78FF5" opacity="0.8"/>
  <!-- Dispersing Astral Shards -->
  <polygon points="34,44 38,40 36,48" fill="#38BDF8"/>
  <polygon points="94,52 98,48 96,56" fill="#38BDF8"/>
  <polygon points="90,78 96,74 92,82" fill="#38BDF8"/>
  <polygon points="30,76 36,72 32,80" fill="#38BDF8"/>
  `
};

CORE_ICONS['spell_echo'] = {
  palette: P_MAGE,
  comment: 'Spell Echo: Resonant Tuning Forks with Harmonic Acoustic Waveforms',
  svg: `
  <!-- Dual Arcane Tuning Forks -->
  <path d="M46 32V60C46 68 52 74 58 74V98" fill="none" stroke="#8752DE" stroke-width="2.5" stroke-linecap="round"/>
  <path d="M34 32V60C34 76 44 86 58 86" fill="none" stroke="#8752DE" stroke-width="2.5" stroke-linecap="round"/>
  <!-- Harmonic Echo Wave Rings -->
  <path d="M68 44C78 48 84 56 84 64C84 72 78 80 68 84" fill="none" stroke="#38BDF8" stroke-width="2" stroke-linecap="round"/>
  <path d="M78 34C92 40 102 52 102 64C102 76 92 88 78 94" fill="none" stroke="#B78FF5" stroke-width="2" stroke-linecap="round"/>
  <circle cx="58" cy="98" r="4" fill="#38BDF8"/>
  <circle cx="64" cy="64" r="6" fill="#FEF08A"/>
  `
};

CORE_ICONS['null_field'] = {
  palette: P_MAGE,
  comment: 'Null Field: Hexagonal Dampening Grid Dome Extinguishing Arcane Sparks',
  svg: `
  <!-- Hexagonal Protective Anti-magic Dome -->
  <polygon points="64,22 98,42 98,82 64,102 30,82 30,42" fill="#120D1C" stroke="#8752DE" stroke-width="2.5"/>
  <!-- Internal Hex Lattice Lines -->
  <line x1="64" y1="22" x2="64" y2="102" stroke="#5C4382" stroke-width="1.8"/>
  <line x1="30" y1="42" x2="98" y2="82" stroke="#5C4382" stroke-width="1.8"/>
  <line x1="30" y1="82" x2="98" y2="42" stroke="#5C4382" stroke-width="1.8"/>
  <!-- Extinguished Center Core with Rune Cross -->
  <circle cx="64" cy="62" r="16" fill="#0A0610" stroke="#38BDF8" stroke-width="2"/>
  <line x1="52" y1="50" x2="76" y2="74" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round"/>
  `
};

CORE_ICONS['prismatic_cage'] = {
  palette: P_MAGE,
  comment: 'Prismatic Cage: Polyhedral Crystal Lattice Locking a Radiant Arcane Core',
  svg: `
  <!-- Faceted Polyhedral Cage -->
  <polygon points="64,18 96,36 96,92 64,110 32,92 32,36" fill="none" stroke="#8752DE" stroke-width="2"/>
  <polygon points="64,38 84,50 84,78 64,90 44,78 44,50" fill="#1C142A" stroke="#B78FF5" stroke-width="2"/>
  <!-- Refraction Beams -->
  <line x1="64" y1="18" x2="64" y2="38" stroke="#38BDF8" stroke-width="2"/>
  <line x1="96" y1="36" x2="84" y2="50" stroke="#F43F5E" stroke-width="2"/>
  <line x1="96" y1="92" x2="84" y2="78" stroke="#F59E0B" stroke-width="2"/>
  <line x1="64" y1="110" x2="64" y2="90" stroke="#22C55E" stroke-width="2"/>
  <line x1="32" y1="92" x2="44" y2="78" stroke="#38BDF8" stroke-width="2"/>
  <line x1="32" y1="36" x2="44" y2="50" stroke="#A855F7" stroke-width="2"/>
  <!-- Inner Shimmering Sphere -->
  <circle cx="64" cy="64" r="10" fill="#FEF08A"/>
  `
};

CORE_ICONS['temporal_distortion'] = {
  palette: P_MAGE,
  comment: 'Temporal Distortion: Mechanical Pocket Watch with Reversing Hands',
  svg: `
  <!-- Watch Casing & Crown -->
  <circle cx="64" cy="66" r="38" fill="#171022" stroke="#8752DE" stroke-width="2.5"/>
  <rect x="58" y="20" width="12" height="8" rx="2" fill="#B78FF5"/>
  <circle cx="64" cy="18" r="5" fill="none" stroke="#B78FF5" stroke-width="2"/>
  <!-- Roman Numeral Hour Ticks -->
  <line x1="64" y1="34" x2="64" y2="40" stroke="#38BDF8" stroke-width="2"/>
  <line x1="64" y1="92" x2="64" y2="98" stroke="#38BDF8" stroke-width="2"/>
  <line x1="34" y1="66" x2="40" y2="66" stroke="#38BDF8" stroke-width="2"/>
  <line x1="92" y1="66" x2="98" y2="66" stroke="#38BDF8" stroke-width="2"/>
  <!-- Reverse Gear Hands & Chronal Spiral -->
  <path d="M64 66L50 52" stroke="#FEF08A" stroke-width="2.5" stroke-linecap="round"/>
  <path d="M64 66L78 48" stroke="#38BDF8" stroke-width="2" stroke-linecap="round"/>
  <path d="M50 44C58 38 72 38 80 46" fill="none" stroke="#B78FF5" stroke-width="2" stroke-linecap="round" marker-end="url(#arrow)"/>
  <circle cx="64" cy="66" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['arcane_convergence'] = {
  palette: P_MAGE,
  comment: 'Arcane Convergence: Triad of Power Crystals Channeling into Central Nexus',
  svg: `
  <!-- Three Converging Prisms -->
  <polygon points="64,20 70,36 58,36" fill="#B78FF5" stroke="#38BDF8" stroke-width="1.5"/>
  <polygon points="26,88 38,76 44,88" fill="#B78FF5" stroke="#38BDF8" stroke-width="1.5"/>
  <polygon points="102,88 90,76 84,88" fill="#B78FF5" stroke="#38BDF8" stroke-width="1.5"/>
  <!-- Channeling Laser Beams -->
  <line x1="64" y1="36" x2="64" y2="64" stroke="#38BDF8" stroke-width="2.5"/>
  <line x1="40" y1="82" x2="64" y2="64" stroke="#38BDF8" stroke-width="2.5"/>
  <line x1="88" y1="82" x2="64" y2="64" stroke="#38BDF8" stroke-width="2.5"/>
  <!-- Central Blazing Nexus -->
  <circle cx="64" cy="64" r="16" fill="#8752DE" opacity="0.6"/>
  <circle cx="64" cy="64" r="9" fill="#FEF08A"/>
  `
};

CORE_ICONS['rift_collapse'] = {
  palette: P_MAGE,
  comment: 'Rift Collapse: Planar Seam Rupturing with Exploding Flame Nova Fragments',
  svg: `
  <!-- Opposing Planar Compression Plates -->
  <polygon points="20,40 54,64 20,88" fill="#1C142A" stroke="#8752DE" stroke-width="2"/>
  <polygon points="108,40 74,64 108,88" fill="#1C142A" stroke="#8752DE" stroke-width="2"/>
  <!-- Collapsing Center Rupture Core -->
  <polygon points="64,28 72,56 94,64 72,72 64,100 56,72 34,64 56,56" fill="#F97316"/>
  <circle cx="64" cy="64" r="10" fill="#FEF08A"/>
  <!-- Exploding Fire Fragments -->
  <polygon points="48,42 54,38 50,46" fill="#F59E0B"/>
  <polygon points="80,42 84,36 86,46" fill="#F59E0B"/>
  <polygon points="46,84 52,88 48,92" fill="#F59E0B"/>
  <polygon points="82,84 86,90 80,92" fill="#F59E0B"/>
  `
};

CORE_ICONS['astral_overload'] = {
  palette: P_MAGE,
  comment: 'Astral Overload: Overloaded Conduit Orb Discharging Lightning Bolts',
  svg: `
  <!-- Overloaded Central Focus Orb -->
  <circle cx="64" cy="64" r="22" fill="#1C142A" stroke="#B78FF5" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="12" fill="#38BDF8"/>
  <circle cx="64" cy="64" r="5" fill="#FFFFFF"/>
  <!-- Branching Astral Lightning Bolts -->
  <path d="M64 42L60 28L68 28L64 14" stroke="#38BDF8" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M86 64L100 60L100 68L114 64" stroke="#38BDF8" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M64 86L68 100L60 100L64 114" stroke="#38BDF8" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M42 64L28 68L28 60L14 64" stroke="#38BDF8" stroke-width="2.4" stroke-linecap="round"/>
  <line x1="48" y1="48" x2="28" y2="28" stroke="#FEF08A" stroke-width="2"/>
  <line x1="80" y1="48" x2="100" y2="28" stroke="#FEF08A" stroke-width="2"/>
  <line x1="80" y1="80" x2="100" y2="100" stroke="#FEF08A" stroke-width="2"/>
  <line x1="48" y1="80" x2="28" y2="100" stroke="#FEF08A" stroke-width="2"/>
  `
};

CORE_ICONS['reality_fracture'] = {
  palette: P_MAGE,
  comment: 'Reality Fracture: Cataclysmic Chasm Tearing Space Fabric Apart',
  svg: `
  <!-- Broken Reality Plates Left and Right -->
  <path d="M18 20L58 20L48 50L64 64L50 82L62 108L18 108Z" fill="#170F24" stroke="#8752DE" stroke-width="2"/>
  <path d="M110 20L70 20L78 48L64 64L76 80L66 108L110 108Z" fill="#170F24" stroke="#8752DE" stroke-width="2"/>
  <!-- Deep Astral Void Chasm Revealed Inside -->
  <path d="M58 20L48 50L64 64L50 82L62 108L66 108L76 80L64 64L78 48L70 20Z" fill="#040208"/>
  <circle cx="64" cy="64" r="7" fill="#FEF08A"/>
  <!-- Dimensional Tear Spark Points -->
  <line x1="48" y1="50" x2="78" y2="48" stroke="#38BDF8" stroke-width="2.5"/>
  <line x1="50" y1="82" x2="76" y2="80" stroke="#38BDF8" stroke-width="2.5"/>
  `
};

// ==========================================
// ROGUE (12)
// ==========================================

CORE_ICONS['quickdraw'] = {
  palette: P_ROGUE,
  comment: 'Quickdraw: Hand-Crossbow Snapping from Holster with High-Speed Bolt Tracer',
  svg: `
  <!-- Hand-Crossbow Frame -->
  <path d="M38 78L78 42L86 50L46 86Z" fill="#243038" stroke="#38BDF8" stroke-width="2"/>
  <path d="M68 28C76 44 86 54 102 62" fill="none" stroke="#785A3C" stroke-width="3" stroke-linecap="round"/>
  <!-- Crossbow String -->
  <line x1="68" y1="28" x2="78" y2="42" stroke="#94A3B8" stroke-width="1.8"/>
  <line x1="102" y1="62" x2="86" y2="50" stroke="#94A3B8" stroke-width="1.8"/>
  <!-- Fired Bolt Speed Streak -->
  <line x1="82" y1="46" x2="114" y2="18" stroke="#FACC15" stroke-width="3" stroke-linecap="round"/>
  <polygon points="114,18 106,20 112,26" fill="#FACC15"/>
  <line x1="68" y1="60" x2="94" y2="36" stroke="#38BDF8" stroke-width="1.5" stroke-dasharray="4 3"/>
  `
};

CORE_ICONS['shadow_veil'] = {
  palette: P_ROGUE,
  comment: 'Shadow Veil: Hooded Assassin Mask in Mist with Glowing Eyes',
  svg: `
  <!-- Assassin Cowl / Hood -->
  <path d="M36 86C34 50 44 26 64 26C84 26 94 50 92 86C80 92 64 96 64 96C64 96 48 92 36 86Z" fill="#0E1317" stroke="#334155" stroke-width="2.5"/>
  <!-- Shrouded Shadow Face Opening -->
  <path d="M46 54C54 44 74 44 82 54C80 74 64 78 64 78C64 78 48 74 46 54Z" fill="#040608"/>
  <!-- Piercing Glowing Rogue Eyes -->
  <ellipse cx="54" cy="58" rx="4.5" ry="2" fill="#4ADE80"/>
  <ellipse cx="74" cy="58" rx="4.5" ry="2" fill="#4ADE80"/>
  <!-- Swirling Darkness Tendrils -->
  <path d="M24 96C38 88 52 98 64 92C76 98 90 88 104 96" fill="none" stroke="#22C55E" stroke-width="2" stroke-linecap="round"/>
  `
};

CORE_ICONS['mark_for_death'] = {
  palette: P_ROGUE,
  comment: 'Mark for Death: Crimson Skull with Target Reticle Crosshairs',
  svg: `
  <!-- Stylized Death Skull -->
  <path d="M42 46C42 32 52 24 64 24C76 24 86 32 86 46C86 58 80 66 76 72H52C48 66 42 58 42 46Z" fill="#15191E" stroke="#EF4444" stroke-width="2"/>
  <rect x="52" y="72" width="24" height="12" fill="#15191E" stroke="#EF4444" stroke-width="2"/>
  <!-- Eye Sockets -->
  <circle cx="53" cy="48" r="6" fill="#0B0E12"/>
  <circle cx="75" cy="48" r="6" fill="#0B0E12"/>
  <!-- Sniper Crosshairs Focused on Forehead -->
  <circle cx="64" cy="38" r="14" fill="none" stroke="#EF4444" stroke-width="2"/>
  <line x1="64" y1="20" x2="64" y2="56" stroke="#EF4444" stroke-width="2"/>
  <line x1="46" y1="38" x2="82" y2="38" stroke="#EF4444" stroke-width="2"/>
  <circle cx="64" cy="38" r="3" fill="#EF4444"/>
  `
};

CORE_ICONS['tripwire'] = {
  palette: P_ROGUE,
  comment: 'Tripwire: Taut Steel Wire Anchored to Iron Stakes with Bear Jaw Trap',
  svg: `
  <!-- Two Ground Peg Stakes -->
  <path d="M22 68L28 86H20Z" fill="#475569" stroke="#94A3B8" stroke-width="1.5"/>
  <path d="M106 68L112 86H104Z" fill="#475569" stroke="#94A3B8" stroke-width="1.5"/>
  <!-- Taut Wire Line -->
  <line x1="25" y1="72" x2="109" y2="72" stroke="#94A3B8" stroke-width="2.5"/>
  <!-- Serrated Spring Jaw Mechanism in Center -->
  <path d="M46 72C46 54 82 54 82 72" fill="none" stroke="#EF4444" stroke-width="3"/>
  <!-- Serrated Teeth -->
  <polygon points="52,72 55,64 58,72" fill="#FACC15"/>
  <polygon points="62,72 65,64 68,72" fill="#FACC15"/>
  <polygon points="72,72 75,64 78,72" fill="#FACC15"/>
  <!-- Spring Coils -->
  <circle cx="64" cy="80" r="6" fill="none" stroke="#94A3B8" stroke-width="2"/>
  `
};

CORE_ICONS['smoke_escape'] = {
  palette: P_ROGUE,
  comment: 'Smoke Escape: Ceramic Smoke Canister with Billowing Fog & Leap Silhouette',
  svg: `
  <!-- Exploding Smoke Canister -->
  <rect x="56" y="80" width="16" height="24" rx="4" fill="#334155" stroke="#94A3B8" stroke-width="2"/>
  <circle cx="64" cy="76" r="3" fill="#FACC15"/>
  <!-- Billowing Volumetric Smoke Puffs -->
  <circle cx="44" cy="62" r="18" fill="#1E293B" stroke="#64748B" stroke-width="2" opacity="0.8"/>
  <circle cx="84" cy="62" r="18" fill="#1E293B" stroke="#64748B" stroke-width="2" opacity="0.8"/>
  <circle cx="64" cy="46" r="22" fill="#334155" stroke="#94A3B8" stroke-width="2" opacity="0.9"/>
  <!-- Vaulting Silhouette Through Smoke -->
  <path d="M58 40L64 26L72 38L66 48Z" fill="#38BDF8"/>
  `
};

CORE_ICONS['pickpocket'] = {
  palette: P_ROGUE,
  comment: 'Pickpocket: Sleight-of-hand Gloved Fingers Snatching Gold Coins from Belt Pouch',
  svg: `
  <!-- Leather Belt Pouch -->
  <path d="M44 56C44 50 84 50 84 56L80 96C80 102 48 102 48 96Z" fill="#1F2937" stroke="#785A3C" stroke-width="2.5"/>
  <path d="M42 56H86V64H42Z" fill="#374151"/>
  <!-- Gold Coins Spilling / Snapped -->
  <circle cx="58" cy="42" r="8" fill="#F59E0B" stroke="#FEF08A" stroke-width="2"/>
  <circle cx="70" cy="36" r="8" fill="#F59E0B" stroke="#FEF08A" stroke-width="2"/>
  <!-- Sleight of Hand Fingers -->
  <path d="M74 22L84 34L76 40L68 28Z" fill="#111827" stroke="#38BDF8" stroke-width="1.8"/>
  <path d="M82 28L92 40L84 46L76 34Z" fill="#111827" stroke="#38BDF8" stroke-width="1.8"/>
  `
};

CORE_ICONS['false_opening'] = {
  palette: P_ROGUE,
  comment: 'False Opening: Deceptive Guard Stance with Concealed Forearm Stiletto',
  svg: `
  <!-- Relaxed High Dueling Blade -->
  <line x1="32" y1="26" x2="84" y2="78" stroke="#64748B" stroke-width="3" stroke-linecap="round"/>
  <!-- Concealed Low Stiletto Forearm Thrust -->
  <path d="M46 94L86 64L92 70L52 100Z" fill="#0F172A" stroke="#38BDF8" stroke-width="2"/>
  <polygon points="86,64 104,50 92,70" fill="#38BDF8"/>
  <!-- Deceptive Feint Arcs -->
  <path d="M38 48C52 40 68 44 76 56" fill="none" stroke="#FACC15" stroke-width="2" stroke-dasharray="4 3"/>
  <circle cx="86" cy="64" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['poisoned_edge'] = {
  palette: P_ROGUE,
  comment: 'Poisoned Edge: Serrated Dagger Dripping Viscous Emerald Toxic Venom',
  svg: `
  <!-- Serrated Toxic Dagger -->
  <path d="M32 96L72 40L82 30L90 38L80 48L68 52L62 64L50 68L44 80Z" fill="#1E293B" stroke="#22C55E" stroke-width="2"/>
  <line x1="26" y1="102" x2="38" y2="90" stroke="#785A3C" stroke-width="4" stroke-linecap="round"/>
  <!-- Venom Coating Glow -->
  <path d="M72 40L82 30L90 38L80 48" fill="#4ADE80"/>
  <!-- Dripping Venom Droplets -->
  <circle cx="94" cy="50" r="3.5" fill="#4ADE80"/>
  <circle cx="102" cy="66" r="4.5" fill="#22C55E"/>
  <path d="M96 86C96 82 104 82 104 86C104 90 96 90 96 86Z" fill="#4ADE80"/>
  `
};

CORE_ICONS['evasive_roll'] = {
  palette: P_ROGUE,
  comment: 'Evasive Roll: Acrobatic Tumbling Arc over Dangerous Ground Caltrops',
  svg: `
  <!-- Dynamic 360 Degree Tumble Spiral Arc -->
  <path d="M30 84C30 50 50 32 74 32C94 32 106 48 102 72C98 90 80 96 66 94" fill="none" stroke="#38BDF8" stroke-width="3" stroke-linecap="round"/>
  <polygon points="66,94 76,90 74,99" fill="#38BDF8"/>
  <!-- Tucking Acrobat Silhouette -->
  <circle cx="64" cy="54" r="12" fill="#0F172A" stroke="#4ADE80" stroke-width="2"/>
  <path d="M56 64C56 74 68 78 76 72" fill="none" stroke="#4ADE80" stroke-width="2.5"/>
  <!-- Caltrops On Floor Avoided -->
  <polygon points="34,98 38,90 42,98" fill="#64748B"/>
  <polygon points="86,98 90,90 94,98" fill="#64748B"/>
  `
};

CORE_ICONS['ambush_protocol'] = {
  palette: P_ROGUE,
  comment: 'Ambush Protocol: Striking from High Rafters with Twin Daggers',
  svg: `
  <!-- Wooden Overhead Rafter Beam -->
  <rect x="18" y="22" width="92" height="12" fill="#271E17" stroke="#785A3C" stroke-width="1.8"/>
  <!-- Shadow Silhouette Dropping Down -->
  <path d="M64 34L58 48L70 48Z" fill="#0F172A"/>
  <!-- Twin Downward Plunging Daggers -->
  <path d="M50 52L46 86L54 86Z" fill="#38BDF8" stroke="#94A3B8" stroke-width="1.5"/>
  <path d="M78 52L74 86L82 86Z" fill="#38BDF8" stroke="#94A3B8" stroke-width="1.5"/>
  <!-- Target Reticle On Ground -->
  <ellipse cx="64" cy="98" rx="28" ry="10" fill="none" stroke="#EF4444" stroke-width="2"/>
  <line x1="64" y1="84" x2="64" y2="112" stroke="#EF4444" stroke-width="2"/>
  `
};

CORE_ICONS['shadow_exchange'] = {
  palette: P_ROGUE,
  comment: 'Shadow Exchange: Inverted Dual Silhouettes Linked by Infinity Energy Loop',
  svg: `
  <!-- Upright Shadow Silhouette -->
  <circle cx="44" cy="44" r="8" fill="#38BDF8"/>
  <path d="M36 68C36 56 44 54 44 54C44 54 52 56 52 68Z" fill="#38BDF8"/>
  <!-- Inverted Shadow Silhouette -->
  <circle cx="84" cy="84" r="8" fill="#64748B"/>
  <path d="M76 60C76 72 84 74 84 74C84 74 92 72 92 60Z" fill="#64748B"/>
  <!-- Interconnecting Infinity Loop -->
  <path d="M44 64C44 76 84 52 84 64C84 76 44 52 44 64Z" fill="none" stroke="#A855F7" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['perfect_execution'] = {
  palette: P_ROGUE,
  comment: 'Perfect Execution: Dual Crossed Guillotine Daggers Severing Vital Cord',
  svg: `
  <!-- Crossing Executioner Blades in Scissor Cut -->
  <path d="M26 32L94 92L102 84L34 24Z" fill="#1E293B" stroke="#DC2626" stroke-width="2"/>
  <path d="M102 32L34 92L26 84L94 24Z" fill="#1E293B" stroke="#DC2626" stroke-width="2"/>
  <!-- Center Sever Point Flash -->
  <polygon points="64,48 68,60 80,64 68,68 64,80 60,68 48,64 60,60" fill="#FEF08A"/>
  <!-- Severed Cord Halves -->
  <line x1="64" y1="20" x2="64" y2="52" stroke="#F59E0B" stroke-width="3" stroke-linecap="round"/>
  <line x1="64" y1="76" x2="64" y2="108" stroke="#F59E0B" stroke-width="3" stroke-linecap="round"/>
  <circle cx="64" cy="64" r="6" fill="#DC2626"/>
  `
};

// ==========================================
// PALADIN (12)
// ==========================================

CORE_ICONS['consecrated_strike'] = {
  palette: P_PALADIN,
  comment: 'Consecrated Strike: Flanged Golden Warhammer Striking with Solar Cross Flames',
  svg: `
  <!-- Heavy Flanged Warhammer Head -->
  <rect x="42" y="36" width="44" height="26" rx="4" fill="#2B1F12" stroke="#F59E0B" stroke-width="2.5"/>
  <polygon points="42,36 34,49 42,62" fill="#FDE047"/>
  <polygon points="86,36 94,49 86,62" fill="#FDE047"/>
  <line x1="64" y1="62" x2="64" y2="114" stroke="#785A3C" stroke-width="3.5" stroke-linecap="round"/>
  <!-- Solar Cross Erupting from Strike -->
  <line x1="64" y1="16" x2="64" y2="36" stroke="#FEF08A" stroke-width="3"/>
  <line x1="18" y1="49" x2="34" y2="49" stroke="#FEF08A" stroke-width="3"/>
  <line x1="94" y1="49" x2="110" y2="49" stroke="#FEF08A" stroke-width="3"/>
  <circle cx="64" cy="49" r="6" fill="#FEF08A"/>
  `
};

CORE_ICONS['oathward'] = {
  palette: P_PALADIN,
  comment: 'Oathward: Radiant Kite Shield with Eye of the Dawn and Protective Wings',
  svg: `
  <!-- Towering Kite Shield -->
  <path d="M34 26C64 22 64 22 94 26C96 66 82 98 64 110C46 98 32 66 34 26Z" fill="#1F170C" stroke="#F59E0B" stroke-width="3"/>
  <!-- Protective Heraldic Wings -->
  <path d="M42 42C52 46 60 56 60 70C50 70 42 60 42 42Z" fill="#8A7038"/>
  <path d="M86 42C76 46 68 56 68 70C78 70 86 60 86 42Z" fill="#8A7038"/>
  <!-- All-Seeing Eye of Dawn -->
  <path d="M46 54C54 46 74 46 82 54C74 62 54 62 46 54Z" fill="#F59E0B" stroke="#FDE047" stroke-width="1.8"/>
  <circle cx="64" cy="54" r="4.5" fill="#FEF08A"/>
  `
};

CORE_ICONS['sanctuary_ring'] = {
  palette: P_PALADIN,
  comment: 'Sanctuary Ring: Cathedral Rose Window Solar Mandala with Prayer Glyphs',
  svg: `
  <!-- Concentric Cathedral Sacred Halos -->
  <circle cx="64" cy="64" r="44" fill="none" stroke="#F59E0B" stroke-width="2"/>
  <circle cx="64" cy="64" r="34" fill="#1C1409" stroke="#FDE047" stroke-width="1.8"/>
  <circle cx="64" cy="64" r="16" fill="#2C2010" stroke="#F59E0B" stroke-width="2"/>
  <!-- Four Cardinal Prayer Runes -->
  <polygon points="64,22 68,30 64,34 60,30" fill="#FEF08A"/>
  <polygon points="64,106 68,98 64,94 60,98" fill="#FEF08A"/>
  <polygon points="22,64 30,68 34,64 30,60" fill="#FEF08A"/>
  <polygon points="106,64 98,68 94,64 98,60" fill="#FEF08A"/>
  <circle cx="64" cy="64" r="6" fill="#FEF08A"/>
  `
};

CORE_ICONS['judgment_mark'] = {
  palette: P_PALADIN,
  comment: 'Judgment Mark: Judicial Scales Suspended from Radiant Flaming Sword',
  svg: `
  <!-- Central Flaming Sword of Justice -->
  <line x1="64" y1="18" x2="64" y2="108" stroke="#F59E0B" stroke-width="3" stroke-linecap="round"/>
  <polygon points="64,14 69,28 59,28" fill="#FEF08A"/>
  <line x1="48" y1="36" x2="80" y2="36" stroke="#FDE047" stroke-width="3"/>
  <!-- Suspended Balance Scales -->
  <line x1="36" y1="46" x2="92" y2="46" stroke="#8A7038" stroke-width="2"/>
  <path d="M26 68C26 76 46 76 46 68Z" fill="#2C2010" stroke="#F59E0B" stroke-width="1.8"/>
  <path d="M82 68C82 76 102 76 102 68Z" fill="#2C2010" stroke="#F59E0B" stroke-width="1.8"/>
  <line x1="36" y1="46" x2="28" y2="68" stroke="#8A7038" stroke-width="1.2"/>
  <line x1="36" y1="46" x2="44" y2="68" stroke="#8A7038" stroke-width="1.2"/>
  <line x1="92" y1="46" x2="84" y2="68" stroke="#8A7038" stroke-width="1.2"/>
  <line x1="92" y1="46" x2="100" y2="68" stroke="#8A7038" stroke-width="1.2"/>
  `
};

CORE_ICONS['radiant_mend'] = {
  palette: P_PALADIN,
  comment: 'Radiant Mend: Cupped Gauntlets Cradling a Blossoming Sacred Golden Lotus',
  svg: `
  <!-- Cupped Holy Gauntlets -->
  <path d="M38 78C38 90 54 98 64 98C74 98 90 90 90 78C80 84 64 86 64 86C64 86 48 84 38 78Z" fill="#2C2010" stroke="#F59E0B" stroke-width="2"/>
  <!-- Blossoming Sacred Lotus Petals -->
  <path d="M64 40C60 52 50 68 64 78C78 68 68 52 64 40Z" fill="#FEF08A" stroke="#F59E0B" stroke-width="1.8"/>
  <path d="M48 54C48 64 54 74 64 78C56 70 54 58 48 54Z" fill="#FDE047"/>
  <path d="M80 54C80 64 74 74 64 78C72 70 74 58 80 54Z" fill="#FDE047"/>
  <!-- Radiant Dawn Healing Rays -->
  <line x1="64" y1="36" x2="64" y2="22" stroke="#FEF08A" stroke-width="2"/>
  <line x1="50" y1="42" x2="40" y2="32" stroke="#FEF08A" stroke-width="2"/>
  <line x1="78" y1="42" x2="88" y2="32" stroke="#FEF08A" stroke-width="2"/>
  `
};

CORE_ICONS['shield_of_conviction'] = {
  palette: P_PALADIN,
  comment: 'Shield of Conviction: Lion Tower Shield Driving Forward with Shockwaves',
  svg: `
  <!-- Massive Tower Shield -->
  <path d="M36 24H92V84L64 106L36 84Z" fill="#241B0E" stroke="#F59E0B" stroke-width="2.8"/>
  <!-- Roaring Lion Emblem -->
  <circle cx="64" cy="54" r="16" fill="#181108" stroke="#FDE047" stroke-width="2"/>
  <polygon points="60,50 68,50 64,58" fill="#F59E0B"/>
  <polygon points="56,44 60,40 62,46" fill="#FDE047"/>
  <polygon points="72,44 68,40 66,46" fill="#FDE047"/>
  <!-- Concussive Shock Arcs -->
  <path d="M102 36C112 50 112 78 102 92" fill="none" stroke="#F59E0B" stroke-width="3" stroke-linecap="round"/>
  <path d="M112 46C120 58 120 70 112 82" fill="none" stroke="#FEF08A" stroke-width="2" stroke-linecap="round"/>
  `
};

CORE_ICONS['oath_of_restraint'] = {
  palette: P_PALADIN,
  comment: 'Oath of Restraint: Spectral Golden Chains Binding Demonic Talon with Padlock',
  svg: `
  <!-- Demonic Talon Outline -->
  <path d="M48 94L54 60L46 42M64 94L64 56L64 36M80 94L74 60L82 42" stroke="#4B3A2C" stroke-width="4" stroke-linecap="round"/>
  <!-- Wrapping Celestial Golden Chains -->
  <path d="M34 68C48 60 80 60 94 68C80 76 48 76 34 68Z" fill="none" stroke="#F59E0B" stroke-width="3"/>
  <path d="M38 52C50 46 78 46 90 52C78 58 50 58 38 52Z" fill="none" stroke="#F59E0B" stroke-width="2.5"/>
  <!-- Sacred Cruciform Padlock -->
  <rect x="56" y="68" width="16" height="18" rx="3" fill="#FDE047" stroke="#8A7038" stroke-width="1.8"/>
  <path d="M60 68V62C60 58 68 58 68 62V68" fill="none" stroke="#8A7038" stroke-width="2"/>
  <circle cx="64" cy="76" r="2" fill="#2C2010"/>
  `
};

CORE_ICONS['sacred_ground'] = {
  palette: P_PALADIN,
  comment: 'Sacred Ground: 5-Tile Solar Cross Consecrated in Stone Pavement',
  svg: `
  <!-- Stone Flagstone Base Grid -->
  <rect x="24" y="24" width="80" height="80" rx="4" fill="#19130A" stroke="#785A3C" stroke-width="2"/>
  <!-- Radiant 5-Tile Solar Cross -->
  <rect x="52" y="28" width="24" height="72" fill="#F59E0B" opacity="0.8"/>
  <rect x="28" y="52" width="72" height="24" fill="#F59E0B" opacity="0.8"/>
  <!-- Inner Holy Sun Core -->
  <rect x="52" y="52" width="24" height="24" fill="#FEF08A"/>
  <circle cx="64" cy="64" r="8" fill="#F59E0B"/>
  <!-- Rising Consecration Sparkles -->
  <circle cx="40" cy="40" r="2.5" fill="#FEF08A"/>
  <circle cx="88" cy="40" r="2.5" fill="#FEF08A"/>
  <circle cx="40" cy="88" r="2.5" fill="#FEF08A"/>
  <circle cx="88" cy="88" r="2.5" fill="#FEF08A"/>
  `
};

CORE_ICONS['burden_of_sin'] = {
  palette: P_PALADIN,
  comment: 'Burden of Sin: Heavy Commandments Stone Tablet with Crushing Gravity Rays',
  svg: `
  <!-- Two Arched Stone Tablets of the Law -->
  <path d="M34 94V42C34 34 46 34 46 42V94Z" fill="#261E14" stroke="#8A7038" stroke-width="2"/>
  <path d="M48 94V42C48 34 60 34 60 42V94Z" fill="#261E14" stroke="#8A7038" stroke-width="2"/>
  <!-- Inscribed Sacred Commandment Lines -->
  <line x1="38" y1="52" x2="42" y2="52" stroke="#FDE047" stroke-width="1.5"/>
  <line x1="38" y1="62" x2="42" y2="62" stroke="#FDE047" stroke-width="1.5"/>
  <line x1="52" y1="52" x2="56" y2="52" stroke="#FDE047" stroke-width="1.5"/>
  <line x1="52" y1="62" x2="56" y2="62" stroke="#FDE047" stroke-width="1.5"/>
  <!-- Downward Crushing Gravity Beams -->
  <line x1="78" y1="26" x2="78" y2="86" stroke="#F59E0B" stroke-width="3" stroke-linecap="round"/>
  <polygon points="78,92 73,82 83,82" fill="#F59E0B"/>
  <line x1="92" y1="36" x2="92" y2="86" stroke="#FEF08A" stroke-width="2.5" stroke-linecap="round"/>
  <polygon points="92,92 88,84 96,84" fill="#FEF08A"/>
  `
};

CORE_ICONS['beacon_of_hope'] = {
  palette: P_PALADIN,
  comment: 'Beacon of Hope: Fortress Citadel Brazier with Eternal Holy Flame',
  svg: `
  <!-- Tower Citadel Spire -->
  <path d="M50 106L56 56H72L78 106Z" fill="#20180D" stroke="#8A7038" stroke-width="2"/>
  <!-- Brazier Cauldron Head -->
  <path d="M42 56C42 66 86 66 86 56L82 48H46Z" fill="#8A7038" stroke="#F59E0B" stroke-width="2"/>
  <!-- Towering Eternal Holy Fire -->
  <path d="M64 16C58 28 50 36 64 48C78 36 70 28 64 16Z" fill="#FEF08A" stroke="#F59E0B" stroke-width="2"/>
  <circle cx="64" cy="38" r="5" fill="#FEF08A"/>
  <!-- Guiding Dawn Star Rays -->
  <line x1="64" y1="12" x2="64" y2="4" stroke="#FDE047" stroke-width="2"/>
  <line x1="42" y1="28" x2="34" y2="22" stroke="#FDE047" stroke-width="2"/>
  <line x1="86" y1="28" x2="94" y2="22" stroke="#FDE047" stroke-width="2"/>
  `
};

CORE_ICONS['divine_intercession'] = {
  palette: P_PALADIN,
  comment: 'Divine Intercession: Angelic Wing Intercepting a Demonic Spear',
  svg: `
  <!-- Sweeping Angelic Heraldic Wing -->
  <path d="M32 94C32 60 48 30 90 26C84 44 76 60 88 78C74 76 64 68 58 84C50 82 42 86 32 94Z" fill="#3D2D15" stroke="#F59E0B" stroke-width="2.5"/>
  <path d="M48 88C50 68 62 46 88 34" fill="none" stroke="#FDE047" stroke-width="2"/>
  <!-- Blocked Demonic Spear Tip Shattering -->
  <path d="M106 38L84 48L98 56Z" fill="#1C140A" stroke="#DC2626" stroke-width="1.8"/>
  <polygon points="84,48 76,42 78,52" fill="#FEF08A"/>
  <line x1="84" y1="48" x2="94" y2="38" stroke="#FEF08A" stroke-width="2"/>
  `
};

CORE_ICONS['final_judgment'] = {
  palette: P_PALADIN,
  comment: 'Final Judgment: Colossal Vertical Celestial Light Pillar Descending onto Broken Stone',
  svg: `
  <!-- Shattered Ground Flagstones -->
  <path d="M18 102H110L98 114H30Z" fill="#1C140A" stroke="#8A7038" stroke-width="2"/>
  <!-- Colossal Descending Celestial Pillar -->
  <rect x="48" y="16" width="32" height="88" fill="#F59E0B" opacity="0.8"/>
  <rect x="56" y="16" width="16" height="88" fill="#FEF08A"/>
  <!-- Blinding Impact Crest Shockwaves -->
  <ellipse cx="64" cy="102" rx="42" ry="10" fill="none" stroke="#FEF08A" stroke-width="3"/>
  <ellipse cx="64" cy="102" rx="26" ry="6" fill="#FFFFFF"/>
  <!-- Heavenly Beams -->
  <line x1="36" y1="16" x2="48" y2="102" stroke="#FDE047" stroke-width="1.8"/>
  <line x1="92" y1="16" x2="80" y2="102" stroke="#FDE047" stroke-width="1.8"/>
  `
};

// ==========================================
// RANGER (12)
// ==========================================

CORE_ICONS['precision_shot'] = {
  palette: P_RANGER,
  comment: 'Precision Shot: Full Drawn Recurve Bow with Telescopic Reticle',
  svg: `
  <!-- Drawn Recurve Bow Stave -->
  <path d="M38 24C62 42 62 86 38 104" fill="none" stroke="#785A3C" stroke-width="4" stroke-linecap="round"/>
  <!-- Drawn Bowstring Pulled Back -->
  <line x1="38" y1="24" x2="78" y2="64" stroke="#E2E8F0" stroke-width="1.8"/>
  <line x1="38" y1="104" x2="78" y2="64" stroke="#E2E8F0" stroke-width="1.8"/>
  <!-- Notched Arrow Aimed Forward -->
  <line x1="78" y1="64" x2="18" y2="64" stroke="#84CC16" stroke-width="3" stroke-linecap="round"/>
  <polygon points="18,64 26,58 26,70" fill="#84CC16"/>
  <!-- Telescopic Aiming Crosshairs on Arrowhead -->
  <circle cx="22" cy="64" r="14" fill="none" stroke="#22C55E" stroke-width="2"/>
  <line x1="22" y1="46" x2="22" y2="82" stroke="#22C55E" stroke-width="1.5"/>
  <line x1="4" y1="64" x2="40" y2="64" stroke="#22C55E" stroke-width="1.5"/>
  `
};

CORE_ICONS['hunters_instinct'] = {
  palette: P_RANGER,
  comment: 'Hunters Instinct: Keen Hawk/Wolf Eye Analyzing Beast Pawprints',
  svg: `
  <!-- Predatory Hawk / Wolf Eye Contour -->
  <path d="M26 64C42 42 86 42 102 64C86 86 42 86 26 64Z" fill="#132216" stroke="#65A30D" stroke-width="2.5"/>
  <!-- Amber Iris & Slit Pupil -->
  <circle cx="64" cy="64" r="18" fill="#F59E0B" stroke="#FEF08A" stroke-width="2"/>
  <ellipse cx="64" cy="64" rx="5" ry="14" fill="#0A110D"/>
  <!-- Tracked Pawprint Glyph -->
  <circle cx="98" cy="38" r="4" fill="#84CC16"/>
  <circle cx="90" cy="32" r="2.5" fill="#84CC16"/>
  <circle cx="98" cy="28" r="2.5" fill="#84CC16"/>
  <circle cx="106" cy="32" r="2.5" fill="#84CC16"/>
  `
};

CORE_ICONS['pinning_arrow'] = {
  palette: P_RANGER,
  comment: 'Pinning Arrow: Heavy Bodkin Arrow Impaling Ground and Iron Leg Shackle',
  svg: `
  <!-- Heavy Bodkin Arrow Plunged Downward -->
  <line x1="88" y1="20" x2="48" y2="86" stroke="#785A3C" stroke-width="3.5" stroke-linecap="round"/>
  <polygon points="48,86 42,96 56,92" fill="#94A3B8" stroke="#475569" stroke-width="1.5"/>
  <!-- Feather Fletching -->
  <polygon points="88,20 80,18 84,28" fill="#84CC16"/>
  <polygon points="88,20 96,28 86,30" fill="#84CC16"/>
  <!-- Pinned Iron Shackle Ring & Chain -->
  <circle cx="48" cy="90" r="14" fill="none" stroke="#64748B" stroke-width="3"/>
  <path d="M38 98C32 104 22 102 18 108" fill="none" stroke="#475569" stroke-width="2.5"/>
  <circle cx="48" cy="90" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['hunting_ground'] = {
  palette: P_RANGER,
  comment: 'Hunting Ground: Crossed Totem Stakes and Feathers Marking Killzone',
  svg: `
  <!-- Crossed Totem Survey Stakes -->
  <line x1="34" y1="28" x2="94" y2="100" stroke="#785A3C" stroke-width="3.5" stroke-linecap="round"/>
  <line x1="94" y1="28" x2="34" y2="100" stroke="#785A3C" stroke-width="3.5" stroke-linecap="round"/>
  <!-- Totemic Warning Feathers -->
  <path d="M64 42C56 34 56 22 64 14C72 22 72 34 64 42Z" fill="#84CC16" stroke="#446648" stroke-width="1.5"/>
  <!-- Wolf Head Killzone Sigil in Center -->
  <polygon points="64,52 74,68 64,80 54,68" fill="#1B2A1E" stroke="#22C55E" stroke-width="2"/>
  <circle cx="64" cy="64" r="3" fill="#FEF08A"/>
  <!-- Perimeter Warning Ring -->
  <circle cx="64" cy="64" r="44" fill="none" stroke="#65A30D" stroke-width="1.8" stroke-dasharray="6 4"/>
  `
};

CORE_ICONS['ricochet_shot'] = {
  palette: P_RANGER,
  comment: 'Ricochet Shot: Arrow Banking Off Steel Pavise and Splitting Trajectories',
  svg: `
  <!-- Angled Steel Deflection Plate -->
  <polygon points="42,42 54,34 76,82 64,90" fill="#334155" stroke="#94A3B8" stroke-width="2"/>
  <!-- Primary Incoming Arrow -->
  <line x1="16" y1="24" x2="52" y2="52" stroke="#84CC16" stroke-width="3" stroke-linecap="round"/>
  <!-- Impact Flash Point -->
  <polygon points="52,52 56,44 60,52 68,54 60,58 58,66 54,58 46,56" fill="#FEF08A"/>
  <!-- Multiple Ricocheting Tracer Vectors -->
  <line x1="56" y1="52" x2="108" y2="34" stroke="#FACC15" stroke-width="2.5" stroke-linecap="round"/>
  <line x1="56" y1="52" x2="112" y2="66" stroke="#FACC15" stroke-width="2.5" stroke-linecap="round"/>
  <line x1="56" y1="52" x2="98" y2="94" stroke="#FACC15" stroke-width="2.5" stroke-linecap="round"/>
  `
};

CORE_ICONS['camouflage'] = {
  palette: P_RANGER,
  comment: 'Camouflage: Hooded Silhouette Blending into Oak Leaves and Forest Bark',
  svg: `
  <!-- Forest Tree Bark Contour Background -->
  <path d="M28 20V108M42 20V108" stroke="#4B3A2C" stroke-width="2.5" stroke-linecap="round"/>
  <!-- Hooded Scout Camouflaged Silhouette -->
  <path d="M46 86C46 54 54 36 68 36C82 36 90 54 90 86Z" fill="#142018" stroke="#65A30D" stroke-width="2"/>
  <!-- Overlapping Oak and Fern Leaves -->
  <path d="M52 48C42 42 42 58 52 64C56 56 60 52 52 48Z" fill="#22C55E"/>
  <path d="M78 44C88 38 88 54 78 60C74 52 70 48 78 44Z" fill="#84CC16"/>
  <path d="M64 68C56 64 56 76 64 82C72 76 72 64 64 68Z" fill="#4ADE80"/>
  `
};

CORE_ICONS['thornline'] = {
  palette: P_RANGER,
  comment: 'Thornline: Intertwined Barricade of Razor Briar Vines and Poison Thorns',
  svg: `
  <!-- Two Thick Intertwining Briar Vines -->
  <path d="M16 64C36 50 54 78 74 64C94 50 112 78 112 64" fill="none" stroke="#2C1F14" stroke-width="5" stroke-linecap="round"/>
  <path d="M16 64C36 78 54 50 74 64C94 78 112 50 112 64" fill="none" stroke="#446648" stroke-width="3.5" stroke-linecap="round"/>
  <!-- Razor Sharp Bramble Thorns -->
  <polygon points="36,54 30,42 42,50" fill="#84CC16"/>
  <polygon points="56,72 50,84 62,76" fill="#84CC16"/>
  <polygon points="74,54 68,42 80,50" fill="#84CC16"/>
  <polygon points="94,72 88,84 100,76" fill="#84CC16"/>
  <polygon points="48,56 52,44 56,54" fill="#FEF08A"/>
  `
};

CORE_ICONS['beast_call'] = {
  palette: P_RANGER,
  comment: 'Beast Call: Bone Hunting Horn with Howling Spirit Timber-Wolf Silhouette',
  svg: `
  <!-- Carved Bone Hunting Horn -->
  <path d="M26 84C42 80 58 64 68 46L76 50C66 70 48 88 28 92Z" fill="#E2E8F0" stroke="#785A3C" stroke-width="2"/>
  <path d="M76 50C82 46 86 38 88 32L66 38C68 44 72 48 76 50Z" fill="#F59E0B"/>
  <!-- Spectral Howling Timber-Wolf Head -->
  <path d="M68 64L82 48L96 54L104 42L106 60L96 74L78 72Z" fill="#152419" stroke="#84CC16" stroke-width="2"/>
  <circle cx="88" cy="56" r="2.5" fill="#FEF08A"/>
  <!-- Resonance Calling Sound Rings -->
  <path d="M96 32C106 40 108 58 98 68" fill="none" stroke="#4ADE80" stroke-width="2" stroke-linecap="round"/>
  `
};

CORE_ICONS['windrunner'] = {
  palette: P_RANGER,
  comment: 'Windrunner: Winged Leather Boots Running with Dynamic Wind Ribbons',
  svg: `
  <!-- Agile Leather Boots in Sprint Stride -->
  <path d="M38 34L54 62L46 78L82 86L86 96H44L34 78L40 50Z" fill="#2C2016" stroke="#65A30D" stroke-width="2.5"/>
  <!-- Heraldic Feather Wings on Ankle -->
  <path d="M36 68C22 60 16 72 14 84C24 82 30 76 36 74Z" fill="#84CC16" stroke="#446648" stroke-width="1.5"/>
  <path d="M42 62C30 52 24 64 22 74C30 72 36 68 42 66Z" fill="#4ADE80"/>
  <!-- Fluid Wind Slipstream Ribbons -->
  <path d="M24 44C44 38 78 44 104 38" fill="none" stroke="#38BDF8" stroke-width="2.5" stroke-linecap="round"/>
  <path d="M48 96C68 90 92 94 114 90" fill="none" stroke="#38BDF8" stroke-width="2" stroke-linecap="round"/>
  `
};

CORE_ICONS['deadfall_trap'] = {
  palette: P_RANGER,
  comment: 'Deadfall Trap: Counterweighted Timber Log with Tensioned Tripwire Trigger',
  svg: `
  <!-- Massive Overhead Suspended Log -->
  <rect x="28" y="28" width="72" height="20" rx="6" fill="#3D2B1D" stroke="#785A3C" stroke-width="2.5"/>
  <line x1="38" y1="28" x2="38" y2="48" stroke="#5A4330" stroke-width="2"/>
  <line x1="88" y1="28" x2="88" y2="48" stroke="#5A4330" stroke-width="2"/>
  <!-- Suspension Support Rope -->
  <line x1="64" y1="14" x2="64" y2="28" stroke="#C27438" stroke-width="2.5"/>
  <!-- Angled Counterweight Trigger Prop -->
  <line x1="38" y1="48" x2="64" y2="92" stroke="#785A3C" stroke-width="3" stroke-linecap="round"/>
  <!-- Tensioned Tripwire Peg -->
  <circle cx="64" cy="94" r="5" fill="#84CC16" stroke="#22C55E" stroke-width="2"/>
  <line x1="64" y1="94" x2="108" y2="94" stroke="#FACC15" stroke-width="1.8" stroke-dasharray="4 3"/>
  `
};

CORE_ICONS['marked_prey'] = {
  palette: P_RANGER,
  comment: 'Marked Prey: Ancient Stag Antlers with Glowing Quarry Crosshairs',
  svg: `
  <!-- Majestic Stag Antlers Silhouette -->
  <path d="M64 92V72M64 72C50 64 36 50 32 30M46 54C38 46 36 38 34 34M54 62C50 52 50 42 48 38" fill="none" stroke="#3D2D1E" stroke-width="3" stroke-linecap="round"/>
  <path d="M64 72C78 64 92 50 96 30M82 54C90 46 92 38 94 34M74 62C78 52 78 42 80 38" fill="none" stroke="#3D2D1E" stroke-width="3" stroke-linecap="round"/>
  <!-- Glowing Green Hunter Quarry Crosshairs -->
  <circle cx="64" cy="52" r="18" fill="none" stroke="#22C55E" stroke-width="2.5"/>
  <line x1="64" y1="30" x2="64" y2="74" stroke="#84CC16" stroke-width="2"/>
  <line x1="42" y1="52" x2="86" y2="52" stroke="#84CC16" stroke-width="2"/>
  <circle cx="64" cy="52" r="4" fill="#FEF08A"/>
  `
};

CORE_ICONS['natures_dominion'] = {
  palette: P_RANGER,
  comment: 'Natures Dominion: Colossal Primordial Tree Trunk with Sprawling Earthen Roots',
  svg: `
  <!-- Primordial Tree Trunk Base -->
  <path d="M52 20C54 44 46 68 34 94M76 20C74 44 82 68 94 94" stroke="#4B3828" stroke-width="5" stroke-linecap="round"/>
  <!-- Ancient Wood Knots and Heart Core -->
  <circle cx="64" cy="52" r="14" fill="#1C140C" stroke="#65A30D" stroke-width="2"/>
  <circle cx="64" cy="52" r="6" fill="#84CC16"/>
  <!-- Sprawling Roots Bursting Through Stone -->
  <path d="M34 94L18 106M46 90L40 108M64 88L64 112M82 90L88 108M94 94L110 106" stroke="#22C55E" stroke-width="3.5" stroke-linecap="round"/>
  <!-- Blossoming Primordial Leaves -->
  <circle cx="48" cy="24" r="5" fill="#84CC16"/>
  <circle cx="80" cy="24" r="5" fill="#84CC16"/>
  <circle cx="64" cy="16" r="6" fill="#4ADE80"/>
  `
};

// Write each icon to public/assets/icons/progression-skills/
let writtenCount = 0;
for (const [id, def] of Object.entries(CORE_ICONS)) {
  const svg = makeIconSvg(id, def.palette, def.svg, def.comment);
  const filePath = path.join(ICONS_DIR, id + '.svg');
  fs.writeFileSync(filePath, svg, 'utf8');
  writtenCount++;
}

console.log('Successfully generated ' + writtenCount + ' distinct core skill icons in ' + ICONS_DIR);
