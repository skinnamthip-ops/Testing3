import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  CompanionId,
  CompanionRelationship,
  CombatUnit,
  GridTile,
  TacticalEnvObject,
  DialogueChoice,
  SkillCheckResult,
  WorldReactivityState,
  DiceRollToastEntry,
  STAGES,
  DIALOGUE_NODES,
  createInitialRelationships,
  createInitialWorldState,
  createEncounterUnits,
  createEncounterObjects,
  generateTacticalGrid,
  getValidMoveTiles,
  resolveAbilityUse,
  resolveEnvironmentalInteraction,
  buildCombatRollToast,
  buildSkillCheckRollToast,
  evaluateTacticalAdvantage,
  computeEnemyTurnAction,
  computeInitiativeRibbonEntries,
  CharacterCreationBuild,
  createDefaultCharacterBuild,
  applyCharacterBuildToParty,
  createWarriorTrialGroundsEncounter,
  resolveWarriorDefensiveReactions,
  createMageTrialGroundsEncounter,
  resolveMageDefensiveReactions,
  isLastStandConditionMet,
  manhattanDistance,
  gridToWorld,
} from './game/rules';
import {
  assignUnitSkillToSlot,
  evaluateSkillSlotState,
  UnitSkillCatalogEntry,
} from './game/skillSystemUi';
import {
  TacticalArena3D,
  ParticleBurstEvent,
  ActiveCombatAnimationEvent,
} from './components/TacticalArena3D';
import {
  CharacterPortraitSvg,
  StatusEffectIconSvg,
  STATUS_EFFECT_META,
} from './components/PortraitsAndIcons';
import { CombatSkillBar } from './components/CombatSkillBar';
import { TacticalSkillMenuModal } from './components/TacticalSkillMenuModal';
import { StartupMenuOverlay } from './components/StartupMenuOverlay';
import {
  SavedAdventureSlot,
  upsertAdventureSaveSlot,
} from './game/saveAdventureSlots';
import { SkillTreeModal } from './components/SkillTreeModal';
import { LevelUpModal } from './components/LevelUpModal';
import {
  CharacterProgressionState,
  createInitialProgressionState,
  sanitizeEquippedSkills,
  normalizePlayableClassKey,
  awardXp,
  applyProgressionToCommander,
  LevelUpResult,
  XP_REWARD_MAIN_QUEST,
  XP_REWARD_SIDE_QUEST,
  XP_REWARD_BOSS_ENEMY,
  CUMULATIVE_XP_TABLE,
} from './game/progressionData';
import { TowerProgressionState } from './game/towerTypes';
import {
  createInitialTowerState,
  buildTowerFloorEncounter,
  completeTowerFloor,
} from './game/towerEngine';
import { ALL_100_TOWER_FLOORS } from './game/towerFloorsData';
import {
  TowerHubModal,
  TowerPostBattleModal,
  TowerBattleResultSummary,
} from './components/TowerHubModal';
import { DialogueModal } from './components/DialogueModal';
import { CompanionCampModal, WorldChronicleModal } from './components/CampAndWorldModals';
import { DiceRollToastOverlay } from './components/DiceRollToastOverlay';
import { UnitInspectPanel } from './components/UnitInspectPanel';
import { soundEngine } from './game/audio';
import { GloamrestSaveState } from './game/gloamrestEngineTypes';
import { MerchantId } from './game/gloamrestItemsAndQuests';
import {
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  InteriorId,
  generateGloamrestExteriorGrid,
} from './game/gloamrestMapAndInteriors';
import {
  TownDialogueChoice,
  buildGloamrestNpcDialogue,
} from './game/gloamrestNpcsAndDialogue';
import {
  applyEquippedGearToPartyUnits,
  applyQuestStepUpdates,
  buyFromMerchant,
  completeOutskirtsWildernessEncounter,
  createInitialGloamrestState,
  equipItemOnPartyMember,
  getNextTimeOfDay,
  interactWithGloamrestObject,
  loadGloamrestStateFromStorage,
  movePlayerInGloamrest,
  repairPartyEquipment,
  resolveTownDialogueChoice,
  saveGloamrestStateToStorage,
  sellToMerchant,
  useConsumableFromInventory,
} from './game/gloamrestEngine';
import {
  GloamrestWorld3D,
  NearbyInteractionPrompt,
} from './components/GloamrestWorld3D';
import {
  GloamrestDialogueModal,
  GloamrestHudOverlay,
  GloamrestInventoryAndMerchantModal,
  GloamrestMapModal,
  GloamrestQuestJournalModal,
  LoreAndTutorialModal,
  WildernessGateModal,
} from './components/GloamrestOverlays';
import { PerformanceOverlay } from './components/PerformanceOverlay';
import { performanceManager } from './game/performanceManager';

type GameShellState = 'title' | 'playing' | 'paused' | 'gameover';
type PlaySubMode = 'gloamrest' | 'combat';
type CombatEncounterContext =
  | 'campaign'
  | 'outskirts_mq03'
  | 'barracks_sparring'
  | 'ascendant_tower';

interface RunSnapshot {
  outcome: 'victory' | 'defeat';
  stageName: string;
  roundsTaken: number;
  damageDealt: number;
  oathAlignment: string;
  highestBondName: string;
  highestBondScore: number;
}

export default function App() {
  const isAutostart = useMemo(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('autostart') === '1';
  }, []);

  const [gameState, setGameState] = useState<GameShellState>(isAutostart ? 'playing' : 'title');
  const [playSubMode, setPlaySubMode] = useState<PlaySubMode>('gloamrest');
  const [combatContext, setCombatContext] = useState<CombatEncounterContext>('campaign');
  const [activeSaveSlotId, setActiveSaveSlotId] = useState<string>('slot-active-adventure');
  const [originChoice, setOriginChoice] = useState<'Mercy' | 'Dominion' | 'Balance'>('Balance');
  const [characterBuild, setCharacterBuild] = useState<CharacterCreationBuild>(() =>
    createDefaultCharacterBuild()
  );
  const characterBuildRef = useRef<CharacterCreationBuild>(characterBuild);
  characterBuildRef.current = characterBuild;

  // Character Level 1-20 Progression & 96-Skill Tree State
  const [progressionState, setProgressionState] = useState<CharacterProgressionState>(() => {
    const cClass = normalizePlayableClassKey(characterBuild.classId);
    return createInitialProgressionState(cClass, characterBuild.subclassId);
  });
  const progressionStateRef = useRef<CharacterProgressionState>(progressionState);
  progressionStateRef.current = progressionState;

  const [showSkillTreeModal, setShowSkillTreeModal] = useState<boolean>(false);
  const [levelUpData, setLevelUpData] = useState<LevelUpResult | null>(null);

  const handleAwardXp = useCallback(
    (amount: number, sourceId?: string) => {
      const res = awardXp(progressionStateRef.current, amount, sourceId);
      setProgressionState(res.nextState);
      progressionStateRef.current = res.nextState;
      if (res.leveledUp) {
        soundEngine.playVictoryFanfare?.();
        setLevelUpData(res);
      }
      return res;
    },
    []
  );

  const handleUpdateProgression = useCallback(
    (nextState: CharacterProgressionState) => {
      setProgressionState(nextState);
      progressionStateRef.current = nextState;
      setUnits((prev) =>
        prev.map((u) => {
          if (u.id !== 'seraphina') return u;
          const updatedAbilities = applyProgressionToCommander(u, nextState).abilities;
          return {
            ...u,
            abilities: updatedAbilities,
          };
        })
      );
    },
    []
  );

  // The Ascendant Tower 100-Floor Progression State
  const [towerState, setTowerState] = useState<TowerProgressionState>(() =>
    createInitialTowerState()
  );
  const towerStateRef = useRef<TowerProgressionState>(towerState);
  towerStateRef.current = towerState;
  const [showTowerModal, setShowTowerModal] = useState<boolean>(false);
  const [activeTowerFloor, setActiveTowerFloor] = useState<number>(1);
  const activeTowerFloorRef = useRef<number>(activeTowerFloor);
  activeTowerFloorRef.current = activeTowerFloor;
  const [towerBattleSummary, setTowerBattleSummary] =
    useState<TowerBattleResultSummary | null>(null);

  const [stageId, setStageId] = useState<number>(0);
  const [highestReachedStage, setHighestReachedStage] = useState<number>(0);

  // Gloamrest Persistent Settlement Hub State
  const gloamrestExteriorGrid = useMemo(() => generateGloamrestExteriorGrid(), []);
  const [gloamrestState, setGloamrestState] = useState<GloamrestSaveState>(
    () => loadGloamrestStateFromStorage() ?? createInitialGloamrestState(createDefaultCharacterBuild())
  );
  const gloamrestStateRef = useRef<GloamrestSaveState>(gloamrestState);
  gloamrestStateRef.current = gloamrestState;

  const [nearbyPrompt, setNearbyPrompt] = useState<NearbyInteractionPrompt | null>(null);
  const [gloamrestBanner, setGloamrestBanner] = useState<string>(
    'Gloamrest · South Pilgrim Gate — Walk north along the cobblestones to Hearth Square or press [E] near villagers and doors.'
  );
  const [activeTownNpcId, setActiveTownNpcId] = useState<string | null>(null);
  const [showTownMapModal, setShowTownMapModal] = useState<boolean>(false);
  const [showTownInventoryModal, setShowTownInventoryModal] = useState<boolean>(false);
  const [activeMerchantId, setActiveMerchantId] = useState<MerchantId | null>(null);
  const [merchantNotice, setMerchantNotice] = useState<string | null>(null);
  const [showTownQuestModal, setShowTownQuestModal] = useState<boolean>(false);
  const [showWildernessGateModal, setShowWildernessGateModal] = useState<boolean>(false);
  const [lorePopupModal, setLorePopupModal] = useState<{
    title: string;
    text: string;
    isTrainingDrill?: boolean;
  } | null>(null);

  const [worldState, setWorldState] = useState<WorldReactivityState>(() => createInitialWorldState());
  const [relationships, setRelationships] = useState<Record<CompanionId, CompanionRelationship>>(() => {
    const initialWorld = createInitialWorldState();
    const initialGrid = generateTacticalGrid(0, initialWorld);
    const baseUnits = createEncounterUnits(0, initialWorld).map((u) => ({
      ...u,
      elevation: initialGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
    }));
    return applyCharacterBuildToParty(
      baseUnits,
      createInitialRelationships(),
      createDefaultCharacterBuild()
    ).relationships;
  });

  const [grid, setGrid] = useState<GridTile[][]>(() =>
    generateTacticalGrid(0, createInitialWorldState())
  );
  const [envObjects, setEnvObjects] = useState<TacticalEnvObject[]>(() =>
    createEncounterObjects(0)
  );
  const [units, setUnits] = useState<CombatUnit[]>(() => {
    const initialWorld = createInitialWorldState();
    const initialGrid = generateTacticalGrid(0, initialWorld);
    const baseUnits = createEncounterUnits(0, initialWorld).map((u) => ({
      ...u,
      elevation: initialGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
    }));
    return applyCharacterBuildToParty(
      baseUnits,
      createInitialRelationships(),
      createDefaultCharacterBuild()
    ).units;
  });
  const [activeUnitId, setActiveUnitId] = useState<string>(() => {
    const initialWorld = createInitialWorldState();
    const initialGrid = generateTacticalGrid(0, initialWorld);
    const baseUnits = createEncounterUnits(0, initialWorld).map((u) => ({
      ...u,
      elevation: initialGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
    }));
    const initial = applyCharacterBuildToParty(
      baseUnits,
      createInitialRelationships(),
      createDefaultCharacterBuild()
    ).units;
    const firstParty = initial.find((u) => u.faction === 'party') ?? initial[0];
    return firstParty.id;
  });

  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [totalDamageDealt, setTotalDamageDealt] = useState<number>(0);
  const [selectedAbilityKey, setSelectedAbilityKey] = useState<'1' | '2' | '3' | '4' | null>(null);
  const [cameraPreset, setCameraPreset] = useState<'tactical' | 'close' | 'overhead'>('tactical');
  const [hudCollapsed, setHudCollapsed] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const [combatBanner, setCombatBanner] = useState<string>(
    'Act I: Select a ground tile to move, or press [1-4] to target enemies, oil pools, or pushable objects.'
  );
  const [burstEvent, setBurstEvent] = useState<ParticleBurstEvent | null>(null);
  const [combatAnimationEvent, setCombatAnimationEvent] = useState<ActiveCombatAnimationEvent | null>(null);
  const [diceToasts, setDiceToasts] = useState<DiceRollToastEntry[]>([]);
  const toastTimersRef = useRef<Map<number, number>>(new Map());

  const [hoverInfo, setHoverInfo] = useState<{
    tile?: { x: number; z: number };
    unitId?: string;
  } | null>(null);

  // Modals in 'playing' state
  const [activeDialogueId, setActiveDialogueId] = useState<string | null>(null);
  const [parleyCompletedStages, setParleyCompletedStages] = useState<number[]>([]);
  const [showCampModal, setShowCampModal] = useState<boolean>(false);
  const [showChronicleModal, setShowChronicleModal] = useState<boolean>(false);
  const [showSkillMenu, setShowSkillMenu] = useState<boolean>(false);
  const [showInspectPanel, setShowInspectPanel] = useState<boolean>(false);
  const [inspectedUnitId, setInspectedUnitId] = useState<string | null>(null);
  const [runSnapshot, setRunSnapshot] = useState<RunSnapshot | null>(null);

  // Ghost bar trailing HP percentage for active unit
  const [ghostHpPct, setGhostHpPct] = useState<number>(100);

  // Track units reaching 0 HP so they play a 850ms collapse / fade-to-dust animation before removal from the initiative ribbon
  const [collapsingUnitIds, setCollapsingUnitIds] = useState<string[]>([]);
  const prevUnitHpRef = useRef<Record<string, number>>({});
  const collapseTimersRef = useRef<Map<string, number>>(new Map());

  useEffect(() => {
    const newlyCollapsed: string[] = [];
    for (const u of units) {
      const prevHp = prevUnitHpRef.current[u.id];
      if (prevHp !== undefined && prevHp > 0 && (u.hp <= 0 || u.isKO)) {
        newlyCollapsed.push(u.id);
      }
      prevUnitHpRef.current[u.id] = u.hp;
    }

    if (newlyCollapsed.length > 0) {
      setCollapsingUnitIds((prev) => Array.from(new Set([...prev, ...newlyCollapsed])));
      for (const id of newlyCollapsed) {
        const existing = collapseTimersRef.current.get(id);
        if (existing) window.clearTimeout(existing);
        const timer = window.setTimeout(() => {
          collapseTimersRef.current.delete(id);
          setCollapsingUnitIds((prev) => prev.filter((item) => item !== id));
        }, 1200);
        collapseTimersRef.current.set(id, timer);
      }
    }
  }, [units]);

  const initiativeRibbonEntries = useMemo(
    () => computeInitiativeRibbonEntries(units, new Set(collapsingUnitIds)),
    [units, collapsingUnitIds]
  );

  const dismissDiceRollToast = useCallback((id: number) => {
    const timer = toastTimersRef.current.get(id);
    if (timer) {
      window.clearTimeout(timer);
      toastTimersRef.current.delete(id);
    }
    setDiceToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const pushDiceRollToast = useCallback(
    (entry: DiceRollToastEntry) => {
      setDiceToasts((prev) => [entry, ...prev].slice(0, 2));
      const timer = window.setTimeout(() => {
        toastTimersRef.current.delete(entry.id);
        setDiceToasts((prev) => prev.filter((t) => t.id !== entry.id));
      }, 6500);
      toastTimersRef.current.set(entry.id, timer);
    },
    []
  );

  useEffect(() => {
    return () => {
      toastTimersRef.current.forEach((timer) => window.clearTimeout(timer));
      toastTimersRef.current.clear();
      collapseTimersRef.current.forEach((timer) => window.clearTimeout(timer));
      collapseTimersRef.current.clear();
      soundEngine.setCombatMusicActive(false);
      soundEngine.setTownAmbienceState(false);
    };
  }, []);

  const tacticalAdvantage = useMemo(
    () => evaluateTacticalAdvantage(units, worldState),
    [units, worldState]
  );

  // Sync dynamic combat music vs Gloamrest medieval town & interior ambience
  useEffect(() => {
    if (gameState !== 'playing') {
      soundEngine.setCombatMusicActive(false);
      soundEngine.setTownAmbienceState(false);
      return;
    }
    if (playSubMode === 'combat') {
      soundEngine.setTownAmbienceState(false);
      soundEngine.setCombatMusicActive(true);
    } else {
      soundEngine.setCombatMusicActive(false);
      const scenePreset =
        gloamrestState.currentSceneId === 'tavern'
          ? 'tavern'
          : gloamrestState.currentSceneId === 'forge'
          ? 'forge'
          : gloamrestState.currentSceneId === 'chapel'
          ? 'chapel'
          : 'exterior';
      soundEngine.setTownAmbienceState(true, scenePreset, gloamrestState.townThreatPhase);
    }
  }, [gameState, playSubMode, gloamrestState.currentSceneId, gloamrestState.townThreatPhase]);

  useEffect(() => {
    soundEngine.setCombatThemeState(tacticalAdvantage.state);
  }, [tacticalAdvantage.state]);

  const activeUnit = useMemo(
    () => units.find((u) => u.id === activeUnitId) ?? units.find((u) => !u.isKO) ?? units[0],
    [units, activeUnitId]
  );

  const validMoveTiles = useMemo(() => {
    if (!activeUnit || activeUnit.faction !== 'party' || selectedAbilityKey !== null) return [];
    return getValidMoveTiles(activeUnit, grid, units, envObjects);
  }, [activeUnit, grid, units, envObjects, selectedAbilityKey]);

  // Mirror game state to document.body.dataset.state
  useEffect(() => {
    document.body.dataset.state = gameState;
  }, [gameState]);

  // Update delayed trailing ghost health bar
  useEffect(() => {
    if (!activeUnit) return;
    const pct = Math.max(0, Math.min(100, Math.round((activeUnit.hp / activeUnit.maxHp) * 100)));
    const timer = window.setTimeout(() => {
      setGhostHpPct(pct);
    }, 280);
    return () => clearTimeout(timer);
  }, [activeUnit?.hp, activeUnit?.maxHp, activeUnit?.id]);

  const triggerParticles = useCallback(
    (gx: number, gz: number, elev: number, colorHex: number, count: number, heavy: boolean) => {
      const [wx, wy, wz] = gridToWorld(gx, gz, elev);
      setBurstEvent({
        id: Date.now() + Math.random(),
        worldX: wx,
        worldY: wy + 1.0,
        worldZ: wz,
        colorHex,
        count,
        heavy,
      });
    },
    []
  );

  const relationshipsRef = useRef(relationships);
  relationshipsRef.current = relationships;

  const loadEncounterStage = useCallback(
    (
      targetStageId: number,
      currentWorld: WorldReactivityState,
      customBuild?: CharacterCreationBuild,
      preserveExistingRelationships = false,
      customEquipped?: GloamrestSaveState['inventory']['equippedByUnit']
    ) => {
      const activeBuild = customBuild ?? characterBuildRef.current;
      const equippedMap = customEquipped ?? gloamrestStateRef.current.inventory.equippedByUnit;
      const newGrid = generateTacticalGrid(targetStageId, currentWorld);
      const newObjects = createEncounterObjects(targetStageId);
      const baseUnits = createEncounterUnits(targetStageId, currentWorld).map((u) => ({
        ...u,
        elevation: newGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
      }));
      const baseRels = preserveExistingRelationships
        ? relationshipsRef.current
        : createInitialRelationships();
      const applied = applyCharacterBuildToParty(baseUnits, baseRels, activeBuild);
      const withProgressionUnits = applied.units.map((u) =>
        u.id === 'seraphina' ? applyProgressionToCommander(u, progressionStateRef.current) : u
      );
      const rawUnits = applyEquippedGearToPartyUnits(withProgressionUnits, equippedMap);
      setRelationships(applied.relationships);

      collapseTimersRef.current.forEach((timer) => window.clearTimeout(timer));
      collapseTimersRef.current.clear();
      setCollapsingUnitIds([]);
      const nextHpMap: Record<string, number> = {};
      for (const u of rawUnits) {
        nextHpMap[u.id] = u.hp;
      }
      prevUnitHpRef.current = nextHpMap;
      setStageId(targetStageId);
      setGrid(newGrid);
      setEnvObjects(newObjects);
      setUnits(rawUnits);
      const firstParty = rawUnits.find((u) => u.faction === 'party') ?? rawUnits[0];
      setActiveUnitId(firstParty.id);
      setSelectedAbilityKey(null);
      setRoundNumber(1);
      setDiceToasts([]);
      setCombatBanner(
        `${STAGES[targetStageId].chapterLabel}: ${STAGES[targetStageId].name} — Press [E] to Parley or engage directly!`
      );
    },
    []
  );

  // Launch Main Quest 03 Whispering Outskirts Beginner Tactical Encounter
  const startOutskirtsEncounter = useCallback(() => {
    const activeBuild = characterBuildRef.current;
    const currentGloam = gloamrestStateRef.current;
    const newGrid = generateTacticalGrid(0, worldState);
    const newObjects = createEncounterObjects(0);
    const baseUnits = createEncounterUnits(0, worldState).map((u) => ({
      ...u,
      elevation: newGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
    }));
    const applied = applyCharacterBuildToParty(baseUnits, relationshipsRef.current, activeBuild);
    const withProgressionUnits = applied.units.map((u) =>
      u.id === 'seraphina' ? applyProgressionToCommander(u, progressionStateRef.current) : u
    );
    const gearedParty = applyEquippedGearToPartyUnits(
      withProgressionUnits.filter((u) => u.faction === 'party'),
      currentGloam.inventory.equippedByUnit
    );
    const rawEnemies = applied.units.filter((u) => u.faction === 'enemy').slice(0, 2);
    const outskirtsEnemies: CombatUnit[] = rawEnemies.map((en, idx) => ({
      ...en,
      name: idx === 0 ? 'Whispering Rift Stalker' : 'Covenant Outrider',
      title: idx === 0 ? 'Vale Ambush Predator' : 'Fractured Patrol Scout',
      maxHp: idx === 0 ? 24 : 22,
      hp: idx === 0 ? 24 : 22,
      armorClass: 12,
    }));
    const combined = [...gearedParty, ...outskirtsEnemies];

    collapseTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    collapseTimersRef.current.clear();
    setCollapsingUnitIds([]);
    const nextHpMap: Record<string, number> = {};
    for (const u of combined) nextHpMap[u.id] = u.hp;
    prevUnitHpRef.current = nextHpMap;

    setStageId(0);
    setGrid(newGrid);
    setEnvObjects(newObjects);
    setUnits(combined);
    setActiveUnitId(gearedParty[0]?.id ?? combined[0].id);
    setSelectedAbilityKey(null);
    setRoundNumber(1);
    setTotalDamageDealt(0);
    setActiveTownNpcId(null);
    setShowWildernessGateModal(false);
    setLorePopupModal(null);
    setCombatContext('outskirts_mq03');
    setPlaySubMode('combat');
    setGameState('playing');
    setCombatBanner(
      'MAIN QUEST 03 · Whispering Outskirts — Defeat the ambushers! Use High Ground (+2 Hit), Flanking, Oil Pools & [1-4] Skills.'
    );
  }, [worldState]);

  // Launch Non-Lethal Watch Barracks Tactical Sparring Bout
  const startBarracksSparring = useCallback(() => {
    const activeBuild = characterBuildRef.current;
    const currentGloam = gloamrestStateRef.current;
    const newGrid = generateTacticalGrid(0, worldState);
    const newObjects = createEncounterObjects(0);
    const baseUnits = createEncounterUnits(0, worldState).map((u) => ({
      ...u,
      elevation: newGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
    }));
    const applied = applyCharacterBuildToParty(baseUnits, relationshipsRef.current, activeBuild);
    const withProgressionUnits = applied.units.map((u) =>
      u.id === 'seraphina' ? applyProgressionToCommander(u, progressionStateRef.current) : u
    );
    const gearedParty = applyEquippedGearToPartyUnits(
      withProgressionUnits.filter((u) => u.faction === 'party'),
      currentGloam.inventory.equippedByUnit
    );
    const drillOpponents: CombatUnit[] = applied.units
      .filter((u) => u.faction === 'enemy')
      .slice(0, 2)
      .map((en, idx) => ({
        ...en,
        name: idx === 0 ? 'Watch Sergeant Halvar' : 'Barracks Marksman',
        title: 'Non-Lethal Sparring Partner',
        maxHp: 20,
        hp: 20,
        armorClass: 12,
      }));
    const combined = [...gearedParty, ...drillOpponents];

    collapseTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    collapseTimersRef.current.clear();
    setCollapsingUnitIds([]);
    const nextHpMap: Record<string, number> = {};
    for (const u of combined) nextHpMap[u.id] = u.hp;
    prevUnitHpRef.current = nextHpMap;

    setStageId(0);
    setGrid(newGrid);
    setEnvObjects(newObjects);
    setUnits(combined);
    setActiveUnitId(gearedParty[0]?.id ?? combined[0].id);
    setSelectedAbilityKey(null);
    setRoundNumber(1);
    setTotalDamageDealt(0);
    setActiveTownNpcId(null);
    setLorePopupModal(null);
    setCombatContext('barracks_sparring');
    setPlaySubMode('combat');
    setGameState('playing');
    setCombatBanner(
      'WATCH BARRACKS SPARRING DRILL (Non-Lethal) — Practice Movement, AP, Skill Menu [K], Telegraphs & Shove!'
    );
  }, [worldState]);

  // Launch The Ascendant Tower Floor Encounter
  const launchTowerFloor = useCallback(
    (floorNumber: number) => {
      const activeBuild = characterBuildRef.current;
      const currentGloam = gloamrestStateRef.current;
      const baseUnits = createEncounterUnits(0, worldState);
      const applied = applyCharacterBuildToParty(baseUnits, relationshipsRef.current, activeBuild);
      const withProgressionUnits = applied.units.map((u) =>
        u.id === 'seraphina' ? applyProgressionToCommander(u, progressionStateRef.current) : u
      );
      const gearedParty = applyEquippedGearToPartyUnits(
        withProgressionUnits.filter((u) => u.faction === 'party'),
        currentGloam.inventory.equippedByUnit
      );

      const enc = buildTowerFloorEncounter(
        floorNumber,
        gearedParty,
        towerStateRef.current
      );

      collapseTimersRef.current.forEach((timer) => window.clearTimeout(timer));
      collapseTimersRef.current.clear();
      setCollapsingUnitIds([]);

      const nextHpMap: Record<string, number> = {};
      for (const u of enc.units) nextHpMap[u.id] = u.hp;
      prevUnitHpRef.current = nextHpMap;

      setActiveTowerFloor(floorNumber);
      activeTowerFloorRef.current = floorNumber;
      setStageId(0);
      setGrid(enc.grid);
      setEnvObjects(enc.envObjects);
      setUnits(enc.units);
      setActiveUnitId(enc.units.find((u) => u.faction === 'party')?.id ?? enc.units[0]?.id);
      setSelectedAbilityKey(null);
      setRoundNumber(1);
      setTotalDamageDealt(0);
      setActiveTownNpcId(null);
      setShowTownMapModal(false);
      setShowTownInventoryModal(false);
      setShowTownQuestModal(false);
      setShowSkillTreeModal(false);
      setShowCampModal(false);
      setShowTowerModal(false);
      setTowerBattleSummary(null);

      setCombatContext('ascendant_tower');
      setPlaySubMode('combat');
      setGameState('playing');
      soundEngine.playHealBless?.();
      setCombatBanner(
        `THE ASCENDANT TOWER · Floor ${floorNumber}: ${enc.floorDef.name} — ${enc.floorDef.objective.title} (${enc.floorDef.difficulty})`
      );
    },
    [worldState]
  );

  // Launch Part VIII Warrior Core Skill Family Combat Test Encounter
  const launchWarriorTrialGrounds = useCallback(() => {
    const enc = createWarriorTrialGroundsEncounter(worldState);
    const allWarriorSkillIds = [
      'sundering_strike',
      'guarded_stance',
      'whirlwind_assault',
      'driving_assault',
      'weapon_parry',
      'crippling_blow',
      'unbreakable_resolve',
      'earthsplitter',
      'relentless_pursuit',
      'iron_reprisal',
      'battlefield_commander',
      'last_stand',
    ];
    const trialProgression: CharacterProgressionState = {
      ...progressionStateRef.current,
      level: 20,
      unspentSkillPoints: 6,
      learnedSkillIds: Array.from(
        new Set([...progressionStateRef.current.learnedSkillIds, ...allWarriorSkillIds])
      ),
      equippedSkillIds: [
        'sundering_strike',
        'whirlwind_assault',
        'driving_assault',
        'earthsplitter',
      ],
    };
    setProgressionState(trialProgression);
    progressionStateRef.current = trialProgression;
    setCharacterBuild((prev) => ({
      ...prev,
      classId: 'warrior' as any,
      subclassId: 'vengeance_knight' as any,
    }));

    setStageId(0);
    setGrid(enc.grid);
    setEnvObjects(enc.envObjects);
    setUnits(enc.units);
    setActiveUnitId('seraphina');
    setSelectedAbilityKey(null);
    setRoundNumber(1);
    setTotalDamageDealt(0);
    setActiveTownNpcId(null);
    setShowTownMapModal(false);
    setShowTownInventoryModal(false);
    setShowTownQuestModal(false);
    setShowSkillTreeModal(false);
    setShowCampModal(false);
    setShowTowerModal(false);
    setActiveDialogueId(null);

    setCombatContext('barracks_sparring');
    setPlaySubMode('combat');
    setGameState('playing');
    soundEngine.playHealBless?.();
    setCombatBanner(
      'WARRIOR TRIAL GROUNDS (Part VIII Test Encounter) — All 12 Warrior Core Skills unlocked! Press [K] anytime to swap active loadout slots.'
    );
  }, [worldState]);

  // Launch Phase 2 Mage Core Skill Family Combat Test Encounter
  const launchMageTrialGrounds = useCallback(() => {
    const enc = createMageTrialGroundsEncounter(worldState);
    const allMageSkillIds = [
      'infernal_orb',
      'glacial_lance',
      'chain_lightning',
      'blink_step',
      'gravitational_collapse',
      'arcane_disjunction',
      'aegis_ward',
      'counterspell',
      'phase_veil',
      'runic_mine',
      'astral_rift',
      'prismatic_field',
    ];
    const trialProgression: CharacterProgressionState = {
      ...progressionStateRef.current,
      level: 20,
      unspentSkillPoints: 6,
      learnedSkillIds: Array.from(
        new Set([...progressionStateRef.current.learnedSkillIds, ...allMageSkillIds])
      ),
      equippedSkillIds: [
        'infernal_orb',
        'glacial_lance',
        'chain_lightning',
        'blink_step',
      ],
    };
    setProgressionState(trialProgression);
    progressionStateRef.current = trialProgression;
    setCharacterBuild((prev) => ({
      ...prev,
      classId: 'mage' as any,
      subclassId: 'blood_weave_arcanist' as any,
    }));

    setStageId(0);
    setGrid(enc.grid);
    setEnvObjects(enc.envObjects);
    setUnits(enc.units);
    setActiveUnitId('seraphina');
    setSelectedAbilityKey(null);
    setRoundNumber(1);
    setTotalDamageDealt(0);
    setActiveTownNpcId(null);
    setShowTownMapModal(false);
    setShowTownInventoryModal(false);
    setShowTownQuestModal(false);
    setShowSkillTreeModal(false);
    setShowCampModal(false);
    setShowTowerModal(false);
    setActiveDialogueId(null);

    setCombatContext('barracks_sparring');
    setPlaySubMode('combat');
    setGameState('playing');
    soundEngine.playHealBless?.();
    setCombatBanner(
      'MAGE TRIAL GROUNDS (Phase 2 Test Encounter) — All 12 Mage Core Skills unlocked! Press [K] anytime to swap active loadout slots.'
    );
  }, [worldState]);

  // Depart Whispering Gate on Main Quest 04 into Act I — Sanctum of the Shattered Oath
  const departToActOneSanctum = useCallback(() => {
    const qUpd = applyQuestStepUpdates(
      gloamrestStateRef.current,
      [
        { questId: 'mq04_road_to_whispering_vale', stepId: 'report_to_aldric' },
        { questId: 'mq04_road_to_whispering_vale', stepId: 'prepare_equipment' },
        { questId: 'mq04_road_to_whispering_vale', stepId: 'speak_companions' },
        { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
        { questId: 'mq04_road_to_whispering_vale', stepId: 'depart_sanctum' },
      ],
      ['mq04_road_to_whispering_vale']
    );
    setGloamrestState(qUpd.nextState);
    saveGloamrestStateToStorage(qUpd.nextState);

    setActiveTownNpcId(null);
    setShowWildernessGateModal(false);
    setLorePopupModal(null);
    loadEncounterStage(
      0,
      worldState,
      characterBuildRef.current,
      true,
      qUpd.nextState.inventory.equippedByUnit
    );
    setCombatContext('campaign');
    setPlaySubMode('combat');
    setGameState('playing');
    soundEngine.playHealBless();
  }, [worldState, loadEncounterStage]);

  const startNewExpedition = useCallback(
    (directToSanctum = false) => {
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      const baseWorld = createInitialWorldState();
      baseWorld.oathAlignment = originChoice;
      if (originChoice === 'Mercy') {
        baseWorld.corruptionLevel = 30;
        baseWorld.chronicleLog.push('Swore the Vanguard Oath of Mercy upon entering Dimraeth.');
      } else if (originChoice === 'Dominion') {
        baseWorld.corruptionLevel = 65;
        baseWorld.chronicleLog.push('Embraced the Blood-Weave Savant origin for arcane supremacy.');
      }

      const freshGloamrest = createInitialGloamrestState(characterBuild);
      setGloamrestState(freshGloamrest);
      saveGloamrestStateToStorage(freshGloamrest);

      const norm = normalizePlayableClassKey(characterBuild.classId);
      const cleanProg = createInitialProgressionState(norm, characterBuild.subclassId);
      setProgressionState(cleanProg);
      progressionStateRef.current = cleanProg;
      setShowSkillTreeModal(false);
      setLevelUpData(null);
      setActiveSaveSlotId(`slot-${Date.now()}`);
      setNearbyPrompt(null);
      setActiveTownNpcId(null);
      setShowTownMapModal(false);
      setShowTownInventoryModal(false);
      setActiveMerchantId(null);
      setShowTownQuestModal(false);
      setShowWildernessGateModal(false);
      setLorePopupModal(null);
      setGloamrestBanner(
        'Arrived at Gloamrest (Whispering Vale) — Follow the cobblestones north to Hearth Square to meet Elder Aldric Veyne!'
      );

      setTotalDamageDealt(0);
      setParleyCompletedStages([]);
      setActiveDialogueId(null);
      setShowCampModal(false);
      setShowChronicleModal(false);
      setShowSkillMenu(false);
      setShowInspectPanel(false);
      setRunSnapshot(null);
      setWorldState(baseWorld);
      loadEncounterStage(
        stageId,
        baseWorld,
        characterBuild,
        false,
        freshGloamrest.inventory.equippedByUnit
      );
      setCombatContext('campaign');
      setPlaySubMode(directToSanctum ? 'combat' : 'gloamrest');
      setGameState('playing');
      soundEngine.playHealBless();
    },
    [originChoice, stageId, characterBuild, loadEncounterStage]
  );

  // Restore a saved adventure slot (including full Gloamrest quests, NPC trust, schedules, inventory & world state)
  const handleLoadSavedSlot = useCallback(
    (slot: SavedAdventureSlot) => {
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      const restoredBuild: CharacterCreationBuild = {
        commanderName: slot.commanderName,
        raceId: slot.raceId,
        classId: slot.classId,
        subclassId: slot.subclassId,
        allocatedStats: slot.allocatedStats ?? characterBuildRef.current.allocatedStats,
        backgroundId: slot.backgroundId ?? characterBuildRef.current.backgroundId,
      };
      setCharacterBuild(restoredBuild);
      setOriginChoice(slot.originChoice);
      setStageId(slot.stageId);
      setActiveSaveSlotId(slot.id);

      const restoredWorld = slot.savedWorldState ?? createInitialWorldState();
      setWorldState(restoredWorld);

      const restoredGloamrest =
        slot.gloamrestState ?? createInitialGloamrestState(restoredBuild);
      setGloamrestState(restoredGloamrest);
      saveGloamrestStateToStorage(restoredGloamrest);

      loadEncounterStage(
        slot.stageId,
        restoredWorld,
        restoredBuild,
        false,
        restoredGloamrest.inventory.equippedByUnit
      );
      if (slot.savedRelationships) {
        setRelationships(slot.savedRelationships);
      }

      if (slot.progressionState) {
        const sanitized: CharacterProgressionState = {
          ...slot.progressionState,
          equippedSkillIds: sanitizeEquippedSkills(slot.progressionState.equippedSkillIds),
        };
        setProgressionState(sanitized);
        progressionStateRef.current = sanitized;
      } else {
        const norm = normalizePlayableClassKey(slot.classId);
        const clean = createInitialProgressionState(norm, slot.subclassId);
        const targetXp = CUMULATIVE_XP_TABLE[slot.level ?? 1] ?? 0;
        const leveled = awardXp(clean, targetXp, `slot_load_${slot.id}`);
        setProgressionState(leveled.nextState);
        progressionStateRef.current = leveled.nextState;
      }
      if (slot.towerState) {
        setTowerState(slot.towerState);
        towerStateRef.current = slot.towerState;
      } else {
        const cleanTower = createInitialTowerState();
        setTowerState(cleanTower);
        towerStateRef.current = cleanTower;
      }
      setShowSkillTreeModal(false);
      setLevelUpData(null);
      setShowTowerModal(false);
      setTowerBattleSummary(null);

      setActiveTownNpcId(null);
      setShowTownMapModal(false);
      setShowTownInventoryModal(false);
      setShowTownQuestModal(false);
      setShowWildernessGateModal(false);
      setLorePopupModal(null);
      setActiveDialogueId(null);
      setShowCampModal(false);
      setShowChronicleModal(false);
      setShowSkillMenu(false);
      setRunSnapshot(null);

      const resumeInTown = slot.inGloamrest !== false && Boolean(slot.gloamrestState);
      setCombatContext('campaign');
      setPlaySubMode(resumeInTown ? 'gloamrest' : 'combat');
      setGameState('playing');
      setGloamrestBanner(`Resumed saved adventure for ${slot.commanderName} in Gloamrest.`);
      soundEngine.playHealBless();
    },
    [loadEncounterStage]
  );

  // Save current adventure state (Gloamrest + World + Bonds + Gear) to persistent storage & Save Slots
  const handleSaveAdventure = useCallback(() => {
    const currentGloam = gloamrestStateRef.current;
    saveGloamrestStateToStorage(currentGloam);

    let locLabel = STAGES[stageId]?.name ?? 'Act I';
    if (playSubMode === 'gloamrest') {
      if (currentGloam.currentSceneId !== 'exterior') {
        locLabel = `Gloamrest · ${GLOAMREST_INTERIORS[currentGloam.currentSceneId as InteriorId].name}`;
      } else {
        const rx = Math.round(currentGloam.playerPos.x);
        const rz = Math.round(currentGloam.playerPos.z);
        const dId = gloamrestExteriorGrid[rx]?.[rz]?.districtId;
        locLabel = dId
          ? `Gloamrest · ${GLOAMREST_DISTRICTS[dId].name}`
          : 'Gloamrest · Whispering Vale';
      }
    }

    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(
      2,
      '0'
    )}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(
      2,
      '0'
    )}:${String(now.getMinutes()).padStart(2, '0')}`;

    const completedQuestsCount = Object.values(currentGloam.quests).filter(
      (q) => q.status === 'completed'
    ).length;

    upsertAdventureSaveSlot({
      id: activeSaveSlotId,
      commanderName: characterBuild.commanderName,
      level: progressionStateRef.current.level,
      raceId: characterBuild.raceId,
      classId: characterBuild.classId,
      subclassId: characterBuild.subclassId,
      backgroundId: characterBuild.backgroundId,
      allocatedStats: characterBuild.allocatedStats,
      originChoice,
      stageId,
      playtime: `Day ${currentGloam.dayCount} (${currentGloam.timeOfDay})`,
      saveDate: formattedDate,
      timestamp: Date.now(),
      inGloamrest: playSubMode === 'gloamrest',
      locationLabel: locLabel,
      gloamrestState: currentGloam,
      savedWorldState: worldState,
      savedRelationships: relationships,
      progressionState: progressionStateRef.current,
      towerState: towerStateRef.current,
    });

    soundEngine.playCoinTrade();
    setGloamrestBanner(
      `Adventure Saved (${locLabel}) — Quests, NPC states, merchant stocks & equipped gear persisted.`
    );
  }, [
    activeSaveSlotId,
    characterBuild,
    originChoice,
    stageId,
    playSubMode,
    gloamrestExteriorGrid,
    worldState,
    relationships,
  ]);

  // Check Victory or Defeat transitions (Combat Sub-Mode Only)
  useEffect(() => {
    if (gameState !== 'playing' || playSubMode !== 'combat') return;
    const livingEnemies = units.filter((u) => u.faction === 'enemy' && !u.isKO);
    const livingParty = units.filter((u) => u.faction === 'party' && !u.isKO);

    if (livingEnemies.length === 0 && units.length > 0) {
      if (combatContext === 'outskirts_mq03') {
        const timer = window.setTimeout(() => {
          soundEngine.playVictoryFanfare();
          handleAwardXp(XP_REWARD_MAIN_QUEST, 'mq03_whispering_outskirts_victory');
          const res = completeOutskirtsWildernessEncounter(gloamrestStateRef.current);
          setGloamrestState(res.nextState);
          saveGloamrestStateToStorage(res.nextState);
          setUnits((prev) =>
            prev
              .filter((u) => u.faction === 'party')
              .map((u) => ({
                ...u,
                hp: Math.max(12, u.hp),
                ap: u.maxAp,
                isKO: false,
                cooldowns: {},
                statuses: [],
              }))
          );
          setCombatContext('campaign');
          setPlaySubMode('gloamrest');
          setGloamrestBanner(
            'Victory in Whispering Outskirts! Main Quest 03 Completed (+45g) — Gloamrest stands on heightened watch; Main Quest 04 unlocked!'
          );
        }, 900);
        return () => clearTimeout(timer);
      }

      if (combatContext === 'barracks_sparring') {
        const timer = window.setTimeout(() => {
          soundEngine.playVictoryFanfare();
          handleAwardXp(XP_REWARD_SIDE_QUEST, 'barracks_sparring_victory');
          setGloamrestState((prev) => ({
            ...prev,
            currentSceneId: 'exterior',
            playerPos: { x: 27, z: 12 },
          }));
          setUnits((prev) =>
            prev
              .filter((u) => u.faction === 'party')
              .map((u) => ({
                ...u,
                hp: u.maxHp,
                ap: u.maxAp,
                isKO: false,
                cooldowns: {},
                statuses: [],
              }))
          );
          setCombatContext('campaign');
          setPlaySubMode('gloamrest');
          setGloamrestBanner(
            'Watch Barracks Sparring Victory! Captain Roderic commends your tactical command — Party vitality restored.'
          );
        }, 900);
        return () => clearTimeout(timer);
      }

      if (combatContext === 'ascendant_tower') {
        const timer = window.setTimeout(() => {
          soundEngine.playVictoryFanfare();
          const currentFloor = activeTowerFloorRef.current;
          const floorDef = ALL_100_TOWER_FLOORS[currentFloor] ?? ALL_100_TOWER_FLOORS[1];
          const res = completeTowerFloor(
            towerStateRef.current,
            currentFloor,
            roundNumber,
            units
          );
          setTowerState(res.nextState);
          towerStateRef.current = res.nextState;

          if (res.xpEarned > 0) {
            handleAwardXp(res.xpEarned, `tower_floor_${currentFloor}_clear`);
          }

          setTowerBattleSummary({
            floorNumber: currentFloor,
            outcome: 'victory',
            roundsTaken: roundNumber,
            shardsEarned: res.shardsEarned,
            xpEarned: res.xpEarned,
            firstClear: res.firstClearEarned,
            unlockedCheckpoint: res.unlockedCheckpoint,
            bossDefeatedName: res.bossDefeated?.name,
          });

          setUnits((prev) =>
            prev
              .filter((u) => u.faction === 'party')
              .map((u) => ({
                ...u,
                hp: floorDef.isSanctuary ? u.maxHp : Math.max(1, u.hp),
                ap: u.maxAp,
                isKO: false,
                cooldowns: {},
                statuses: [],
              }))
          );
          setCombatContext('campaign');
          setPlaySubMode('gloamrest');
          setGloamrestBanner(
            `Tower Floor ${currentFloor} Conquered! (+${res.shardsEarned} Shards, +${res.xpEarned} XP) — Press [T] to view the Spire.`
          );
        }, 900);
        return () => clearTimeout(timer);
      }

      const bestComp = (Object.values(relationships) as CompanionRelationship[]).sort(
        (a, b) => b.approval - a.approval
      )[0];
      const timer = window.setTimeout(() => {
        soundEngine.playVictoryFanfare();
        handleAwardXp(XP_REWARD_BOSS_ENEMY, `campaign_stage_${stageId}_victory`);
        setHighestReachedStage((prev) => Math.max(prev, Math.min(STAGES.length - 1, stageId + 1)));
        setRunSnapshot({
          outcome: 'victory',
          stageName: STAGES[stageId].name,
          roundsTaken: roundNumber,
          damageDealt: totalDamageDealt,
          oathAlignment: worldState.oathAlignment,
          highestBondName: bestComp.name,
          highestBondScore: bestComp.approval,
        });
        setGameState('gameover');
      }, 950);
      return () => clearTimeout(timer);
    }

    if (livingParty.length === 0 && units.length > 0) {
      if (combatContext === 'ascendant_tower') {
        const timer = window.setTimeout(() => {
          soundEngine.playDefeatSting();
          const currentFloor = activeTowerFloorRef.current;
          setTowerBattleSummary({
            floorNumber: currentFloor,
            outcome: 'defeat',
            roundsTaken: roundNumber,
            shardsEarned: 0,
            xpEarned: 0,
            firstClear: false,
            defeatReason: `Party collapsed on Floor ${currentFloor}. Fallen members retreat to Gloamrest sanctuary.`,
          });
          setUnits((prev) =>
            prev
              .filter((u) => u.faction === 'party')
              .map((u) => ({
                ...u,
                hp: Math.max(10, Math.round(u.maxHp * 0.5)),
                ap: u.maxAp,
                isKO: false,
                cooldowns: {},
                statuses: [],
              }))
          );
          setCombatContext('campaign');
          setPlaySubMode('gloamrest');
          setGloamrestBanner(
            `Tower Ascent Interrupted on Floor ${currentFloor} — Party recuperating in Gloamrest.`
          );
        }, 900);
        return () => clearTimeout(timer);
      }

      if (combatContext === 'outskirts_mq03' || combatContext === 'barracks_sparring') {
        const timer = window.setTimeout(() => {
          soundEngine.playDefeatSting();
          setUnits((prev) =>
            prev
              .filter((u) => u.faction === 'party')
              .map((u) => ({
                ...u,
                hp:
                  combatContext === 'barracks_sparring'
                    ? u.maxHp
                    : Math.max(10, Math.round(u.maxHp * 0.5)),
                ap: u.maxAp,
                isKO: false,
                cooldowns: {},
                statuses: [],
              }))
          );
          const wasSparring = combatContext === 'barracks_sparring';
          setCombatContext('campaign');
          setPlaySubMode('gloamrest');
          setGloamrestBanner(
            wasSparring
              ? 'Sparring Bout Concluded — Party restored to full vitality in the Watch Barracks yard.'
              : 'Scout Sera Wren pulled your party back inside Whispering Gate! Visit the Chapel or Herbalist before engaging again.'
          );
        }, 900);
        return () => clearTimeout(timer);
      }

      const bestComp = (Object.values(relationships) as CompanionRelationship[]).sort(
        (a, b) => b.approval - a.approval
      )[0];
      const timer = window.setTimeout(() => {
        soundEngine.playDefeatSting();
        setRunSnapshot({
          outcome: 'defeat',
          stageName: STAGES[stageId].name,
          roundsTaken: roundNumber,
          damageDealt: totalDamageDealt,
          oathAlignment: worldState.oathAlignment,
          highestBondName: bestComp.name,
          highestBondScore: bestComp.approval,
        });
        setGameState('gameover');
      }, 950);
      return () => clearTimeout(timer);
    }
  }, [
    units,
    gameState,
    playSubMode,
    combatContext,
    stageId,
    roundNumber,
    totalDamageDealt,
    worldState.oathAlignment,
    relationships,
  ]);

  const unitsRef = useRef(units);
  unitsRef.current = units;
  const activeUnitIdRef = useRef(activeUnitId);
  activeUnitIdRef.current = activeUnitId;

  // Advance Turn Order cleanly without calling setState inside another state updater
  const advanceTurn = useCallback(() => {
    const currentUnits = unitsRef.current;
    const currentActiveId = activeUnitIdRef.current;
    const conscious = currentUnits.filter((u) => !u.isKO);
    if (conscious.length === 0) return;

    const curIdx = conscious.findIndex((u) => u.id === currentActiveId);
    const nextIdx = (curIdx + 1) % conscious.length;
    const nextUnit = conscious[nextIdx];

    setSelectedAbilityKey(null);
    if (nextIdx === 0) {
      setRoundNumber((r) => r + 1);
    }
    setActiveUnitId(nextUnit.id);

    setUnits((prevUnits) =>
      prevUnits.map((u) => {
        if (u.id !== nextUnit.id) return { ...u, telegraph: undefined };
        const nextCooldowns: Record<string, number> = {};
        for (const [k, v] of Object.entries(u.cooldowns) as [string, number][]) {
          if (v > 1) nextCooldowns[k] = v - 1;
        }
        const burnDmg = u.statuses.some((s) => s.type === 'burning') ? 3 : 0;
        const nextHp = Math.max(1, u.hp - burnDmg);
        const nextStatuses = u.statuses
          .map((s) => ({ ...s, turnsLeft: s.turnsLeft - 1 }))
          .filter((s) => s.turnsLeft > 0);

        const nextGuardedTurns =
          (u.guardedStanceTurns ?? 0) > 1 ? (u.guardedStanceTurns ?? 0) - 1 : 0;
        const nextLastStandTurns =
          (u.lastStandTurns ?? 0) > 1 ? (u.lastStandTurns ?? 0) - 1 : 0;
        const nextCounterspellTurns =
          (u.counterspellTurns ?? 0) > 1 ? (u.counterspellTurns ?? 0) - 1 : 0;
        const nextPhaseVeilTurns =
          (u.phaseVeilTurns ?? 0) > 1 ? (u.phaseVeilTurns ?? 0) - 1 : 0;
        const nextAegisWardTurns =
          (u.aegisWardTurns ?? 0) > 1 ? (u.aegisWardTurns ?? 0) - 1 : 0;

        return {
          ...u,
          hp: nextHp,
          ap: u.maxAp,
          movedThisTurn: false,
          cooldowns: nextCooldowns,
          statuses: nextStatuses,
          guardedStanceTurns: nextGuardedTurns,
          lastStandTurns: nextLastStandTurns,
          weaponParryActive: false,
          ironReprisalActive: false,
          counterspellActive: nextCounterspellTurns > 0,
          counterspellTurns: nextCounterspellTurns,
          phaseVeilTurns: nextPhaseVeilTurns,
          aegisWardActive: nextAegisWardTurns > 0 && u.tempHp > 0,
          aegisWardTurns: nextAegisWardTurns,
          telegraph: undefined,
        };
      })
    );
  }, []);

  // Trigger Enemy AI turn when activeUnit is an enemy
  useEffect(() => {
    if (
      gameState !== 'playing' ||
      playSubMode !== 'combat' ||
      activeDialogueId ||
      showCampModal ||
      showChronicleModal ||
      showSkillMenu
    ) {
      return;
    }
    if (!activeUnit || activeUnit.faction !== 'enemy' || activeUnit.isKO) return;

    const currentUnits = unitsRef.current;
    const plan = computeEnemyTurnAction(activeUnit, currentUnits, grid, envObjects);
    const targetUnit = currentUnits.find((u) => u.id === plan.targetUnitId);
    if (!targetUnit) {
      advanceTurn();
      return;
    }

    // Phase 1: Telegraph windup (420ms)
    soundEngine.playTelegraphWarning();
    const newElev = grid[plan.moveTo.x]?.[plan.moveTo.z]?.elevation ?? 0;
    setUnits((prev) =>
      prev.map((u) =>
        u.id === activeUnit.id
          ? {
              ...u,
              gridX: plan.moveTo.x,
              gridZ: plan.moveTo.z,
              elevation: newElev,
              movedThisTurn: true,
              telegraph: {
                abilityName: plan.ability.name,
                targetUnitId: targetUnit.id,
                targetX: targetUnit.gridX,
                targetZ: targetUnit.gridZ,
                damagePreview: plan.ability.damageRange[1],
              },
            }
          : u
      )
    );
    setCombatBanner(
      `TELEGRAPH: ${activeUnit.name} winds up ${plan.ability.name} against ${targetUnit.name}!`
    );

    let step2Timer = 0;
    // Phase 2: Execute attack after windup
    const step1Timer = window.setTimeout(() => {
      const latestUnits = unitsRef.current;
      const latestTarget = latestUnits.find((u) => u.id === targetUnit.id) ?? targetUnit;
      const dist = manhattanDistance(
        plan.moveTo.x,
        plan.moveTo.z,
        latestTarget.gridX,
        latestTarget.gridZ
      );
      if (dist <= plan.ability.range) {
        const movedAttacker: CombatUnit = {
          ...activeUnit,
          gridX: plan.moveTo.x,
          gridZ: plan.moveTo.z,
          elevation: newElev,
        };
        const res = resolveAbilityUse(
          movedAttacker,
          latestTarget,
          plan.ability,
          latestUnits,
          relationships,
          worldState
        );
        pushDiceRollToast(buildCombatRollToast(movedAttacker, latestTarget, plan.ability, res));
        setCombatAnimationEvent({
          id: Date.now() + Math.random(),
          attackerId: movedAttacker.id,
          targetId: latestTarget.id,
          targetGrid: [latestTarget.gridX, latestTarget.gridZ],
          skillId: plan.ability.id,
          isMiss: !res.hit,
        });

        if (res.hit) {
          soundEngine.playMeleeHit(res.critical);
          triggerParticles(
            latestTarget.gridX,
            latestTarget.gridZ,
            latestTarget.elevation,
            0xf43f5e,
            res.critical ? 24 : 14,
            true
          );
        } else {
          soundEngine.playFootstep();
        }

        const warriorDef = res.hit
          ? resolveWarriorDefensiveReactions(
              movedAttacker,
              latestTarget,
              plan.ability,
              res.damage
            )
          : {
              finalDamage: 0,
              parryTriggered: false,
              reprisalTriggered: false,
              lastStandClamped: false,
              counterDamageToAttacker: 0,
              reactionLog: [],
            };

        const mageDef = res.hit
          ? resolveMageDefensiveReactions(
              movedAttacker,
              latestTarget,
              plan.ability,
              warriorDef.finalDamage,
              latestUnits
            )
          : {
              finalDamage: 0,
              counterspellTriggered: false,
              phaseVeilMitigated: false,
              aegisWardShockwave: false,
              counterDamageToAttacker: 0,
              shockwaveTargets: [],
              reactionLog: [],
            };

        const combinedReactionLog = [
          ...warriorDef.reactionLog,
          ...mageDef.reactionLog,
        ];
        const bannerSuffix =
          combinedReactionLog.length > 0
            ? ` · ${combinedReactionLog.join(' · ')}`
            : '';
        setCombatBanner(`${res.summaryText}${bannerSuffix}`);

        setUnits((prev) =>
          prev.map((u) => {
            if (u.id === latestTarget.id && res.hit) {
              const effectiveDmg = mageDef.finalDamage;
              const absorbed = Math.min(u.tempHp, effectiveDmg);
              const hpDmg = Math.max(0, effectiveDmg - absorbed);
              const newHp = Math.max(0, u.hp - hpDmg);
              const remainingTempHp = u.tempHp - absorbed;
              return {
                ...u,
                tempHp: remainingTempHp,
                hp: newHp,
                isKO: newHp <= 0,
                weaponParryActive: warriorDef.parryTriggered
                  ? false
                  : u.weaponParryActive,
                ironReprisalActive: warriorDef.reprisalTriggered
                  ? false
                  : u.ironReprisalActive,
                counterspellActive: mageDef.counterspellTriggered
                  ? false
                  : u.counterspellActive,
                aegisWardActive:
                  mageDef.aegisWardShockwave || remainingTempHp <= 0
                    ? false
                    : u.aegisWardActive,
                damageTakenSinceLastTurn:
                  (u.damageTakenSinceLastTurn ?? 0) + effectiveDmg,
                statuses:
                  res.statusApplied && !warriorDef.parryTriggered && !mageDef.counterspellTriggered
                    ? [
                        ...u.statuses.filter((s) => s.type !== res.statusApplied),
                        { type: res.statusApplied as any, turnsLeft: 2 },
                      ]
                    : u.statuses,
              };
            }
            if (u.id === activeUnit.id) {
              const counterDmg =
                warriorDef.counterDamageToAttacker +
                mageDef.counterDamageToAttacker;
              const nextEnemyHp = Math.max(0, u.hp - counterDmg);
              return {
                ...u,
                hp: nextEnemyHp,
                isKO: nextEnemyHp <= 0,
                telegraph: undefined,
                ap: 0,
              };
            }
            const shockwaveHit = mageDef.shockwaveTargets.find(
              (st) => st.unit.id === u.id
            );
            if (shockwaveHit) {
              const shockHp = Math.max(0, u.hp - shockwaveHit.damage);
              return {
                ...u,
                hp: shockHp,
                isKO: shockHp <= 0,
              };
            }
            return u;
          })
        );
      } else {
        setCombatBanner(`${activeUnit.name} advances to (${plan.moveTo.x}, ${plan.moveTo.z}).`);
      }

      step2Timer = window.setTimeout(() => {
        advanceTurn();
      }, 380);
    }, 480);

    return () => {
      clearTimeout(step1Timer);
      clearTimeout(step2Timer);
    };
  }, [
    activeUnit?.id,
    activeUnit?.faction,
    gameState,
    playSubMode,
    activeDialogueId,
    showCampModal,
    showChronicleModal,
    showSkillMenu,
    grid,
    envObjects,
    relationships,
    worldState,
    triggerParticles,
    advanceTurn,
    pushDiceRollToast,
  ]);

  // Handle Player clicking a 3D Grid Tile or Environmental Object (Move, Shove, or Ground-Target Ability)
  const handleTileClick = useCallback(
    (gx: number, gz: number) => {
      if (!activeUnit || activeUnit.faction !== 'party' || activeUnit.isKO) return;

      const envObjAtTile = envObjects.find((o) => !o.destroyed && o.gridX === gx && o.gridZ === gz);
      const tileInfo = grid[gx]?.[gz];

      // 1. If an ability [1-4] is selected, allow targeting environmental objects or reactive tiles!
      if (selectedAbilityKey !== null) {
        const ability = activeUnit.abilities.find((a) => a.key === selectedAbilityKey);
        if (!ability) return;

        if (activeUnit.ap < ability.apCost) {
          setCombatBanner(`Not enough Action Points (${ability.apCost} AP required).`);
          return;
        }
        if ((activeUnit.cooldowns[ability.id] ?? 0) > 0) {
          setCombatBanner(`${ability.name} is on cooldown.`);
          return;
        }

        const dist = manhattanDistance(activeUnit.gridX, activeUnit.gridZ, gx, gz);
        if (dist > ability.range) {
          setCombatBanner(
            `Target tile (${gx}, ${gz}) is ${dist} tiles away (${ability.name} has range ${ability.range}).`
          );
          return;
        }

        const reaction = resolveEnvironmentalInteraction(
          activeUnit,
          ability,
          gx,
          gz,
          grid,
          envObjects,
          units
        );

        setCombatAnimationEvent({
          id: Date.now() + Math.random(),
          attackerId: activeUnit.id,
          targetGrid: [gx, gz],
          skillId: ability.id,
          isMiss: false,
        });

        if (reaction.triggeredEvents.length > 0) {
          if (ability.element === 'fire') {
            soundEngine.playArcaneCast();
          } else if (ability.element === 'radiant') {
            soundEngine.playHealBless();
          } else {
            soundEngine.playMeleeHit(true);
          }

          const burstTiles =
            reaction.ignitedTiles.length > 0 ? reaction.ignitedTiles : [{ x: gx, z: gz }];
          burstTiles.slice(0, 3).forEach((pt) => {
            const elev = reaction.updatedGrid[pt.x]?.[pt.z]?.elevation ?? 0;
            triggerParticles(
              pt.x,
              pt.z,
              elev,
              ability.element === 'fire'
                ? 0xf97316
                : ability.element === 'nature'
                ? 0x4ade80
                : 0x38bdf8,
              18,
              true
            );
          });

          if (reaction.bonusDamageDealt > 0) {
            setTotalDamageDealt((d) => d + reaction.bonusDamageDealt);
          }

          setGrid(reaction.updatedGrid);
          setEnvObjects(reaction.updatedObjects);
          setUnits(
            reaction.updatedUnits.map((u) => {
              if (u.id === activeUnit.id) {
                return {
                  ...u,
                  ap: Math.max(0, u.ap - ability.apCost),
                  cooldowns:
                    ability.cooldown > 0
                      ? { ...u.cooldowns, [ability.id]: ability.cooldown }
                      : u.cooldowns,
                };
              }
              return u;
            })
          );
          setSelectedAbilityKey(null);
          setCombatBanner(reaction.triggeredEvents.join(' · '));
          return;
        }

        setCombatBanner(
          `Select a valid unit, oil pool, or pushable object within range ${ability.range} for ${ability.name}.`
        );
        return;
      }

      // 2. If no ability is selected and player clicks an intact Environmental Object, Shove/Interact if in range!
      if (envObjAtTile) {
        const dist = manhattanDistance(activeUnit.gridX, activeUnit.gridZ, gx, gz);
        if (dist <= 2 && activeUnit.ap >= 1) {
          const shoveAbility = {
            ...activeUnit.abilities[0],
            name: 'Kinetic Shove',
            apCost: 1,
            pushDistance: 1,
            element: 'physical' as const,
          };
          const reaction = resolveEnvironmentalInteraction(
            activeUnit,
            shoveAbility,
            gx,
            gz,
            grid,
            envObjects,
            units
          );
          if (reaction.triggeredEvents.length > 0) {
            soundEngine.playMeleeHit(false);
            triggerParticles(gx, gz, tileInfo?.elevation ?? 0, 0x38bdf8, 14, true);
            if (reaction.bonusDamageDealt > 0) {
              setTotalDamageDealt((d) => d + reaction.bonusDamageDealt);
            }
            setGrid(reaction.updatedGrid);
            setEnvObjects(reaction.updatedObjects);
            setUnits(
              reaction.updatedUnits.map((u) =>
                u.id === activeUnit.id ? { ...u, ap: Math.max(0, u.ap - 1) } : u
              )
            );
            setCombatBanner(reaction.triggeredEvents.join(' · '));
            return;
          }
        }
        setCombatBanner(
          `${envObjAtTile.name} at (${gx}, ${gz}) — Move within 2 tiles & click to Shove (1 AP), or target with [1-4] abilities!`
        );
        return;
      }

      // 3. Otherwise, move activeUnit to valid destination tile and resolve surface hazards/blessings
      const isValidMove = validMoveTiles.some((m) => m.x === gx && m.z === gz);
      if (!isValidMove) {
        setCombatBanner('Tile out of movement range or obstructed. Select a blue highlighted tile.');
        return;
      }
      const newElev = tileInfo?.elevation ?? 0;
      const surface = tileInfo?.surface ?? 'none';
      const isRunicMine = surface === 'runic_mine';
      const isAstralRift = surface === 'astral_rift';
      const isPrismaticField = surface === 'prismatic_field';

      const runicMineDmg = isRunicMine ? 14 : 0;
      const astralRiftDmg = isAstralRift ? 4 : 0;
      const riftHazardDmg = tileInfo?.terrain === 'hazard_rift' ? 3 : 0;
      const fireSurfaceDmg = surface === 'fire_pool' ? 4 : 0;
      const brambleDmg = surface === 'bramble_snare' ? 3 : 0;
      const sanctifiedHeal = surface === 'sanctified_pool' ? 4 : 0;
      const totalStepDmg =
        riftHazardDmg + fireSurfaceDmg + brambleDmg + runicMineDmg + astralRiftDmg;

      if (isRunicMine) {
        soundEngine.playRunicMine?.();
        triggerParticles(gx, gz, newElev, 0xf59e0b, 22, true);
        setGrid((prev) =>
          prev.map((row, x) =>
            row.map((t, z) => (x === gx && z === gz ? { ...t, surface: 'none' } : t))
          )
        );
      } else if (isAstralRift) {
        soundEngine.playAstralRift?.();
        triggerParticles(gx, gz, newElev, 0x8b5cf6, 16, true);
      } else if (isPrismaticField) {
        soundEngine.playPrismaticField?.();
        triggerParticles(gx, gz, newElev, 0x06b6d4, 18, true);
      } else {
        soundEngine.playFootstep();
        triggerParticles(
          gx,
          gz,
          newElev,
          surface === 'fire_pool' ? 0xf97316 : surface === 'sanctified_pool' ? 0xfde047 : 0x38bdf8,
          8,
          false
        );
      }

      setUnits((prev) =>
        prev.map((u) => {
          if (u.id !== activeUnit.id) return u;
          let nextStatuses = [...u.statuses];
          let nextTempHp = u.tempHp;

          if (surface === 'fire_pool') {
            nextStatuses = [
              ...nextStatuses.filter((s) => s.type !== 'burning'),
              { type: 'burning', turnsLeft: 2 },
            ];
          } else if (surface === 'bramble_snare' || isRunicMine) {
            nextStatuses = [
              ...nextStatuses.filter((s) => s.type !== 'rooted'),
              { type: 'rooted', turnsLeft: 2 },
            ];
          } else if (surface === 'sanctified_pool') {
            nextStatuses = [
              ...nextStatuses.filter((s) => s.type !== 'blessed' && s.type !== 'burning'),
              { type: 'blessed', turnsLeft: 2 },
            ];
          } else if (isAstralRift) {
            nextStatuses = [
              ...nextStatuses.filter((s) => s.type !== 'sundered'),
              { type: 'sundered', turnsLeft: 2 },
            ];
          } else if (isPrismaticField) {
            if (u.faction === 'party') {
              nextTempHp = Math.max(nextTempHp, 8);
              nextStatuses = [
                ...nextStatuses.filter((s) => s.type !== 'warded'),
                { type: 'warded', turnsLeft: 2 },
              ];
            } else {
              nextStatuses = [
                ...nextStatuses.filter((s) => s.type !== 'sundered'),
                { type: 'sundered', turnsLeft: 2 },
              ];
            }
          }

          const nextHp = Math.min(
            u.maxHp,
            Math.max(1, u.hp - totalStepDmg + sanctifiedHeal)
          );
          return {
            ...u,
            gridX: gx,
            gridZ: gz,
            elevation: newElev,
            movedThisTurn: true,
            hp: nextHp,
            tempHp: nextTempHp,
            statuses: nextStatuses,
          };
        })
      );

      const surfaceNotes: string[] = [];
      if (newElev > 0) surfaceNotes.push('[High Ground +2 Hit]');
      if (riftHazardDmg > 0) surfaceNotes.push('[-3 HP Astral Rift Burn]');
      if (fireSurfaceDmg > 0) surfaceNotes.push('[-4 HP Ignited Oil Pool + Burning]');
      if (brambleDmg > 0) surfaceNotes.push('[-3 HP Bramble Snare + Rooted]');
      if (sanctifiedHeal > 0) surfaceNotes.push('[+4 HP Sanctified Pool + Blessed]');
      if (runicMineDmg > 0) surfaceNotes.push('[-14 Arcane DMG + Rooted (Runic Mine Detonation!)]');
      if (astralRiftDmg > 0) surfaceNotes.push('[-4 Arcane DMG + Sundered (Astral Rift)]');
      if (isPrismaticField) {
        if (activeUnit.faction === 'party') {
          surfaceNotes.push('[+8 Temp HP & Warded (Prismatic Matrix)]');
        } else {
          surfaceNotes.push('[Sundered (Prismatic Distortion)]');
        }
      }

      setCombatBanner(
        `${activeUnit.name} moves to (${gx}, ${gz})${
          surfaceNotes.length > 0 ? ' ' + surfaceNotes.join(' ') : ''
        }.`
      );
    },
    [activeUnit, selectedAbilityKey, validMoveTiles, grid, units, envObjects, triggerParticles]
  );

  // Handle Player clicking a Unit (Select Party Member or Execute Ability on Target + Environmental Reactions)
  const handleUnitClick = useCallback(
    (targetUnitId: string) => {
      const clickedUnit = units.find((u) => u.id === targetUnitId);
      if (!clickedUnit || clickedUnit.isKO) return;

      if (!activeUnit || activeUnit.faction !== 'party') return;

      // If an ability is selected, attempt to cast/attack on clickedUnit
      if (selectedAbilityKey !== null) {
        const ability = activeUnit.abilities.find((a) => a.key === selectedAbilityKey);
        if (!ability) return;

        if (activeUnit.ap < ability.apCost) {
          setCombatBanner(`Not enough Action Points (${ability.apCost} AP required).`);
          return;
        }
        if ((activeUnit.cooldowns[ability.id] ?? 0) > 0) {
          setCombatBanner(`${ability.name} is on cooldown.`);
          return;
        }

        const dist = manhattanDistance(
          activeUnit.gridX,
          activeUnit.gridZ,
          clickedUnit.gridX,
          clickedUnit.gridZ
        );
        if (dist > ability.range) {
          setCombatBanner(
            `Target is ${dist} tiles away (${ability.name} has range ${ability.range}). Move closer first!`
          );
          return;
        }

        if (ability.targetType === 'enemy' && clickedUnit.faction !== 'enemy') {
          setCombatBanner('Select an enemy unit to attack.');
          return;
        }
        if (
          (ability.targetType === 'ally' || ability.targetType === 'self') &&
          clickedUnit.faction !== 'party'
        ) {
          setCombatBanner('Select a party companion to heal or buff.');
          return;
        }
        if (ability.targetType === 'self' && clickedUnit.id !== activeUnit.id) {
          setCombatBanner(`${ability.name} can only target ${activeUnit.name} directly.`);
          return;
        }
        if (ability.id === 'last_stand') {
          const cond = isLastStandConditionMet(activeUnit, units);
          if (!cond.allowed) {
            setCombatBanner(`${ability.name}: ${cond.reason}`);
            return;
          }
        }
        if (
          (ability.id === 'driving_assault' || ability.id === 'relentless_pursuit') &&
          activeUnit.statuses.some((s) => s.type === 'rooted') &&
          dist > 1
        ) {
          setCombatBanner(`${activeUnit.name} is Rooted and cannot dash or charge!`);
          return;
        }

        const res = resolveAbilityUse(
          activeUnit,
          clickedUnit,
          ability,
          units,
          relationships,
          worldState
        );
        pushDiceRollToast(buildCombatRollToast(activeUnit, clickedUnit, ability, res));
        setCombatAnimationEvent({
          id: Date.now() + Math.random(),
          attackerId: activeUnit.id,
          targetId: clickedUnit.id,
          targetGrid: [clickedUnit.gridX, clickedUnit.gridZ],
          skillId: ability.id,
          isMiss: !res.hit,
        });

        if (ability.targetType === 'ally' || ability.targetType === 'self') {
          soundEngine.playHealBless();
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            ability.element === 'arcane'
              ? 0xa855f7
              : ability.element === 'radiant'
              ? 0xfde047
              : 0x4ade80,
            18,
            false
          );
        } else if (ability.element === 'arcane') {
          soundEngine.playArcaneCast();
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            0xa855f7,
            res.critical ? 28 : 20,
            res.hit
          );
        } else if (ability.element === 'fire') {
          soundEngine.playArcaneCast();
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            0xf97316,
            res.critical ? 28 : 20,
            res.hit
          );
        } else if (ability.element === 'radiant') {
          soundEngine.playMeleeHit(true);
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            0xfde047,
            res.critical ? 28 : 22,
            res.hit
          );
        } else if (ability.element === 'nature') {
          soundEngine.playMeleeHit(res.critical || ability.apCost >= 2);
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            0x4ade80,
            res.critical ? 26 : 18,
            res.hit
          );
        } else {
          soundEngine.playMeleeHit(res.critical || ability.apCost >= 2);
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            0xf59e0b,
            res.critical ? 26 : 16,
            res.hit
          );
        }

        // Apply direct ability results first (including AP refund on KO, Temp HP, Affliction Cleanse, and Move Phase Reset)
        const unitsAfterDirectHit = units.map((u) => {
          let updated = { ...u };
          if (u.id === activeUnit.id) {
            const refund = res.hit ? res.apRefunded ?? 0 : 0;
            updated.ap = Math.min(updated.maxAp, Math.max(0, u.ap - ability.apCost + refund));
            if (ability.cooldown > 0) {
              updated.cooldowns = { ...u.cooldowns, [ability.id]: ability.cooldown };
            }
            if (res.hit && ability.id === 'ironwood_tempest' && (res.tempHpGranted ?? 0) > 0) {
              updated.tempHp = Math.max(updated.tempHp, res.tempHpGranted ?? 0);
            }
          }
          if (u.id === clickedUnit.id) {
            if (res.heal > 0) {
              updated.hp = Math.min(updated.maxHp, updated.hp + res.heal);
            }
            if (
              (ability.targetType === 'ally' || ability.targetType === 'self') &&
              (res.tempHpGranted ?? 0) > 0
            ) {
              updated.tempHp = Math.max(updated.tempHp, res.tempHpGranted ?? 0);
            }
            if (res.resetTargetMove) {
              updated.movedThisTurn = false;
            }
            if (res.damage > 0 && res.hit) {
              const absorbed = Math.min(updated.tempHp, res.damage);
              const hpDmg = Math.max(0, res.damage - absorbed);
              updated.tempHp = updated.tempHp - absorbed;
              updated.hp = Math.max(0, updated.hp - hpDmg);
              updated.isKO = updated.hp <= 0;
            }
            if ((ability.cleanseStatuses?.length ?? 0) > 0 && res.hit) {
              const cleanseSet = new Set(ability.cleanseStatuses);
              updated.statuses = updated.statuses.filter((s) => !cleanseSet.has(s.type as any));
            }
            if (res.statusApplied && res.hit) {
              updated.statuses = [
                ...updated.statuses.filter((s) => s.type !== res.statusApplied),
                { type: res.statusApplied as any, turnsLeft: 2 },
              ];
            }
          }
          return updated;
        });

        // Resolve Environmental Interactions on the target tile (e.g., Fire igniting oil pools, Push knocking unit back, Nature sprouting brambles)
        const envReaction =
          res.hit || ability.targetType !== 'enemy'
            ? resolveEnvironmentalInteraction(
                activeUnit,
                ability,
                clickedUnit.gridX,
                clickedUnit.gridZ,
                grid,
                envObjects,
                unitsAfterDirectHit,
                clickedUnit.id
              )
            : null;

        const totalDmgThisAction = res.damage + (envReaction?.bonusDamageDealt ?? 0);
        if (totalDmgThisAction > 0) {
          setTotalDamageDealt((d) => d + totalDmgThisAction);
        }

        if (envReaction && envReaction.triggeredEvents.length > 0) {
          setGrid(envReaction.updatedGrid);
          setEnvObjects(envReaction.updatedObjects);
          setUnits(envReaction.updatedUnits);
          setCombatBanner(`${res.summaryText} · ${envReaction.triggeredEvents.join(' ')}`);
        } else {
          setUnits(unitsAfterDirectHit);
          setCombatBanner(res.summaryText);
        }
        setSelectedAbilityKey(null);
        return;
      }

      // If no ability selected and player clicks another party companion, switch active party unit
      if (clickedUnit.faction === 'party') {
        setActiveUnitId(clickedUnit.id);
        setInspectedUnitId(clickedUnit.id);
        setCombatBanner(
          `Commanding ${clickedUnit.name} (${clickedUnit.ap}/${clickedUnit.maxAp} AP remaining).`
        );
        return;
      }

      // If no ability selected and player clicks an enemy within basic attack range, fire Ability 1 automatically!
      if (clickedUnit.faction === 'enemy') {
        setInspectedUnitId(clickedUnit.id);
        const primaryAbility =
          activeUnit.abilities.find((a) => a.key === '1') ?? activeUnit.abilities[0];
        const dist = manhattanDistance(
          activeUnit.gridX,
          activeUnit.gridZ,
          clickedUnit.gridX,
          clickedUnit.gridZ
        );
        if (
          primaryAbility &&
          primaryAbility.targetType === 'enemy' &&
          dist <= primaryAbility.range &&
          activeUnit.ap >= primaryAbility.apCost &&
          (activeUnit.cooldowns[primaryAbility.id] ?? 0) <= 0
        ) {
          setSelectedAbilityKey('1');
          // Immediately resolve primary strike
          const res = resolveAbilityUse(
            activeUnit,
            clickedUnit,
            primaryAbility,
            units,
            relationships,
            worldState
          );
          pushDiceRollToast(buildCombatRollToast(activeUnit, clickedUnit, primaryAbility, res));
          setCombatAnimationEvent({
            id: Date.now() + Math.random(),
            attackerId: activeUnit.id,
            targetId: clickedUnit.id,
            targetGrid: [clickedUnit.gridX, clickedUnit.gridZ],
            skillId: primaryAbility.id,
            isMiss: !res.hit,
          });
          soundEngine.playMeleeHit(res.critical);
          triggerParticles(
            clickedUnit.gridX,
            clickedUnit.gridZ,
            clickedUnit.elevation,
            0xf59e0b,
            res.critical ? 24 : 15,
            res.hit
          );

          const unitsAfterPrimary = units.map((u) => {
            if (u.id === activeUnit.id) {
              return {
                ...u,
                ap: Math.max(0, u.ap - primaryAbility.apCost),
                cooldowns:
                  primaryAbility.cooldown > 0
                    ? { ...u.cooldowns, [primaryAbility.id]: primaryAbility.cooldown }
                    : u.cooldowns,
              };
            }
            if (u.id === clickedUnit.id && res.hit) {
              const absorbed = Math.min(u.tempHp, res.damage);
              const hpDmg = Math.max(0, res.damage - absorbed);
              const newHp = Math.max(0, u.hp - hpDmg);
              return {
                ...u,
                tempHp: u.tempHp - absorbed,
                hp: newHp,
                isKO: newHp <= 0,
                statuses: res.statusApplied
                  ? [
                      ...u.statuses.filter((s) => s.type !== res.statusApplied),
                      { type: res.statusApplied as any, turnsLeft: 2 },
                    ]
                  : u.statuses,
              };
            }
            return u;
          });

          const envReaction = res.hit
            ? resolveEnvironmentalInteraction(
                activeUnit,
                primaryAbility,
                clickedUnit.gridX,
                clickedUnit.gridZ,
                grid,
                envObjects,
                unitsAfterPrimary,
                clickedUnit.id
              )
            : null;

          const totalDmg = res.damage + (envReaction?.bonusDamageDealt ?? 0);
          if (totalDmg > 0) setTotalDamageDealt((d) => d + totalDmg);

          if (envReaction && envReaction.triggeredEvents.length > 0) {
            setGrid(envReaction.updatedGrid);
            setEnvObjects(envReaction.updatedObjects);
            setUnits(envReaction.updatedUnits);
            setCombatBanner(`${res.summaryText} · ${envReaction.triggeredEvents.join(' ')}`);
          } else {
            setUnits(unitsAfterPrimary);
            setCombatBanner(res.summaryText);
          }
          setSelectedAbilityKey(null);
        } else {
          setCombatBanner(
            `${clickedUnit.name} (${clickedUnit.hp}/${clickedUnit.maxHp} HP · AC ${clickedUnit.armorClass}) — Move within ${primaryAbility.range} tiles or select a ranged ability [1-4].`
          );
        }
      }
    },
    [
      activeUnit,
      selectedAbilityKey,
      units,
      grid,
      envObjects,
      relationships,
      worldState,
      triggerParticles,
      pushDiceRollToast,
    ]
  );

  // Handle completing a Branching Narrative & D20 Skill Check choice
  const handleCompleteDialogueChoice = useCallback(
    (choice: DialogueChoice, rollResult: SkillCheckResult) => {
      // 1. Update Companion Approvals
      setRelationships((prev) => {
        const next = { ...prev };
        for (const [compId, delta] of Object.entries(choice.approvalDeltas)) {
          const id = compId as CompanionId;
          if (next[id] && delta) {
            next[id] = {
              ...next[id],
              approval: Math.max(0, Math.min(100, next[id].approval + delta)),
            };
          }
        }
        return next;
      });

      // 2. Apply World State Reactivity flags & alignment if check succeeded (or no check required)
      let updatedWorld = { ...worldState };
      if (rollResult.success) {
        const newFlags = new Set(updatedWorld.flags);
        choice.setWorldFlags?.forEach((f) => newFlags.add(f));
        updatedWorld = {
          ...updatedWorld,
          flags: Array.from(newFlags),
          corruptionLevel: Math.max(
            0,
            Math.min(100, updatedWorld.corruptionLevel + (choice.corruptionDelta ?? 0))
          ),
          oathAlignment: choice.alignmentShift ?? updatedWorld.oathAlignment,
          chronicleLog: [...updatedWorld.chronicleLog, choice.outcomeSummary],
        };
        setWorldState(updatedWorld);
        if (choice.setWorldFlags?.includes('sanctum_purified')) {
          setGrid(generateTacticalGrid(stageId, updatedWorld));
        }
      } else {
        updatedWorld = {
          ...updatedWorld,
          chronicleLog: [
            ...updatedWorld.chronicleLog,
            `Attempted ${choice.skillCheck?.skillName ?? 'Parley'} (${rollResult.total} vs DC ${rollResult.dc}) — Adversaries resisted.`,
          ],
        };
        setWorldState(updatedWorld);
      }

      // 3. Apply Combat Buffs / Enemy Debuffs on the live battlefield
      if (rollResult.success && choice.combatEffect) {
        setUnits((prev) =>
          prev.map((u) => {
            if (choice.combatEffect === 'bless_party' && u.faction === 'party') {
              return {
                ...u,
                hp: u.hp + 6,
                maxHp: u.maxHp + 6,
                statuses: [...u.statuses, { type: 'blessed', turnsLeft: 3 }],
              };
            }
            if (choice.combatEffect === 'heal_party' && u.faction === 'party') {
              return {
                ...u,
                hp: u.maxHp,
                statuses: [...u.statuses, { type: 'warded', turnsLeft: 3 }],
              };
            }
            if (choice.combatEffect === 'weaken_enemies' && u.faction === 'enemy') {
              return {
                ...u,
                hp: Math.max(10, u.hp - 6),
                statuses: [...u.statuses, { type: 'sundered', turnsLeft: 3 }],
              };
            }
            if (choice.combatEffect === 'empower_kaelen' && u.faction === 'party') {
              return {
                ...u,
                statuses: [
                  ...u.statuses.filter((s) => s.type !== 'blessed'),
                  { type: 'blessed', turnsLeft: 3 },
                ],
              };
            }
            return u;
          })
        );
      }

      setParleyCompletedStages((prev) => (prev.includes(stageId) ? prev : [...prev, stageId]));
      setActiveDialogueId(null);
      setCombatBanner(
        rollResult.success ? choice.outcomeSummary : 'Parley concluded — blades are drawn!'
      );
    },
    [worldState, stageId]
  );

  // =========================================================================
  // GLOAMREST SETTLEMENT HANDLERS (MOVEMENT, NPCS, OBJECTS, MERCHANTS & TIME)
  // =========================================================================

  const partyUnits = useMemo(
    () => units.filter((u) => u.faction === 'party'),
    [units]
  );

  // Sync live party unit statistics whenever equipped gear changes in Gloamrest
  const refreshPartyUnitsFromEquippedGear = useCallback(
    (equippedMap: GloamrestSaveState['inventory']['equippedByUnit']) => {
      const baseGrid = generateTacticalGrid(stageId, worldState);
      const baseEncounter = createEncounterUnits(stageId, worldState).map((u) => ({
        ...u,
        elevation: baseGrid[u.gridX]?.[u.gridZ]?.elevation ?? 0,
      }));
      const applied = applyCharacterBuildToParty(
        baseEncounter,
        relationshipsRef.current,
        characterBuildRef.current
      );
      const geared = applyEquippedGearToPartyUnits(applied.units, equippedMap);
      setUnits((prev) =>
        prev.map((existing) => {
          if (existing.faction !== 'party') return existing;
          const template = geared.find((g) => g.id === existing.id);
          if (!template) return existing;
          const hpRatio = existing.maxHp > 0 ? existing.hp / existing.maxHp : 1;
          return {
            ...existing,
            maxHp: template.maxHp,
            hp: Math.min(template.maxHp, Math.max(1, Math.round(hpRatio * template.maxHp))),
            armorClass: template.armorClass,
            stats: template.stats,
            abilities: template.abilities,
          };
        })
      );
    },
    [stageId, worldState]
  );

  const handleGloamrestPlayerMove = useCallback(
    (x: number, z: number, facingRad: number) => {
      setGloamrestState((prev) => {
        const res = movePlayerInGloamrest(prev, x, z, facingRad, gloamrestExteriorGrid);
        if (res.notifications.length > 0) {
          setGloamrestBanner(res.notifications.join(' · '));
        }
        return res.nextState;
      });
    },
    [gloamrestExteriorGrid]
  );

  const handleInteractTownNpc = useCallback((npcId: string) => {
    soundEngine.playFootstep();
    setActiveTownNpcId(npcId);
  }, []);

  const handleInteractTownObject = useCallback(
    (objectId: string) => {
      const current = gloamrestStateRef.current;
      const out = interactWithGloamrestObject(
        current,
        objectId,
        unitsRef.current,
        relationshipsRef.current,
        gloamrestExteriorGrid
      );

      if (out.nextState.currentSceneId !== current.currentSceneId) {
        soundEngine.playDoorTransition();
        setNearbyPrompt(null);
      } else if (
        out.nextState.lootedOrHarvestedIds.length > current.lootedOrHarvestedIds.length
      ) {
        if (objectId.includes('herb')) {
          soundEngine.playGatherHerb();
        } else {
          soundEngine.playCoinTrade();
        }
      } else {
        soundEngine.playFootstep();
      }

      if (out.healPartyFull) {
        soundEngine.playHealBless();
        setUnits((prev) =>
          prev.map((u) =>
            u.faction === 'party'
              ? { ...u, hp: u.maxHp, ap: u.maxAp, isKO: false, statuses: [], cooldowns: {} }
              : u
          )
        );
      }

      if (out.skillCheckResult) {
        soundEngine.playDiceRoll(out.skillCheckResult.result.critical);
        const syntheticChoice: DialogueChoice = {
          id: objectId,
          text: out.skillCheckResult.label,
          skillCheck: {
            stat: objectId.includes('manor') ? 'dex' : 'int',
            skillName: objectId.includes('manor') ? 'Insight' : 'Arcana',
            dc: out.skillCheckResult.result.dc,
            speakerId: objectId.includes('manor') ? 'thorne' : 'kaelen',
          },
          approvalDeltas: {},
          nextNodeId: 'END_PEACEFUL_BUFF',
          outcomeSummary: out.bannerMessage,
        };
        pushDiceRollToast(
          buildSkillCheckRollToast(
            syntheticChoice,
            out.skillCheckResult.result,
            relationshipsRef.current
          )
        );
      }

      setGloamrestState(out.nextState);
      saveGloamrestStateToStorage(out.nextState);
      setGloamrestBanner(out.bannerMessage);

      if (out.lorePopup) {
        setLorePopupModal({
          title: out.lorePopup.title,
          text: out.lorePopup.text,
        });
      }
      if (out.triggerAction === 'prompt_wilderness_gate') {
        setShowWildernessGateModal(true);
      } else if (out.triggerAction === 'start_outskirts_combat') {
        startOutskirtsEncounter();
      } else if (out.triggerAction === 'depart_act1_sanctum') {
        departToActOneSanctum();
      }
    },
    [gloamrestExteriorGrid, pushDiceRollToast, startOutskirtsEncounter, departToActOneSanctum]
  );

  const handleTriggerNearbyInteract = useCallback(() => {
    if (!nearbyPrompt) return;
    if (nearbyPrompt.kind === 'npc') {
      handleInteractTownNpc(nearbyPrompt.id);
    } else {
      handleInteractTownObject(nearbyPrompt.id);
    }
  }, [nearbyPrompt, handleInteractTownNpc, handleInteractTownObject]);

  const activeTownDialogue = useMemo(() => {
    if (!activeTownNpcId) return null;
    return buildGloamrestNpcDialogue(
      activeTownNpcId,
      gloamrestState,
      characterBuild,
      worldState
    );
  }, [activeTownNpcId, gloamrestState, characterBuild, worldState]);

  const handleSelectTownDialogueChoice = useCallback(
    (choice: TownDialogueChoice) => {
      if (!activeTownNpcId) {
        return { replyText: '', closesDialogue: true };
      }
      const res = resolveTownDialogueChoice(
        gloamrestStateRef.current,
        activeTownNpcId,
        choice,
        unitsRef.current,
        relationshipsRef.current
      );

      setGloamrestState(res.nextState);
      saveGloamrestStateToStorage(res.nextState);

      if (res.skillCheckResult && choice.skillCheck) {
        soundEngine.playDiceRoll(res.skillCheckResult.critical);
        const syntheticChoice: DialogueChoice = {
          id: choice.id,
          text: choice.text,
          skillCheck: {
            stat: choice.skillCheck.stat,
            skillName: choice.skillCheck.skillName,
            dc: res.skillCheckResult.dc,
            speakerId: choice.skillCheck.speakerId,
          },
          approvalDeltas: res.approvalDeltas ?? {},
          nextNodeId: 'END_PEACEFUL_BUFF',
          outcomeSummary: res.replyText,
        };
        pushDiceRollToast(
          buildSkillCheckRollToast(
            syntheticChoice,
            res.skillCheckResult,
            relationshipsRef.current
          )
        );
      }

      if (res.approvalDeltas) {
        setRelationships((prev) => {
          const next = { ...prev };
          for (const [compId, delta] of Object.entries(res.approvalDeltas!)) {
            const id = compId as CompanionId;
            if (next[id] && delta) {
              next[id] = {
                ...next[id],
                approval: Math.max(0, Math.min(100, next[id].approval + delta)),
              };
            }
          }
          return next;
        });
      }

      if (res.oathShift || res.chronicleNote) {
        setWorldState((prev) => ({
          ...prev,
          oathAlignment: res.oathShift ?? prev.oathAlignment,
          chronicleLog: res.chronicleNote
            ? [...prev.chronicleLog, res.chronicleNote]
            : prev.chronicleLog,
        }));
      }

      if (res.healPartyFull) {
        soundEngine.playHealBless();
        setUnits((prev) =>
          prev.map((u) =>
            u.faction === 'party'
              ? { ...u, hp: u.maxHp, ap: u.maxAp, isKO: false, statuses: [], cooldowns: {} }
              : u
          )
        );
      }

      if (res.notifications.length > 0) {
        setGloamrestBanner(res.notifications.join(' · '));
      }

      if (res.openMerchantId) {
        setActiveTownNpcId(null);
        setActiveMerchantId(res.openMerchantId);
        setMerchantNotice(null);
        setShowTownInventoryModal(true);
      } else if (res.triggerAction === 'start_training_drill') {
        setActiveTownNpcId(null);
        setLorePopupModal({
          title: 'Captain Roderic’s Tactical Combat Briefing',
          text: 'Before stepping past Whispering Gate, ensure your party commands the fundamentals of DIMRAETH tactical combat. Would you like to step into a non-lethal Watch Barracks sparring bout right now?',
          isTrainingDrill: true,
        });
      } else if (res.triggerAction === 'start_sparring_combat') {
        startBarracksSparring();
      } else if (res.triggerAction === 'start_outskirts_combat') {
        startOutskirtsEncounter();
      } else if (res.triggerAction === 'depart_act1_sanctum') {
        departToActOneSanctum();
      } else if (res.closesDialogue && !res.skillCheckResult) {
        setActiveTownNpcId(null);
      }

      return {
        replyText: res.replyText,
        skillCheckResult: res.skillCheckResult,
        closesDialogue: res.closesDialogue,
      };
    },
    [
      activeTownNpcId,
      pushDiceRollToast,
      startBarracksSparring,
      startOutskirtsEncounter,
      departToActOneSanctum,
    ]
  );

  const handleAdvanceWatchTime = useCallback(() => {
    setGloamrestState((prev) => {
      const { nextPhase, wrappedNewDay } = getNextTimeOfDay(prev.timeOfDay);
      const next: GloamrestSaveState = {
        ...prev,
        timeOfDay: nextPhase,
        dayCount: prev.dayCount + (wrappedNewDay ? 1 : 0),
      };
      saveGloamrestStateToStorage(next);
      setGloamrestBanner(
        `Time advanced to ${nextPhase.toUpperCase()} (Day ${next.dayCount}) — Villagers and Watch patrols shifted to their ${nextPhase} schedules.`
      );
      return next;
    });
    soundEngine.playFootstep();
  }, []);

  const handleBuyMerchantItem = useCallback((merchantId: MerchantId, itemId: string) => {
    const res = buyFromMerchant(gloamrestStateRef.current, merchantId, itemId);
    setGloamrestState(res.nextState);
    saveGloamrestStateToStorage(res.nextState);
    setMerchantNotice(res.message);
    if (res.ok) {
      soundEngine.playCoinTrade();
      setGloamrestBanner(res.message);
    }
  }, []);

  const handleSellMerchantItem = useCallback((merchantId: MerchantId, itemId: string) => {
    const res = sellToMerchant(gloamrestStateRef.current, merchantId, itemId);
    setGloamrestState(res.nextState);
    saveGloamrestStateToStorage(res.nextState);
    setMerchantNotice(res.message);
    if (res.ok) {
      soundEngine.playCoinTrade();
      setGloamrestBanner(res.message);
    }
  }, []);

  const handleEquipTownItem = useCallback(
    (unitId: string, itemId: string) => {
      const res = equipItemOnPartyMember(gloamrestStateRef.current, unitId, itemId);
      setGloamrestState(res.nextState);
      saveGloamrestStateToStorage(res.nextState);
      setMerchantNotice(res.message);
      if (res.ok) {
        soundEngine.playFootstep();
        refreshPartyUnitsFromEquippedGear(res.nextState.inventory.equippedByUnit);
        setGloamrestBanner(res.message);
      }
    },
    [refreshPartyUnitsFromEquippedGear]
  );

  const handleUseTownConsumable = useCallback((itemId: string, unitId: string) => {
    const res = useConsumableFromInventory(
      gloamrestStateRef.current,
      itemId,
      unitId,
      unitsRef.current
    );
    setGloamrestState(res.nextState);
    saveGloamrestStateToStorage(res.nextState);
    setUnits(res.updatedUnits);
    setMerchantNotice(res.message);
    if (res.ok) {
      soundEngine.playHealBless();
      setGloamrestBanner(res.message);
    }
  }, []);

  const handleRepairEquipment = useCallback(() => {
    const res = repairPartyEquipment(gloamrestStateRef.current, 8);
    setGloamrestState(res.nextState);
    saveGloamrestStateToStorage(res.nextState);
    setMerchantNotice(res.message);
    if (res.ok) {
      soundEngine.playCoinTrade();
      setGloamrestBanner(res.message);
    }
  }, []);

  const handleRentTavernRoomRest = useCallback(() => {
    const cur = gloamrestStateRef.current;
    if (cur.inventory.gold < 10) {
      setMerchantNotice('Renting a room at the Wandering Stag requires 10 Gold.');
      return;
    }
    const { nextPhase, wrappedNewDay } = getNextTimeOfDay(cur.timeOfDay);
    const rested: GloamrestSaveState = {
      ...cur,
      timeOfDay: nextPhase,
      dayCount: cur.dayCount + (wrappedNewDay ? 1 : 0),
      inventory: {
        ...cur.inventory,
        gold: cur.inventory.gold - 10,
      },
    };
    const qUpd =
      rested.quests.mq04_road_to_whispering_vale.status === 'active'
        ? applyQuestStepUpdates(rested, [
            { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
          ])
        : { nextState: rested };
    setGloamrestState(qUpd.nextState);
    saveGloamrestStateToStorage(qUpd.nextState);
    setUnits((prev) =>
      prev.map((u) =>
        u.faction === 'party'
          ? { ...u, hp: u.maxHp, ap: u.maxAp, isKO: false, statuses: [], cooldowns: {} }
          : u
      )
    );
    soundEngine.playHealBless();
    const msg = `Rested in the Wandering Stag (-10g). Party HP restored; it is now ${nextPhase.toUpperCase()}.`;
    setMerchantNotice(msg);
    setGloamrestBanner(msg);
  }, []);

  const isAnyTownModalOpen =
    Boolean(activeTownNpcId) ||
    showTownMapModal ||
    showTownInventoryModal ||
    showTownQuestModal ||
    showWildernessGateModal ||
    showTowerModal ||
    Boolean(towerBattleSummary) ||
    Boolean(lorePopupModal) ||
    showSkillMenu ||
    showSkillTreeModal ||
    Boolean(levelUpData) ||
    showCampModal ||
    showChronicleModal ||
    showInspectPanel;

  // Handle equipping / swapping unlocked abilities in the Tactical Skill Menu without consuming AP or advancing the turn
  const handleAssignSkillToSlot = useCallback(
    (
      targetUnitId: string,
      catalogEntry: UnitSkillCatalogEntry,
      slotKey: '1' | '2' | '3' | '4'
    ) => {
      setUnits((prev) =>
        prev.map((u) => {
          if (u.id !== targetUnitId) return u;
          const res = assignUnitSkillToSlot(u, catalogEntry, slotKey);
          return res.changed ? res.updatedUnit : u;
        })
      );
      setSelectedAbilityKey(null);
      soundEngine.playFootstep();
      setCombatBanner(
        `Assigned ${catalogEntry.ability.name} to Slot [${slotKey}] (0 AP cost).`
      );
      setGloamrestBanner(
        `Assigned ${catalogEntry.ability.name} to Slot [${slotKey}].`
      );
    },
    []
  );

  // Global Keyboard Shortcuts (Title Start, Abilities 1-4, K Skill Menu, Space End Turn, I Inspect, E Parley, C Camp, J Chronicle, H Collapse, P/Esc Pause)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        if (e.code === 'Escape') {
          e.target.blur();
        }
        return;
      }

      if (gameState === 'title') {
        if (e.code === 'Enter' || e.code === 'Space') {
          e.preventDefault();
          startNewExpedition();
        }
        return;
      }

      if (e.code === 'F5') {
        e.preventDefault();
        handleSaveAdventure();
        return;
      }

      if (e.code === 'Escape') {
        if (showTowerModal) {
          setShowTowerModal(false);
          return;
        }
        if (towerBattleSummary) {
          setTowerBattleSummary(null);
          return;
        }
        if (showSkillTreeModal) {
          setShowSkillTreeModal(false);
          return;
        }
        if (levelUpData) {
          setLevelUpData(null);
          return;
        }
        if (activeTownNpcId) {
          setActiveTownNpcId(null);
          return;
        }
        if (lorePopupModal) {
          setLorePopupModal(null);
          return;
        }
        if (showWildernessGateModal) {
          setShowWildernessGateModal(false);
          return;
        }
        if (showTownInventoryModal) {
          setShowTownInventoryModal(false);
          setActiveMerchantId(null);
          return;
        }
        if (showTownMapModal) {
          setShowTownMapModal(false);
          return;
        }
        if (showTownQuestModal) {
          setShowTownQuestModal(false);
          return;
        }
        if (activeDialogueId) {
          setActiveDialogueId(null);
          return;
        }
        if (showSkillMenu) {
          setShowSkillMenu(false);
          return;
        }
        if (showCampModal) {
          setShowCampModal(false);
          return;
        }
        if (showChronicleModal) {
          setShowChronicleModal(false);
          return;
        }
        if (showInspectPanel) {
          setShowInspectPanel(false);
          return;
        }
        if (selectedAbilityKey) {
          setSelectedAbilityKey(null);
          return;
        }
        setGameState((prev) => (prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev));
        return;
      }

      if (
        e.code === 'KeyP' &&
        !activeDialogueId &&
        !isAnyTownModalOpen
      ) {
        setGameState((prev) => (prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev));
        return;
      }

      if (gameState !== 'playing') return;

      // -------------------- GLOAMREST EXPLORATION SHORTCUTS --------------------
      if (playSubMode === 'gloamrest') {
        if (e.code === 'KeyM' && !activeTownNpcId) {
          e.preventDefault();
          setShowTownMapModal((v) => !v);
          return;
        }
        if (e.code === 'KeyB' && !activeTownNpcId) {
          e.preventDefault();
          setActiveMerchantId(null);
          setMerchantNotice(null);
          setShowTownInventoryModal((v) => !v);
          return;
        }
        if (e.code === 'KeyJ' && !activeTownNpcId) {
          e.preventDefault();
          setShowTownQuestModal((v) => !v);
          return;
        }
        if (e.code === 'KeyK' && !activeTownNpcId) {
          e.preventDefault();
          setShowSkillTreeModal((v) => !v);
          return;
        }
        if (e.code === 'KeyT' && !activeTownNpcId) {
          e.preventDefault();
          setShowTowerModal((v) => !v);
          return;
        }
        if (e.code === 'KeyC' && !activeTownNpcId) {
          e.preventDefault();
          setShowCampModal((v) => !v);
          return;
        }
        if (e.code === 'KeyI' && !activeTownNpcId) {
          e.preventDefault();
          if (!showInspectPanel) {
            setInspectedUnitId(partyUnits[0]?.id ?? null);
            setShowInspectPanel(true);
          } else {
            setShowInspectPanel(false);
          }
          return;
        }
        if (e.code === 'KeyE' && !isAnyTownModalOpen) {
          e.preventDefault();
          handleTriggerNearbyInteract();
          return;
        }
        return;
      }

      // -------------------- TACTICAL COMBAT SHORTCUTS --------------------
      if (activeDialogueId || showCampModal || showChronicleModal) return;

      if (e.code === 'KeyK') {
        e.preventDefault();
        setShowSkillTreeModal((open) => !open);
        return;
      }

      if (e.code === 'KeyT') {
        e.preventDefault();
        setShowTowerModal((open) => !open);
        return;
      }

      if (showSkillMenu || showSkillTreeModal || showTowerModal) return;

      const hotkeyMap: Record<string, '1' | '2' | '3' | '4'> = {
        Digit1: '1',
        Digit2: '2',
        Digit3: '3',
        Digit4: '4',
      };
      const pressedSlot = hotkeyMap[e.code];
      if (pressedSlot && activeUnit) {
        const slotAb = activeUnit.abilities.find((a) => a.key === pressedSlot);
        if (slotAb) {
          const evalRes = evaluateSkillSlotState(
            activeUnit,
            slotAb,
            units,
            grid,
            envObjects,
            { isSelected: selectedAbilityKey === pressedSlot }
          );
          if (!evalRes.canSelect) {
            if (evalRes.restrictionReason) {
              setCombatBanner(evalRes.restrictionReason);
            }
            return;
          }
          if (slotAb.targetType === 'self' && selectedAbilityKey === pressedSlot) {
            handleUnitClick(activeUnit.id);
            return;
          }
          setSelectedAbilityKey((cur) => {
            const next = cur === pressedSlot ? null : pressedSlot;
            if (next !== null && evalRes.state === 'out_of_range' && evalRes.restrictionReason) {
              setCombatBanner(evalRes.restrictionReason);
            }
            return next;
          });
        }
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        if (activeUnit?.faction === 'party') {
          advanceTurn();
        }
      }
      if (e.code === 'KeyI') {
        e.preventDefault();
        const candidateId = hoverInfo?.unitId ?? inspectedUnitId ?? activeUnit?.id ?? units[0]?.id ?? null;
        if (!showInspectPanel) {
          setInspectedUnitId(candidateId);
          setShowInspectPanel(true);
        } else if (hoverInfo?.unitId && hoverInfo.unitId !== inspectedUnitId) {
          setInspectedUnitId(hoverInfo.unitId);
        } else {
          setShowInspectPanel(false);
        }
      }
      if (e.code === 'KeyE') {
        setActiveDialogueId(STAGES[stageId].introNodeId);
      }
      if (e.code === 'KeyC') {
        setShowCampModal(true);
      }
      if (e.code === 'KeyJ') {
        setShowChronicleModal(true);
      }
      if (e.code === 'KeyH') {
        setHudCollapsed((c) => !c);
      }
      if (e.code === 'KeyM') {
        soundEngine.setMuted(!soundEngine.muted);
        setIsMuted(soundEngine.muted);
      }
      if (e.code === 'KeyR') {
        loadEncounterStage(stageId, worldState);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    gameState,
    playSubMode,
    activeTownNpcId,
    lorePopupModal,
    showWildernessGateModal,
    showTownInventoryModal,
    showTownMapModal,
    showTownQuestModal,
    isAnyTownModalOpen,
    partyUnits,
    activeDialogueId,
    showCampModal,
    showChronicleModal,
    showSkillMenu,
    showInspectPanel,
    inspectedUnitId,
    hoverInfo?.unitId,
    selectedAbilityKey,
    activeUnit,
    units,
    grid,
    envObjects,
    stageId,
    worldState,
    startNewExpedition,
    advanceTurn,
    loadEncounterStage,
    handleSaveAdventure,
    handleTriggerNearbyInteract,
  ]);

  const inspectedUnit = useMemo(() => {
    if (inspectedUnitId) {
      const found = units.find((u) => u.id === inspectedUnitId && !u.isKO);
      if (found) return found;
    }
    return activeUnit ?? units[0];
  }, [inspectedUnitId, units, activeUnit]);

  const hoveredUnit = useMemo(
    () => (hoverInfo?.unitId ? units.find((u) => u.id === hoverInfo.unitId) : undefined),
    [hoverInfo, units]
  );

  const hoveredEnvDescription = useMemo(() => {
    if (!hoverInfo?.tile) return null;
    const { x, z } = hoverInfo.tile;
    const obj = envObjects.find((o) => !o.destroyed && o.gridX === x && o.gridZ === z);
    const tile = grid[x]?.[z];
    const surface = tile?.surface ?? 'none';
    const parts: string[] = [];
    if (obj) {
      parts.push(
        `${obj.name} (${x}, ${z}) [${
          obj.kind === 'oil_barrel'
            ? 'Flammable Cask · Shove or Ignite'
            : obj.kind === 'runic_brazier'
            ? 'Fire Brazier · Shove or Detonate'
            : 'Heavy Monolith · Shove onto Rifts or Foes'
        }]`
      );
    }
    if (surface === 'oil_pool') {
      parts.push(`Oil Pool (${x}, ${z}) [Ignites on Fire abilities]`);
    } else if (surface === 'fire_pool') {
      parts.push(`Blazing Surface (${x}, ${z}) [4 Fire DMG + Burning]`);
    } else if (surface === 'bramble_snare') {
      parts.push(`Bramble Snare (${x}, ${z}) [3 Nature DMG + Rooted]`);
    } else if (surface === 'sanctified_pool') {
      parts.push(`Sanctified Ground (${x}, ${z}) [+4 HP + Blessed]`);
    } else if (tile?.terrain === 'hazard_rift') {
      parts.push(`Astral Rift (${x}, ${z}) [3 DMG · Push Runestone to Seal or Purify]`);
    }
    return parts.length > 0 ? parts.join(' · ') : null;
  }, [hoverInfo, envObjects, grid]);

  return (
    <main className="relative w-screen h-screen overflow-hidden select-none bg-[#0b0a0e]">
      {/* 1A. Full-Viewport 3D Gloamrest Settlement & Walkable Interiors (`playSubMode === 'gloamrest'`) */}
      {playSubMode === 'gloamrest' ? (
        <GloamrestWorld3D
          gloamrestState={gloamrestState}
          characterBuild={characterBuild}
          cameraPreset={cameraPreset}
          isUiModalOpen={gameState !== 'playing' || isAnyTownModalOpen}
          onPlayerMove={handleGloamrestPlayerMove}
          onInteractNpc={handleInteractTownNpc}
          onInteractObject={handleInteractTownObject}
          onNearbyPromptChange={setNearbyPrompt}
        />
      ) : (
        /* 1B. Full-Viewport 3D Tactical Combat Arena (`playSubMode === 'combat'`) */
        <TacticalArena3D
          gameState={gameState}
          stageId={stageId}
          grid={grid}
          units={units}
          envObjects={envObjects}
          activeUnitId={activeUnit?.id ?? ''}
          selectedAbilityKey={selectedAbilityKey}
          validMoveTiles={validMoveTiles}
          worldState={worldState}
          cameraPreset={cameraPreset}
          burstEvent={burstEvent}
          combatAnimationEvent={combatAnimationEvent}
          onTileClick={handleTileClick}
          onUnitClick={handleUnitClick}
          onHoverChange={setHoverInfo}
        />
      )}

      {/* 2. START-UP MENU & CHARACTER CREATION OVERLAY (`document.body.dataset.state === 'title'`) */}
      {gameState === 'title' && (
        <StartupMenuOverlay
          characterBuild={characterBuild}
          onChangeCharacterBuild={setCharacterBuild}
          originChoice={originChoice}
          onChangeOriginChoice={setOriginChoice}
          selectedStageId={stageId}
          onChangeStageId={setStageId}
          onStartExpedition={() => startNewExpedition(false)}
          onStartWithParley={() => {
            startNewExpedition(true);
            setActiveDialogueId(STAGES[stageId].introNodeId);
          }}
          onLoadSavedSlot={handleLoadSavedSlot}
        />
      )}

      {/* 2B. GLOAMREST EXPLORATION HUD & TOWN MODALS (`playSubMode === 'gloamrest'`) */}
      {gameState === 'playing' && playSubMode === 'gloamrest' && (
        <>
          <GloamrestHudOverlay
            gloamrestState={gloamrestState}
            partyUnits={partyUnits}
            nearbyPrompt={nearbyPrompt}
            bannerMessage={gloamrestBanner}
            cameraPreset={cameraPreset}
            isMuted={isMuted}
            onSetCameraPreset={setCameraPreset}
            onTriggerNearbyInteract={handleTriggerNearbyInteract}
            onAdvanceWatchTime={handleAdvanceWatchTime}
            onOpenMap={() => setShowTownMapModal(true)}
            onOpenInventory={() => {
              setActiveMerchantId(null);
              setMerchantNotice(null);
              setShowTownInventoryModal(true);
            }}
            onOpenQuestJournal={() => setShowTownQuestModal(true)}
            onOpenSkillMenu={() => setShowSkillTreeModal(true)}
            onOpenTower={() => setShowTowerModal(true)}
            onOpenCamp={() => setShowCampModal(true)}
            onOpenInspect={() => {
              setInspectedUnitId(partyUnits[0]?.id ?? null);
              setShowInspectPanel(true);
            }}
            onQuickSave={handleSaveAdventure}
            onToggleMute={() => {
              soundEngine.setMuted(!soundEngine.muted);
              setIsMuted(soundEngine.muted);
            }}
            onPause={() => setGameState('paused')}
          />

          {showTownMapModal && (
            <GloamrestMapModal
              gloamrestState={gloamrestState}
              onClose={() => setShowTownMapModal(false)}
            />
          )}

          {activeTownDialogue && (
            <GloamrestDialogueModal
              dialogue={activeTownDialogue}
              partyUnits={partyUnits}
              relationships={relationships}
              onSelectChoice={handleSelectTownDialogueChoice}
              onClose={() => setActiveTownNpcId(null)}
            />
          )}

          {showTownInventoryModal && (
            <GloamrestInventoryAndMerchantModal
              gloamrestState={gloamrestState}
              activeMerchantId={activeMerchantId}
              partyUnits={partyUnits}
              characterBuild={characterBuild}
              statusNotice={merchantNotice}
              onBuyItem={handleBuyMerchantItem}
              onSellItem={handleSellMerchantItem}
              onEquipItem={handleEquipTownItem}
              onUseConsumable={handleUseTownConsumable}
              onRepairAll={handleRepairEquipment}
              onRentRoomRest={handleRentTavernRoomRest}
              onClose={() => {
                setShowTownInventoryModal(false);
                setActiveMerchantId(null);
              }}
            />
          )}

          {showTownQuestModal && (
            <GloamrestQuestJournalModal
              gloamrestState={gloamrestState}
              onTrackQuest={(qId) =>
                setGloamrestState((prev) => ({ ...prev, activeTrackedQuestId: qId }))
              }
              onOpenWorldChronicle={() => {
                setShowTownQuestModal(false);
                setShowChronicleModal(true);
              }}
              onClose={() => setShowTownQuestModal(false)}
            />
          )}

          {showWildernessGateModal && (
            <WildernessGateModal
              gloamrestState={gloamrestState}
              onStartOutskirtsCombat={startOutskirtsEncounter}
              onDepartActOneSanctum={departToActOneSanctum}
              onOpenTower={() => setShowTowerModal(true)}
              onClose={() => setShowWildernessGateModal(false)}
            />
          )}

          {lorePopupModal && (
            <LoreAndTutorialModal
              title={lorePopupModal.title}
              text={lorePopupModal.text}
              isTrainingDrill={lorePopupModal.isTrainingDrill}
              onStartSparring={startBarracksSparring}
              onClose={() => setLorePopupModal(null)}
            />
          )}
        </>
      )}

      {/* 3. TACTICAL COMBAT PLAYING HUD OVERLAY (`playSubMode === 'combat'`) */}
      {gameState === 'playing' && playSubMode === 'combat' && (
        <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4">
          {/* Top Perimeter Row: Left Initiative & World Cluster + Right Utility Controls */}
          <div className="flex items-start justify-between gap-4">
            {/* Top-Left Cluster: Stage, Round, World State, Dynamic Theme & Initiative Ribbon */}
            <div
              className="pointer-events-auto rounded-xl border border-amber-500/35 px-4 py-2.5 shadow-xl max-w-2xl"
              style={{ backgroundColor: 'rgba(13, 11, 20, 0.93)' }}
            >
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                <span className="font-display font-bold text-amber-200 whitespace-nowrap">
                  {STAGES[stageId].name}
                </span>
                <span aria-hidden="true" className="text-stone-600">·</span>
                <span className="font-mono tabular-nums text-amber-400 font-semibold whitespace-nowrap">
                  Round {roundNumber}
                </span>
                <span aria-hidden="true" className="text-stone-600">·</span>
                <span className="text-stone-300 whitespace-nowrap">
                  Oath: {worldState.oathAlignment}
                </span>
                <span aria-hidden="true" className="text-stone-600">·</span>
                <span
                  data-testid="combat-theme-indicator"
                  className={`font-mono whitespace-nowrap ${
                    tacticalAdvantage.state === 'party_ascendant'
                      ? 'text-emerald-300'
                      : tacticalAdvantage.state === 'enemy_dominance'
                      ? 'text-rose-400'
                      : 'text-amber-300'
                  }`}
                  title={`Dynamic Combat Theme: ${tacticalAdvantage.themeTitle} (${tacticalAdvantage.shortLabel})`}
                >
                  ♪ {tacticalAdvantage.themeTitle} ({tacticalAdvantage.shortLabel})
                </span>
              </div>

              {/* Compact Initiative Order Portraits */}
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="text-[11px] uppercase tracking-wider text-stone-400 font-mono mr-1">
                  Turn Order
                </span>
                {initiativeRibbonEntries.map(({ unit: u, collapseState }) => {
                  const isCollapsing = collapseState === 'collapsing';
                  const isCurrent = !isCollapsing && u.id === activeUnit?.id;
                  const statusSummary =
                    u.statuses.length > 0
                      ? ` · ${u.statuses
                          .map((s) => `${STATUS_EFFECT_META[s.type]?.label ?? s.type} (${s.turnsLeft}t)`)
                          .join(', ')}`
                      : '';
                  return (
                    <button
                      key={u.id}
                      type="button"
                      disabled={isCollapsing}
                      data-testid={`initiative-unit-${u.id}`}
                      data-active-turn={isCurrent ? 'true' : 'false'}
                      data-collapse-state={collapseState}
                      aria-current={isCurrent ? 'step' : undefined}
                      onClick={() => handleUnitClick(u.id)}
                      aria-label={`${u.name} (${
                        isCollapsing ? '0 HP · Collapsing to Dust' : `${Math.round(u.hp)} HP`
                      }${isCurrent ? ' · Active Turn' : ''}${statusSummary})`}
                      className={`relative flex items-center gap-1.5 px-2 py-1 rounded border transition-colors hover:z-30 ${
                        isCollapsing
                          ? 'border-rose-500/80 bg-stone-950/90 unit-collapse-dust-anim'
                          : isCurrent
                          ? 'border-amber-300 bg-amber-500/25 active-turn-slot-pulse z-10'
                          : u.faction === 'party'
                          ? 'border-stone-700 bg-stone-900/90 hover:border-amber-500/50'
                          : 'border-rose-900/70 bg-rose-950/60 hover:border-rose-500/60'
                      }`}
                    >
                      <div
                        data-testid={`initiative-portrait-${u.id}`}
                        className={`relative shrink-0 rounded ${
                          isCurrent ? 'active-turn-portrait-pulse ring-1 ring-amber-300/90' : ''
                        }`}
                      >
                        <CharacterPortraitSvg
                          id={u.companionId ?? u.archetype ?? 'inquisitor'}
                          className="w-6 h-6 rounded shrink-0"
                        />
                        {isCurrent && (
                          <span
                            data-testid="active-turn-pip"
                            aria-hidden="true"
                            className="absolute -top-1 -left-1 w-2 h-2 rounded-sm rotate-45 bg-amber-300 border border-stone-950 shadow"
                          />
                        )}
                        {isCollapsing && (
                          <span
                            data-testid={`initiative-ko-dust-${u.id}`}
                            className="absolute inset-0 flex items-center justify-center rounded bg-stone-950/75 text-[9px] font-mono font-bold text-rose-300 tracking-tighter"
                          >
                            KO
                          </span>
                        )}
                        {!isCollapsing && u.statuses.length > 0 && (
                          <span
                            data-testid={`initiative-status-badge-${u.id}`}
                            className="absolute -bottom-1 -right-1.5 flex items-center gap-0.5 px-0.5 rounded bg-stone-950/95 border border-stone-700/80 shadow"
                          >
                            {u.statuses.map((s, sIdx) => (
                              <StatusEffectIconSvg
                                key={`${s.type}-${sIdx}`}
                                type={s.type}
                                turnsLeft={s.turnsLeft}
                                tooltipPlacement="bottom"
                                testId={`initiative-status-icon-${u.id}-${s.type}`}
                                className="w-3.5 h-3.5"
                              />
                            ))}
                          </span>
                        )}
                      </div>
                      <span
                        className={`text-xs font-mono tabular-nums ml-0.5 ${
                          isCollapsing
                            ? 'text-rose-400 line-through'
                            : isCurrent
                            ? 'text-amber-100 font-bold'
                            : 'text-stone-200'
                        }`}
                      >
                        {isCollapsing ? 0 : Math.round(u.hp)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Top-Right Compact Utility Icon/Action Cluster */}
            <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
              <div
                className="hidden xl:flex items-center gap-0.5 p-1 rounded-md border border-[#5A4B38]"
                style={{ backgroundColor: '#171B19' }}
                role="group"
                aria-label="Fixed Isometric Scale"
              >
                {(
                  [
                    { id: 'tactical', label: 'ISO 1x' },
                    { id: 'close', label: 'Zoom' },
                    { id: 'overhead', label: 'Wide' },
                  ] as const
                ).map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    tabIndex={-1}
                    onClick={(e) => {
                      e.currentTarget.blur();
                      setCameraPreset(preset.id);
                    }}
                    style={{
                      backgroundColor: cameraPreset === preset.id ? '#3A3324' : 'transparent',
                      color: cameraPreset === preset.id ? '#E2B05A' : '#B5AC9A',
                    }}
                    className="px-2 py-1 text-[11px] font-mono rounded transition-colors whitespace-nowrap cursor-pointer hover:text-[#F2ECE1]"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  setPlaySubMode('gloamrest');
                  setCombatContext('campaign');
                }}
                className="px-3 py-2 rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-semibold text-[#7E9C82] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                style={{ backgroundColor: '#171B19' }}
              >
                ← Gloamrest
              </button>

              {combatContext === 'campaign' && (
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    setActiveDialogueId(STAGES[stageId].introNodeId);
                  }}
                  className="px-3 py-2 rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-semibold text-[#E2B05A] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  style={{ backgroundColor: '#171B19' }}
                >
                  Parley [E]
                </button>
              )}

              <button
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  setShowCampModal(true);
                }}
                className="px-3 py-2 rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-semibold text-[#F2ECE1] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                style={{ backgroundColor: '#171B19' }}
              >
                Camp &amp; Bonds [C]
              </button>

              <button
                type="button"
                tabIndex={-1}
                data-testid="toggle-inspect-btn"
                onClick={(e) => {
                  e.currentTarget.blur();
                  if (!showInspectPanel) {
                    setInspectedUnitId(hoverInfo?.unitId ?? inspectedUnitId ?? activeUnit?.id ?? units[0]?.id ?? null);
                    setShowInspectPanel(true);
                  } else {
                    setShowInspectPanel(false);
                  }
                }}
                style={{
                  backgroundColor: showInspectPanel ? '#3A3324' : '#171B19',
                  borderColor: showInspectPanel ? '#E2B05A' : '#5A4B38',
                  color: showInspectPanel ? '#E2B05A' : '#F2ECE1',
                }}
                className="px-3 py-2 rounded-md border text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer hover:border-[#E2B05A]"
              >
                Inspect [I]
              </button>

              <button
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  setShowChronicleModal(true);
                }}
                className="px-3 py-2 rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-semibold text-[#F2ECE1] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                style={{ backgroundColor: '#171B19' }}
              >
                Chronicle [J]
              </button>

              <button
                type="button"
                tabIndex={-1}
                aria-label={isMuted ? 'Unmute Audio' : 'Mute Audio'}
                onClick={(e) => {
                  e.currentTarget.blur();
                  soundEngine.setMuted(!soundEngine.muted);
                  setIsMuted(soundEngine.muted);
                }}
                className="w-9 h-9 flex items-center justify-center rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-mono text-[#B5AC9A] hover:text-[#F2ECE1] transition-colors shrink-0 cursor-pointer"
                style={{ backgroundColor: '#171B19' }}
              >
                {isMuted ? 'M✕' : 'M'}
              </button>

              <button
                type="button"
                tabIndex={-1}
                aria-label="Restart Encounter"
                onClick={(e) => {
                  e.currentTarget.blur();
                  loadEncounterStage(stageId, worldState);
                }}
                className="w-9 h-9 flex items-center justify-center rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-mono text-[#B5AC9A] hover:text-[#F2ECE1] transition-colors shrink-0 cursor-pointer"
                style={{ backgroundColor: '#171B19' }}
              >
                R
              </button>

              <button
                type="button"
                tabIndex={-1}
                aria-label="Pause Game"
                onClick={(e) => {
                  e.currentTarget.blur();
                  setGameState('paused');
                }}
                className="w-9 h-9 flex items-center justify-center rounded-md border border-[#5A4B38] hover:border-[#E2B05A] text-xs font-mono text-[#B5AC9A] hover:text-[#F2ECE1] transition-colors shrink-0 cursor-pointer"
                style={{ backgroundColor: '#171B19' }}
              >
                P
              </button>
            </div>
          </div>

          {/* Unified Collapsible Bottom Tactical Skill Bar */}
          <div className="mx-auto w-full max-w-[1090px] flex flex-col items-center">
            {/* Compact Tactical Feedback Ticker + Interactive Environmental Object Chips + Hide Bar Toggle */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 mb-1.5 pointer-events-auto">
              <div
                data-testid="combat-banner-ticker"
                style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
                className="px-3.5 py-1 rounded border text-xs shadow-md max-w-xl truncate"
              >
                {hoveredUnit
                  ? `${hoveredUnit.name} (${hoveredUnit.title}) · HP ${Math.round(hoveredUnit.hp)}/${hoveredUnit.maxHp} · AC ${hoveredUnit.armorClass}`
                  : hoveredEnvDescription ?? combatBanner}
              </div>

              {envObjects
                .filter((obj) => !obj.destroyed)
                .map((obj) => (
                  <button
                    key={obj.id}
                    type="button"
                    data-testid={`env-object-btn-${obj.id}`}
                    onClick={() => handleTileClick(obj.gridX, obj.gridZ)}
                    title={`${obj.name} at (${obj.gridX}, ${obj.gridZ}) — Click to Shove (when adjacent) or Target with selected ability [1-4]`}
                    style={{
                      backgroundColor: '#171B19',
                      borderColor: selectedAbilityKey !== null ? '#E2B05A' : '#5A4B38',
                      color: selectedAbilityKey !== null ? '#E2B05A' : '#B5AC9A',
                    }}
                    className="px-2.5 py-1 rounded border text-[11px] font-mono transition-colors whitespace-nowrap shrink-0 cursor-pointer hover:border-[#E2B05A] hover:text-[#F2ECE1]"
                  >
                    {obj.kind === 'oil_barrel'
                      ? '🛢️'
                      : obj.kind === 'runic_brazier'
                      ? '🔥'
                      : '🪨'}{' '}
                    {obj.name} ({obj.gridX},{obj.gridZ})
                  </button>
                ))}

              <button
                type="button"
                onClick={() => setHudCollapsed((c) => !c)}
                style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#B5AC9A' }}
                className="px-2.5 py-1 rounded border hover:border-[#E2B05A] hover:text-[#F2ECE1] text-xs font-mono transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {hudCollapsed ? '▴ Show Bar [H]' : '▾ Hide Bar [H]'}
              </button>
            </div>

            {!hudCollapsed && activeUnit && (
              <CombatSkillBar
                activeUnit={activeUnit}
                allUnits={units}
                grid={grid}
                envObjects={envObjects}
                relationships={relationships}
                worldState={worldState}
                characterBuild={characterBuild}
                ghostHpPct={ghostHpPct}
                selectedAbilityKey={selectedAbilityKey}
                isSkillMenuOpen={showSkillTreeModal || showSkillMenu}
                onSelectAbilityKey={setSelectedAbilityKey}
                onUnavailableFeedback={(reason) => setCombatBanner(reason)}
                onToggleSkillMenu={() => setShowSkillTreeModal((open) => !open)}
                onEndTurn={advanceTurn}
              />
            )}
          </div>
        </div>
      )}

      {/* 3A. EXPANDED SKILL TREE MODAL & LOADOUT MANAGER ('K' KEY) */}
      {gameState === 'playing' && showSkillTreeModal && (
        <SkillTreeModal
          progressionState={progressionState}
          commanderName={characterBuild.commanderName}
          classId={characterBuild.classId}
          subclassId={characterBuild.subclassId}
          onUpdateProgression={handleUpdateProgression}
          onLaunchWarriorTrialGrounds={launchWarriorTrialGrounds}
          onLaunchMageTrialGrounds={launchMageTrialGrounds}
          onClose={() => setShowSkillTreeModal(false)}
        />
      )}

      {/* 3A-T. THE ASCENDANT TOWER MODAL ('T' KEY) */}
      {gameState === 'playing' && showTowerModal && (
        <TowerHubModal
          isOpen={showTowerModal}
          onClose={() => setShowTowerModal(false)}
          towerState={towerState}
          onUpdateTowerState={(next) => {
            setTowerState(next);
            towerStateRef.current = next;
          }}
          onLaunchTowerFloor={launchTowerFloor}
          partyLevel={progressionState.level}
          commanderName={characterBuild.commanderName}
        />
      )}

      {/* 3A-S. TOWER POST-BATTLE SUMMARY OVERLAY */}
      {towerBattleSummary && (
        <TowerPostBattleModal
          isOpen={!!towerBattleSummary}
          summary={towerBattleSummary}
          onAscendNext={() => {
            const nextFloor = towerBattleSummary.floorNumber + 1;
            setTowerBattleSummary(null);
            launchTowerFloor(nextFloor);
          }}
          onReturnToHub={() => {
            setTowerBattleSummary(null);
            setShowTowerModal(true);
          }}
        />
      )}

      {/* 3A-2. LEVEL-UP ADVANCEMENT NOTIFICATION MODAL */}
      {gameState === 'playing' && levelUpData && (
        <LevelUpModal
          result={levelUpData}
          onOpenSkillTree={() => {
            setLevelUpData(null);
            setShowSkillTreeModal(true);
          }}
          onClose={() => setLevelUpData(null)}
        />
      )}

      {/* 3A-3. TACTICAL SKILL TOME MODAL */}
      {gameState === 'playing' && showSkillMenu && activeUnit && (
        <TacticalSkillMenuModal
          unit={activeUnit}
          allUnits={units}
          grid={grid}
          envObjects={envObjects}
          relationships={relationships}
          worldState={worldState}
          characterBuild={characterBuild}
          selectedAbilityKey={selectedAbilityKey}
          onSelectPartyUnit={(uid) => {
            const found = units.find((u) => u.id === uid && u.faction === 'party' && !u.isKO);
            if (found) {
              setActiveUnitId(found.id);
              setInspectedUnitId(found.id);
              setSelectedAbilityKey(null);
            }
          }}
          onAssignSkillToSlot={handleAssignSkillToSlot}
          onClose={() => setShowSkillMenu(false)}
        />
      )}

      {/* 3B. D20 DICE ROLL & MODIFIER BREAKDOWN TOAST OVERLAY */}
      {gameState === 'playing' && (
        <DiceRollToastOverlay toasts={diceToasts} onDismiss={dismissDiceRollToast} />
      )}

      {/* 3C. TACTICAL UNIT INSPECT SIDE-PANEL ('I' KEY) */}
      {gameState === 'playing' && showInspectPanel && inspectedUnit && (
        <UnitInspectPanel
          unit={inspectedUnit}
          allUnits={units}
          relationships={relationships}
          worldState={worldState}
          onSelectUnit={(uid) => setInspectedUnitId(uid)}
          onClose={() => setShowInspectPanel(false)}
        />
      )}

      {/* 4. BRANCHING NARRATIVE & D20 SKILL CHECK MODAL */}
      {gameState === 'playing' && activeDialogueId && DIALOGUE_NODES[activeDialogueId] && (
        <DialogueModal
          node={DIALOGUE_NODES[activeDialogueId]}
          units={units}
          relationships={relationships}
          onRollSkillCheck={(choice, rollResult) => {
            pushDiceRollToast(buildSkillCheckRollToast(choice, rollResult, relationships));
          }}
          onCompleteChoice={handleCompleteDialogueChoice}
          onClose={() => setActiveDialogueId(null)}
        />
      )}

      {/* 5. COMPANION CAMP & RELATIONSHIPS MODAL */}
      {gameState === 'playing' && showCampModal && (
        <CompanionCampModal
          relationships={relationships}
          onCampChoice={(compId, convoId, delta, chronicleNote) => {
            setRelationships((prev) => ({
              ...prev,
              [compId]: {
                ...prev[compId],
                approval: Math.min(100, prev[compId].approval + delta),
                campConversationsCompleted: [...prev[compId].campConversationsCompleted, convoId],
              },
            }));
              setWorldState((prev) => ({
                ...prev,
                chronicleLog: [...prev.chronicleLog, chronicleNote],
              }));
              setGloamrestState((prev) => {
                if (prev.quests.mq04_road_to_whispering_vale.status !== 'active') return prev;
                const qUpd = applyQuestStepUpdates(prev, [
                  { questId: 'mq04_road_to_whispering_vale', stepId: 'speak_companions' },
                ]);
                saveGloamrestStateToStorage(qUpd.nextState);
                return qUpd.nextState;
              });
            }}
            onRestAndHealParty={() => {
              setUnits((prev) =>
                prev.map((u) =>
                  u.faction === 'party'
                    ? { ...u, hp: u.maxHp, ap: u.maxAp, isKO: false, cooldowns: {}, movedThisTurn: false }
                    : u
                )
              );
              setGloamrestState((prev) => {
                if (prev.quests.mq04_road_to_whispering_vale.status !== 'active') return prev;
                const qUpd = applyQuestStepUpdates(prev, [
                  { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
                ]);
                saveGloamrestStateToStorage(qUpd.nextState);
                return qUpd.nextState;
              });
            }}
          onClose={() => setShowCampModal(false)}
        />
      )}

      {/* 6. WORLD CHRONICLE & REACTIVITY MODAL */}
      {gameState === 'playing' && showChronicleModal && (
        <WorldChronicleModal
          stageId={stageId}
          highestReachedStage={highestReachedStage}
          worldState={worldState}
          onSelectStage={(idx) => loadEncounterStage(idx, worldState)}
          onClose={() => setShowChronicleModal(false)}
        />
      )}

      {/* 7. PAUSE MODAL (`document.body.dataset.state === 'paused'`) */}
      {gameState === 'paused' && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pause-modal-heading"
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(7, 6, 12, 0.82)' }}
        >
          <div
            className="w-full max-w-md rounded-xl border border-amber-500/40 p-6 shadow-2xl text-center space-y-5"
            style={{ backgroundColor: 'rgba(16, 14, 24, 0.97)' }}
          >
            <div>
              <p className="text-xs font-mono uppercase tracking-widest text-amber-400">
                Expedition Paused
              </p>
              <h2 id="pause-modal-heading" className="text-2xl font-display font-bold text-amber-100 mt-1">
                {playSubMode === 'gloamrest'
                  ? 'Gloamrest · Whispering Vale'
                  : STAGES[stageId].name}
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-2.5 text-left">
              <div className="p-3 rounded-lg border border-stone-800 bg-stone-900/80">
                <p className="text-[11px] text-stone-400">
                  {playSubMode === 'gloamrest' ? 'Day / Watch' : 'Round'}
                </p>
                <p className="text-lg font-mono font-bold tabular-nums text-amber-200">
                  {playSubMode === 'gloamrest'
                    ? `D${gloamrestState.dayCount}`
                    : roundNumber}
                </p>
              </div>
              <div className="p-3 rounded-lg border border-stone-800 bg-stone-900/80">
                <p className="text-[11px] text-stone-400">
                  {playSubMode === 'gloamrest' ? 'Gold' : 'Damage'}
                </p>
                <p className="text-lg font-mono font-bold tabular-nums text-emerald-300">
                  {playSubMode === 'gloamrest'
                    ? `${gloamrestState.inventory.gold}g`
                    : totalDamageDealt}
                </p>
              </div>
              <div className="p-3 rounded-lg border border-stone-800 bg-stone-900/80">
                <p className="text-[11px] text-stone-400">Oath</p>
                <p className="text-sm font-display font-bold text-amber-300 mt-1">
                  {worldState.oathAlignment}
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => setGameState('playing')}
                className="w-full py-2.5 text-sm font-display font-bold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
              >
                Resume Expedition [Esc]
              </button>
              <button
                type="button"
                data-testid="pause-save-adventure-btn"
                onClick={() => {
                  handleSaveAdventure();
                  setGameState('playing');
                }}
                className="w-full py-2.5 text-xs font-semibold text-emerald-300 border border-emerald-500/40 hover:border-emerald-400 rounded-lg transition-colors cursor-pointer"
              >
                Save Adventure [F5]
              </button>
              {playSubMode === 'combat' && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setPlaySubMode('gloamrest');
                      setCombatContext('campaign');
                      setGameState('playing');
                    }}
                    className="w-full py-2.5 text-xs font-semibold text-amber-200 border border-stone-700 hover:border-amber-400 rounded-lg transition-colors cursor-pointer"
                  >
                    Return to Gloamrest Settlement
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      loadEncounterStage(stageId, worldState);
                      setGameState('playing');
                    }}
                    className="w-full py-2.5 text-xs font-semibold text-stone-200 border border-stone-700 hover:border-amber-400 rounded-lg transition-colors cursor-pointer"
                  >
                    Restart Encounter
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() => performanceManager.toggleHudVisible()}
                className="w-full py-2.5 text-xs font-semibold text-sky-300 border border-sky-500/30 hover:border-sky-400 rounded-lg transition-colors cursor-pointer"
              >
                Performance &amp; FPS Overlay [F3]
              </button>
              <button
                type="button"
                onClick={() => setGameState('title')}
                className="w-full py-2.5 text-xs font-medium text-stone-400 hover:text-stone-200 rounded-lg transition-colors cursor-pointer"
              >
                Return to Title Screen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. VICTORY / GAME OVER MODAL (`document.body.dataset.state === 'gameover'`) */}
      {gameState === 'gameover' && runSnapshot && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="outcome-modal-heading"
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(7, 6, 12, 0.85)' }}
        >
          <div
            className="w-full max-w-lg rounded-xl border border-amber-500/45 p-6 shadow-2xl text-center space-y-5"
            style={{ backgroundColor: 'rgba(16, 14, 24, 0.98)' }}
          >
            <div>
              <p className="text-xs font-mono uppercase tracking-widest text-amber-400">
                {runSnapshot.outcome === 'victory' ? 'Sanctum Cleared' : 'Expedition Fallen'}
              </p>
              <h2
                id="outcome-modal-heading"
                className="text-3xl font-display font-bold text-amber-100 mt-1"
              >
                {runSnapshot.outcome === 'victory'
                  ? 'Victory in Dimraeth'
                  : 'The Shattered Oath Claims All'}
              </h2>
              <p className="text-xs text-stone-400 mt-1">{runSnapshot.stageName}</p>
            </div>

            <div className="grid grid-cols-3 gap-3 text-left">
              <div className="p-3 rounded-lg border border-stone-800 bg-stone-900/80">
                <p className="text-xs text-stone-400">Rounds Taken</p>
                <p className="text-xl font-mono font-bold tabular-nums text-amber-200 mt-0.5">
                  {runSnapshot.roundsTaken}
                </p>
              </div>
              <div className="p-3 rounded-lg border border-stone-800 bg-stone-900/80">
                <p className="text-xs text-stone-400">Damage Dealt</p>
                <p className="text-xl font-mono font-bold tabular-nums text-emerald-300 mt-0.5">
                  {runSnapshot.damageDealt}
                </p>
              </div>
              <div className="p-3 rounded-lg border border-stone-800 bg-stone-900/80">
                <p className="text-xs text-stone-400">Sworn Bond</p>
                <p className="text-sm font-display font-bold text-amber-300 truncate mt-0.5">
                  {runSnapshot.highestBondName.split(' ')[0]} ({runSnapshot.highestBondScore})
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              {runSnapshot.outcome === 'victory' && stageId < STAGES.length - 1 && (
                <button
                  type="button"
                  data-start="true"
                  onClick={() => {
                    const nextStage = stageId + 1;
                    loadEncounterStage(nextStage, worldState);
                    setGameState('playing');
                  }}
                  className="flex-1 py-3 text-sm font-display font-bold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
                >
                  Advance to {STAGES[stageId + 1].chapterLabel}
                </button>
              )}
              <button
                type="button"
                data-start="true"
                onClick={() => {
                  loadEncounterStage(stageId, worldState);
                  setGameState('playing');
                }}
                className="flex-1 py-3 text-xs font-semibold text-amber-100 border border-amber-500/40 hover:border-amber-400 rounded-lg transition-colors cursor-pointer"
              >
                {runSnapshot.outcome === 'victory' ? 'Replay Encounter' : 'Try Again'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setPlaySubMode('gloamrest');
                  setCombatContext('campaign');
                  setGameState('playing');
                }}
                className="flex-1 py-3 text-xs font-semibold text-emerald-200 border border-emerald-500/40 hover:border-emerald-400 rounded-lg transition-colors cursor-pointer"
              >
                Return to Gloamrest
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 9. REAL-TIME PERFORMANCE & FPS OVERLAY [F3] */}
      <PerformanceOverlay />
    </main>
  );
}
