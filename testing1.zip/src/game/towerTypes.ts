import {
  Ability,
  AbilityAoeShape,
  AbilityCategory,
  AbilityElement,
  CombatUnit,
  EnvironmentalSurface,
  GridTile,
  TacticalEnvObject,
} from './rules';

/**
 * DIMRAETH: THE SHATTERED OATH
 * THE ASCENDANT TOWER — 100-Floor Tactical Battle Progression System
 */

export type TowerRegionId =
  | 'forgotten_threshold' // Region I: Floors 1–10 (Lv 1–4)
  | 'withered_wilds'      // Region II: Floors 11–20 (Lv 4–6)
  | 'ember_foundry'       // Region III: Floors 21–30 (Lv 6–8)
  | 'frozen_reliquary'    // Region IV: Floors 31–40 (Lv 8–10)
  | 'astral_divide'       // Region V: Floors 41–50 (Lv 10–12)
  | 'drowned_kingdom'     // Region VI: Floors 51–60 (Lv 12–14)
  | 'crimson_covenant'    // Region VII: Floors 61–70 (Lv 14–16)
  | 'ashen_dominion'      // Region VIII: Floors 71–80 (Lv 16–18)
  | 'shattered_expanse'   // Region IX: Floors 81–90 (Lv 18–19)
  | 'throne_beyond';      // Region X: Floors 91–100 (Lv 19–20)

export type TowerDifficulty =
  | 'Beginner'
  | 'Easy'
  | 'Moderate'
  | 'Hard'
  | 'Very Hard'
  | 'Extreme'
  | 'Legendary';

export type TowerEncounterType =
  | 'standard'       // Defeat all enemy forces
  | 'multi_wave'     // Survive and defeat 2–3 successive enemy waves
  | 'survival'       // Survive for a specific number of combat rounds
  | 'boss'           // Defeat the Major Multi-Phase Boss
  | 'mini_boss'      // Defeat the Elite Mini-Boss & their guard
  | 'defense'        // Protect a sacred relic/pillar from being destroyed
  | 'escort'         // Escort an astral wisp or civilian to extraction tile
  | 'destruction'    // Destroy designated enemy pylons/portals before reinforcement overload
  | 'puzzle'         // Push runestones/objects into sockets while surviving
  | 'trial';         // Special tactical constraints (e.g. melee-only, high-ground only)

export interface TowerRegionMetadata {
  id: TowerRegionId;
  regionNumber: number; // 1..10
  name: string;
  floorRange: [number, number];
  recommendedLevelRange: [number, number];
  difficulty: TowerDifficulty;
  tagline: string;
  loreDescription: string;
  visualTheme: string;
  ambientPreset: 'twilight_sanctum' | 'crimson_rift' | 'emerald_grove';
  signatureHazard: string;
  primaryColors: {
    bg: string;
    border: string;
    accent: string;
    glow: string;
  };
}

export interface TowerEnemySlotConfig {
  id: string;
  name: string;
  title: string;
  archetype: 'stalker' | 'weaver' | 'inquisitor' | 'bruiser' | 'champion';
  gridX: number;
  gridZ: number;
  elevation?: number;
  hp: number;
  maxHp: number;
  armorClass: number;
  moveRange: number;
  ap: number;
  initiative: number;
  stats: { str: number; dex: number; int: number; cha: number };
  abilities: Ability[];
  isBoss?: boolean;
  isMiniBoss?: boolean;
}

export interface TowerObjectiveConfig {
  type: TowerEncounterType;
  title: string;
  description: string;
  surviveRounds?: number;
  targetUnitIds?: string[];
  targetEnvObjectIds?: string[];
  defendTargetId?: string;
  escapeTile?: { x: number; z: number };
  puzzleSockets?: { objId: string; targetX: number; targetZ: number }[];
}

export interface TowerFloorRewardConfig {
  firstClearXp: number;
  firstClearOathShards: number;
  gold: number;
  lootItemIds: string[];
  guaranteedItemName?: string;
}

export interface TowerGridPreset {
  elevations?: Record<string, number>; // "x,z" => elevation
  customTerrains?: Record<string, 'stone' | 'moss' | 'hazard_rift' | 'pillar' | 'bastion'>;
  surfaces?: Record<string, EnvironmentalSurface>;
  unwalkableTiles?: { x: number; z: number }[];
  objects?: {
    id: string;
    name: string;
    kind: 'oil_barrel' | 'runic_brazier' | 'runestone_block';
    x: number;
    z: number;
    hp?: number;
    pushable?: boolean;
  }[];
}

export interface TowerFloorDefinition {
  floorNumber: number; // 1..100
  floorId: string;
  regionId: TowerRegionId;
  name: string;
  difficulty: TowerDifficulty;
  recommendedLevel: number;
  encounterType: TowerEncounterType;
  specialFeature: string;
  objective: TowerObjectiveConfig;
  gridPreset: TowerGridPreset;
  enemyFormation: TowerEnemySlotConfig[];
  reinforcementWaves?: {
    triggerRound: number;
    enemies: TowerEnemySlotConfig[];
    announceMessage: string;
  }[];
  rewards: TowerFloorRewardConfig;
  isBossFloor: boolean;
  isMiniBossFloor: boolean;
  isCheckpoint: boolean;
  isSanctuary: boolean;
}

export interface TowerBossPhase {
  phaseNumber: number;
  name: string;
  hpThresholdPercent: number; // e.g. 100, 50, 25
  announceQuote: string;
  arenaModification?: {
    collapsePillars?: { x: number; z: number }[];
    spawnHazards?: { x: number; z: number; surface: EnvironmentalSurface }[];
    spawnAddEnemies?: TowerEnemySlotConfig[];
  };
  bonusStatModifiers?: {
    apBonus?: number;
    acBonus?: number;
    damageMultiplier?: number;
  };
  telegraphedAttack?: {
    name: string;
    targetTiles: { x: number; z: number }[];
    damage: number;
    element: AbilityElement;
    warningMessage: string;
  };
}

export interface TowerBossDefinition {
  floorNumber: number;
  bossId: string;
  name: string;
  epithet: string;
  introDialogue: string;
  defeatDialogue: string;
  phases: TowerBossPhase[];
  weakness: string;
  resistanceProfile: string;
  specialArenaMechanic: string;
  exclusiveArtifactReward: {
    id: string;
    name: string;
    type: 'weapon' | 'armor' | 'relic';
    description: string;
  };
}

export interface TowerShopItem {
  id: string;
  name: string;
  category: 'weapon' | 'armor' | 'relic' | 'consumable' | 'oath_perk';
  oathShardCost: number;
  requiredFloorCleared: number;
  rarity: 'Uncommon' | 'Rare' | 'Epic' | 'Legendary';
  description: string;
  statsSummary: string;
}

export interface TowerProgressionState {
  highestFloorCleared: number;
  currentUnlockedFloor: number;
  completedFloorNumbers: number[];
  unlockedCheckpoints: number[]; // 10, 20, 30, 40, 50, 60, 70, 80, 90, 100
  oathShards: number;
  firstClearClaimedFloorNumbers: number[];
  bossClearRecords: Record<number, { clearedAt: number; roundsTaken: number }>;
  purchasedShopItemIds: string[];
  activeRun?: {
    currentFloor: number;
    partyHpSnapshot: Record<string, number>;
  };
}

export const TOWER_CHECKPOINT_FLOORS = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
