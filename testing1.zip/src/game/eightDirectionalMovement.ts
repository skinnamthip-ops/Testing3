/**
 * DIMRAETH: THE SHATTERED OATH - 8-DIRECTIONAL MOVEMENT ENGINE
 * 
 * Provides unified, mathematically verified 8-directional movement,
 * diagonal vector normalization, corner-cutting collision validation,
 * smooth angular rotation, and warrior combat stance/weapon attachment.
 */

export type Direction8 =
  | 'N'
  | 'NE'
  | 'E'
  | 'SE'
  | 'S'
  | 'SW'
  | 'W'
  | 'NW';

export interface Direction8Spec {
  id: Direction8;
  label: string;
  dx: number;
  dz: number;
  angleRad: number;
  isDiagonal: boolean;
}

export const DIRECTION_8_SPECS: Record<Direction8, Direction8Spec> = {
  S: { id: 'S', label: 'South', dx: 0, dz: 1, angleRad: 0, isDiagonal: false },
  SE: { id: 'SE', label: 'Southeast', dx: 1, dz: 1, angleRad: Math.PI / 4, isDiagonal: true },
  E: { id: 'E', label: 'East', dx: 1, dz: 0, angleRad: Math.PI / 2, isDiagonal: false },
  NE: { id: 'NE', label: 'Northeast', dx: 1, dz: -1, angleRad: (3 * Math.PI) / 4, isDiagonal: true },
  N: { id: 'N', label: 'North', dx: 0, dz: -1, angleRad: Math.PI, isDiagonal: false },
  NW: { id: 'NW', label: 'Northwest', dx: -1, dz: -1, angleRad: -(3 * Math.PI) / 4, isDiagonal: true },
  W: { id: 'W', label: 'West', dx: -1, dz: 0, angleRad: -Math.PI / 2, isDiagonal: false },
  SW: { id: 'SW', label: 'Southwest', dx: -1, dz: 1, angleRad: -Math.PI / 4, isDiagonal: true },
};

export const ALL_8_DIRECTIONS: Direction8[] = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];

/**
 * Derives the discrete 8-directional compass sector from a 2D vector (dx, dz).
 */
export function getDirection8FromVector(dx: number, dz: number): Direction8 {
  if (dx === 0 && dz === 0) return 'S';
  const angle = Math.atan2(dx, dz);
  return getDirection8FromAngle(angle);
}

/**
 * Maps any continuous radian angle (-PI..PI or beyond) to the closest of the 8 compass directions.
 */
export function getDirection8FromAngle(angleRad: number): Direction8 {
  // Normalize angle to (-PI..PI]
  let a = angleRad % (Math.PI * 2);
  if (a > Math.PI) a -= Math.PI * 2;
  if (a <= -Math.PI) a += Math.PI * 2;

  // Sector boundaries are centered at 0, 45, 90, 135, 180, -135, -90, -45 deg
  const step = Math.PI / 4; // 45 degrees
  const halfStep = step / 2; // 22.5 degrees

  if (a >= -halfStep && a < halfStep) return 'S';
  if (a >= halfStep && a < halfStep + step) return 'SE';
  if (a >= halfStep + step && a < halfStep + 2 * step) return 'E';
  if (a >= halfStep + 2 * step && a < halfStep + 3 * step) return 'NE';
  if (a >= halfStep + 3 * step || a < -halfStep - 3 * step) return 'N';
  if (a >= -halfStep - 3 * step && a < -halfStep - 2 * step) return 'NW';
  if (a >= -halfStep - 2 * step && a < -halfStep - step) return 'W';
  return 'SW';
}

/**
 * Returns the exact forward rotation angle in radians for a given 8-direction.
 */
export function getAngleForDirection8(dir: Direction8): number {
  return DIRECTION_8_SPECS[dir].angleRad;
}

/**
 * Resolves keyboard inputs into a normalized movement vector (length 1.0 or 0.0),
 * supporting simultaneous diagonal presses (e.g. W+D, S+A, etc.).
 */
export function resolve8DirectionalInput(keys: Set<string>): {
  moveX: number;
  moveZ: number;
  rawX: number;
  rawZ: number;
  dir8: Direction8 | null;
  isMoving: boolean;
  isRunning: boolean;
} {
  let rawX = 0;
  let rawZ = 0;

  if (keys.has('KeyW') || keys.has('ArrowUp')) rawZ -= 1;
  if (keys.has('KeyS') || keys.has('ArrowDown')) rawZ += 1;
  if (keys.has('KeyA') || keys.has('ArrowLeft')) rawX -= 1;
  if (keys.has('KeyD') || keys.has('ArrowRight')) rawX += 1;

  const isRunning = keys.has('ShiftLeft') || keys.has('ShiftRight');

  if (rawX === 0 && rawZ === 0) {
    return {
      moveX: 0,
      moveZ: 0,
      rawX: 0,
      rawZ: 0,
      dir8: null,
      isMoving: false,
      isRunning,
    };
  }

  // Normalization: prevents diagonal movement from being sqrt(2) ~ 1.414x faster
  const length = Math.hypot(rawX, rawZ);
  const moveX = rawX / length;
  const moveZ = rawZ / length;
  const dir8 = getDirection8FromVector(rawX, rawZ);

  return {
    moveX,
    moveZ,
    rawX,
    rawZ,
    dir8,
    isMoving: true,
    isRunning,
  };
}

/**
 * Checks if movement from (fromX, fromZ) to (toX, toZ) is valid on a grid.
 * Enforces the corner-cutting rule:
 * When moving diagonally, BOTH adjacent orthogonal tiles must be walkable.
 */
export function canMove8Directional(
  fromX: number,
  fromZ: number,
  toX: number,
  toZ: number,
  isWalkable: (x: number, z: number) => boolean
): boolean {
  // Destination must be walkable
  if (!isWalkable(toX, toZ)) return false;

  const dx = toX - fromX;
  const dz = toZ - fromZ;

  // If orthogonal (only one axis changed), no corner-cutting check is needed
  if (dx === 0 || dz === 0) {
    return true;
  }

  // Diagonal movement: corner cutting check
  // Moving from (x, z) to (x+dx, z+dz) requires both (x+dx, z) and (x, z+dz) to be clear
  const cornerAWalkable = isWalkable(fromX + dx, fromZ);
  const cornerBWalkable = isWalkable(fromX, fromZ + dz);

  return cornerAWalkable && cornerBWalkable;
}

/**
 * Computes shortest angular distance between two angles in radians (-PI..PI).
 */
export function shortestAngleDiff(targetRad: number, currentRad: number): number {
  let diff = (targetRad - currentRad) % (Math.PI * 2);
  if (diff > Math.PI) diff -= Math.PI * 2;
  if (diff <= -Math.PI) diff += Math.PI * 2;
  return diff;
}

/**
 * Smoothly interpolates an angle towards target using exponential damping.
 */
export function smoothRotateAngle(
  currentRad: number,
  targetRad: number,
  lambda: number,
  dtSeconds: number
): number {
  const diff = shortestAngleDiff(targetRad, currentRad);
  const damp = 1 - Math.exp(-lambda * dtSeconds);
  return currentRad + diff * damp;
}

/**
 * Full BFS reachability for tactical combat grids:
 * Computes all valid reachable tiles within moveRange supporting all 8 directions,
 * strictly prohibiting corner-cutting through obstacles.
 */
export function get8DirectionalValidMoves(
  startX: number,
  startZ: number,
  moveRange: number,
  gridWidth: number,
  gridDepth: number,
  isWalkable: (x: number, z: number) => boolean
): { x: number; z: number; path: { x: number; z: number }[]; cost: number; dir8: Direction8 }[] {
  const inBounds = (x: number, z: number) => x >= 0 && x < gridWidth && z >= 0 && z < gridDepth;
  const key = (x: number, z: number) => `${x},${z}`;

  // Priority queue / Dijkstra state
  const distMap = new Map<string, number>();
  const parentMap = new Map<string, { x: number; z: number }>();
  const queue: { x: number; z: number; dist: number }[] = [{ x: startX, z: startZ, dist: 0 }];

  distMap.set(key(startX, startZ), 0);

  const results: {
    x: number;
    z: number;
    path: { x: number; z: number }[];
    cost: number;
    dir8: Direction8;
  }[] = [];

  while (queue.length > 0) {
    queue.sort((a, b) => a.dist - b.dist);
    const curr = queue.shift()!;
    const currKey = key(curr.x, curr.z);

    if (curr.dist > (distMap.get(currKey) ?? Infinity)) continue;

    // Record valid reachable tile (excluding starting position)
    if (curr.dist > 0 && curr.dist <= moveRange) {
      // Reconstruct path
      const path: { x: number; z: number }[] = [];
      let step: { x: number; z: number } | undefined = { x: curr.x, z: curr.z };
      while (step && !(step.x === startX && step.z === startZ)) {
        path.unshift(step);
        step = parentMap.get(key(step.x, step.z));
      }
      const dir8 = getDirection8FromVector(curr.x - startX, curr.z - startZ);
      results.push({
        x: curr.x,
        z: curr.z,
        path,
        cost: curr.dist,
        dir8,
      });
    }

    if (curr.dist >= moveRange) continue;

    // Explore all 8 directions
    for (const dir of ALL_8_DIRECTIONS) {
      const spec = DIRECTION_8_SPECS[dir];
      const nx = curr.x + spec.dx;
      const nz = curr.z + spec.dz;

      if (!inBounds(nx, nz)) continue;

      // Validate movement including corner-cutting for diagonals
      if (!canMove8Directional(curr.x, curr.z, nx, nz, isWalkable)) {
        continue;
      }

      // In DIMRAETH tactical combat, each step in any of the 8 directions costs 1 move tile
      const nextDist = curr.dist + 1;
      const nextKey = key(nx, nz);

      if (nextDist < (distMap.get(nextKey) ?? Infinity)) {
        distMap.set(nextKey, nextDist);
        parentMap.set(nextKey, { x: curr.x, z: curr.z });
        queue.push({ x: nx, z: nz, dist: nextDist });
      }
    }
  }

  return results;
}

/**
 * Dynamic Combat Stance and Animation Spec for Warrior in 8 Directions.
 * Computes exact procedural bone/prop orientations for idle, walking, and running:
 * - Legs swing along the local movement axis.
 * - Longsword in right hand sways naturally in rhythm.
 * - Shield on left arm maintains defensive guard without torso clipping.
 */
export interface WarriorStanceState {
  direction8: Direction8;
  isMoving: boolean;
  isRunning: boolean;
  stridePhase: number;
  torsoPitch: number;
  torsoRoll: number;
  bodyBobY: number;
  legLeftRotX: number;
  legRightRotX: number;
  swordPos: [number, number, number];
  swordRot: [number, number, number];
  shieldPos: [number, number, number];
  shieldRot: [number, number, number];
}

export function computeWarrior8DirStance(
  facingRad: number,
  isMoving: boolean,
  isRunning: boolean,
  elapsedSeconds: number,
  speedFactor = 1.0
): WarriorStanceState {
  const dir8 = getDirection8FromAngle(facingRad);

  if (!isMoving) {
    // Idle Combat Stance: Alert, breathing, shield held forward, sword poised
    const breathe = Math.sin(elapsedSeconds * 2.4);
    const pulse = Math.cos(elapsedSeconds * 1.8);

    return {
      direction8: dir8,
      isMoving: false,
      isRunning: false,
      stridePhase: 0,
      torsoPitch: 0.04, // Slight alert forward posture
      torsoRoll: 0,
      bodyBobY: breathe * 0.02,
      legLeftRotX: 0.08,  // Left foot slightly forward (orthodox fighter stance)
      legRightRotX: -0.08, // Right foot slightly back
      swordPos: [0.38, 0.98 + breathe * 0.015, 0.16 + pulse * 0.01],
      swordRot: [0.12, 0.08, -0.06],
      shieldPos: [-0.36, 0.94 + breathe * 0.01, 0.22],
      shieldRot: [0.18, 0.22, 0.04], // Angled forward-outward to guard the body
    };
  }

  // Active Locomotion (Walk vs Run)
  const freq = isRunning ? 13.5 * speedFactor : 9.5 * speedFactor;
  const legAmp = isRunning ? 0.72 : 0.48;
  const armAmp = isRunning ? 0.44 : 0.28;
  const stridePhase = elapsedSeconds * freq;

  const legSwing = Math.sin(stridePhase);
  const bob = Math.abs(Math.sin(stridePhase)) * (isRunning ? 0.14 : 0.08);
  const torsoPitch = isRunning ? 0.16 : 0.08; // Running forward lean
  const torsoRoll = Math.sin(stridePhase) * 0.035;

  // Longsword & Shield rhythm during locomotion
  // Right arm swings counter to left leg
  const swordSway = Math.sin(stridePhase + Math.PI) * armAmp;
  const shieldGuardBob = Math.sin(stridePhase) * 0.06;

  return {
    direction8: dir8,
    isMoving: true,
    isRunning,
    stridePhase,
    torsoPitch,
    torsoRoll,
    bodyBobY: bob,
    legLeftRotX: legSwing * legAmp,
    legRightRotX: -legSwing * legAmp,
    swordPos: [0.38, 0.96 + bob * 0.5, 0.16 + swordSway * 0.2],
    swordRot: [0.18 + swordSway * 0.5, 0.05, -0.08],
    shieldPos: [-0.36, 0.92 + shieldGuardBob, 0.24 + Math.abs(swordSway) * 0.05],
    shieldRot: [0.22, 0.25, 0.06], // Shield stays steady in front to guard chest
  };
}
