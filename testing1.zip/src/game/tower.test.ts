import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ALL_100_TOWER_FLOORS,
  TOWER_REGIONS,
} from './towerFloorsData';
import {
  TOWER_MAJOR_BOSSES,
  TOWER_MINI_BOSSES,
} from './towerBossesData';
import {
  buildTowerFloorEncounter,
  completeTowerFloor,
  createInitialTowerState,
  evaluateTowerFloorObjective,
  generateTowerGrid,
  purchaseTowerShopItem,
  restAtTowerSanctuary,
  TOWER_SHOP_CATALOG,
} from './towerEngine';
import {
  TOWER_CHECKPOINT_FLOORS,
  TowerProgressionState,
  TowerRegionId,
} from './towerTypes';
import { CombatUnit, GRID_SIZE } from './rules';
import { SavedAdventureSlot } from './saveAdventureSlots';

/**
 * THE ASCENDANT TOWER TEST SUITE
 * Verifies all 100 floors, 10 regions, 10 major bosses, 10 mini-bosses,
 * encounter objectives, progression, checkpoints, economy, and persistence.
 */

test('1. Tower Structure: exactly 100 uniquely defined floors across 10 regions', () => {
  const floorNumbers = Object.keys(ALL_100_TOWER_FLOORS).map(Number);
  assert.equal(floorNumbers.length, 100, 'Must contain exactly 100 floors');

  const namesSet = new Set<string>();

  for (let f = 1; f <= 100; f++) {
    const floor = ALL_100_TOWER_FLOORS[f];
    assert.ok(floor, `Floor ${f} must exist`);
    assert.equal(floor.floorNumber, f);
    assert.ok(floor.name.length > 0, `Floor ${f} must have a name`);
    assert.ok(floor.enemyFormation.length > 0, `Floor ${f} must have enemy formation`);
    assert.ok(floor.rewards.firstClearOathShards > 0, `Floor ${f} must award Oath Shards`);
    assert.ok(floor.rewards.firstClearXp > 0, `Floor ${f} must award XP`);
    assert.ok(floor.objective.title.length > 0, `Floor ${f} must have an objective`);

    namesSet.add(floor.name);
  }

  // All 100 floors have distinct descriptive names
  assert.equal(namesSet.size, 100, 'All 100 floors must have unique names');
});

test('2. 10 Environmental Regions: correct floor ranges, scaling levels, and thematic metadata', () => {
  const regionKeys = Object.keys(TOWER_REGIONS) as TowerRegionId[];
  assert.equal(regionKeys.length, 10, 'Must have exactly 10 regions');

  const expectedRanges: [number, number][] = [
    [1, 10],
    [11, 20],
    [21, 30],
    [31, 40],
    [41, 50],
    [51, 60],
    [61, 70],
    [71, 80],
    [81, 90],
    [91, 100],
  ];

  regionKeys.forEach((key, idx) => {
    const reg = TOWER_REGIONS[key];
    assert.equal(reg.regionNumber, idx + 1);
    assert.deepEqual(reg.floorRange, expectedRanges[idx]);
    assert.ok(reg.recommendedLevelRange[0] <= reg.recommendedLevelRange[1]);
    assert.ok(reg.visualTheme.length > 0);
    assert.ok(reg.signatureHazard.length > 0);
  });
});

test('3. 10 Major Multi-Phase Bosses & 10 Mini-Bosses on designated milestone floors', () => {
  const majorBossFloors = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  const miniBossFloors = [5, 15, 25, 35, 45, 55, 65, 75, 85, 95];

  for (const f of majorBossFloors) {
    const floor = ALL_100_TOWER_FLOORS[f];
    assert.equal(floor.isBossFloor, true, `Floor ${f} must be marked as boss floor`);
    assert.equal(floor.isCheckpoint, true, `Floor ${f} must be a checkpoint`);
    assert.equal(floor.isSanctuary, true, `Floor ${f} must be a sanctuary`);

    const boss = TOWER_MAJOR_BOSSES[f];
    assert.ok(boss, `Major boss for floor ${f} must exist`);
    assert.ok(boss.phases.length >= 2, `Major boss ${boss.name} must have at least 2 phases`);
    assert.ok(boss.introDialogue.length > 0);
    assert.ok(boss.defeatDialogue.length > 0);
    assert.ok(boss.weakness.length > 0);
    assert.ok(boss.exclusiveArtifactReward.name.length > 0);
  }

  for (const f of miniBossFloors) {
    const floor = ALL_100_TOWER_FLOORS[f];
    assert.equal(floor.isMiniBossFloor, true, `Floor ${f} must be marked as mini-boss floor`);
    const mini = TOWER_MINI_BOSSES[f];
    assert.ok(mini, `Mini-boss for floor ${f} must exist`);
    assert.ok(mini.name.length > 0);
  }
});

test('4. Tactical Grid & Environmental Encounter Generation', () => {
  const f1Def = ALL_100_TOWER_FLOORS[1];
  const grid = generateTowerGrid(f1Def);

  assert.equal(grid.length, GRID_SIZE);
  assert.equal(grid[0].length, GRID_SIZE);

  // Mock party
  const mockParty: CombatUnit[] = [
    {
      id: 'seraphina',
      name: 'Seraphina Vane',
      title: 'Dawn Warden Commander',
      faction: 'party',
      gridX: 1,
      gridZ: 8,
      elevation: 0,
      hp: 30,
      maxHp: 30,
      tempHp: 0,
      ap: 4,
      maxAp: 4,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 15,
      initiative: 12,
      stats: { str: 16, dex: 12, int: 10, cha: 14 },
      abilities: [],
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
    },
  ];

  const encounter = buildTowerFloorEncounter(10, mockParty);
  assert.equal(encounter.floorDef.floorNumber, 10);
  assert.equal(encounter.floorDef.isBossFloor, true);
  assert.ok(encounter.units.some((u) => u.faction === 'party'));
  assert.ok(encounter.units.some((u) => u.faction === 'enemy' && u.name.includes('Valerius')));
});

test('5. Objective Evaluation: handles survival, boss, destruction, and standard combat', () => {
  const f4Def = ALL_100_TOWER_FLOORS[4]; // Survival encounter
  assert.equal(f4Def.encounterType, 'survival');

  const livingParty: CombatUnit[] = [
    {
      id: 'seraphina',
      name: 'Seraphina',
      title: 'Cmd',
      faction: 'party',
      gridX: 2,
      gridZ: 2,
      elevation: 0,
      hp: 25,
      maxHp: 30,
      tempHp: 0,
      ap: 4,
      maxAp: 4,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 14,
      initiative: 10,
      stats: { str: 14, dex: 10, int: 10, cha: 10 },
      abilities: [],
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
    },
  ];

  // In round 2 of a 4-round survival: in progress
  const evalInProgress = evaluateTowerFloorObjective(f4Def, livingParty, 2, []);
  assert.equal(evalInProgress.outcome, 'in_progress');

  // In round 5 (exceeded required surviveRounds 4): victory
  const evalWon = evaluateTowerFloorObjective(f4Def, livingParty, 5, []);
  assert.equal(evalWon.outcome, 'victory');

  // Total party wipe: defeat
  const deadParty = livingParty.map((u) => ({ ...u, hp: 0, isKO: true }));
  const evalLost = evaluateTowerFloorObjective(f4Def, deadParty, 2, []);
  assert.equal(evalLost.outcome, 'defeat');
});

test('6. Progression & Floor Clearance: unlocks next floor, checkpoints, and awards Oath Shards', () => {
  let state = createInitialTowerState();
  assert.equal(state.highestFloorCleared, 0);
  assert.equal(state.currentUnlockedFloor, 1);
  assert.equal(state.oathShards, 0);

  const mockParty: CombatUnit[] = [
    {
      id: 'seraphina',
      name: 'Seraphina',
      title: 'Cmd',
      faction: 'party',
      gridX: 2,
      gridZ: 2,
      elevation: 0,
      hp: 20,
      maxHp: 30,
      tempHp: 0,
      ap: 4,
      maxAp: 4,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 14,
      initiative: 10,
      stats: { str: 14, dex: 10, int: 10, cha: 10 },
      abilities: [],
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
    },
  ];

  // Clear Floor 1
  const res1 = completeTowerFloor(state, 1, 3, mockParty);
  assert.equal(res1.firstClearEarned, true);
  assert.ok(res1.shardsEarned > 0);
  assert.ok(res1.xpEarned > 0);
  assert.equal(res1.nextState.highestFloorCleared, 1);
  assert.equal(res1.nextState.currentUnlockedFloor, 2);
  assert.equal(res1.nextState.completedFloorNumbers.includes(1), true);

  state = res1.nextState;

  // Repeat clear Floor 1 gives reduced rewards
  const res1Repeat = completeTowerFloor(state, 1, 2, mockParty);
  assert.equal(res1Repeat.firstClearEarned, false);
  assert.ok(res1Repeat.shardsEarned < res1.shardsEarned);

  // Clear Floor 10 (Boss & Checkpoint Floor)
  const res10 = completeTowerFloor(state, 10, 5, mockParty);
  assert.equal(res10.firstClearEarned, true);
  assert.equal(res10.unlockedCheckpoint, 10);
  assert.ok(res10.bossDefeated !== undefined);
  assert.equal(res10.bossDefeated?.floorNumber, 10);
  assert.equal(res10.nextState.bossClearRecords[10].roundsTaken, 5);
  assert.equal(res10.nextState.unlockedCheckpoints.includes(10), true);
});

test('7. Tower Sanctuary Rest restores active run HP snapshot', () => {
  let state = createInitialTowerState();
  state.activeRun = {
    currentFloor: 5,
    partyHpSnapshot: { seraphina: 8 },
  };

  const restedState = restAtTowerSanctuary(state);
  assert.deepEqual(restedState.activeRun?.partyHpSnapshot, {});
});

test('8. Tower Shop: catalog filtering, floor requirements, and Oath Shard purchases', () => {
  assert.ok(TOWER_SHOP_CATALOG.length >= 10, 'Catalog must contain at least 10 items');

  let state = createInitialTowerState();
  state.oathShards = 200;
  state.highestFloorCleared = 15; // Cleared up to floor 15

  // Attempting to buy item that requires Floor 40 should fail
  const failRes = purchaseTowerShopItem(state, 'tower_item_armor_frost');
  assert.equal(failRes.success, false);
  assert.ok(failRes.reason?.includes('Locked! Requires reaching and clearing Floor 40'));

  // Buying valid consumable (Tower Draught) should succeed
  const buyRes = purchaseTowerShopItem(state, 'tower_item_consumable_draught');
  assert.equal(buyRes.success, true);
  assert.equal(buyRes.nextState.oathShards, 200 - 12);

  state = buyRes.nextState;

  // Buying Warden's Granite Bulwark (requires floor 10, costs 45 shards)
  const buyShield = purchaseTowerShopItem(state, 'tower_item_shield_valerius');
  assert.equal(buyShield.success, true);
  assert.equal(buyShield.nextState.purchasedShopItemIds.includes('tower_item_shield_valerius'), true);

  // Buying unique item again should fail
  const buyDuplicate = purchaseTowerShopItem(buyShield.nextState, 'tower_item_shield_valerius');
  assert.equal(buyDuplicate.success, false);
});

test('9. Save/Load Persistence: SavedAdventureSlot cleanly stores and recovers towerState', () => {
  const initialTower = createInitialTowerState();
  initialTower.highestFloorCleared = 20;
  initialTower.currentUnlockedFloor = 21;
  initialTower.completedFloorNumbers = [1, 2, 3, 10, 20];
  initialTower.unlockedCheckpoints = [10, 20];
  initialTower.oathShards = 185;
  initialTower.purchasedShopItemIds = ['tower_item_shield_valerius'];

  const slot: SavedAdventureSlot = {
    id: 'slot-test-tower',
    commanderName: 'Seraphina Vane',
    level: 7,
    raceId: 'half_elf',
    classId: 'paladin',
    subclassId: 'dawn_warden',
    originChoice: 'Balance',
    stageId: 0,
    playtime: '04h 12m',
    saveDate: '2026-11-01 15:30',
    timestamp: Date.now(),
    towerState: initialTower,
  };

  const serialized = JSON.stringify(slot);
  const loadedSlot: SavedAdventureSlot = JSON.parse(serialized);

  assert.ok(loadedSlot.towerState);
  assert.equal(loadedSlot.towerState.highestFloorCleared, 20);
  assert.equal(loadedSlot.towerState.currentUnlockedFloor, 21);
  assert.equal(loadedSlot.towerState.oathShards, 185);
  assert.deepEqual(loadedSlot.towerState.unlockedCheckpoints, [10, 20]);
  assert.deepEqual(loadedSlot.towerState.purchasedShopItemIds, ['tower_item_shield_valerius']);
});
