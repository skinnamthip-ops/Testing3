import {
  Ability,
  AbilityAoeShape,
  AbilityCategory,
  AbilityElement,
  CharacterClassId,
  CharacterSubclassId,
  CombatUnit,
} from './rules';
import { ArchetypeClassId } from '../components/CharacterPixelPreviewCanvas';

/**
 * DIMRAETH: THE SHATTERED OATH
 * Character Progression & 96-Skill Tree Engine
 */

export const MAX_CHARACTER_LEVEL = 20;

/**
 * Cumulative XP Thresholds (Level 1–20)
 * As specified in Master Directive Section 1.
 */
export const CUMULATIVE_XP_TABLE: Record<number, number> = {
  1: 0,
  2: 300,
  3: 750,
  4: 1350,
  5: 2100,
  6: 3000,
  7: 4050,
  8: 5250,
  9: 6600,
  10: 8100,
  11: 9750,
  12: 11550,
  13: 13500,
  14: 15600,
  15: 17850,
  16: 20250,
  17: 22800,
  18: 25500,
  19: 28350,
  20: 31350,
};

export const XP_REWARD_ORDINARY_ENEMY = 50;
export const XP_REWARD_ELITE_ENEMY = 150;
export const XP_REWARD_BOSS_ENEMY = 500;
export const XP_REWARD_MAIN_QUEST = 400;
export const XP_REWARD_SIDE_QUEST = 200;
export const XP_REWARD_EXPLORATION_DISCOVERY = 75;

export type PlayableClassKey = 'warrior' | 'mage' | 'rogue' | 'paladin' | 'ranger';

export interface SkillProgressionDefinition {
  id: string;
  name: string;
  classKey: PlayableClassKey;
  specializationKey?: CharacterSubclassId;
  minLevel: number;
  skillPointCost: number;
  category: AbilityCategory;
  isPassive: boolean;
  apCost: number;
  cooldown: number;
  range: number;
  targetType: 'enemy' | 'ally' | 'self' | 'ground';
  aoeShape?: AbilityAoeShape;
  element: AbilityElement;
  damageRange: [number, number];
  healAmount?: number;
  grantTempHp?: number;
  cleanseStatuses?: ('burning' | 'rooted' | 'sundered')[];
  statusEffect?: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded';
  pushDistance?: number;
  pullDistance?: number;
  selfReposition?: 'leap_adjacent' | 'backstep_1';
  refundApOnKO?: number;
  damageFormula: string;
  attributeScaling: string;
  centralMechanic: string;
  tacticalExplanation: string;
  terrainInteraction?: string;
  animationReference: string;
  iconReference: string;
  description: string;
}

export interface ClassMasteryOption {
  id: string;
  title: string;
  milestoneLevel: 5 | 10 | 15 | 20;
  classKey: PlayableClassKey;
  tagline: string;
  description: string;
  statBonuses?: { str?: number; dex?: number; int?: number; cha?: number };
  hpBonus?: number;
  acBonus?: number;
  moveBonus?: number;
  passivePerk: string;
}

export interface CharacterProgressionState {
  level: number; // 1..20
  totalXp: number; // cumulative XP
  unspentSkillPoints: number;
  unspentAttributePoints: number;
  learnedSkillIds: string[];
  equippedSkillIds: [string, string, string, string];
  unlockedMasteries: Partial<Record<5 | 10 | 15 | 20, string>>;
  allocatedAttributes: {
    str: number;
    dex: number;
    int: number;
    cha: number;
  };
  completedXpSourceIds: string[];
}

export interface LevelUpResult {
  nextState: CharacterProgressionState;
  leveledUp: boolean;
  previousLevel: number;
  newLevel: number;
  xpGained: number;
  skillPointsGained: number;
  attributePointsGained: number;
  newlyAvailableSkills: SkillProgressionDefinition[];
  masteryMilestoneReached?: 5 | 10 | 15 | 20;
}

/**
 * Normalizes any class string into one of the 5 canonical playable class keys.
 */
export function normalizePlayableClassKey(raw: string | undefined): PlayableClassKey {
  const lower = (raw ?? '').toLowerCase();
  if (lower === 'arcanist' || lower === 'mage') return 'mage';
  if (lower === 'warden' || lower === 'ranger') return 'ranger';
  if (lower === 'warrior') return 'warrior';
  if (lower === 'rogue') return 'rogue';
  return 'paladin';
}

/**
 * Calculates current level (1 to 20) given cumulative XP.
 */
export function calculateLevelFromXp(totalXp: number): number {
  const safeXp = Math.max(0, totalXp);
  for (let lvl = MAX_CHARACTER_LEVEL; lvl >= 1; lvl--) {
    if (safeXp >= CUMULATIVE_XP_TABLE[lvl]) {
      return lvl;
    }
  }
  return 1;
}

/**
 * Computes progress toward next level.
 */
export function getXpProgressForLevel(totalXp: number): {
  currentLevel: number;
  nextLevel: number | null;
  currentLevelBaseXp: number;
  nextLevelXp: number | null;
  xpInCurrentLevel: number;
  xpNeededForLevel: number;
  progressPercent: number;
  xpRemaining: number;
} {
  const currentLevel = calculateLevelFromXp(totalXp);
  const currentLevelBaseXp = CUMULATIVE_XP_TABLE[currentLevel];
  if (currentLevel >= MAX_CHARACTER_LEVEL) {
    return {
      currentLevel: MAX_CHARACTER_LEVEL,
      nextLevel: null,
      currentLevelBaseXp,
      nextLevelXp: null,
      xpInCurrentLevel: totalXp - currentLevelBaseXp,
      xpNeededForLevel: 0,
      progressPercent: 100,
      xpRemaining: 0,
    };
  }

  const nextLevel = currentLevel + 1;
  const nextLevelXp = CUMULATIVE_XP_TABLE[nextLevel];
  const xpInCurrentLevel = Math.max(0, totalXp - currentLevelBaseXp);
  const xpNeededForLevel = nextLevelXp - currentLevelBaseXp;
  const progressPercent = Math.min(100, Math.max(0, (xpInCurrentLevel / xpNeededForLevel) * 100));
  const xpRemaining = Math.max(0, nextLevelXp - totalXp);

  return {
    currentLevel,
    nextLevel,
    currentLevelBaseXp,
    nextLevelXp,
    xpInCurrentLevel,
    xpNeededForLevel,
    progressPercent,
    xpRemaining,
  };
}

/**
 * Checks whether an attribute milestone level is reached (4, 8, 12, 16, 20).
 */
export function isAttributeMilestoneLevel(level: number): boolean {
  return level === 4 || level === 8 || level === 12 || level === 16 || level === 20;
}

/**
 * Checks whether a class mastery milestone level is reached (5, 10, 15, 20).
 */
export function isClassMasteryMilestoneLevel(level: number): boolean {
  return level === 5 || level === 10 || level === 15 || level === 20;
}

/**
 * Legacy skill ID migration mapping to maintain save compatibility.
 */
export const LEGACY_SKILL_ID_MIGRATIONS: Record<string, string> = {
  arcane_bolt: 'infernal_orb',
  ley_line_sense: 'glacial_lance',
  gravity_well: 'chain_lightning',
  astral_step: 'blink_step',
  spell_echo: 'gravitational_collapse',
  null_field: 'arcane_disjunction',
  prismatic_cage: 'aegis_ward',
  temporal_distortion: 'counterspell',
  arcane_convergence: 'phase_veil',
  rift_collapse: 'runic_mine',
  astral_overload: 'astral_rift',
  reality_fracture: 'prismatic_field',
};

export function migrateLegacySkillId(skillId: string): string {
  return LEGACY_SKILL_ID_MIGRATIONS[skillId] ?? skillId;
}

/**
 * Creates initial clean progression state.
 */
/**
 * Sanitizes an equipped skills array so that:
 * 1. Exactly 4 slot strings are returned.
 * 2. Any skill ID appears in AT MOST ONE slot (strictly zero duplicates).
 * 3. Any duplicated occurrence in later slots is set to empty string ('').
 * 4. Migrates any legacy skill IDs.
 */
export function sanitizeEquippedSkills(
  equipped: readonly string[]
): [string, string, string, string] {
  const seen = new Set<string>();
  const result: [string, string, string, string] = ['', '', '', ''];
  for (let i = 0; i < 4; i++) {
    const rawId = equipped[i];
    const id = rawId ? migrateLegacySkillId(rawId) : '';
    if (id && id.trim() !== '' && !seen.has(id)) {
      seen.add(id);
      result[i] = id;
    } else {
      result[i] = '';
    }
  }
  return result;
}

export function createInitialProgressionState(
  classKey: PlayableClassKey = 'paladin',
  specializationKey: CharacterSubclassId = 'dawn_warden'
): CharacterProgressionState {
  const startingLearnedMap: Record<PlayableClassKey, string[]> = {
    warrior: ['sundering_strike', 'guarded_stance'],
    mage: ['infernal_orb', 'aegis_ward'],
    rogue: ['quickdraw', 'shadow_veil'],
    paladin: ['consecrated_strike', 'oathward'],
    ranger: ['precision_shot', 'hunters_instinct'],
  };

  // Rule: One skill can only equip 1 slot. No duplicated skills across slots.
  const defaultEquippedMap: Record<PlayableClassKey, [string, string, string, string]> = {
    warrior: ['sundering_strike', 'guarded_stance', '', ''],
    mage: ['infernal_orb', 'aegis_ward', '', ''],
    rogue: ['quickdraw', 'shadow_veil', '', ''],
    paladin: ['consecrated_strike', 'oathward', '', ''],
    ranger: ['precision_shot', '', '', ''],
  };

  const startingLearned = startingLearnedMap[classKey] ?? startingLearnedMap.paladin;
  const defaultEquipped = defaultEquippedMap[classKey] ?? defaultEquippedMap.paladin;

  return {
    level: 1,
    totalXp: 0,
    unspentSkillPoints: 0,
    unspentAttributePoints: 0,
    learnedSkillIds: [...startingLearned],
    equippedSkillIds: sanitizeEquippedSkills(defaultEquipped),
    unlockedMasteries: {},
    allocatedAttributes: { str: 0, dex: 0, int: 0, cha: 0 },
    completedXpSourceIds: [],
  };
}

/**
 * Awards XP, detects level up, grants skill points and attribute points,
 * and prevents duplicate XP from the same source ID.
 */
export function awardXp(
  state: CharacterProgressionState,
  amount: number,
  sourceId?: string
): LevelUpResult {
  if (amount <= 0) {
    return {
      nextState: state,
      leveledUp: false,
      previousLevel: state.level,
      newLevel: state.level,
      xpGained: 0,
      skillPointsGained: 0,
      attributePointsGained: 0,
      newlyAvailableSkills: [],
    };
  }

  // Prevent duplicate XP awards for the same source ID
  if (sourceId && state.completedXpSourceIds.includes(sourceId)) {
    return {
      nextState: state,
      leveledUp: false,
      previousLevel: state.level,
      newLevel: state.level,
      xpGained: 0,
      skillPointsGained: 0,
      attributePointsGained: 0,
      newlyAvailableSkills: [],
    };
  }

  const previousLevel = state.level;
  const maxCapXp = CUMULATIVE_XP_TABLE[MAX_CHARACTER_LEVEL];
  const newTotalXp = Math.min(maxCapXp, state.totalXp + amount);
  const actualXpGained = newTotalXp - state.totalXp;
  const newLevel = calculateLevelFromXp(newTotalXp);
  const leveledUp = newLevel > previousLevel;

  let skillPointsGained = 0;
  let attributePointsGained = 0;
  let masteryMilestoneReached: 5 | 10 | 15 | 20 | undefined;

  if (leveledUp) {
    for (let l = previousLevel + 1; l <= newLevel; l++) {
      skillPointsGained += 1;
      if (isAttributeMilestoneLevel(l)) {
        attributePointsGained += 1;
      }
      if (isClassMasteryMilestoneLevel(l)) {
        masteryMilestoneReached = l as 5 | 10 | 15 | 20;
      }
    }
  }

  const newlyAvailableSkills: SkillProgressionDefinition[] = [];
  if (leveledUp) {
    Object.values(ALL_SKILLS_DATABASE).forEach((skill) => {
      if (
        skill.minLevel > previousLevel &&
        skill.minLevel <= newLevel &&
        !state.learnedSkillIds.includes(skill.id)
      ) {
        newlyAvailableSkills.push(skill);
      }
    });
  }

  const nextSourceIds = sourceId
    ? [...state.completedXpSourceIds, sourceId]
    : state.completedXpSourceIds;

  const nextState: CharacterProgressionState = {
    ...state,
    level: newLevel,
    totalXp: newTotalXp,
    unspentSkillPoints: state.unspentSkillPoints + skillPointsGained,
    unspentAttributePoints: state.unspentAttributePoints + attributePointsGained,
    completedXpSourceIds: nextSourceIds,
  };

  return {
    nextState,
    leveledUp,
    previousLevel,
    newLevel,
    xpGained: actualXpGained,
    skillPointsGained,
    attributePointsGained,
    newlyAvailableSkills,
    masteryMilestoneReached,
  };
}

/**
 * Unlocks a skill using Skill Points.
 */
export function unlockSkill(
  state: CharacterProgressionState,
  skillId: string,
  charLevel?: number
): { success: boolean; error?: string; nextState: CharacterProgressionState } {
  const skill = ALL_SKILLS_DATABASE[skillId];
  if (!skill) {
    return { success: false, error: `Skill "${skillId}" not found in registry.`, nextState: state };
  }

  if (state.learnedSkillIds.includes(skillId)) {
    return { success: false, error: `Skill "${skill.name}" is already learned.`, nextState: state };
  }

  const currentLevel = charLevel ?? state.level;
  if (currentLevel < skill.minLevel) {
    return {
      success: false,
      error: `Requires character level ${skill.minLevel} (Current: ${currentLevel}).`,
      nextState: state,
    };
  }

  if (state.unspentSkillPoints < skill.skillPointCost) {
    return {
      success: false,
      error: `Insufficient Skill Points. Requires ${skill.skillPointCost}, have ${state.unspentSkillPoints}.`,
      nextState: state,
    };
  }

  const nextState: CharacterProgressionState = {
    ...state,
    unspentSkillPoints: state.unspentSkillPoints - skill.skillPointCost,
    learnedSkillIds: [...state.learnedSkillIds, skillId],
  };

  return { success: true, nextState };
}

/**
 * Assigns a learned active skill to one of the 4 combat loadout slots.
 * Rule: One skill can only equip 1 slot.
 * - If already equipped in another slot, moves it or performs a clean swap.
 * - Enforces strictly zero duplicated active skills across loadout slots.
 */
export function equipSkillToSlot(
  state: CharacterProgressionState,
  slotIndex: 0 | 1 | 2 | 3,
  skillId: string
): { success: boolean; error?: string; nextState: CharacterProgressionState } {
  const skill = ALL_SKILLS_DATABASE[skillId];
  if (!skill) {
    return { success: false, error: `Skill "${skillId}" not found.`, nextState: state };
  }

  if (!state.learnedSkillIds.includes(skillId)) {
    return { success: false, error: `Cannot equip "${skill.name}" — skill has not been unlocked yet.`, nextState: state };
  }

  if (skill.isPassive) {
    return { success: false, error: `"${skill.name}" is a passive perk and cannot be equipped to an active combat slot.`, nextState: state };
  }

  // Pre-sanitize to eliminate any pre-existing duplicates
  const cleanEquipped = sanitizeEquippedSkills(state.equippedSkillIds);
  const newEquipped = [...cleanEquipped] as [string, string, string, string];

  // If already equipped in another slot, swap with target slot
  const existingSlot = newEquipped.indexOf(skillId);
  if (existingSlot !== -1 && existingSlot !== slotIndex) {
    const prevInTarget = newEquipped[slotIndex];
    newEquipped[existingSlot] = prevInTarget;
    newEquipped[slotIndex] = skillId;
  } else {
    newEquipped[slotIndex] = skillId;
  }

  // Strict enforcement: one skill can only equip 1 slot. Remove any duplicate.
  for (let i = 0; i < 4; i++) {
    if (i !== slotIndex && newEquipped[i] === skillId) {
      newEquipped[i] = '';
    }
  }

  const nextState: CharacterProgressionState = {
    ...state,
    equippedSkillIds: newEquipped,
  };

  return { success: true, nextState };
}

/**
 * Unequips a skill from the specified combat loadout slot.
 */
export function unequipSkillSlot(
  state: CharacterProgressionState,
  slotIndex: 0 | 1 | 2 | 3
): { success: boolean; nextState: CharacterProgressionState } {
  const cleanEquipped = sanitizeEquippedSkills(state.equippedSkillIds);
  const newEquipped = [...cleanEquipped] as [string, string, string, string];
  newEquipped[slotIndex] = '';
  return {
    success: true,
    nextState: {
      ...state,
      equippedSkillIds: newEquipped,
    },
  };
}

/**
 * Spends 1 attribute point to increase STR, DEX, INT, or CHA.
 */
export function spendAttributePoint(
  state: CharacterProgressionState,
  attribute: 'str' | 'dex' | 'int' | 'cha'
): { success: boolean; error?: string; nextState: CharacterProgressionState } {
  if (state.unspentAttributePoints < 1) {
    return { success: false, error: 'No unspent Attribute Points available.', nextState: state };
  }

  const nextState: CharacterProgressionState = {
    ...state,
    unspentAttributePoints: state.unspentAttributePoints - 1,
    allocatedAttributes: {
      ...state.allocatedAttributes,
      [attribute]: state.allocatedAttributes[attribute] + 1,
    },
  };

  return { success: true, nextState };
}

/**
 * Selects a class mastery milestone choice at levels 5, 10, 15, or 20.
 */
export function selectClassMastery(
  state: CharacterProgressionState,
  milestoneLevel: 5 | 10 | 15 | 20,
  choiceId: string
): { success: boolean; error?: string; nextState: CharacterProgressionState } {
  if (state.level < milestoneLevel) {
    return {
      success: false,
      error: `Requires character level ${milestoneLevel} (Current: ${state.level}).`,
      nextState: state,
    };
  }

  const choices = CLASS_MASTERY_CHOICES[milestoneLevel];
  const choice = choices?.find((c) => c.id === choiceId);
  if (!choice) {
    return { success: false, error: `Invalid mastery choice ID: ${choiceId}`, nextState: state };
  }

  const nextState: CharacterProgressionState = {
    ...state,
    unlockedMasteries: {
      ...state.unlockedMasteries,
      [milestoneLevel]: choiceId,
    },
  };

  return { success: true, nextState };
}

/**
 * Converts a progression skill definition into a combat-ready Ability object.
 */
export function toCombatAbility(
  def: SkillProgressionDefinition,
  slotKey: '1' | '2' | '3' | '4' = '1'
): Ability {
  return {
    id: def.id,
    name: def.name,
    key: slotKey,
    apCost: def.apCost,
    cooldown: def.cooldown,
    range: def.range,
    aoeRadius: def.id === 'battlefield_commander' ? 4 : def.aoeShape === 'shockwave_ring' || def.aoeShape === 'chebyshev_3x3' ? 1 : undefined,
    aoeShape: def.aoeShape ?? 'single',
    category: def.category,
    damageRange: def.damageRange,
    healAmount: def.healAmount,
    grantTempHp: def.grantTempHp,
    cleanseStatuses: def.cleanseStatuses,
    statusEffect: def.statusEffect,
    element: def.element,
    pushDistance: def.pushDistance,
    pullDistance: def.pullDistance,
    selfReposition: def.selfReposition,
    refundApOnKO: def.refundApOnKO,
    uniqueMechanicLabel: def.centralMechanic,
    targetType: def.targetType,
    roleClue: `${def.damageFormula} · ${def.attributeScaling}`,
    description: def.description,
  };
}

/* ========================================================================= */
/* CLASS MASTERY CHOICES (Levels 5, 10, 15, 20)                              */
/* ========================================================================= */

export const CLASS_MASTERY_CHOICES: Record<5 | 10 | 15 | 20, ClassMasteryOption[]> = {
  5: [
    // Warrior
    {
      id: 'warrior_mastery_5_vanguard',
      title: 'Vanguard Weapon Mastery',
      milestoneLevel: 5,
      classKey: 'warrior',
      tagline: '+2 STR · Heavy Cleave Impact',
      description: 'Master greatsword and warhammer balance. All melee attacks gain +2 bonus physical damage.',
      statBonuses: { str: 2 },
      passivePerk: '+2 STR and +2 Melee Damage',
    },
    {
      id: 'warrior_mastery_5_bastion',
      title: 'Bastion Defensive Discipline',
      milestoneLevel: 5,
      classKey: 'warrior',
      tagline: '+2 AC · +8 Max HP',
      description: 'Anchor armor seams against incoming blows, raising armor class and base health.',
      acBonus: 2,
      hpBonus: 8,
      passivePerk: '+2 AC and +8 Max HP',
    },
    {
      id: 'warrior_mastery_5_momentum',
      title: 'Combat Momentum',
      milestoneLevel: 5,
      classKey: 'warrior',
      tagline: '+1 Move Range · Knockout Surge',
      description: 'Defeating an enemy immediately grants +1 Action Point for the rest of that turn.',
      moveBonus: 1,
      passivePerk: '+1 Move and +1 AP refund on enemy KO',
    },
    // Mage
    {
      id: 'mage_mastery_5_aether',
      title: 'Aether Manipulation',
      milestoneLevel: 5,
      classKey: 'mage',
      tagline: '+2 INT · +1 Spell Range',
      description: 'Deepen mental alignment with the astral plane, projecting spells 1 tile farther.',
      statBonuses: { int: 2 },
      passivePerk: '+2 INT and +1 Spell Range',
    },
    {
      id: 'mage_mastery_5_efficiency',
      title: 'Arcane Efficiency',
      milestoneLevel: 5,
      classKey: 'mage',
      tagline: 'Ley-Line AP Conservation',
      description: 'The first spell cast each combat encounter costs 1 fewer Action Point (minimum 1 AP).',
      passivePerk: '-1 AP on opening spell of encounter',
    },
    {
      id: 'mage_mastery_5_resonance',
      title: 'Elemental Resonance',
      milestoneLevel: 5,
      classKey: 'mage',
      tagline: '+4 DMG vs Burning Foes',
      description: 'Exploits thermal weaknesses, increasing spell damage against burning or debuffed targets.',
      passivePerk: '+4 bonus damage against burning enemies',
    },
    // Rogue
    {
      id: 'rogue_mastery_5_shadow',
      title: 'Shadow Precision',
      milestoneLevel: 5,
      classKey: 'rogue',
      tagline: '+2 DEX · Sneak Attack +4 DMG',
      description: 'Refines critical edge alignment. Attacks from stealth or flanking deal +4 damage.',
      statBonuses: { dex: 2 },
      passivePerk: '+2 DEX and +4 Sneak Attack damage',
    },
    {
      id: 'rogue_mastery_5_deception',
      title: 'Acrobatic Deception',
      milestoneLevel: 5,
      classKey: 'rogue',
      tagline: '+2 Move · Opportunity Dodge',
      description: 'Weaves effortlessly through threatened tiles without triggering enemy opportunity strikes.',
      moveBonus: 2,
      passivePerk: '+2 Move Range and immunity to opportunity attacks',
    },
    {
      id: 'rogue_mastery_5_trapmaster',
      title: 'Trap Artificer',
      milestoneLevel: 5,
      classKey: 'rogue',
      tagline: 'Root Duration +1 · +4 Trap DMG',
      description: 'Engineers traps with serrated triggers that hold victims for an additional turn.',
      passivePerk: 'Traps deal +4 damage and root for +1 turn',
    },
    // Paladin
    {
      id: 'paladin_mastery_5_protection',
      title: 'Shield of the Covenant',
      milestoneLevel: 5,
      classKey: 'paladin',
      tagline: '+2 AC · Fortified Wards',
      description: 'Blesses heavy plate and shields. All shields and defensive wards grant +5 Temp HP.',
      acBonus: 2,
      passivePerk: '+2 AC and defensive abilities grant +5 Temp HP',
    },
    {
      id: 'paladin_mastery_5_judgment',
      title: 'Sacred Retribution',
      milestoneLevel: 5,
      classKey: 'paladin',
      tagline: '+2 STR · Radiant Wrath',
      description: 'Melee weapon strikes burn with celestial flame, adding +2 Radiant damage.',
      statBonuses: { str: 2 },
      passivePerk: '+2 STR and +2 Radiant damage on melee hits',
    },
    {
      id: 'paladin_mastery_5_mercy',
      title: 'Sanctified Compassion',
      milestoneLevel: 5,
      classKey: 'paladin',
      tagline: '+4 Healing · Dual Cleansing',
      description: 'Deepens vows of mercy. Restorative abilities heal +4 HP and cleanse 2 debuffs.',
      passivePerk: '+4 Healing on radiant spells and purges 2 debuffs',
    },
    // Ranger
    {
      id: 'ranger_mastery_5_deadeye',
      title: 'Deadeye Marksmanship',
      milestoneLevel: 5,
      classKey: 'ranger',
      tagline: '+2 DEX · High Ground +2 Hit',
      description: 'Master of elevated perches. Ranged attacks from high ground gain +2 attack roll bonus.',
      statBonuses: { dex: 2 },
      passivePerk: '+2 DEX and +2 High Ground attack roll',
    },
    {
      id: 'ranger_mastery_5_sylvan',
      title: 'Vale Bramble-Walker',
      milestoneLevel: 5,
      classKey: 'ranger',
      tagline: 'Ignore Hazard Slow · +6 HP',
      description: 'Passes unhindered through brambles, rubble, and rough terrain while gaining stamina.',
      hpBonus: 6,
      passivePerk: 'Ignores difficult terrain and +6 Max HP',
    },
    {
      id: 'ranger_mastery_5_instinct',
      title: 'Predator Reflexes',
      milestoneLevel: 5,
      classKey: 'ranger',
      tagline: '+1 Move · +10% Crit vs Wounded',
      description: 'Tracks blood trails, gaining increased critical chance against enemies below 50% HP.',
      moveBonus: 1,
      passivePerk: '+1 Move and +10% Crit against wounded foes',
    },
  ],
  10: [
    // Warrior
    {
      id: 'warrior_mastery_10_colossus',
      title: 'Unstoppable Vanguard',
      milestoneLevel: 10,
      classKey: 'warrior',
      tagline: '+10 Max HP · Knockback Immunity',
      description: 'Anchored like mountain granite; cannot be forcibly shoved or pulled by enemies.',
      hpBonus: 10,
      passivePerk: '+10 Max HP and immune to forced displacement',
    },
    {
      id: 'warrior_mastery_10_retaliation',
      title: 'Retaliatory Instinct',
      milestoneLevel: 10,
      classKey: 'warrior',
      tagline: 'Melee Riposte Reaction',
      description: 'Once per round, automatically retaliates against adjacent melee attacks for 6 damage.',
      passivePerk: 'Automatic counter-attack reaction once per round',
    },
    // Mage
    {
      id: 'mage_mastery_10_singularity',
      title: 'Gravitational Weave',
      milestoneLevel: 10,
      classKey: 'mage',
      tagline: 'Vortices Pull +1 Tile',
      description: 'Expands spatial distortion fields, pulling targets an extra tile toward centers.',
      passivePerk: 'All displacement and vortex spells pull +1 additional tile',
    },
    {
      id: 'mage_mastery_10_shielding',
      title: 'Aegis of the Void',
      milestoneLevel: 10,
      classKey: 'mage',
      tagline: '+3 AC · Spell Warding',
      description: 'Creates a shimmering deflection barrier that increases Armor Class by +3.',
      acBonus: 3,
      passivePerk: '+3 AC against all attacks and projectiles',
    },
    // Rogue
    {
      id: 'rogue_mastery_10_flanker',
      title: 'Lethal Angles',
      milestoneLevel: 10,
      classKey: 'rogue',
      tagline: 'Flanking Bonus +4 Hit / +4 DMG',
      description: 'Doubles standard combat flanking bonuses when striking adjacent to an ally.',
      passivePerk: 'Flanking grants +4 Attack Roll and +4 Damage',
    },
    {
      id: 'rogue_mastery_10_venom',
      title: 'Virulent Toxins',
      milestoneLevel: 10,
      classKey: 'rogue',
      tagline: 'Poisons Reduce Healing by 50%',
      description: 'Weapon coatings rot the target from within, suppressing enemy healing and regeneration.',
      passivePerk: 'Weapon debuffs cut target healing by 50%',
    },
    // Paladin
    {
      id: 'paladin_mastery_10_aura',
      title: 'Aura of Courage',
      milestoneLevel: 10,
      classKey: 'paladin',
      tagline: '3-Tile Party Blessed Aura',
      description: 'Nearby allies within 3 tiles gain +1 on attack rolls and immunity to fear effects.',
      passivePerk: 'Allies within 3 tiles gain +1 Attack Roll',
    },
    {
      id: 'paladin_mastery_10_consecration',
      title: 'Hallowed Dominance',
      milestoneLevel: 10,
      classKey: 'paladin',
      tagline: 'Sanctified Tiles Heal +3 / Turn',
      description: 'Consecrated ground mends allies for 3 HP each turn they stand inside it.',
      passivePerk: 'Sanctified tiles heal standing allies for 3 HP per turn',
    },
    // Ranger
    {
      id: 'ranger_mastery_10_volley',
      title: 'Ricochet Precision',
      milestoneLevel: 10,
      classKey: 'ranger',
      tagline: 'Ricochets Hit 1 Extra Foe',
      description: 'Calculates glancing trajectories off walls and armor to hit an extra enemy.',
      passivePerk: 'Multi-target shots bounce to 1 additional target',
    },
    {
      id: 'ranger_mastery_10_camo',
      title: 'Living Camouflage',
      milestoneLevel: 10,
      classKey: 'ranger',
      tagline: 'Stealth on Brush End-Turn',
      description: 'Ending your turn in brambles or foliage automatically conceals you from ranged targeting.',
      passivePerk: 'Ending turn in foliage grants partial stealth',
    },
  ],
  15: [
    // Warrior
    {
      id: 'warrior_mastery_15_overpower',
      title: 'Crushing Momentum',
      milestoneLevel: 15,
      classKey: 'warrior',
      tagline: 'Melee Attacks Sunder Armor',
      description: 'Every successful melee strike automatically applies Sundered (-2 AC) to the target.',
      passivePerk: 'All melee attacks automatically apply Sundered',
    },
    {
      id: 'warrior_mastery_15_second_wind',
      title: 'Veteran Second Wind',
      milestoneLevel: 15,
      classKey: 'warrior',
      tagline: 'Sub-30% HP Heals 18 HP',
      description: 'When dropping below 30% HP, instantly restores 18 HP once per encounter.',
      passivePerk: 'Emergency heal of 18 HP when dropping below 30% health',
    },
    // Mage
    {
      id: 'mage_mastery_15_overchannel',
      title: 'Planar Overchannel',
      milestoneLevel: 15,
      classKey: 'mage',
      tagline: '+6 Critical Spell Damage',
      description: 'Surges astral energy through critical strikes, multiplying catastrophic damage.',
      passivePerk: 'Spell critical hits deal +6 bonus planar damage',
    },
    {
      id: 'mage_mastery_15_chain_ignite',
      title: 'Chain Pyromancy',
      milestoneLevel: 15,
      classKey: 'mage',
      tagline: 'Fire Spells Ignite All Nearby Oil',
      description: 'Pyromantic spells detonate all oil pools and volatile objects within 4 tiles.',
      passivePerk: 'Fire attacks trigger 4-tile chain ignitions on hazards',
    },
    // Rogue
    {
      id: 'rogue_mastery_15_shadowstep',
      title: 'Shadow Phasing',
      milestoneLevel: 15,
      classKey: 'rogue',
      tagline: '+3 Tile Shadow Teleport',
      description: 'Evasive maneuvers allow blinking through enemy lines to an unthreatened tile.',
      passivePerk: 'Evasive rolls gain +3 teleportation distance',
    },
    {
      id: 'rogue_mastery_15_assassins_mark',
      title: 'Executioner Focus',
      milestoneLevel: 15,
      classKey: 'rogue',
      tagline: '+8 DMG vs Debuffed Foes',
      description: 'Strikes against Sundered, Rooted, or Burning targets inflict +8 execution damage.',
      passivePerk: '+8 bonus damage against crowd-controlled targets',
    },
    // Paladin
    {
      id: 'paladin_mastery_15_intercession',
      title: 'Guardian Shield Wall',
      milestoneLevel: 15,
      classKey: 'paladin',
      tagline: 'Absorb 50% Ally Damage in 2 Tiles',
      description: 'Redirects half the incoming damage dealt to adjacent allies to the Paladin instead.',
      passivePerk: 'Adjacent allies take 50% less damage',
    },
    {
      id: 'paladin_mastery_15_radiant_fury',
      title: 'Dawn Smite Consecration',
      milestoneLevel: 15,
      classKey: 'paladin',
      tagline: 'Smites Create Sanctified Ground',
      description: 'Every offensive ability permanently blesses the impact tile into sanctified ground.',
      passivePerk: 'Offensive strikes leave sanctified tiles behind',
    },
    // Ranger
    {
      id: 'ranger_mastery_15_snipers_perch',
      title: 'Highland Ballistics',
      milestoneLevel: 15,
      classKey: 'ranger',
      tagline: '+2 Longbow Range on Elevation',
      description: 'Mastery of ballistic arc increases effective bow range by +2 tiles from high ground.',
      passivePerk: '+2 Range when attacking from high ground',
    },
    {
      id: 'ranger_mastery_15_wild_communion',
      title: 'Wild Beast Bond',
      milestoneLevel: 15,
      classKey: 'ranger',
      tagline: 'Summoned Beasts Gain +8 HP / +3 DMG',
      description: 'Spiritual connection empowers animal companions and summoned nature entities.',
      passivePerk: 'Summons gain +8 HP and +3 attack damage',
    },
  ],
  20: [
    // Warrior
    {
      id: 'warrior_mastery_20_warlord',
      title: 'Grand Warlord of Dimraeth',
      milestoneLevel: 20,
      classKey: 'warrior',
      tagline: '+1 Max AP · Party Vanguard Command',
      description: 'Commands the entire battlefield. Maximum Action Points increased to 4 for all combat.',
      passivePerk: '+1 Max Action Point and +4 STR',
    },
    // Mage
    {
      id: 'mage_mastery_20_archmage',
      title: 'Astral Archmage',
      milestoneLevel: 20,
      classKey: 'mage',
      tagline: '+1 Max AP · Dual Spell Mastery',
      description: 'Achieves total transcendence over the astral weave. Spells ignore 50% target magic AC.',
      passivePerk: '+1 Max Action Point and spells ignore 4 Armor Class',
    },
    // Rogue
    {
      id: 'rogue_mastery_20_shadowlord',
      title: 'Master of the Eclipse',
      milestoneLevel: 20,
      classKey: 'rogue',
      tagline: '+1 Max AP · Stealth Never Breaks on Miss',
      description: 'Supreme phantom of Whispering Vale. Missing an attack does not break stealth.',
      passivePerk: '+1 Max Action Point and attacks from stealth refund 1 AP on hit',
    },
    // Paladin
    {
      id: 'paladin_mastery_20_exemplar',
      title: 'Solar Exemplar of the Covenant',
      milestoneLevel: 20,
      classKey: 'paladin',
      tagline: '+1 Max AP · Radiant Aura of Resurrection',
      description: 'Channels the immortal sun. Revives 1 defeated ally per encounter with 30% health.',
      passivePerk: '+1 Max Action Point and +4 CHA',
    },
    // Ranger
    {
      id: 'ranger_mastery_20_apex_warden',
      title: 'Apex Warden of the Sylvan Vale',
      milestoneLevel: 20,
      classKey: 'ranger',
      tagline: '+1 Max AP · 100% Critical from Perches',
      description: 'The definitive master of Whispering Vale. Unmoved shots from high ground always crit.',
      passivePerk: '+1 Max Action Point and +4 DEX',
    },
  ],
};

/* ========================================================================= */
/* 96 ABILITIES DATABASE (60 Core + 36 Specialization)                       */
/* ========================================================================= */

export const ALL_SKILLS_DATABASE: Record<string, SkillProgressionDefinition> = {
  /* ----------------------------------------------------------------------- */
  /* WARRIOR (12 Core Skills)                                                */
  /* ----------------------------------------------------------------------- */
  sundering_strike: {
    id: 'sundering_strike',
    name: 'Sundering Strike',
    classKey: 'warrior',
    minLevel: 1,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 1,
    cooldown: 0,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [9, 14],
    damageFormula: '1d6 + STR + 3',
    attributeScaling: 'STR',
    statusEffect: 'sundered',
    centralMechanic: 'Sunders target armor (-2 AC) and deals +3 bonus cleave if target was already sundered.',
    tacticalExplanation: 'Use on high-armor frontline enemies to soften them for companion follow-ups.',
    animationReference: 'warrior_overhead_cleave',
    iconReference: 'sundering_strike',
    description: 'Deliver a crushing overhead blow that shatters enemy plate, inflicting Sundered (-2 AC) for 2 turns.',
  },
  guarded_stance: {
    id: 'guarded_stance',
    name: 'Guarded Stance',
    classKey: 'warrior',
    minLevel: 1,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 6,
    damageFormula: 'Warded (+2 AC) + 25% Phys Reduction + 6 Temp HP (-1 Move Trade-off)',
    attributeScaling: 'STR/CHA',
    statusEffect: 'warded',
    centralMechanic: 'Enter an unyielding defensive brace: +2 AC, 25% Physical Reduction, 6 Temp HP, Displacement Immunity, and -1 Move Range trade-off while active.',
    tacticalExplanation: 'Activate before holding a choke point or absorbing a boss strike.',
    animationReference: 'warrior_shield_brace',
    iconReference: 'guarded_stance',
    description: 'Brace your greatshield and lock footing, gaining Warded (+2 AC), 25% physical damage mitigation, displacement immunity, and 6 Temp HP for 2 turns (-1 Move Range while braced).',
  },
  whirlwind_assault: {
    id: 'whirlwind_assault',
    name: 'Whirlwind Assault',
    classKey: 'warrior',
    minLevel: 2,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'shockwave_ring',
    element: 'physical',
    damageRange: [8, 13],
    damageFormula: '1d8 + STR + 2 (All Adjacent Enemies)',
    attributeScaling: 'STR',
    centralMechanic: 'Spins greatsword in a 360-degree sweep around the Warrior, cleaving all adjacent enemies within 1 tile once without displacing them or moving the caster.',
    tacticalExplanation: 'Clear clustered swarms and punish enemy flanking formations without breaking your anchor tile.',
    animationReference: 'warrior_whirlwind_spin',
    iconReference: 'whirlwind_assault',
    description: 'Perform a sweeping 360-degree blade rotation that strikes all adjacent foes once for 8-13 physical DMG while holding your current tile.',
  },
  driving_assault: {
    id: 'driving_assault',
    name: 'Driving Assault',
    classKey: 'warrior',
    minLevel: 4,
    skillPointCost: 1,
    category: 'execution_gapcloser',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 3,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [11, 16],
    pushDistance: 2,
    selfReposition: 'leap_adjacent',
    damageFormula: '1d10 + STR + 4 + Push 2 & Wall Impact',
    attributeScaling: 'STR',
    statusEffect: 'sundered',
    centralMechanic: 'Vanguard bull-rush across up to 3 tiles; stops at first enemy struck, deals physical damage, and shoves target 2 tiles back (+4 impact DMG against walls).',
    tacticalExplanation: 'Gap-closer to push ranged weavers off bastions or ram enemies into obstacles.',
    animationReference: 'warrior_shoulder_charge',
    iconReference: 'driving_assault',
    description: 'Rush across up to 3 tiles to ram the target, stopping adjacent to them, dealing 11-16 DMG, pushing them 2 tiles back, and inflicting Sundered.',
  },
  weapon_parry: {
    id: 'weapon_parry',
    name: 'Weapon Parry',
    classKey: 'warrior',
    minLevel: 6,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 8,
    damageFormula: 'Deflects Next Melee Hit + 8 Counter DMG + 8 Temp HP',
    attributeScaling: 'DEX/STR',
    statusEffect: 'warded',
    centralMechanic: 'Prepares a melee blade parry reaction: Deflects the next qualifying incoming melee attack, negating its damage and delivering an 8 DMG counter-slash.',
    tacticalExplanation: 'Negate boss heavy melee strikes while turning enemy aggression against them (does not parry ranged or area spells).',
    animationReference: 'warrior_blade_riposte',
    iconReference: 'weapon_parry',
    description: 'Enter a poised deflection guard that grants 8 Temp HP, Warded (+2 AC), and parries the next incoming melee attack with an immediate counter-slash.',
  },
  crippling_blow: {
    id: 'crippling_blow',
    name: 'Crippling Blow',
    classKey: 'warrior',
    minLevel: 8,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [10, 15],
    statusEffect: 'rooted',
    damageFormula: '1d8 + STR + Hamstring Root (0 Move)',
    attributeScaling: 'STR',
    centralMechanic: 'Strikes low at tendons, dealing physical damage and impairing target movement (Rooted for 2 turns, respecting movement immunity).',
    tacticalExplanation: 'Pin evasive skirmishers and rogue stalkers in place for party focus fire.',
    animationReference: 'warrior_low_sweep',
    iconReference: 'crippling_blow',
    description: 'Aim a vicious low cut at the enemy’s leg armor, inflicting 10-15 physical DMG and impairing movement (Rooted) for 2 turns.',
  },
  unbreakable_resolve: {
    id: 'unbreakable_resolve',
    name: 'Unbreakable Resolve',
    classKey: 'warrior',
    minLevel: 10,
    skillPointCost: 1,
    category: 'cleansing_mend',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 12,
    cleanseStatuses: ['burning', 'rooted', 'sundered'],
    damageFormula: 'Purge Crowd Control + 12 Temp HP',
    attributeScaling: 'STR/CHA',
    centralMechanic: 'Braces with iron endurance to purge crowd-control/debuff statuses immediately and refresh a 12 Temporary HP buffer without infinite stacking.',
    tacticalExplanation: 'Emergency self-dispel when rooted in fire or heavily debuffed.',
    animationReference: 'warrior_warcry_flex',
    iconReference: 'unbreakable_resolve',
    description: 'Flex iron will to purge Burning, Rooted, and Sundered afflictions immediately and bolster oneself with 12 Temporary HP.',
  },
  earthsplitter: {
    id: 'earthsplitter',
    name: 'Earthsplitter',
    classKey: 'warrior',
    minLevel: 12,
    skillPointCost: 1,
    category: 'seismic_glaive',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 3,
    targetType: 'enemy',
    aoeShape: 'piercing_ray',
    element: 'physical',
    damageRange: [14, 20],
    damageFormula: '2d8 + STR (3-Tile Directional Fracture Line)',
    attributeScaling: 'STR',
    statusEffect: 'sundered',
    centralMechanic: 'Slams great weapon into stone, projecting a 3-tile directional ground fracture that damages and sunders each enemy on the line, stopping at impassable pillars.',
    tacticalExplanation: 'Hit multiple lined-up enemies, piercing frontlines to reach fragile spellcasters.',
    animationReference: 'warrior_ground_slam',
    iconReference: 'earthsplitter',
    description: 'Drive your blade into the earth to project a 3-tile linear fracture, dealing 14-20 physical DMG and Sundering all enemies along the unblocked line.',
  },
  relentless_pursuit: {
    id: 'relentless_pursuit',
    name: 'Relentless Pursuit',
    classKey: 'warrior',
    minLevel: 14,
    skillPointCost: 1,
    category: 'execution_gapcloser',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [8, 12],
    selfReposition: 'leap_adjacent',
    refundApOnKO: 1,
    damageFormula: 'Path Pursuit (Range 4) + Follow-up Strike (+1 AP vs <=40% HP)',
    attributeScaling: 'STR/DEX',
    centralMechanic: 'Moves along a valid path adjacent to target enemy within 4 tiles and executes a follow-up melee strike without target displacement; refunds 1 AP if target is <=40% HP or defeated.',
    tacticalExplanation: 'Catch fleeing enemies and prevent ranged snipers from keeping distance without shoving them away.',
    animationReference: 'warrior_leaping_strike',
    iconReference: 'relentless_pursuit',
    description: 'Sprint across up to 4 tiles to an open space adjacent to the target enemy and deliver a controlled 8-12 DMG follow-up cut (refunds 1 AP vs bloodied/KO targets).',
  },
  iron_reprisal: {
    id: 'iron_reprisal',
    name: 'Iron Reprisal',
    classKey: 'warrior',
    minLevel: 16,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [15, 24],
    damageFormula: '1d12 + STR + Absorbed-Hit Retaliation & Counter-Arm',
    attributeScaling: 'STR',
    centralMechanic: 'Retaliatory execution that deals +6 bonus vengeance damage after absorbing hits and arms a single non-recursive 9 DMG melee counter-retaliation for 1 round.',
    tacticalExplanation: 'Turn boss focus fire into a lethal counter-strike.',
    animationReference: 'warrior_furious_overhead',
    iconReference: 'iron_reprisal',
    description: 'Unleash absorbed kinetic punishment for 15-24 physical DMG (+6 Vengeance DMG when wounded/struck) and arm a 1-round melee retaliation.',
  },
  battlefield_commander: {
    id: 'battlefield_commander',
    name: 'Battlefield Commander',
    classKey: 'warrior',
    minLevel: 18,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 4,
    targetType: 'ally',
    aoeShape: 'bastion_aura',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 10,
    statusEffect: 'blessed',
    damageFormula: 'Radius-4 Party Command: +10 Temp HP + Blessed (+2 Hit)',
    attributeScaling: 'CHA/STR',
    centralMechanic: 'Rallies the Warrior and all conscious party allies within a 4-tile radius, granting +10 Temporary HP and Blessed (+2 Attack Roll) for 2 turns.',
    tacticalExplanation: 'Mass squad coordination buff before an all-out assault.',
    animationReference: 'warrior_banner_rally',
    iconReference: 'battlefield_commander',
    description: 'Raise the vanguard standard to coordinate all conscious allies within 4 tiles, granting +10 Temp HP and Blessed (+2 Hit) for 2 turns.',
  },
  last_stand: {
    id: 'last_stand',
    name: 'Last Stand',
    classKey: 'warrior',
    minLevel: 20,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 2,
    cooldown: 5,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 20,
    statusEffect: 'warded',
    damageFormula: 'Critical Condition Only (Once/Combat): 20 Temp HP + Warded + 1 HP Floor (2T)',
    attributeScaling: 'STR',
    centralMechanic: 'Available only in critical conditions (<=45% HP, surrounded by 2+ enemies, or last ally standing) once per combat: Grants 20 Temp HP, Warded (+2 AC), and prevents HP from dropping below 1 for 2 turns.',
    tacticalExplanation: 'Ultimate survival clutch: withstand lethal bursts under critical threat without permanent invulnerability.',
    animationReference: 'warrior_last_stand_glow',
    iconReference: 'last_stand',
    description: 'Requires critical condition (<=45% HP, 2+ adjacent foes, or last conscious ally; once per combat). Refuse to fall: gain 20 Temp HP, Warded (+2 AC), and a 1 HP survival floor for 2 turns.',
  },

  /* ----------------------------------------------------------------------- */
  /* MAGE (12 Core Skills)                                                   */
  /* ----------------------------------------------------------------------- */
  infernal_orb: {
    id: 'infernal_orb',
    name: 'Infernal Orb',
    classKey: 'mage',
    minLevel: 1,
    skillPointCost: 1,
    category: 'pyromantic_detonation',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'fire',
    damageRange: [12, 16],
    damageFormula: '1d6 + INT + 8 (Radius 1 Fire Blast & Hazard Ignition)',
    attributeScaling: 'INT',
    statusEffect: 'burning',
    centralMechanic: 'Hurls a roaring pyromantic sphere across 4 tiles: Deals 12-16 Fire damage, inflicts Burning for 2 turns in a 1-tile radius, and ignites oil surfaces and explosive barrels.',
    tacticalExplanation: 'Primary elemental blast for igniting alchemical oil pools and burning clusters of adversaries.',
    animationReference: 'mage_infernal_orb_cast',
    iconReference: 'infernal_orb',
    description: 'Hurl a blazing orb of elemental fire up to 4 tiles away. Explodes in a 1-tile radius for 12-16 Fire DMG, applies Burning for 2 turns, and ignites volatile hazards.',
  },
  glacial_lance: {
    id: 'glacial_lance',
    name: 'Glacial Lance',
    classKey: 'mage',
    minLevel: 2,
    skillPointCost: 1,
    category: 'piercing_ray',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'piercing_ray',
    element: 'arcane',
    damageRange: [10, 14],
    damageFormula: '1d8 + INT + 4 (Piercing Frost Ray; +4 DMG vs Chilled)',
    attributeScaling: 'INT',
    statusEffect: 'rooted',
    centralMechanic: 'Conjures a razor frost spear piercing up to 3 tiles in target direction: Deals 10-14 Frost damage and Chilled for 2 turns (+4 bonus damage against already-Chilled foes; halts at impassable pillars).',
    tacticalExplanation: 'Pierces through frontliners to strike backline casters while freezing advance lanes.',
    animationReference: 'mage_glacial_lance_thrust',
    iconReference: 'glacial_lance',
    description: 'Launch a piercing frost projectile through up to 3 linear tiles, dealing 10-14 Frost DMG and Chilled to each enemy hit (+4 DMG vs already-Chilled targets; stops at walls).',
  },
  chain_lightning: {
    id: 'chain_lightning',
    name: 'Chain Lightning',
    classKey: 'mage',
    minLevel: 4,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [12, 12],
    damageFormula: 'Deterministic 3-Arc Arcane Voltage: 12 -> 8 -> 5 DMG',
    attributeScaling: 'INT',
    centralMechanic: 'Discharges an electric arc arcing to up to 3 nearest unique enemies within 4 tiles: Deals 12 DMG to first target, 8 to second, and 5 to third (never hits allies or duplicates).',
    tacticalExplanation: 'Reliable multi-target punishment against grouped or dispersed enemy formations.',
    animationReference: 'mage_chain_lightning_arc',
    iconReference: 'chain_lightning',
    description: 'Discharge cascading planar lightning at range 4. Strikes up to 3 enemies in deterministic sequence (12 DMG, 8 DMG, 5 DMG), never hitting allies or the same foe twice.',
  },
  blink_step: {
    id: 'blink_step',
    name: 'Blink Step',
    classKey: 'mage',
    minLevel: 6,
    skillPointCost: 1,
    category: 'phase_transfusion',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'ground',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    damageFormula: 'Unimpeded Spacetime Teleportation up to 4 Tiles (Usable while Rooted)',
    attributeScaling: 'INT',
    centralMechanic: 'Instantly teleports the Mage to an unoccupied walkable tile up to 4 tiles away: Can be executed while Rooted, crosses intervening obstacles, and does not trigger opportunity attacks.',
    tacticalExplanation: 'Instant tactical escape from melee lock-downs or elevation repositioning onto bastions.',
    animationReference: 'mage_blink_step_teleport',
    iconReference: 'blink_step',
    description: 'Bend space to teleport up to 4 tiles to an empty walkable space. Usable while Rooted, ignores intervening obstacles and units, and does not trigger opportunity strikes.',
  },
  gravitational_collapse: {
    id: 'gravitational_collapse',
    name: 'Gravitational Collapse',
    classKey: 'mage',
    minLevel: 8,
    skillPointCost: 1,
    category: 'spacetime_implosion',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'ground',
    aoeShape: 'vacuum_implosion',
    element: 'arcane',
    damageRange: [8, 8],
    pullDistance: 1,
    damageFormula: 'Radius-2 Gravitational Pull 1 Tile + 8 Arcane DMG',
    attributeScaling: 'INT',
    statusEffect: 'rooted',
    centralMechanic: 'Generates a powerful micro-singularity at range 4: Pulls all eligible enemies within 2 tiles 1 tile toward center, deals 8 Arcane damage, and roots them (does not displace allies).',
    tacticalExplanation: 'Drag ranged snipers off high ground or pack enemies together into fire pools and cleave radiuses.',
    animationReference: 'mage_gravitational_collapse_vortex',
    iconReference: 'gravitational_collapse',
    description: 'Ignite a spatial singularity at range 4 with a 2-tile radius. Pulls enemies 1 tile inward, inflicts 8 Arcane DMG, and pins them in place without displacing allies.',
  },
  arcane_disjunction: {
    id: 'arcane_disjunction',
    name: 'Arcane Disjunction',
    classKey: 'mage',
    minLevel: 10,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [6, 12],
    damageFormula: '6 Base Arcane DMG (+6 Bonus DMG & Dispels Warded/Blessed/Temp HP)',
    attributeScaling: 'INT',
    centralMechanic: 'Unravels protective magic at range 4: Strips Warded, Blessed, and Temp HP from the target enemy, dealing 6 Arcane damage (+6 bonus damage if buffs or shields were purged).',
    tacticalExplanation: 'Shatters heavily shielded boss barriers and strips inquisitor buffs.',
    animationReference: 'mage_arcane_disjunction_shatter',
    iconReference: 'arcane_disjunction',
    description: 'Unweave magical enchantments at range 5. Deals 8 Arcane DMG, purges Warded, Blessed, and Temp HP shields, and inflicts +6 bonus DMG if any barrier was stripped.',
  },
  aegis_ward: {
    id: 'aegis_ward',
    name: 'Aegis Ward',
    classKey: 'mage',
    minLevel: 1,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 3,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    grantTempHp: 10,
    statusEffect: 'warded',
    damageFormula: '+10 Temp HP + Warded (+2 AC) for 2 Turns (6 Backlash DMG when Broken)',
    attributeScaling: 'INT',
    centralMechanic: 'Weaves a protective runic shroud around self or ally within 3 tiles: Grants +10 Temp HP and Warded (+2 AC) for 2 turns; if broken by damage, emits an arcane backlash dealing 6 damage to adjacent foes.',
    tacticalExplanation: 'Proactive shield for fragile companions or self with punishing retaliation on shield break.',
    animationReference: 'mage_aegis_ward_barrier',
    iconReference: 'aegis_ward',
    description: 'Envelop self or an ally within 3 tiles in an ethereal ward, granting +10 Temp HP and Warded (+2 AC) for 2 turns. If the barrier is depleted by enemy damage, it explodes for 6 Arcane DMG to adjacent foes.',
  },
  counterspell: {
    id: 'counterspell',
    name: 'Counterspell',
    classKey: 'mage',
    minLevel: 12,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    grantTempHp: 6,
    statusEffect: 'warded',
    damageFormula: 'Spell Reversal Reaction (2T): Negates Next Ranged/Elemental Hit & Reflects 8 DMG',
    attributeScaling: 'INT',
    centralMechanic: 'Prepares a spell-reversal reaction for 2 turns: Negates the next incoming enemy ranged or magical attack and reflects 8 Arcane damage back to the attacker (does not block adjacent melee strikes).',
    tacticalExplanation: 'Neutralize deadly ranged boss spells and turn enemy artillery against itself.',
    animationReference: 'mage_counterspell_weave',
    iconReference: 'counterspell',
    description: 'Poise a reflective counter-ward for 2 turns (+6 Temp HP). Completely negates the next incoming ranged or elemental attack, reflecting 8 Arcane DMG back at the caster.',
  },
  phase_veil: {
    id: 'phase_veil',
    name: 'Phase Veil',
    classKey: 'mage',
    minLevel: 14,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    cleanseStatuses: ['burning', 'rooted', 'sundered'],
    damageFormula: 'Planar Shifting: Purge All Debuffs + 1 Move Range + Physical Damage Protection (1T)',
    attributeScaling: 'INT',
    statusEffect: 'warded',
    centralMechanic: 'Shifts into a translucent planar state for 1 turn: Purges Rooted, Burning, and Sundered instantly, grants +1 Move Range, and provides physical damage mitigation.',
    tacticalExplanation: 'Emergency cleanse and repositioning surge when pinned or threatened by melee brute rushers.',
    animationReference: 'mage_phase_veil_shroud',
    iconReference: 'phase_veil',
    description: 'Phase partially into the ethereal weave. Immediately purges Burning, Rooted, and Sundered, gaining +1 Move Range and physical damage protection for 1 turn.',
  },
  runic_mine: {
    id: 'runic_mine',
    name: 'Runic Mine',
    classKey: 'mage',
    minLevel: 16,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'ground',
    aoeShape: 'trap_tile',
    element: 'arcane',
    damageRange: [12, 16],
    damageFormula: 'Concealed Trap: 12-16 Arcane DMG + Root (1T) on Enemy Entry',
    attributeScaling: 'INT',
    statusEffect: 'rooted',
    centralMechanic: 'Inscribes a dormant arcane mine on an unoccupied walkable tile within 4 tiles (max 1 active mine per Mage): Detonates when an enemy enters or begins turn on the tile for 12-16 Arcane damage and Rooted (1 turn).',
    tacticalExplanation: 'Area denial against flankers and choke point lockdown.',
    animationReference: 'mage_runic_mine_inscribe',
    iconReference: 'runic_mine',
    description: 'Inscribe a concealed runic trap on an empty tile up to 4 tiles away (max 1 active mine). Detonates when an enemy steps on it, dealing 12-16 Arcane DMG and Rooting them for 1 turn.',
  },
  astral_rift: {
    id: 'astral_rift',
    name: 'Astral Rift',
    classKey: 'mage',
    minLevel: 18,
    skillPointCost: 1,
    category: 'spacetime_implosion',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'ground',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [4, 4],
    damageFormula: 'Temporary Surface Hazard (2T): 4 Arcane DMG on Entry/Turn Start + Sundered (-2 AC)',
    attributeScaling: 'INT',
    statusEffect: 'sundered',
    centralMechanic: 'Rips open a temporary astral rift on target walkable tile for 2 turns: Deals 4 Arcane damage and inflicts Sundered (-2 AC) to any enemy stepping onto or starting turn on the tile without overwriting permanent rift terrain.',
    tacticalExplanation: 'Creates tactical hazard zones to funnel enemy approach corridors.',
    animationReference: 'mage_astral_rift_tear',
    iconReference: 'astral_rift',
    description: 'Tear open an ethereal chasm across the target tile for 2 turns. Enemies entering or starting turns inside suffer 4 Arcane DMG and are Sundered (-2 AC).',
  },
  prismatic_field: {
    id: 'prismatic_field',
    name: 'Prismatic Field',
    classKey: 'mage',
    minLevel: 20,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'arcane',
    damageRange: [0, 0],
    grantTempHp: 8,
    damageFormula: '3x3 Planar Harmonic Zone (2T): Allies +8 Temp HP & Warded / Enemies -2 Hit & Sundered',
    attributeScaling: 'INT',
    statusEffect: 'blessed',
    centralMechanic: 'Establishes a 3x3 harmonic planar matrix for 2 turns: Allies inside receive +8 Temp HP and Warded (+2 AC); enemies inside suffer -2 to attack rolls and Sundered (-2 AC) (effects end upon leaving zone).',
    tacticalExplanation: 'Pinnacle battlefield control field creating overwhelming team advantage in team clashes.',
    animationReference: 'mage_prismatic_field_matrix',
    iconReference: 'prismatic_field',
    description: 'Deploy an immense 3x3 harmonic field for 2 turns. Allies standing within gain +8 Temp HP and Warded (+2 AC); enemies suffer an accuracy penalty (-2 Hit) and Sundered (-2 AC).',
  },

  /* ----------------------------------------------------------------------- */
  /* ROGUE (12 Core Skills)                                                  */
  /* ----------------------------------------------------------------------- */
  quickdraw: {
    id: 'quickdraw',
    name: 'Quickdraw',
    classKey: 'rogue',
    minLevel: 1,
    skillPointCost: 1,
    category: 'predator_strike',
    isPassive: false,
    apCost: 1,
    cooldown: 0,
    range: 3,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [7, 12],
    damageFormula: '1d6 + DEX + Rapid Strike (+2 vs Low AC)',
    attributeScaling: 'DEX',
    centralMechanic: 'Rapid hand-crossbow or throwing knife: Deals 7-12 damage with +2 hit against un-armored foes.',
    tacticalExplanation: 'Low-cost poke to finish off weak targets without exposing yourself to melee.',
    animationReference: 'rogue_wrist_snap',
    iconReference: 'quickdraw',
    description: 'Snap-fire a concealed throwing dagger or hand crossbow at range 3, dealing 7-12 physical DMG.',
  },
  shadow_veil: {
    id: 'shadow_veil',
    name: 'Shadow Veil',
    classKey: 'rogue',
    minLevel: 1,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 4,
    damageFormula: 'Stealth Concealment + Guaranteed Sneak Attack (+6 DMG)',
    attributeScaling: 'DEX',
    centralMechanic: 'Enters stealth: Enemies cannot target rogue directly; rogue’s next strike deals +6 guaranteed sneak damage.',
    tacticalExplanation: 'Drop target aggro and prepare a devastating ambush on high-value targets.',
    animationReference: 'rogue_smoke_fade',
    iconReference: 'shadow_veil',
    description: 'Vanish into gloomy shadows, gaining untargetability and empowering your next attack with +6 Sneak Attack DMG.',
  },
  mark_for_death: {
    id: 'mark_for_death',
    name: 'Mark for Death',
    classKey: 'rogue',
    minLevel: 2,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 5,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    statusEffect: 'sundered',
    damageFormula: 'Quarry Mark: Party Deals +3 Bonus DMG vs Target',
    attributeScaling: 'DEX/INT',
    centralMechanic: 'Designates target as squad quarry: Every party member deals +3 bonus damage against this enemy for 3 turns.',
    tacticalExplanation: 'Place on elite or boss enemies immediately so all companion attacks hit harder.',
    animationReference: 'rogue_mark_target',
    iconReference: 'mark_for_death',
    description: 'Mark a priority enemy, causing all party attacks against them to deal +3 bonus DMG and applying Sundered.',
  },
  tripwire: {
    id: 'tripwire',
    name: 'Tripwire',
    classKey: 'rogue',
    minLevel: 4,
    skillPointCost: 1,
    category: 'trap_snare',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 3,
    targetType: 'ground',
    aoeShape: 'trap_tile',
    element: 'physical',
    damageRange: [8, 14],
    statusEffect: 'rooted',
    damageFormula: 'Concealed Trap: 8-14 Piercing + Prone / Rooted',
    attributeScaling: 'DEX/INT',
    centralMechanic: 'Rig a concealed wire trap: First enemy to step on tile takes 8-14 damage, loses all move, and becomes Rooted.',
    tacticalExplanation: 'Guard flanks and staircases so rushing melee enemies trip and lose their turn.',
    animationReference: 'rogue_plant_wire',
    iconReference: 'tripwire',
    description: 'Deploy an invisible wire snare on a target tile that triggers when stepped on, dealing 8-14 DMG and Rooting the victim.',
  },
  smoke_escape: {
    id: 'smoke_escape',
    name: 'Smoke Escape',
    classKey: 'rogue',
    minLevel: 6,
    skillPointCost: 1,
    category: 'evasive_barrage',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 2,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 6,
    damageFormula: 'Smoke Screen (Blocks LoS) + 2 Tile Dash',
    attributeScaling: 'DEX',
    centralMechanic: 'Drops a thick smoke bomb blocking line of sight and vaults 2 tiles backward.',
    tacticalExplanation: 'Break line of sight from enemy archers while repositioning safely.',
    animationReference: 'rogue_smoke_tumble',
    iconReference: 'smoke_escape',
    description: 'Shatter a smoke pellet to obscure line of sight, gain 6 Temp HP, and tumble 2 tiles away from danger.',
  },
  pickpocket: {
    id: 'pickpocket',
    name: 'Pickpocket',
    classKey: 'rogue',
    minLevel: 8,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [4, 8],
    damageFormula: 'Steals 1 AP From Adjacent Foe + 4-8 DMG',
    attributeScaling: 'DEX',
    centralMechanic: 'Combat sleight of hand: Steals 1 Action Point from target enemy and adds it to rogue’s pool this turn.',
    tacticalExplanation: 'Rob boss units of their expensive actions while gaining bonus attacks for yourself.',
    animationReference: 'rogue_sleight_strike',
    iconReference: 'pickpocket',
    description: 'Deliver a distracting feint, dealing 4-8 DMG, siphoning 1 Action Point from the foe, and adding it to your turn.',
  },
  false_opening: {
    id: 'false_opening',
    name: 'False Opening',
    classKey: 'rogue',
    minLevel: 10,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    statusEffect: 'warded',
    grantTempHp: 8,
    damageFormula: 'Auto-Dodge Next Melee Attack + Immediate Counter-Slash',
    attributeScaling: 'DEX',
    centralMechanic: 'Bait attack: Rogue automatically dodges the next melee attack and delivers an immediate riposte for 10 damage.',
    tacticalExplanation: 'Punish aggressive enemies who dare engage the rogue in melee.',
    animationReference: 'rogue_counter_stance',
    iconReference: 'false_opening',
    description: 'Feign exhaustion to bait an incoming blow, automatically dodging it and slashing the attacker for 10 DMG.',
  },
  poisoned_edge: {
    id: 'poisoned_edge',
    name: 'Poisoned Edge',
    classKey: 'rogue',
    minLevel: 12,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [0, 0],
    damageFormula: 'Next 2 Attacks Inflict 5 Nature DoT & Halve Healing',
    attributeScaling: 'DEX/INT',
    centralMechanic: 'Coats blades in deadly nightshade: Next 2 attacks inflict 5 Nature damage per turn and reduce target healing by 50%.',
    tacticalExplanation: 'Counters healing paladins and inquisitors while dealing guaranteed passive attrition.',
    animationReference: 'rogue_poison_vial',
    iconReference: 'poisoned_edge',
    description: 'Coat your weapons in lethal Whispering Vale toxin. Your next two attacks inflict 5 Nature DoT and halve healing.',
  },
  evasive_roll: {
    id: 'evasive_roll',
    name: 'Evasive Roll',
    classKey: 'rogue',
    minLevel: 14,
    skillPointCost: 1,
    category: 'evasive_barrage',
    isPassive: false,
    apCost: 1,
    cooldown: 1,
    range: 3,
    targetType: 'ground',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 5,
    statusEffect: 'warded',
    damageFormula: '3-Tile Tumble + +3 AC Until Next Turn',
    attributeScaling: 'DEX',
    centralMechanic: 'Tumbles across 3 tiles without provoking reactions, gaining +3 AC (Warded) until start of next turn.',
    tacticalExplanation: 'Low-cooldown mobility to escape surrounded positions or dive into flanking spots.',
    animationReference: 'rogue_combat_roll',
    iconReference: 'evasive_roll',
    description: 'Roll acrobatically through enemy zones of control up to 3 tiles, gaining +3 AC and 5 Temp HP.',
  },
  ambush_protocol: {
    id: 'ambush_protocol',
    name: 'Ambush Protocol',
    classKey: 'rogue',
    minLevel: 16,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'physical',
    damageRange: [0, 0],
    damageFormula: 'Passive: Attacks from Stealth Refund 1 AP & Ignore 4 AC',
    attributeScaling: 'DEX',
    centralMechanic: 'Attacking from stealth or flanking automatically refunds 1 AP and penetrates 4 points of enemy Armor Class.',
    tacticalExplanation: 'Allows rogues to maintain rapid multi-strike turns when properly coordinated.',
    animationReference: 'rogue_ambush_stance',
    iconReference: 'ambush_protocol',
    description: 'Attacking from stealth or flanking refunds 1 Action Point and bypasses 4 points of enemy Armor Class.',
  },
  shadow_exchange: {
    id: 'shadow_exchange',
    name: 'Shadow Exchange',
    classKey: 'rogue',
    minLevel: 18,
    skillPointCost: 1,
    category: 'phase_transfusion',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 5,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [10, 16],
    statusEffect: 'sundered',
    damageFormula: 'Swap Positions with Target + 10-16 DMG + Sunder',
    attributeScaling: 'DEX/INT',
    centralMechanic: 'Instantly swaps grid coordinates with target enemy; target is disoriented, taking 10-16 damage and Sundered.',
    tacticalExplanation: 'Pull enemy bosses into your waiting vanguard while teleporting rogue to safety.',
    animationReference: 'rogue_shadow_swap',
    iconReference: 'shadow_exchange',
    description: 'Swap physical positions with an enemy within 5 tiles, disorienting them for 10-16 DMG and applying Sundered.',
  },
  perfect_execution: {
    id: 'perfect_execution',
    name: 'Perfect Execution',
    classKey: 'rogue',
    minLevel: 20,
    skillPointCost: 1,
    category: 'execution_gapcloser',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [28, 42],
    damageFormula: '28-42 DMG + Instant Kill if Target ≤35% HP',
    attributeScaling: 'DEX',
    centralMechanic: 'Surgical assassination strike: Deals 28-42 physical damage; if target is below 35% HP, instantly executes them and resets all rogue CDs.',
    tacticalExplanation: 'The ultimate boss executioner strike in the game.',
    animationReference: 'rogue_throat_slit',
    iconReference: 'perfect_execution',
    description: 'Deliver an infallible assassination strike dealing 28-42 DMG; instantly executes foes below 35% HP and resets all cooldowns.',
  },

  /* ----------------------------------------------------------------------- */
  /* PALADIN (12 Core Skills)                                                */
  /* ----------------------------------------------------------------------- */
  consecrated_strike: {
    id: 'consecrated_strike',
    name: 'Consecrated Strike',
    classKey: 'paladin',
    minLevel: 1,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 1,
    cooldown: 0,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [9, 14],
    statusEffect: 'sundered',
    damageFormula: '1d8 + STR + Consecrates Impact Tile',
    attributeScaling: 'STR/CHA',
    centralMechanic: 'Infuses warhammer with holy fire, dealing radiant damage and converting the target tile into sanctified ground.',
    tacticalExplanation: 'Basic frontline attack that creates persistent healing ground for allies.',
    animationReference: 'paladin_hammer_down',
    iconReference: 'consecrated_strike',
    description: 'Smite with sanctified silver, dealing 9-14 Radiant DMG, applying Sundered, and blessing the impact tile.',
  },
  oathward: {
    id: 'oathward',
    name: 'Oathward',
    classKey: 'paladin',
    minLevel: 1,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 3,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [0, 0],
    grantTempHp: 8,
    statusEffect: 'warded',
    damageFormula: 'Warded (+2 AC) + 8 Temp HP to Ally',
    attributeScaling: 'CHA',
    centralMechanic: 'Projects a luminous aegis: Grants target ally Warded (+2 AC) and absorbs up to 8 incoming damage.',
    tacticalExplanation: 'Protect vulnerable squishy casters or rangers under focus fire.',
    animationReference: 'paladin_shield_cast',
    iconReference: 'oathward',
    description: 'Shield an ally within 3 tiles with covenant light, granting Warded (+2 AC) and 8 Temporary HP.',
  },
  sanctuary_ring: {
    id: 'sanctuary_ring',
    name: 'Sanctuary Ring',
    classKey: 'paladin',
    minLevel: 2,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'chebyshev_3x3',
    element: 'radiant',
    damageRange: [0, 0],
    grantTempHp: 6,
    healAmount: 6,
    statusEffect: 'blessed',
    damageFormula: '3x3 Ward: Allies Gain +2 AC & Regen 3 HP/Turn',
    attributeScaling: 'CHA',
    centralMechanic: 'Establishes a blessed boundary around paladin: Allies inside gain +2 AC and regenerate 3 HP per turn.',
    tacticalExplanation: 'Drop when grouping up in tight rooms or protecting the party against swarm attacks.',
    animationReference: 'paladin_ring_of_light',
    iconReference: 'sanctuary_ring',
    description: 'Manifest a 3x3 halo of sanctuary: all allies inside gain +2 AC, 6 Temp HP, and regenerate health each turn.',
  },
  judgment_mark: {
    id: 'judgment_mark',
    name: 'Judgment Mark',
    classKey: 'paladin',
    minLevel: 4,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [6, 10],
    damageFormula: 'Retribution Brand: 50% Damage Reflected Back',
    attributeScaling: 'CHA',
    centralMechanic: 'Condemns an enemy: When target damages any ally, they immediately take 50% of that damage back as radiant retribution.',
    tacticalExplanation: 'Neutralize aggressive boss attackers and force them to suffer for every strike.',
    animationReference: 'paladin_brand_forehead',
    iconReference: 'judgment_mark',
    description: 'Condemn an enemy at range 4: dealing 6-10 Radiant DMG and reflecting 50% of damage they inflict back to them.',
  },
  radiant_mend: {
    id: 'radiant_mend',
    name: 'Radiant Mend',
    classKey: 'paladin',
    minLevel: 6,
    skillPointCost: 1,
    category: 'cleansing_mend',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [0, 0],
    healAmount: 14,
    cleanseStatuses: ['burning', 'rooted', 'sundered'],
    damageFormula: 'Restore 14 HP + Purge All Debuffs',
    attributeScaling: 'CHA',
    statusEffect: 'blessed',
    centralMechanic: 'Channels dawnlight to restore 14 HP to an ally and purge Burning, Rooted, or Sundered statuses.',
    tacticalExplanation: 'Core paladin life-saver to rescue low-health comrades and cleanse debilitating crowd control.',
    animationReference: 'paladin_lay_on_hands',
    iconReference: 'radiant_mend',
    description: 'Bathe an ally in dawnlight, restoring 14 HP, purging all negative statuses, and granting Blessed.',
  },
  shield_of_conviction: {
    id: 'shield_of_conviction',
    name: 'Shield of Conviction',
    classKey: 'paladin',
    minLevel: 8,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [9, 14],
    pushDistance: 2,
    statusEffect: 'sundered',
    damageFormula: '1d8 + STR + Push 2 Tiles (Stuns on Collision)',
    attributeScaling: 'STR',
    centralMechanic: 'Shield bash dealing 9-14 damage and pushing enemy 2 tiles back; stuns if they hit terrain or barrels.',
    tacticalExplanation: 'Knock enemies into oil barrels, braziers, or off high-ground ledges.',
    animationReference: 'paladin_shield_ram',
    iconReference: 'shield_of_conviction',
    description: 'Ram your crested shield into the enemy, dealing 9-14 DMG, shoving them 2 tiles back, and sundering armor.',
  },
  oath_of_restraint: {
    id: 'oath_of_restraint',
    name: 'Oath of Restraint',
    classKey: 'paladin',
    minLevel: 10,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [7, 12],
    statusEffect: 'rooted',
    damageFormula: 'Spectral Golden Chains: -1 AP & 0 Move for 2 Turns',
    attributeScaling: 'CHA',
    centralMechanic: 'Spectral golden chains bind target: Reduces enemy AP by 1 and restricts movement to 0 for 2 turns.',
    tacticalExplanation: 'Lock down fast bosses or mobile skirmishers.',
    animationReference: 'paladin_golden_chains',
    iconReference: 'oath_of_restraint',
    description: 'Summon golden shackles of covenant law, dealing 7-12 Radiant DMG, reducing target AP by 1, and Rooting them.',
  },
  sacred_ground: {
    id: 'sacred_ground',
    name: 'Sacred Ground',
    classKey: 'paladin',
    minLevel: 12,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'ground',
    aoeShape: 'solar_cross',
    element: 'radiant',
    damageRange: [10, 16],
    healAmount: 8,
    statusEffect: 'blessed',
    damageFormula: '5-Tile Solar Cross: 10-16 DMG to Foes & 8 Heal to Allies',
    attributeScaling: 'CHA/STR',
    centralMechanic: 'Consecrates a 5-tile solar cross: Deals radiant damage to enemies and heals standing allies for 8 HP.',
    tacticalExplanation: 'Turn contested choke points into sacred zones of victory.',
    animationReference: 'paladin_cross_consecration',
    iconReference: 'sacred_ground',
    description: 'Hallow a 5-tile cross on the ground: heals allies for 8 HP and deals 10-16 Radiant DMG to enemies.',
  },
  burden_of_sin: {
    id: 'burden_of_sin',
    name: 'Burden of Sin',
    classKey: 'paladin',
    minLevel: 14,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 3,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [11, 17],
    statusEffect: 'sundered',
    damageFormula: 'Weighs Target: -4 DMG on All Enemy Attacks for 2 Turns',
    attributeScaling: 'CHA',
    centralMechanic: 'Places the weight of guilt on the target: Reduces all their attack damage by -4 and halves their movement for 2 turns.',
    tacticalExplanation: 'Massive debuff against high-damage enemy commanders.',
    animationReference: 'paladin_sin_brand',
    iconReference: 'burden_of_sin',
    description: 'Crush the target under the moral gravity of their sins, reducing their attack damage by 4 for 2 turns.',
  },
  beacon_of_hope: {
    id: 'beacon_of_hope',
    name: 'Beacon of Hope',
    classKey: 'paladin',
    minLevel: 16,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 3,
    targetType: 'self',
    aoeShape: 'bastion_aura',
    element: 'radiant',
    damageRange: [0, 0],
    damageFormula: 'Passive Aura: Sub-30% Allies Gain +10 Temp HP & Blessed',
    attributeScaling: 'CHA',
    centralMechanic: 'Aura of salvation: Any ally within 3 tiles dropping below 30% HP immediately gains 10 Temp HP and Blessed status.',
    tacticalExplanation: 'Prevents party members from suffering sudden burst fatalities.',
    animationReference: 'paladin_beacon_radiance',
    iconReference: 'beacon_of_hope',
    description: 'Radiate an aura of divine grace: Nearby companions falling below 30% HP instantly receive 10 Temp HP and Blessed.',
  },
  divine_intercession: {
    id: 'divine_intercession',
    name: 'Divine Intercession',
    classKey: 'paladin',
    minLevel: 18,
    skillPointCost: 1,
    category: 'cleansing_mend',
    isPassive: false,
    apCost: 1,
    cooldown: 4,
    range: 4,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [0, 0],
    healAmount: 18,
    grantTempHp: 10,
    statusEffect: 'warded',
    damageFormula: 'Teleport to Ally + Absorb Fatal Blow + 18 Heal',
    attributeScaling: 'CHA/STR',
    centralMechanic: 'Paladin blinks adjacent to an imperiled ally, heals them for 18 HP, and grants them Warded (+2 AC).',
    tacticalExplanation: 'Save a companion from certain death with immediate gap-closing intervention.',
    animationReference: 'paladin_teleport_intercession',
    iconReference: 'divine_intercession',
    description: 'Instantly leap adjacent to an imperiled ally, restoring 18 HP, granting 10 Temp HP, and warding them against harm.',
  },
  final_judgment: {
    id: 'final_judgment',
    name: 'Final Judgment',
    classKey: 'paladin',
    minLevel: 20,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'radiant',
    damageRange: [26, 38],
    healAmount: 15,
    statusEffect: 'sundered',
    damageFormula: '3x3 Celestial Pillar: 26-38 Radiant DMG + Consecrates 9 Tiles',
    attributeScaling: 'CHA/STR',
    centralMechanic: 'Calls down a column of divine wrath: Deals 26-38 Radiant damage in 3x3, heals standing allies for 15, and consecrates all tiles.',
    tacticalExplanation: 'Ultimate paladin cataclysm that cleanses corrupted ground and finishes high-threat encounters.',
    animationReference: 'paladin_pillar_of_wrath',
    iconReference: 'final_judgment',
    description: 'Call down a colossal pillar of radiant judgment, dealing 26-38 Radiant DMG, healing allies, and hallowing the area.',
  },

  /* ----------------------------------------------------------------------- */
  /* RANGER (12 Core Skills)                                                 */
  /* ----------------------------------------------------------------------- */
  precision_shot: {
    id: 'precision_shot',
    name: 'Precision Shot',
    classKey: 'ranger',
    minLevel: 1,
    skillPointCost: 1,
    category: 'deadeye_snipe',
    isPassive: false,
    apCost: 1,
    cooldown: 0,
    range: 5,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [9, 14],
    damageFormula: '1d8 + DEX + 2 (+3 Hit if Unmoved)',
    attributeScaling: 'DEX',
    centralMechanic: 'Aimed longbow shot: Gains +3 attack roll if ranger has not moved yet this turn.',
    tacticalExplanation: 'Find high ground, remain stationary, and pick off priority targets with unmatched accuracy.',
    animationReference: 'ranger_aim_draw',
    iconReference: 'precision_shot',
    description: 'Take careful aim with an ironwood recurve bow, dealing 9-14 physical DMG with +3 accuracy if stationary.',
  },
  hunters_instinct: {
    id: 'hunters_instinct',
    name: 'Hunter\'s Instinct',
    classKey: 'ranger',
    minLevel: 1,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'nature',
    damageRange: [0, 0],
    damageFormula: 'Passive: +2 Move & +10% Crit vs Foes ≤50% HP',
    attributeScaling: 'DEX',
    centralMechanic: 'Tracks wounded prey: Gains +2 movement speed and +10% critical strike chance against enemies below 50% HP.',
    tacticalExplanation: 'Close distance to execute weakened enemies.',
    animationReference: 'ranger_scout_glow',
    iconReference: 'hunters_instinct',
    description: 'Attune senses to the scent of blood: gain +2 Move Range and +10% Crit against wounded prey.',
  },
  pinning_arrow: {
    id: 'pinning_arrow',
    name: 'Pinning Arrow',
    classKey: 'ranger',
    minLevel: 2,
    skillPointCost: 1,
    category: 'deadeye_snipe',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 5,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [8, 13],
    statusEffect: 'rooted',
    damageFormula: '1d8 + DEX + Rooted (2 Turns)',
    attributeScaling: 'DEX',
    centralMechanic: 'Heavy bodkin shaft staples target’s leg to ground, dealing damage and Rooting them for 2 turns.',
    tacticalExplanation: 'Stop charging warriors and melee stalkers dead in their tracks.',
    animationReference: 'ranger_pin_shot',
    iconReference: 'pinning_arrow',
    description: 'Pin the enemy to the terrain with a heavy bodkin arrow, inflicting 8-13 DMG and Rooted for 2 turns.',
  },
  hunting_ground: {
    id: 'hunting_ground',
    name: 'Hunting Ground',
    classKey: 'ranger',
    minLevel: 4,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'nature',
    damageRange: [0, 0],
    grantTempHp: 5,
    statusEffect: 'blessed',
    damageFormula: '3x3 Zone: Party Gains High-Ground Bonus & Stealth Revealed',
    attributeScaling: 'DEX',
    centralMechanic: 'Designates a tactical 3x3 killzone: Ranger and allies treat all shots as High Ground (+2 Hit) and reveals stealth.',
    tacticalExplanation: 'Create artificial elevation advantages on flat terrain.',
    animationReference: 'ranger_designate_zone',
    iconReference: 'hunting_ground',
    description: 'Designate a 3x3 killzone where all allies gain High Ground accuracy (+2 Hit) and invisible foes are exposed.',
  },
  ricochet_shot: {
    id: 'ricochet_shot',
    name: 'Ricochet Shot',
    classKey: 'ranger',
    minLevel: 6,
    skillPointCost: 1,
    category: 'deadeye_snipe',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'shockwave_ring',
    element: 'physical',
    damageRange: [10, 15],
    damageFormula: '10-15 DMG to Primary + Ricochets to 2 Nearby Foes',
    attributeScaling: 'DEX',
    centralMechanic: 'Curved trick arrow: Strikes primary target and ricochets to hit up to 2 additional adjacent enemies.',
    tacticalExplanation: 'Clear clustered enemy archers and weavers with a single shot.',
    animationReference: 'ranger_trick_shot',
    iconReference: 'ricochet_shot',
    description: 'Fire a trick arrow that impacts the primary target for 10-15 DMG and bounces into two adjacent foes.',
  },
  camouflage: {
    id: 'camouflage',
    name: 'Camouflage',
    classKey: 'ranger',
    minLevel: 8,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [0, 0],
    grantTempHp: 6,
    statusEffect: 'warded',
    damageFormula: 'Untargetable from Ranged Attacks While Near Cover',
    attributeScaling: 'DEX',
    centralMechanic: 'Blends into foliage or stonework: Cannot be targeted by ranged attacks while adjacent to obstacles.',
    tacticalExplanation: 'Immunity to enemy snipers while sniping from cover.',
    animationReference: 'ranger_ghillie_fade',
    iconReference: 'camouflage',
    description: 'Blend into terrain cover, gaining 6 Temp HP and becoming untargetable by enemy ranged abilities.',
  },
  thornline: {
    id: 'thornline',
    name: 'Thornline',
    classKey: 'ranger',
    minLevel: 10,
    skillPointCost: 1,
    category: 'briar_barricade',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'ground',
    aoeShape: 'briar_wall_3',
    element: 'nature',
    damageRange: [8, 14],
    statusEffect: 'rooted',
    damageFormula: '3-Tile Bramble Wall: 8-14 Nature DMG + Rooted',
    attributeScaling: 'DEX',
    centralMechanic: 'Launches a thorn cartridge that sprouts a 3-tile razor bramble wall, damaging and rooting anyone attempting to pass.',
    tacticalExplanation: 'Choke off corridors and bridges to delay reinforcements.',
    animationReference: 'ranger_seed_scatter',
    iconReference: 'thornline',
    description: 'Sprout an impenetrable 3-tile barrier of living brambles that roots enemies and deals 8-14 Nature DMG.',
  },
  beast_call: {
    id: 'beast_call',
    name: 'Beast Call',
    classKey: 'ranger',
    minLevel: 12,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 3,
    targetType: 'ground',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [0, 0],
    grantTempHp: 12,
    statusEffect: 'blessed',
    damageFormula: 'Summons Sylvan Wolf (16 HP, Flanks, 7-11 Bite)',
    attributeScaling: 'DEX',
    centralMechanic: 'Summons an astral timber-wolf companion that occupies a grid tile, flanks enemies, and attacks with Bite.',
    tacticalExplanation: 'Provide an additional body to trigger flanking bonuses and absorb enemy hits.',
    animationReference: 'ranger_wolf_howl',
    iconReference: 'beast_call',
    description: 'Whistle for a spectral sylvan timber-wolf to join combat, establishing flanking lines and harrying enemies.',
  },
  windrunner: {
    id: 'windrunner',
    name: 'Windrunner',
    classKey: 'ranger',
    minLevel: 14,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'nature',
    damageRange: [0, 0],
    damageFormula: 'Passive: Moving 2 Tiles Grants +2 DMG on Next Arrow (Max +6)',
    attributeScaling: 'DEX',
    centralMechanic: 'Kinetic momentum: For every 2 tiles moved in a turn, ranger’s next arrow deals +2 bonus damage (up to +6).',
    tacticalExplanation: 'Kite constantly around the edge of the battlefield to maximize per-shot damage.',
    animationReference: 'ranger_wind_trail',
    iconReference: 'windrunner',
    description: 'Convert kinetic stride into piercing force: moving across the battlefield builds up to +6 bonus damage on your next shot.',
  },
  deadfall_trap: {
    id: 'deadfall_trap',
    name: 'Deadfall Trap',
    classKey: 'ranger',
    minLevel: 16,
    skillPointCost: 1,
    category: 'trap_snare',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 3,
    targetType: 'ground',
    aoeShape: 'trap_tile',
    element: 'physical',
    damageRange: [16, 24],
    statusEffect: 'sundered',
    damageFormula: 'Heavy Deadfall: 16-24 Crushing DMG & -3 Armor Class',
    attributeScaling: 'DEX/STR',
    centralMechanic: 'Deploys a heavy counterweighted deadfall trap: Deals 16-24 crushing damage and permanently sunders armor by -3.',
    tacticalExplanation: 'Devastating against heavy vanguard enemies who tread predictable pathways.',
    animationReference: 'ranger_deadfall_arm',
    iconReference: 'deadfall_trap',
    description: 'Arm a massive deadfall counterweight trap that crushes triggers for 16-24 DMG and drops AC by 3.',
  },
  marked_prey: {
    id: 'marked_prey',
    name: 'Marked Prey',
    classKey: 'ranger',
    minLevel: 18,
    skillPointCost: 1,
    category: 'deadeye_snipe',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 6,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [12, 18],
    statusEffect: 'sundered',
    damageFormula: 'Sniper Brand: Range 6 + Ignores Cover + +4 DMG from Party',
    attributeScaling: 'DEX',
    centralMechanic: 'Paints an enemy from extreme range (6 tiles): Attacks against them ignore cover and deal +4 damage.',
    tacticalExplanation: 'Strip cover bonuses from stubborn boss targets positioned behind walls.',
    animationReference: 'ranger_hawk_mark',
    iconReference: 'marked_prey',
    description: 'Identify the structural weak points of an enemy at extreme range 6, dealing 12-18 DMG and exposing them to +4 party damage.',
  },
  natures_dominion: {
    id: 'natures_dominion',
    name: 'Nature\'s Dominion',
    classKey: 'ranger',
    minLevel: 20,
    skillPointCost: 1,
    category: 'briar_barricade',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 5,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'nature',
    damageRange: [24, 34],
    statusEffect: 'rooted',
    damageFormula: 'Battlefield Overgrowth: 24-34 DMG + Roots All Enemies in 5x5',
    attributeScaling: 'DEX',
    centralMechanic: 'Awakens primordial roots of Whispering Vale: Roots all enemies, deals 24-34 Nature damage, and grants party +3 Move.',
    tacticalExplanation: 'The ranger’s ultimate arena-wide crowd control ability.',
    animationReference: 'ranger_dominion_growth',
    iconReference: 'natures_dominion',
    description: 'Awaken the ancient sylvan heart of the vale, dealing 24-34 Nature DMG, Rooting all foes, and empowering party movement.',
  },

  /* ----------------------------------------------------------------------- */
  /* SPECIALIZATION 1: DAWN WARDEN (Paladin Spec)                            */
  /* ----------------------------------------------------------------------- */
  solar_flare: {
    id: 'solar_flare',
    name: 'Solar Flare',
    classKey: 'paladin',
    specializationKey: 'dawn_warden',
    minLevel: 5,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 3,
    targetType: 'enemy',
    aoeShape: 'chebyshev_3x3',
    element: 'radiant',
    damageRange: [8, 13],
    statusEffect: 'sundered',
    damageFormula: 'Blinding Flash: 8-13 Radiant + Foes Suffer -3 Hit',
    attributeScaling: 'CHA',
    centralMechanic: 'Blinds enemy formation with concentrated sunlight, imposing -3 on attack rolls and revealing hidden units.',
    tacticalExplanation: 'Neutralize an incoming enemy alpha strike by blinding their vanguard.',
    animationReference: 'dawn_solar_flash',
    iconReference: 'solar_flare',
    description: 'Unleash a searing solar burst across a 3x3 area, dealing 8-13 Radiant DMG and blinding foes (-3 to hit).',
  },
  aegis_of_the_dawn: {
    id: 'aegis_of_the_dawn',
    name: 'Aegis of the Dawn',
    classKey: 'paladin',
    specializationKey: 'dawn_warden',
    minLevel: 8,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 3,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [0, 0],
    grantTempHp: 15,
    statusEffect: 'warded',
    damageFormula: 'Solar Aegis: 15 Temp HP + Detonates for 10 Radiant When Depleted',
    attributeScaling: 'CHA',
    centralMechanic: 'Envelops ally in a solar barrier that absorbs 15 damage and explodes in radiant light when destroyed.',
    tacticalExplanation: 'Cast on frontline tanks or endangered allies right before a boss strikes.',
    animationReference: 'dawn_aegis_shield',
    iconReference: 'aegis_of_the_dawn',
    description: 'Bestow a protective dawn barrier with 15 Temp HP that explodes for 10 Radiant DMG when breached.',
  },
  daybreak_smite: {
    id: 'daybreak_smite',
    name: 'Daybreak Smite',
    classKey: 'paladin',
    specializationKey: 'dawn_warden',
    minLevel: 11,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'radiant',
    damageRange: [14, 22],
    statusEffect: 'sundered',
    damageFormula: '2d8 + STR + 8 vs Undead/Corrupted + Consecrates Tile',
    attributeScaling: 'STR/CHA',
    centralMechanic: 'Heavy radiant warhammer strike dealing bonus damage against corrupted foes and purifying the tile.',
    tacticalExplanation: 'Shatter elite inquisitors and undead rifts.',
    animationReference: 'dawn_daybreak_strike',
    iconReference: 'daybreak_smite',
    description: 'Channel pure daybreak through your weapon, dealing 14-22 Radiant DMG (+8 vs Corrupted) and consecrating ground.',
  },
  sunwell_aura: {
    id: 'sunwell_aura',
    name: 'Sunwell Aura',
    classKey: 'paladin',
    specializationKey: 'dawn_warden',
    minLevel: 14,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'radiant',
    damageRange: [0, 0],
    damageFormula: 'Passive: Standing on Sanctified Tiles Grants +5 Temp HP & +1 AP',
    attributeScaling: 'CHA',
    centralMechanic: 'Sanctified pools empower all party members: Entering or ending turn in sanctified water grants +5 Temp HP and +1 AP.',
    tacticalExplanation: 'Combine with Consecrated Strike and Sacred Ground for continuous action advantage.',
    animationReference: 'dawn_sunwell_pulse',
    iconReference: 'sunwell_aura',
    description: 'Transform all sanctified ground into sunwells: allies standing in sanctified pools receive +5 Temp HP and +1 AP.',
  },
  radiant_bastion: {
    id: 'radiant_bastion',
    name: 'Radiant Bastion',
    classKey: 'paladin',
    specializationKey: 'dawn_warden',
    minLevel: 17,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 1,
    targetType: 'self',
    aoeShape: 'chebyshev_3x3',
    element: 'radiant',
    damageRange: [0, 0],
    grantTempHp: 18,
    statusEffect: 'warded',
    damageFormula: '3x3 Bastion of Light: +3 AC & Immunity to Status Effects',
    attributeScaling: 'CHA',
    centralMechanic: 'Erects a gleaming pavilion of dawn: All party members inside gain +3 AC and complete debuff immunity for 2 turns.',
    tacticalExplanation: 'Neutralize enemy boss status combos (burning/poison/root) entirely.',
    animationReference: 'dawn_radiant_pavilion',
    iconReference: 'radiant_bastion',
    description: 'Erect a glowing cathedral of dawnlight, granting 18 Temp HP, +3 AC, and immunity to negative statuses for 2 turns.',
  },
  avatar_of_the_sun: {
    id: 'avatar_of_the_sun',
    name: 'Avatar of the Sun',
    classKey: 'paladin',
    specializationKey: 'dawn_warden',
    minLevel: 20,
    skillPointCost: 1,
    category: 'consecration_judgment',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 1,
    targetType: 'self',
    aoeShape: 'shockwave_ring',
    element: 'radiant',
    damageRange: [18, 28],
    healAmount: 20,
    grantTempHp: 20,
    statusEffect: 'blessed',
    damageFormula: 'Avatar Form: +8 Radiant on Hits + Heals Party 6 HP/Turn',
    attributeScaling: 'CHA/STR',
    centralMechanic: 'Transforms into living incarnation of the Dawn: Emits radiant shockwaves, adds +8 Radiant DMG to all strikes, and regenerates party.',
    tacticalExplanation: 'Dawn Warden capstone: dominates the endgame with overwhelming radiant supremacy.',
    animationReference: 'dawn_avatar_ascension',
    iconReference: 'avatar_of_the_sun',
    description: 'Ascend as the living Avatar of the Sun: gain 20 Temp HP, radiate 18-28 damage to adjacent foes, and heal companions every turn.',
  },

  /* ----------------------------------------------------------------------- */
  /* SPECIALIZATION 2: VENGEANCE KNIGHT (Paladin / Warrior Cross-Spec)       */
  /* ----------------------------------------------------------------------- */
  retribution_strike: {
    id: 'retribution_strike',
    name: 'Retribution Strike',
    classKey: 'warrior',
    specializationKey: 'vengeance_knight',
    minLevel: 5,
    skillPointCost: 1,
    category: 'execution_gapcloser',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [10, 16],
    damageFormula: '10-16 DMG + +1 DMG per 5% Missing Health',
    attributeScaling: 'STR',
    centralMechanic: 'Strikes with fueled fury: Deals +1 bonus damage for every 5% missing health on the knight.',
    tacticalExplanation: 'Becomes lethal when fighting at low health.',
    animationReference: 'vengeance_heavy_slash',
    iconReference: 'retribution_strike',
    description: 'Strike with reckless wrath, dealing 10-16 physical DMG plus 1 additional damage for every 5% missing health.',
  },
  spiteful_ward: {
    id: 'spiteful_ward',
    name: 'Spiteful Ward',
    classKey: 'warrior',
    specializationKey: 'vengeance_knight',
    minLevel: 8,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [0, 0],
    grantTempHp: 10,
    statusEffect: 'warded',
    damageFormula: 'Reflects 6 Physical DMG to Melee Attackers & Sunders',
    attributeScaling: 'STR',
    centralMechanic: 'Spiked defensive ward: When struck by melee, reflects 6 physical damage and inflicts Sundered on the attacker.',
    tacticalExplanation: 'Deter enemy swarm attackers from focusing the knight.',
    animationReference: 'vengeance_spiked_shield',
    iconReference: 'spiteful_ward',
    description: 'Raise a barbed barrier granting 10 Temp HP that reflects 6 DMG and Sunders any foe who strikes you in melee.',
  },
  dread_inscription: {
    id: 'dread_inscription',
    name: 'Dread Inscription',
    classKey: 'warrior',
    specializationKey: 'vengeance_knight',
    minLevel: 11,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [8, 14],
    statusEffect: 'sundered',
    damageFormula: 'Brand of Ruin: Knight Gains +2 Move Toward Target & +5 DMG',
    attributeScaling: 'STR',
    centralMechanic: 'Inscribes blood vow on target: Knight gains +2 movement toward this foe and attacks deal +5 bonus damage.',
    tacticalExplanation: 'Relentlessly hunt down enemy commanders and archers.',
    animationReference: 'vengeance_brand_rune',
    iconReference: 'dread_inscription',
    description: 'Carve a blood sigil onto an enemy at range 4, dealing 8-14 DMG, gaining +2 Move toward them, and dealing +5 DMG.',
  },
  unrelenting_vengeance: {
    id: 'unrelenting_vengeance',
    name: 'Unrelenting Vengeance',
    classKey: 'warrior',
    specializationKey: 'vengeance_knight',
    minLevel: 14,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'physical',
    damageRange: [0, 0],
    damageFormula: 'Passive: When Ally Drops Below 20% HP, Gain +2 AP & +3 STR',
    attributeScaling: 'STR',
    centralMechanic: 'Comrade protection trigger: Whenever a companion drops below 20% HP or is downed, knight gains +2 AP and +3 STR next turn.',
    tacticalExplanation: 'Provides explosive comeback potential during dire combat situations.',
    animationReference: 'vengeance_rage_glow',
    iconReference: 'unrelenting_vengeance',
    description: 'When an ally falls below 20% HP, surge with vengeful fury, gaining +2 Action Points and +3 STR on your next turn.',
  },
  executioners_wrath: {
    id: 'executioners_wrath',
    name: 'Executioner\'s Wrath',
    classKey: 'warrior',
    specializationKey: 'vengeance_knight',
    minLevel: 17,
    skillPointCost: 1,
    category: 'execution_gapcloser',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 2,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [18, 28],
    pushDistance: 2,
    statusEffect: 'sundered',
    damageFormula: '2d10 + STR + Double DMG vs Foes ≤40% HP',
    attributeScaling: 'STR',
    centralMechanic: 'Savage execution strike: Deals double damage if target is below 40% health and knocks them back 2 tiles.',
    tacticalExplanation: 'Finisher attack that guarantees instant elimination of bloodied targets.',
    animationReference: 'vengeance_guillotine_chop',
    iconReference: 'executioners_wrath',
    description: 'Deliver an unmerciful executioner chop dealing 18-28 DMG; damage doubles against foes below 40% HP.',
  },
  oath_of_total_ruin: {
    id: 'oath_of_total_ruin',
    name: 'Oath of Total Ruin',
    classKey: 'warrior',
    specializationKey: 'vengeance_knight',
    minLevel: 20,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 1,
    targetType: 'self',
    aoeShape: 'shockwave_ring',
    element: 'physical',
    damageRange: [20, 30],
    statusEffect: 'sundered',
    grantTempHp: 20,
    damageFormula: 'Unblockable Strikes: Ignore All Armor + Shockwave on Hit',
    attributeScaling: 'STR',
    centralMechanic: 'Unchains total destructive vengeance: Attacks ignore armor, trigger explosive shockwaves, and grant 20 Temp HP.',
    tacticalExplanation: 'Capstone vengeance state: shred heavily armored bosses with zero resistance.',
    animationReference: 'vengeance_total_ruin_eruption',
    iconReference: 'oath_of_total_ruin',
    description: 'Unleash the forbidden Oath of Total Ruin: gain 20 Temp HP, cause melee attacks to ignore enemy armor, and shatter nearby terrain.',
  },

  /* ----------------------------------------------------------------------- */
  /* SPECIALIZATION 3: CRIMSON SAVANT (Mage / Rogue Cross-Spec)              */
  /* ----------------------------------------------------------------------- */
  blood_siphon: {
    id: 'blood_siphon',
    name: 'Blood Siphon',
    classKey: 'mage',
    specializationKey: 'crimson_savant',
    minLevel: 5,
    skillPointCost: 1,
    category: 'phase_transfusion',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [9, 14],
    healAmount: 6,
    damageFormula: '9-14 Blood DMG + Heals Caster for 50% of Damage',
    attributeScaling: 'INT',
    centralMechanic: 'Siphons life essence through astral conduits, dealing damage and healing the savant for 50% of damage dealt.',
    tacticalExplanation: 'Keep mage HP topped up while poking enemies from a safe distance.',
    animationReference: 'crimson_siphon_stream',
    iconReference: 'blood_siphon',
    description: 'Draw vitality from target’s bloodstream, dealing 9-14 Arcane DMG and restoring 6 HP to yourself.',
  },
  boiling_veins: {
    id: 'boiling_veins',
    name: 'Boiling Veins',
    classKey: 'mage',
    specializationKey: 'crimson_savant',
    minLevel: 8,
    skillPointCost: 1,
    category: 'pyromantic_detonation',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'fire',
    damageRange: [11, 17],
    statusEffect: 'burning',
    damageFormula: '11-17 Fire + Intense Burning (Leaves Fire Trails on Move)',
    attributeScaling: 'INT',
    centralMechanic: 'Ignites target blood from within: Inflicts Burning; moving forces target to take extra damage and leave fire tiles.',
    tacticalExplanation: 'Deter fast melee enemies from chasing you across the battlefield.',
    animationReference: 'crimson_boil_ignite',
    iconReference: 'boiling_veins',
    description: 'Heat target’s blood to boiling point, dealing 11-17 Fire DMG, inflicting Burning, and igniting tiles behind them if they move.',
  },
  sanguine_transfusion: {
    id: 'sanguine_transfusion',
    name: 'Sanguine Transfusion',
    classKey: 'mage',
    specializationKey: 'crimson_savant',
    minLevel: 11,
    skillPointCost: 1,
    category: 'phase_transfusion',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 4,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    healAmount: 16,
    grantTempHp: 6,
    damageFormula: 'Sacrifices 6 HP to Heal Ally for 16 HP & +1 AP',
    attributeScaling: 'INT',
    centralMechanic: 'Sacrifices 6 of savant’s health to restore 16 HP to an ally and grant them +1 Action Point on their next turn.',
    tacticalExplanation: 'High-utility clutch transfusion to save a companion and enable bonus actions.',
    animationReference: 'crimson_blood_bridge',
    iconReference: 'sanguine_transfusion',
    description: 'Transfuse personal vitality to an ally, sacrificing 6 HP to restore 16 HP and grant 6 Temp HP.',
  },
  hemorrhage_curse: {
    id: 'hemorrhage_curse',
    name: 'Hemorrhage Curse',
    classKey: 'mage',
    specializationKey: 'crimson_savant',
    minLevel: 14,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'fire',
    damageRange: [0, 0],
    damageFormula: 'Passive: Burning/Bleeding Foes Take +4 Extra Arcane DMG',
    attributeScaling: 'INT',
    centralMechanic: 'Enemies afflicted with Burning take +4 additional damage from all subsequent arcane and shadow strikes.',
    tacticalExplanation: 'Amplify party damage against burning bosses.',
    animationReference: 'crimson_curse_sigil',
    iconReference: 'hemorrhage_curse',
    description: 'Amplify affliction: enemies suffering from Burning take +4 additional damage from all arcane and shadow attacks.',
  },
  crimson_maelstrom: {
    id: 'crimson_maelstrom',
    name: 'Crimson Maelstrom',
    classKey: 'mage',
    specializationKey: 'crimson_savant',
    minLevel: 17,
    skillPointCost: 1,
    category: 'pyromantic_detonation',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'fire',
    damageRange: [16, 24],
    pullDistance: 1,
    statusEffect: 'burning',
    damageFormula: '3x3 Boiling Vortex: 16-24 Fire + Pull 1 + Burning',
    attributeScaling: 'INT',
    centralMechanic: 'Swirling vortex of boiling blood: Pulls enemies 1 tile inward, inflicts Burning, and detonates all oil hazards.',
    tacticalExplanation: 'Massive area combination that sweeps targets into burning ground.',
    animationReference: 'crimson_maelstrom_spin',
    iconReference: 'crimson_maelstrom',
    description: 'Summon a 3x3 cyclone of blood-fire, dealing 16-24 Fire DMG, dragging victims toward the center, and inflicting Burning.',
  },
  heartstop_sovereign: {
    id: 'heartstop_sovereign',
    name: 'Heartstop Sovereign',
    classKey: 'mage',
    specializationKey: 'crimson_savant',
    minLevel: 20,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [25, 36],
    statusEffect: 'rooted',
    damageFormula: 'Internal Rupture: 25-36 Arcane DMG + 1-Turn Stun + Blood Curse',
    attributeScaling: 'INT',
    centralMechanic: 'Grips enemy heart from within: Deals 25-36 necrotic damage, stuns target for 1 turn, and spreads blood curse to adjacent foes.',
    tacticalExplanation: 'Crimson Savant capstone: completely disables target boss while spreading devastation.',
    animationReference: 'crimson_heart_crush',
    iconReference: 'heartstop_sovereign',
    description: 'Crush the target’s heart through sympathetic planar resonance, inflicting 25-36 DMG, stunning for 1 turn, and cursing adjacent foes.',
  },

  /* ----------------------------------------------------------------------- */
  /* SPECIALIZATION 4: RIFT CHRONOMANCER (Mage Spec)                         */
  /* ----------------------------------------------------------------------- */
  time_slip: {
    id: 'time_slip',
    name: 'Time Slip',
    classKey: 'mage',
    specializationKey: 'rift_chronomancer',
    minLevel: 5,
    skillPointCost: 1,
    category: 'phase_transfusion',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 3,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    grantTempHp: 6,
    damageFormula: 'Rewind Position + Refund 2 Movement Points',
    attributeScaling: 'INT',
    centralMechanic: 'Shifts target back along their timeline: Blinks them back to their tile at start of turn and refunds 2 movement.',
    tacticalExplanation: 'Rescue a scout who overextended into a dangerous trap or enemy melee pack.',
    animationReference: 'chrono_time_slip',
    iconReference: 'time_slip',
    description: 'Rewind the spatial timeline of an ally within 3 tiles, snapping them back to their turn start tile and granting 6 Temp HP.',
  },
  chronostasis: {
    id: 'chronostasis',
    name: 'Chronostasis',
    classKey: 'mage',
    specializationKey: 'rift_chronomancer',
    minLevel: 8,
    skillPointCost: 1,
    category: 'control',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [5, 10],
    statusEffect: 'rooted',
    damageFormula: 'Time Freeze: Target Cannot Act or Move for 1 Turn',
    attributeScaling: 'INT',
    centralMechanic: 'Suspends target in a frozen temporal bubble for 1 turn: Target cannot take actions, move, or receive buffs.',
    tacticalExplanation: 'Take a dangerous enemy out of the fight completely for a full round.',
    animationReference: 'chrono_stasis_bubble',
    iconReference: 'chronostasis',
    description: 'Encase a foe in localized stasis: deals 5-10 DMG and freezes them outside of time for 1 complete turn.',
  },
  accelerate_flow: {
    id: 'accelerate_flow',
    name: 'Accelerate Flow',
    classKey: 'mage',
    specializationKey: 'rift_chronomancer',
    minLevel: 11,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 4,
    targetType: 'ally',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    grantTempHp: 8,
    statusEffect: 'blessed',
    damageFormula: 'Haste Flow: Ally Gains +1 AP & +2 Move Next Turn',
    attributeScaling: 'INT',
    centralMechanic: 'Hastens temporal flow for an ally: Target companion gains +1 AP and +2 Move Range on their next turn.',
    tacticalExplanation: 'Supercharge your primary damage dealer for an explosive assault turn.',
    animationReference: 'chrono_haste_rays',
    iconReference: 'accelerate_flow',
    description: 'Accelerate an ally’s personal timeline, granting 8 Temp HP, +1 Action Point, and +2 Move Range on their next turn.',
  },
  echoes_of_eternity: {
    id: 'echoes_of_eternity',
    name: 'Echoes of Eternity',
    classKey: 'mage',
    specializationKey: 'rift_chronomancer',
    minLevel: 14,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'arcane',
    damageRange: [0, 0],
    damageFormula: 'Passive: 30% Chance to Shave 1 Turn Off Any Cooldown',
    attributeScaling: 'INT',
    centralMechanic: 'Chronological recursion: Whenever Chronomancer uses an ability with a cooldown, there is a 30% chance to immediately reduce that cooldown by 1 turn.',
    tacticalExplanation: 'Allows rapid cycling of powerful temporal manipulation spells.',
    animationReference: 'chrono_echo_clock',
    iconReference: 'echoes_of_eternity',
    description: 'Temporal ripples echo through your spellcraft: 30% chance upon casting an ability to reduce its cooldown by 1 turn.',
  },
  paradox_nova: {
    id: 'paradox_nova',
    name: 'Paradox Nova',
    classKey: 'mage',
    specializationKey: 'rift_chronomancer',
    minLevel: 17,
    skillPointCost: 1,
    category: 'spacetime_implosion',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'arcane',
    damageRange: [16, 24],
    statusEffect: 'sundered',
    damageFormula: '3x3 Paradox Burst: 16-24 Spacetime DMG & Disorients Turn Order',
    attributeScaling: 'INT',
    centralMechanic: 'Creates a localized temporal paradox in 3x3 area: Deals 16-24 damage, strips enemy buffs, and reduces enemy initiative.',
    tacticalExplanation: 'Disrupt coordinated enemy turns and soften enemy clusters.',
    animationReference: 'chrono_paradox_burst',
    iconReference: 'paradox_nova',
    description: 'Trigger a localized chronological paradox across a 3x3 area, dealing 16-24 Spacetime DMG and stripping positive buffs.',
  },
  time_stop: {
    id: 'time_stop',
    name: 'Time Stop',
    classKey: 'mage',
    specializationKey: 'rift_chronomancer',
    minLevel: 20,
    skillPointCost: 1,
    category: 'spacetime_implosion',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'arcane',
    damageRange: [0, 0],
    grantTempHp: 15,
    statusEffect: 'blessed',
    damageFormula: 'Halts Time: Chronomancer Gains Free Immediate Extra Turn with 3 AP',
    attributeScaling: 'INT',
    centralMechanic: 'Freezes all external time: Chronomancer immediately receives a bonus full turn with 3 Action Points while all other units are paused.',
    tacticalExplanation: 'The pinnacle of spellcasting: execute an entire sequence of spells uninterrupted.',
    animationReference: 'chrono_time_stop_freeze',
    iconReference: 'time_stop',
    description: 'Halt the universal clock: pause all other units on the battlefield and immediately take an uninterrupted bonus turn with 3 AP.',
  },

  /* ----------------------------------------------------------------------- */
  /* SPECIALIZATION 5: BRIAR STALKER (Ranger / Rogue Cross-Spec)             */
  /* ----------------------------------------------------------------------- */
  ambush_snare: {
    id: 'ambush_snare',
    name: 'Ambush Snare',
    classKey: 'ranger',
    specializationKey: 'briar_stalker',
    minLevel: 5,
    skillPointCost: 1,
    category: 'trap_snare',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'ground',
    aoeShape: 'trap_tile',
    element: 'nature',
    damageRange: [9, 15],
    statusEffect: 'rooted',
    damageFormula: 'Living Root Trap: 9-15 Nature + Root & Sunder',
    attributeScaling: 'DEX',
    centralMechanic: 'Deploys a living root snare on tile: First enemy stepping on it takes 9-15 Nature damage, becomes Rooted, and suffers Sundered.',
    tacticalExplanation: 'Choke point ambush trap that primes targets for predator damage.',
    animationReference: 'briar_root_snare_plant',
    iconReference: 'ambush_snare',
    description: 'Lay an invisible snare of thorny roots that trips the first enemy to enter, inflicting 9-15 Nature DMG, Rooted, and Sundered.',
  },
  shadow_thorn: {
    id: 'shadow_thorn',
    name: 'Shadow Thorn',
    classKey: 'ranger',
    specializationKey: 'briar_stalker',
    minLevel: 8,
    skillPointCost: 1,
    category: 'deadeye_snipe',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 4,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [11, 16],
    damageFormula: 'Barbed Spine: 11-16 DMG (+5 from Stealth) + Anti-Heal',
    attributeScaling: 'DEX',
    centralMechanic: 'Fires a barbed shadow-spine: Deals +5 bonus damage when fired from stealth and prevents target from being healed for 2 turns.',
    tacticalExplanation: 'Ideal sniper opening strike against enemy healers or paladins.',
    animationReference: 'briar_spine_shot',
    iconReference: 'shadow_thorn',
    description: 'Shoot an organic shadow-spine at range 4, dealing 11-16 DMG (+5 from Stealth) and suppressing target healing for 2 turns.',
  },
  bramble_stride: {
    id: 'bramble_stride',
    name: 'Bramble Stride',
    classKey: 'ranger',
    specializationKey: 'briar_stalker',
    minLevel: 11,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'nature',
    damageRange: [0, 0],
    damageFormula: 'Passive: Moves Freely Through Brambles + Heals 2 HP/Tile',
    attributeScaling: 'DEX',
    centralMechanic: 'The stalker moves through brambles and rough terrain with zero penalty, regenerating 2 HP per bramble tile traversed.',
    tacticalExplanation: 'Turn hazardous overgrown terrain into personal health fountains and escape routes.',
    animationReference: 'briar_stride_flora',
    iconReference: 'bramble_stride',
    description: 'Pass freely through bramble hazards without slowdown, restoring 2 HP for every bramble tile traversed.',
  },
  venomous_bramble: {
    id: 'venomous_bramble',
    name: 'Venomous Bramble',
    classKey: 'ranger',
    specializationKey: 'briar_stalker',
    minLevel: 14,
    skillPointCost: 1,
    category: 'briar_barricade',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'nature',
    damageRange: [10, 16],
    statusEffect: 'rooted',
    damageFormula: '3x3 Toxic Briars: 10-16 Nature + 4 Poison DoT/Turn',
    attributeScaling: 'DEX',
    centralMechanic: 'Sprouts a field of toxic thorns across a 3x3 area: Deals Nature damage and inflicts poison on any unit starting turn inside.',
    tacticalExplanation: 'Area denial that punishes stationary enemy firing squads.',
    animationReference: 'briar_toxic_patch',
    iconReference: 'venomous_bramble',
    description: 'Grow a field of toxic sylvan brambles across a 3x3 area, dealing 10-16 Nature DMG and poisoning anyone who steps within.',
  },
  lurker_in_the_foliage: {
    id: 'lurker_in_the_foliage',
    name: 'Lurker in the Foliage',
    classKey: 'ranger',
    specializationKey: 'briar_stalker',
    minLevel: 17,
    skillPointCost: 1,
    category: 'support',
    isPassive: false,
    apCost: 1,
    cooldown: 3,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [0, 0],
    grantTempHp: 10,
    damageFormula: 'Dissolves into Foliage: Fully Untargetable + +6 DMG on Next Strike',
    attributeScaling: 'DEX',
    centralMechanic: 'Dissolves into nearby plant life: Becomes completely untargetable until attacking and gains +6 damage on next strike.',
    tacticalExplanation: 'Drop all enemy aggression instantly and line up a guaranteed kill.',
    animationReference: 'briar_meld_bush',
    iconReference: 'lurker_in_the_foliage',
    description: 'Meld into the forest floor, becoming completely untargetable, gaining 10 Temp HP, and preparing +6 DMG on your next strike.',
  },
  wrath_of_the_primordial_grove: {
    id: 'wrath_of_the_primordial_grove',
    name: 'Wrath of the Primordial Grove',
    classKey: 'ranger',
    specializationKey: 'briar_stalker',
    minLevel: 20,
    skillPointCost: 1,
    category: 'briar_barricade',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 4,
    targetType: 'ground',
    aoeShape: 'chebyshev_3x3',
    element: 'nature',
    damageRange: [24, 36],
    statusEffect: 'rooted',
    damageFormula: 'Primordial Roots: 24-36 Nature DMG + Roots & Sunders All Foes in Area',
    attributeScaling: 'DEX',
    centralMechanic: 'Awakens colossal subterranean roots: Crushes all trapped foes for 24-36 Nature damage, knocks them prone, and roots them.',
    tacticalExplanation: 'The Briar Stalker capstone: turns the entire combat grid into a lethal carnivorous grove.',
    animationReference: 'briar_grove_awakening',
    iconReference: 'wrath_of_the_primordial_grove',
    description: 'Summon ancient iron roots from beneath the earth, crushing all enemies in a 3x3 area for 24-36 Nature DMG and Rooting them.',
  },

  /* ----------------------------------------------------------------------- */
  /* SPECIALIZATION 6: IRONBOUGH SENTINEL (Warrior / Ranger Cross-Spec)       */
  /* ----------------------------------------------------------------------- */
  ironwood_brace: {
    id: 'ironwood_brace',
    name: 'Ironwood Brace',
    classKey: 'warrior',
    specializationKey: 'ironbough_sentinel',
    minLevel: 5,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 1,
    cooldown: 2,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [0, 0],
    grantTempHp: 12,
    statusEffect: 'warded',
    damageFormula: 'Immunity to Knockback + +3 AC + 12 Temp HP',
    attributeScaling: 'STR/DEX',
    centralMechanic: 'Roots feet into bedrock: Gains immunity to displacement, +3 AC, and absorbs up to 12 damage for 1 turn.',
    tacticalExplanation: 'Hold high-ground bastions against enemy shove attacks and knockback spells.',
    animationReference: 'sentinel_ironwood_brace',
    iconReference: 'ironwood_brace',
    description: 'Anchor yourself into the bedrock with petrified bark, gaining immunity to knockback, +3 AC, and 12 Temp HP.',
  },
  rooting_cleave: {
    id: 'rooting_cleave',
    name: 'Rooting Cleave',
    classKey: 'warrior',
    specializationKey: 'ironbough_sentinel',
    minLevel: 8,
    skillPointCost: 1,
    category: 'martial_cleave',
    isPassive: false,
    apCost: 2,
    cooldown: 2,
    range: 1,
    targetType: 'enemy',
    aoeShape: 'shockwave_ring',
    element: 'nature',
    damageRange: [10, 16],
    statusEffect: 'rooted',
    damageFormula: 'Cleaves Adjacent Foes for 10-16 DMG + Roots Legs',
    attributeScaling: 'STR',
    centralMechanic: 'Sweeping polearm swing that hits adjacent enemies and binds their legs with iron roots (Rooted for 2 turns).',
    tacticalExplanation: 'Prevent enemy melee units from swarming past you to reach fragile backline companions.',
    animationReference: 'sentinel_root_cleave',
    iconReference: 'rooting_cleave',
    description: 'Sweep a heavy ironwood polearm in an arc, dealing 10-16 Nature DMG to all adjacent enemies and Rooting them in place.',
  },
  grounded_bastion: {
    id: 'grounded_bastion',
    name: 'Grounded Bastion',
    classKey: 'warrior',
    specializationKey: 'ironbough_sentinel',
    minLevel: 11,
    skillPointCost: 1,
    category: 'support',
    isPassive: true,
    apCost: 0,
    cooldown: 0,
    range: 0,
    targetType: 'self',
    element: 'nature',
    damageRange: [0, 0],
    damageFormula: 'Passive: Cannot be Moved & Grants Adjacent Allies +2 AC',
    attributeScaling: 'STR',
    centralMechanic: 'Sentinel cannot be forcibly moved or pulled, and grants +2 Armor Class to all adjacent companions.',
    tacticalExplanation: 'Position next to companions to form an impenetrable phalanx.',
    animationReference: 'sentinel_ground_aura',
    iconReference: 'grounded_bastion',
    description: 'Your mass anchors the earth: you cannot be forcibly displaced, and adjacent companions gain +2 Armor Class.',
  },
  timberfall_slam: {
    id: 'timberfall_slam',
    name: 'Timberfall Slam',
    classKey: 'warrior',
    specializationKey: 'ironbough_sentinel',
    minLevel: 14,
    skillPointCost: 1,
    category: 'seismic_glaive',
    isPassive: false,
    apCost: 2,
    cooldown: 3,
    range: 2,
    targetType: 'enemy',
    aoeShape: 'single',
    element: 'physical',
    damageRange: [15, 23],
    pushDistance: 2,
    statusEffect: 'sundered',
    damageFormula: 'Crushing Slam: 15-23 DMG + Push 2 Tiles & Creates Log Cover',
    attributeScaling: 'STR',
    centralMechanic: 'Slams a petrified trunk into enemy: Deals 15-23 damage, shoves target 2 tiles back, and leaves obstacle cover behind.',
    tacticalExplanation: 'Creates tactical obstacles on open maps while knocking foes into hazards.',
    animationReference: 'sentinel_timber_smash',
    iconReference: 'timberfall_slam',
    description: 'Smash an ironwood trunk down on the target, dealing 15-23 DMG, pushing them 2 tiles, and creating half-cover.',
  },
  heart_of_the_ancient_bough: {
    id: 'heart_of_the_ancient_bough',
    name: 'Heart of the Ancient Bough',
    classKey: 'warrior',
    specializationKey: 'ironbough_sentinel',
    minLevel: 17,
    skillPointCost: 1,
    category: 'cleansing_mend',
    isPassive: false,
    apCost: 2,
    cooldown: 4,
    range: 1,
    targetType: 'self',
    aoeShape: 'single',
    element: 'nature',
    damageRange: [0, 0],
    grantTempHp: 20,
    cleanseStatuses: ['burning', 'rooted', 'sundered'],
    damageFormula: 'Petrified Bark: Purge All Debuffs + 20 Temp HP + +1 Max AP for 3 Turns',
    attributeScaling: 'STR/DEX',
    centralMechanic: 'Channels deep sylvan bark: Cleanses all debuffs, grants 20 Temp HP, and increases Max AP by +1 for 3 turns.',
    tacticalExplanation: 'Prepare for intense multi-round boss engagements.',
    animationReference: 'sentinel_bough_heart',
    iconReference: 'heart_of_the_ancient_bough',
    description: 'Infuse your body with petrified heartwood: purge all debuffs, gain 20 Temp HP, and increase Max AP by 1 for 3 turns.',
  },
  colossus_of_the_vale: {
    id: 'colossus_of_the_vale',
    name: 'Colossus of the Vale',
    classKey: 'warrior',
    specializationKey: 'ironbough_sentinel',
    minLevel: 20,
    skillPointCost: 1,
    category: 'bastion_aura',
    isPassive: false,
    apCost: 3,
    cooldown: 5,
    range: 1,
    targetType: 'self',
    aoeShape: 'shockwave_ring',
    element: 'nature',
    damageRange: [18, 28],
    grantTempHp: 25,
    statusEffect: 'warded',
    damageFormula: 'Colossus Form: Reach +1 Tile + 40% Damage Reduction + 25 Temp HP',
    attributeScaling: 'STR',
    centralMechanic: 'Transforms into an unyielding ironwood colossus: Reach increased to 2 tiles, takes 40% reduced damage, and cleaves all adjacent foes.',
    tacticalExplanation: 'The ultimate defensive raid boss transformation.',
    animationReference: 'sentinel_colossus_rise',
    iconReference: 'colossus_of_the_vale',
    description: 'Grow into a titanic living ironwood colossus: gain 25 Temp HP, +1 melee reach, 40% damage reduction, and sweeping cleaves.',
  },
};

/* ========================================================================= */
/* MANDATORY SKILL UNIQUENESS AUDIT REGISTRY (Section 13)                    */
/* ========================================================================= */

export interface SkillAuditEntry {
  skillId: string;
  centralMechanic: string;
  tacticalPurpose: string;
  targetingBehavior: string;
  terrainInteraction: string;
  mainStatusEffect: string;
  classIdentity: string;
}

export const SKILL_UNIQUENESS_REGISTRY: Record<string, SkillAuditEntry> = Object.fromEntries(
  Object.values(ALL_SKILLS_DATABASE).map((skill) => [
    skill.id,
    {
      skillId: skill.id,
      centralMechanic: skill.centralMechanic,
      tacticalPurpose: skill.tacticalExplanation,
      targetingBehavior: `${skill.targetType} (Range ${skill.range}${skill.aoeShape ? `, Shape: ${skill.aoeShape}` : ''})`,
      terrainInteraction: skill.terrainInteraction ?? 'Standard tactical grid interaction',
      mainStatusEffect: skill.statusEffect ?? (skill.healAmount ? 'Healing' : 'Direct damage'),
      classIdentity: skill.specializationKey ? `${skill.classKey} (${skill.specializationKey})` : skill.classKey,
    },
  ])
);

/**
 * Applies character progression (equipped abilities, attribute upgrades,
 * level health scaling, and class mastery bonuses) to a CombatUnit.
 */
export function applyProgressionToCommander(
  commanderUnit: CombatUnit,
  progression: CharacterProgressionState
): CombatUnit {
  const cleanEquipped = sanitizeEquippedSkills(progression.equippedSkillIds);
  const slotKeys: ('1' | '2' | '3' | '4')[] = ['1', '2', '3', '4'];
  const usedAbilityIds = new Set<string>();

  const equippedAbilities: Ability[] = slotKeys.map((key, idx) => {
    const skillId = cleanEquipped[idx];
    const def = skillId ? ALL_SKILLS_DATABASE[skillId] : undefined;
    if (def && !usedAbilityIds.has(def.id)) {
      usedAbilityIds.add(def.id);
      return toCombatAbility(def, key);
    }
    // Fallback: pick an ability from commanderUnit that hasn't been used yet
    const fallback = commanderUnit.abilities.find((a) => a && !usedAbilityIds.has(a.id));
    if (fallback) {
      usedAbilityIds.add(fallback.id);
      return { ...fallback, key };
    }
    const defaultId = `vanguard_strike_${key}`;
    usedAbilityIds.add(defaultId);
    return {
      id: defaultId,
      name: 'Vanguard Strike',
      key,
      apCost: 1,
      cooldown: 0,
      range: 1,
      damageRange: [9, 14],
      targetType: 'enemy',
      roleClue: '1d6 + STR',
      description: 'Frontline melee strike.',
    };
  });

  const bonusStats = { ...progression.allocatedAttributes };
  let extraAc = 0;
  let extraHp = 0;
  let extraMove = 0;

  Object.values(progression.unlockedMasteries).forEach((choiceId) => {
    if (!choiceId) return;
    for (const lvl of [5, 10, 15, 20] as const) {
      const option = CLASS_MASTERY_CHOICES[lvl]?.find((c) => c.id === choiceId);
      if (option) {
        if (option.statBonuses?.str) bonusStats.str += option.statBonuses.str;
        if (option.statBonuses?.dex) bonusStats.dex += option.statBonuses.dex;
        if (option.statBonuses?.int) bonusStats.int += option.statBonuses.int;
        if (option.statBonuses?.cha) bonusStats.cha += option.statBonuses.cha;
        if (option.acBonus) extraAc += option.acBonus;
        if (option.hpBonus) extraHp += option.hpBonus;
        if (option.moveBonus) extraMove += option.moveBonus;
      }
    }
  });

  const levelHpBonus = (progression.level - 1) * 3;
  const newMaxHp = commanderUnit.maxHp + levelHpBonus + extraHp;
  const currentRatio = commanderUnit.hp / Math.max(1, commanderUnit.maxHp);
  const newHp = Math.min(newMaxHp, Math.max(1, Math.round(newMaxHp * currentRatio)));

  return {
    ...commanderUnit,
    hp: newHp,
    maxHp: newMaxHp,
    armorClass: commanderUnit.armorClass + extraAc,
    moveRange: commanderUnit.moveRange + extraMove,
    stats: {
      str: commanderUnit.stats.str + bonusStats.str,
      dex: commanderUnit.stats.dex + bonusStats.dex,
      int: commanderUnit.stats.int + bonusStats.int,
      cha: commanderUnit.stats.cha + bonusStats.cha,
    },
    abilities: equippedAbilities,
  };
}

/**
 * Validates that all 96 abilities in ALL_SKILLS_DATABASE have strictly unique IDs
 * and distinct central mechanics as mandated by Section 13.
 */
export function verifySkillUniquenessAudit(): {
  totalSkills: number;
  coreSkills: number;
  specSkills: number;
  duplicatesFound: string[];
} {
  const allSkills = Object.values(ALL_SKILLS_DATABASE);
  const seenIds = new Set<string>();
  const seenMechanics = new Set<string>();
  const duplicatesFound: string[] = [];

  let coreSkills = 0;
  let specSkills = 0;

  for (const skill of allSkills) {
    if (skill.specializationKey) {
      specSkills++;
    } else {
      coreSkills++;
    }

    if (seenIds.has(skill.id)) {
      duplicatesFound.push(`Duplicate ID: ${skill.id}`);
    }
    seenIds.add(skill.id);

    const normMechanic = skill.centralMechanic.toLowerCase().trim();
    if (seenMechanics.has(normMechanic)) {
      duplicatesFound.push(`Duplicate Central Mechanic in ${skill.id}: "${skill.centralMechanic}"`);
    }
    seenMechanics.add(normMechanic);
  }

  return {
    totalSkills: allSkills.length,
    coreSkills,
    specSkills,
    duplicatesFound,
  };
}

