import { DistrictId, InteriorId, TownSceneId } from './gloamrestMapAndInteriors';
import { MerchantId, QuestId, QuestStatus } from './gloamrestItemsAndQuests';

export type ItemId = string;

export type TimeOfDayPhase = 'morning' | 'afternoon' | 'evening' | 'night';

export type TownThreatPhase =
  | 'peaceful'
  | 'uneasy'
  | 'astral_resonance'
  | 'fortified';

export interface InventoryStack {
  itemId: ItemId;
  quantity: number;
  durability?: number;
}

export interface UnitEquippedGear {
  weapon?: ItemId;
  armor?: ItemId;
  shield?: ItemId;
  accessory?: ItemId;
}

export interface PartyInventoryState {
  gold: number;
  items: InventoryStack[];
  equippedByUnit: Record<string, UnitEquippedGear>;
}

export interface QuestProgressEntry {
  questId: QuestId;
  status: QuestStatus;
  completedStepIds: string[];
  outcomeSummary?: string;
}

export interface GloamrestSaveState {
  version: number;
  currentSceneId: TownSceneId;
  playerPos: { x: number; z: number };
  playerFacingRad: number;
  timeOfDay: TimeOfDayPhase;
  dayCount: number;
  townThreatPhase: TownThreatPhase;
  discoveredDistricts: DistrictId[];
  discoveredInteriors: InteriorId[];
  unlockedObjectIds: string[];
  lootedOrHarvestedIds: string[];
  movedObjectPositions: Record<string, { x: number; z: number }>;
  storyFlags: string[];
  npcTrust: Record<string, number>;
  talkedNpcIds: string[];
  inventory: PartyInventoryState;
  merchantStocks: Record<MerchantId, { itemId: string; quantity: number }[]>;
  quests: Record<QuestId, QuestProgressEntry>;
  activeTrackedQuestId: QuestId;
  journalFeed: string[];
}
