import { TacticalAdvantageState } from './rules';

class SoundEngine {
  private ctx: AudioContext | null = null;
  public muted = false;
  public currentThemeState: TacticalAdvantageState = 'evenly_matched';
  public isCombatMusicActive = false;
  public isTownAmbienceActive = false;
  public townScenePreset = 'exterior';
  public townThreatPhase = 'peaceful';
  private musicTimerId: number | null = null;
  private townTimerId: number | null = null;
  private stepIndex = 0;
  private townStepIndex = 0;
  private gestureBound = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.bindFirstGestureUnlock();
    }
  }

  private bindFirstGestureUnlock() {
    if (this.gestureBound) return;
    this.gestureBound = true;
    const unlock = () => {
      if (!this.muted && this.isCombatMusicActive) {
        this.ensureContext();
        if (!this.musicTimerId) {
          this.startMusicLoop();
        }
      }
      if (!this.muted && this.isTownAmbienceActive) {
        this.ensureContext();
        if (!this.townTimerId) {
          this.startTownAmbienceLoop();
        }
      }
    };
    window.addEventListener('pointerdown', unlock, { passive: true });
    window.addEventListener('keydown', unlock, { passive: true });
  }

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private pitchJitter(baseFreq: number): number {
    return baseFreq * (0.93 + Math.random() * 0.14);
  }

  public setMuted(nextMuted: boolean) {
    this.muted = nextMuted;
    if (this.muted) {
      this.stopMusicLoop();
      this.stopTownAmbienceLoop();
    } else if (this.isCombatMusicActive) {
      this.ensureContext();
      this.startMusicLoop();
    } else if (this.isTownAmbienceActive) {
      this.ensureContext();
      this.startTownAmbienceLoop();
    }
  }

  public setCombatMusicActive(active: boolean) {
    if (this.isCombatMusicActive === active) return;
    this.isCombatMusicActive = active;
    if (active) {
      this.stopTownAmbienceLoop();
    }
    if (active && !this.muted) {
      this.startMusicLoop();
    } else {
      this.stopMusicLoop();
    }
  }

  public setTownAmbienceState(
    active: boolean,
    scenePreset = 'exterior',
    threatPhase = 'peaceful'
  ) {
    this.townScenePreset = scenePreset;
    this.townThreatPhase = threatPhase;
    if (this.isTownAmbienceActive === active) return;
    this.isTownAmbienceActive = active;
    if (active) {
      this.stopMusicLoop();
    }
    if (active && !this.muted) {
      this.startTownAmbienceLoop();
    } else {
      this.stopTownAmbienceLoop();
    }
  }

  private startTownAmbienceLoop() {
    this.stopTownAmbienceLoop();
    if (typeof window === 'undefined' || this.muted || !this.isTownAmbienceActive) return;
    this.townTimerId = window.setInterval(() => {
      this.scheduleTownAmbienceStep();
    }, 520);
  }

  private stopTownAmbienceLoop() {
    if (this.townTimerId !== null && typeof window !== 'undefined') {
      window.clearInterval(this.townTimerId);
      this.townTimerId = null;
    }
  }

  private scheduleTownAmbienceStep() {
    if (this.muted || !this.isTownAmbienceActive) return;
    const ctx = this.ensureContext();
    if (!ctx || ctx.state !== 'running') return;

    const now = ctx.currentTime;
    const step = this.townStepIndex % 12;
    this.townStepIndex = (this.townStepIndex + 1) % 12;

    // Gentle medieval D-Dorian lute/harp exploration motif (shifts slightly darker when town threat rises)
    const peacefulLute = [
      293.66, 0, 349.23, 440.0, 0, 392.0, 349.23, 0, 329.63, 293.66, 0, 220.0,
    ];
    const tenseLute = [
      293.66, 0, 311.13, 392.0, 0, 349.23, 311.13, 0, 293.66, 261.63, 0, 220.0,
    ];
    const notes = this.townThreatPhase === 'peaceful' ? peacefulLute : tenseLute;
    if (notes[step] > 0) {
      this.triggerThemeNote(ctx, notes[step], now, 0.42, 'triangle', 0.024, 920);
    }
    if (step === 0 || step === 6) {
      this.triggerThemeNote(ctx, 146.83, now, 0.85, 'sine', 0.026, 420);
    }

    // Scene-specific ambient environmental cues
    if (this.townScenePreset === 'forge' && (step === 3 || step === 9)) {
      // Distant blacksmith anvil ring
      this.triggerThemeNote(ctx, this.pitchJitter(820), now, 0.14, 'triangle', 0.02, 1800);
    } else if (this.townScenePreset === 'chapel' && step === 0) {
      // Distant chapel sanctuary bell resonance
      this.triggerThemeNote(ctx, 587.33, now, 1.1, 'sine', 0.022, 1300);
    } else if (this.townScenePreset === 'tavern' && step % 3 === 1) {
      // Soft hearth crackle warmth
      this.triggerThemeNote(ctx, this.pitchJitter(170), now, 0.09, 'triangle', 0.015, 540);
    } else if (this.townScenePreset === 'exterior' && step === 10) {
      // Gentle brook / wind shimmer or distant watch bell
      const freq = this.townThreatPhase === 'fortified' ? 523.25 : 659.25;
      this.triggerThemeNote(ctx, freq, now, 0.55, 'sine', 0.012, 950);
    }
  }

  public setCombatThemeState(nextState: TacticalAdvantageState) {
    if (this.currentThemeState === nextState) return;
    const prevState = this.currentThemeState;
    this.currentThemeState = nextState;
    this.stepIndex = 0;

    if (this.isCombatMusicActive && !this.muted) {
      this.playThemeShiftCue(nextState, prevState);
      this.startMusicLoop();
    }
  }

  private getStepIntervalMs(): number {
    switch (this.currentThemeState) {
      case 'party_ascendant':
        return 255; // ~118 BPM heroic drive
      case 'enemy_dominance':
        return 230; // ~130 BPM urgent dread pulse
      case 'evenly_matched':
      default:
        return 295; // ~102 BPM measured tactical ostinato
    }
  }

  private startMusicLoop() {
    this.stopMusicLoop();
    if (typeof window === 'undefined' || this.muted || !this.isCombatMusicActive) return;
    const intervalMs = this.getStepIntervalMs();
    this.musicTimerId = window.setInterval(() => {
      this.scheduleCombatMusicStep();
    }, intervalMs);
  }

  private stopMusicLoop() {
    if (this.musicTimerId !== null && typeof window !== 'undefined') {
      window.clearInterval(this.musicTimerId);
      this.musicTimerId = null;
    }
  }

  private playThemeShiftCue(nextState: TacticalAdvantageState, _prevState: TacticalAdvantageState) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Distinct 3-note harmonic swell announcing the shift in tactical momentum
    const notes =
      nextState === 'party_ascendant'
        ? [293.66, 369.99, 587.33] // D Major / Dorian heroic brass rise
        : nextState === 'enemy_dominance'
        ? [196.0, 155.56, 146.83] // Ominous minor-second descent into D Phrygian
        : [220.0, 261.63, 293.66]; // Balanced tactical cadence

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = nextState === 'enemy_dominance' ? 'sawtooth' : 'triangle';
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(nextState === 'enemy_dominance' ? 620 : 1250, now);

      const startAt = now + i * 0.075;
      osc.frequency.setValueAtTime(freq, startAt);
      gain.gain.setValueAtTime(0.08, startAt);
      gain.gain.exponentialRampToValueAtTime(0.001, startAt + 0.38);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startAt);
      osc.stop(startAt + 0.4);
    });
  }

  private scheduleCombatMusicStep() {
    if (this.muted || !this.isCombatMusicActive) return;
    const ctx = this.ensureContext();
    if (!ctx || ctx.state !== 'running') return;

    const now = ctx.currentTime;
    const step = this.stepIndex % 8;
    this.stepIndex = (this.stepIndex + 1) % 8;

    if (this.currentThemeState === 'party_ascendant') {
      // "Ascendant Dawn": Heroic D Dorian / Mixolydian arpeggio + warm fifths bass
      const melody = [293.66, 369.99, 440.0, 493.88, 587.33, 493.88, 440.0, 369.99];
      const bass = [146.83, 0, 146.83, 0, 220.0, 0, 196.0, 0];

      this.triggerThemeNote(ctx, melody[step], now, 0.22, 'triangle', 0.048, 1400);
      if (bass[step] > 0) {
        this.triggerThemeNote(ctx, bass[step], now, 0.34, 'sine', 0.062, 700);
      }
      if (step === 0 || step === 4) {
        this.triggerWarDrumPulse(ctx, now, 130, 0.055);
      }
      return;
    }

    if (this.currentThemeState === 'enemy_dominance') {
      // "Ashen Eclipse": Tense D Phrygian / Locrian motif + urgent double-heartbeat bass
      const melody = [293.66, 311.13, 415.3, 392.0, 349.23, 311.13, 277.18, 293.66];
      const bass = [73.42, 73.42, 0, 0, 77.78, 73.42, 0, 65.41];

      this.triggerThemeNote(ctx, melody[step], now, 0.2, 'sawtooth', 0.038, 680);
      if (bass[step] > 0) {
        this.triggerThemeNote(ctx, bass[step], now, 0.24, 'sawtooth', 0.058, 360);
      }
      if (step === 0 || step === 1 || step === 4) {
        this.triggerWarDrumPulse(ctx, now, 88, 0.068);
      }
      return;
    }

    // "Clash of Oaths" ('evenly_matched'): Measured D Minor tactical ostinato
    const melody = [293.66, 349.23, 440.0, 392.0, 349.23, 329.63, 293.66, 261.63];
    const bass = [146.83, 0, 0, 130.81, 110.0, 0, 130.81, 0];

    this.triggerThemeNote(ctx, melody[step], now, 0.25, 'triangle', 0.042, 950);
    if (bass[step] > 0) {
      this.triggerThemeNote(ctx, bass[step], now, 0.32, 'triangle', 0.052, 520);
    }
    if (step === 0) {
      this.triggerWarDrumPulse(ctx, now, 105, 0.05);
    }
  }

  private triggerThemeNote(
    ctx: AudioContext,
    freq: number,
    startTime: number,
    duration: number,
    wave: OscillatorType,
    peakGain: number,
    cutoffHz: number
  ) {
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = wave;
    osc.frequency.setValueAtTime(freq, startTime);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(cutoffHz, startTime);

    gain.gain.setValueAtTime(0.001, startTime);
    gain.gain.linearRampToValueAtTime(peakGain, startTime + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0008, startTime + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  private triggerWarDrumPulse(
    ctx: AudioContext,
    startTime: number,
    startFreq: number,
    peakGain: number
  ) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, startTime);
    osc.frequency.exponentialRampToValueAtTime(36, startTime + 0.14);

    gain.gain.setValueAtTime(peakGain, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.15);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(startTime);
    osc.stop(startTime + 0.16);
  }

  public playFootstep() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(this.pitchJitter(115), now);
    osc.frequency.exponentialRampToValueAtTime(45, now + 0.08);
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.09);
  }

  public playMeleeHit(heavy = false) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Metallic ring + low thud
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'triangle';
    const base = heavy ? 160 : 240;
    osc1.frequency.setValueAtTime(this.pitchJitter(base), now);
    osc1.frequency.exponentialRampToValueAtTime(52, now + (heavy ? 0.28 : 0.16));

    osc2.frequency.setValueAtTime(this.pitchJitter(580), now);
    osc2.frequency.exponentialRampToValueAtTime(190, now + 0.14);

    gain.gain.setValueAtTime(heavy ? 0.25 : 0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (heavy ? 0.29 : 0.18));

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + (heavy ? 0.3 : 0.19));
    osc2.stop(now + 0.16);
  }

  public playArcaneCast() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(this.pitchJitter(320), now);
    osc.frequency.exponentialRampToValueAtTime(760, now + 0.18);
    osc.frequency.exponentialRampToValueAtTime(210, now + 0.35);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.37);
  }

  public playHealBless() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.055);
      gain.gain.setValueAtTime(0.11, now + idx * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.055 + 0.26);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.055);
      osc.stop(now + idx * 0.055 + 0.27);
    });
  }

  public playDiceRoll(success: boolean) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Clatter ticks
    for (let i = 0; i < 4; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(300 + i * 95, now + i * 0.045);
      gain.gain.setValueAtTime(0.06, now + i * 0.045);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.045 + 0.035);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.045);
      osc.stop(now + i * 0.045 + 0.04);
    }

    // Outcome chord
    const endFreq = success ? 659.25 : 196.0;
    const oscOut = ctx.createOscillator();
    const gainOut = ctx.createGain();
    oscOut.type = success ? 'triangle' : 'sawtooth';
    oscOut.frequency.setValueAtTime(endFreq, now + 0.2);
    gainOut.gain.setValueAtTime(0.16, now + 0.2);
    gainOut.gain.exponentialRampToValueAtTime(0.001, now + 0.52);
    oscOut.connect(gainOut);
    gainOut.connect(ctx.destination);
    oscOut.start(now + 0.2);
    oscOut.stop(now + 0.53);
  }

  public playTelegraphWarning() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.linearRampToValueAtTime(360, now + 0.25);
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.27);
  }

  public playVictoryFanfare() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const chord = [293.66, 369.99, 440, 587.33];
    chord.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.09);
      gain.gain.setValueAtTime(0.15, now + i * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.09 + 0.55);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.09);
      osc.stop(now + i * 0.09 + 0.56);
    });
  }

  public playDefeatSting() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const chord = [261.63, 233.08, 196.0, 146.83];
    chord.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now + i * 0.12);
      gain.gain.setValueAtTime(0.14, now + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.12);
      osc.stop(now + i * 0.12 + 0.52);
    });
  }

  public playDoorTransition() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(75, now + 0.18);
    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.21);
  }

  public playCoinTrade() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    [987.77, 1318.51].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.055);
      gain.gain.setValueAtTime(0.09, now + i * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.055 + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.055);
      osc.stop(now + i * 0.055 + 0.19);
    });
  }

  public playGatherHerb() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.045);
      gain.gain.setValueAtTime(0.08, now + i * 0.045);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.045 + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.045);
      osc.stop(now + i * 0.045 + 0.17);
    });
  }

  /* ------------------------------------------------------------------------- */
  /* WARRIOR 12 UNIQUE COMBAT SKILL AUDIO CUES                                */
  /* ------------------------------------------------------------------------- */

  /** 1. Sundering Strike: Heavy metal-on-armor cleave with low-frequency crush */
  public playSunderingStrike() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscLow = ctx.createOscillator();
    const oscAnvil = ctx.createOscillator();
    const gain = ctx.createGain();

    oscLow.type = 'sawtooth';
    oscLow.frequency.setValueAtTime(this.pitchJitter(130), now);
    oscLow.frequency.exponentialRampToValueAtTime(38, now + 0.32);

    oscAnvil.type = 'triangle';
    oscAnvil.frequency.setValueAtTime(this.pitchJitter(480), now);
    oscAnvil.frequency.exponentialRampToValueAtTime(110, now + 0.22);

    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.34);

    oscLow.connect(gain);
    oscAnvil.connect(gain);
    gain.connect(ctx.destination);

    oscLow.start(now);
    oscAnvil.start(now);
    oscLow.stop(now + 0.35);
    oscAnvil.stop(now + 0.24);
  }

  /** 2. Guarded Stance: Low metallic settling sound & shield brace lock */
  public playShieldBrace() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscMetal = ctx.createOscillator();
    const oscHum = ctx.createOscillator();
    const gain = ctx.createGain();

    oscMetal.type = 'triangle';
    oscMetal.frequency.setValueAtTime(320, now);
    oscMetal.frequency.exponentialRampToValueAtTime(220, now + 0.18);

    oscHum.type = 'sine';
    oscHum.frequency.setValueAtTime(165, now);
    oscHum.frequency.linearRampToValueAtTime(130, now + 0.42);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    oscMetal.connect(gain);
    oscHum.connect(gain);
    gain.connect(ctx.destination);

    oscMetal.start(now);
    oscHum.start(now);
    oscMetal.stop(now + 0.2);
    oscHum.stop(now + 0.46);
  }

  /** 3. Whirlwind Assault: Fast cutting blade whoosh & sweeping multi-hit ring */
  public playWhirlwindSlash() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscSweep = ctx.createOscillator();
    const gain = ctx.createGain();

    oscSweep.type = 'sawtooth';
    oscSweep.frequency.setValueAtTime(220, now);
    oscSweep.frequency.exponentialRampToValueAtTime(540, now + 0.14);
    oscSweep.frequency.exponentialRampToValueAtTime(160, now + 0.32);

    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    oscSweep.connect(gain);
    gain.connect(ctx.destination);

    oscSweep.start(now);
    oscSweep.stop(now + 0.36);
  }

  /** 4. Driving Assault: Heavy vanguard ram thud & armor impact */
  public playShoulderCharge() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscRam = ctx.createOscillator();
    const gain = ctx.createGain();

    oscRam.type = 'triangle';
    oscRam.frequency.setValueAtTime(180, now);
    oscRam.frequency.exponentialRampToValueAtTime(42, now + 0.26);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    oscRam.connect(gain);
    gain.connect(ctx.destination);

    oscRam.start(now);
    oscRam.stop(now + 0.29);
  }

  /** 5. Weapon Parry: High-tension sharp metallic blade clash */
  public playBladeParry() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscClash1 = ctx.createOscillator();
    const oscClash2 = ctx.createOscillator();
    const gain = ctx.createGain();

    oscClash1.type = 'triangle';
    oscClash1.frequency.setValueAtTime(this.pitchJitter(880), now);
    oscClash1.frequency.exponentialRampToValueAtTime(440, now + 0.16);

    oscClash2.type = 'square';
    oscClash2.frequency.setValueAtTime(this.pitchJitter(1320), now);
    oscClash2.frequency.exponentialRampToValueAtTime(660, now + 0.09);

    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    oscClash1.connect(gain);
    oscClash2.connect(gain);
    gain.connect(ctx.destination);

    oscClash1.start(now);
    oscClash2.start(now);
    oscClash1.stop(now + 0.23);
    oscClash2.stop(now + 0.12);
  }

  /** 6. Crippling Blow: Focused low angle tendon slash */
  public playCripplingStrike() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscSlice = ctx.createOscillator();
    const gain = ctx.createGain();

    oscSlice.type = 'sawtooth';
    oscSlice.frequency.setValueAtTime(360, now);
    oscSlice.frequency.exponentialRampToValueAtTime(95, now + 0.18);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    oscSlice.connect(gain);
    gain.connect(ctx.destination);

    oscSlice.start(now);
    oscSlice.stop(now + 0.21);
  }

  /** 7. Unbreakable Resolve: Resolute warcry breath & rallying steel hum */
  public playUnbreakableResolve() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const chords = [196.0, 246.94, 293.66]; // G Major resolute chord
    chords.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.04);
      gain.gain.setValueAtTime(0.12, now + idx * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.04 + 0.42);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.04);
      osc.stop(now + idx * 0.04 + 0.44);
    });
  }

  /** 8. Earthsplitter: Heavy downward slam & seismic rumble */
  public playEarthsplitterSlam() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscThud = ctx.createOscillator();
    const oscRumble = ctx.createOscillator();
    const gain = ctx.createGain();

    oscThud.type = 'sawtooth';
    oscThud.frequency.setValueAtTime(140, now);
    oscThud.frequency.exponentialRampToValueAtTime(30, now + 0.38);

    oscRumble.type = 'triangle';
    oscRumble.frequency.setValueAtTime(80, now + 0.05);
    oscRumble.frequency.linearRampToValueAtTime(45, now + 0.48);

    gain.gain.setValueAtTime(0.32, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    oscThud.connect(gain);
    oscRumble.connect(gain);
    gain.connect(ctx.destination);

    oscThud.start(now);
    oscRumble.start(now + 0.05);
    oscThud.stop(now + 0.4);
    oscRumble.stop(now + 0.52);
  }

  /** 9. Relentless Pursuit: Quick aggressive double-step boots */
  public playTacticalSprint() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    [0, 0.11, 0.22].forEach((offset) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(125, now + offset);
      osc.frequency.exponentialRampToValueAtTime(50, now + offset + 0.07);
      gain.gain.setValueAtTime(0.16, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + offset);
      osc.stop(now + offset + 0.09);
    });
  }

  /** 10. Iron Reprisal: Sharp defensive recoil counter-slash */
  public playIronReprisal() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.15);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  /** 11. Battlefield Commander: Resonant tactical rallying trumpet / command call */
  public playBattlefieldCommander() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const fan = [293.66, 369.99, 440.0, 587.33]; // D Dorian command brass fan
    fan.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + idx * 0.07);
      gain.gain.setValueAtTime(0.14, now + idx * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.32);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.07);
      osc.stop(now + idx * 0.07 + 0.34);
    });
  }

  /** 12. Last Stand: Defiant low war-horn & resonant unyielding aura */
  public playLastStandDefiance() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const oscHorn = ctx.createOscillator();
    const oscSub = ctx.createOscillator();
    const gain = ctx.createGain();

    oscHorn.type = 'sawtooth';
    oscHorn.frequency.setValueAtTime(110.0, now); // Low A
    oscHorn.frequency.linearRampToValueAtTime(146.83, now + 0.28); // Rising to D
    oscHorn.frequency.exponentialRampToValueAtTime(73.42, now + 0.65);

    oscSub.type = 'sine';
    oscSub.frequency.setValueAtTime(73.42, now);
    oscSub.frequency.exponentialRampToValueAtTime(36.71, now + 0.7);

    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.75);

    oscHorn.connect(gain);
    oscSub.connect(gain);
    gain.connect(ctx.destination);

    oscHorn.start(now);
    oscSub.start(now);
    oscHorn.stop(now + 0.76);
    oscSub.stop(now + 0.76);
  }

  // ==========================================
  // MAGE 12 CORE SKILL SOUNDS
  // ==========================================

  public playInfernalOrb() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const noiseGain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(420, now + 0.15);
    osc.frequency.exponentialRampToValueAtTime(75, now + 0.35);
    noiseGain.gain.setValueAtTime(0.32, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
    osc.connect(noiseGain); noiseGain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.4);
  }

  public playGlacialLance() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [1200, 1600, 2400].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.04);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.4, now + idx * 0.04 + 0.18);
      gain.gain.setValueAtTime(0.18, now + idx * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.04 + 0.22);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + idx * 0.04); osc.stop(now + idx * 0.04 + 0.24);
    });
  }

  public playChainLightning() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [660, 880, 1320].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + idx * 0.07);
      osc.frequency.linearRampToValueAtTime(freq * 1.8, now + idx * 0.07 + 0.04);
      osc.frequency.exponentialRampToValueAtTime(110, now + idx * 0.07 + 0.14);
      gain.gain.setValueAtTime(0.22, now + idx * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.16);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + idx * 0.07); osc.stop(now + idx * 0.07 + 0.18);
    });
  }

  public playBlinkStep() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(1480, now + 0.12);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.24);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.28);
  }

  public playGravitationalCollapse() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const oscLow = ctx.createOscillator();
    const oscSingularity = ctx.createOscillator();
    const gain = ctx.createGain();
    oscLow.type = 'sawtooth';
    oscLow.frequency.setValueAtTime(240, now);
    oscLow.frequency.exponentialRampToValueAtTime(45, now + 0.38);
    oscSingularity.type = 'sine';
    oscSingularity.frequency.setValueAtTime(700, now);
    oscSingularity.frequency.linearRampToValueAtTime(1400, now + 0.18);
    oscSingularity.frequency.exponentialRampToValueAtTime(60, now + 0.4);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.44);
    oscLow.connect(gain); oscSingularity.connect(gain); gain.connect(ctx.destination);
    oscLow.start(now); oscSingularity.start(now);
    oscLow.stop(now + 0.46); oscSingularity.stop(now + 0.46);
  }

  public playArcaneDisjunction() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [880, 587.33, 440].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.05);
      osc.frequency.exponentialRampToValueAtTime(120, now + idx * 0.05 + 0.2);
      gain.gain.setValueAtTime(0.24, now + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.24);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + idx * 0.05); osc.stop(now + idx * 0.05 + 0.26);
    });
  }

  public playAegisWard() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [523.25, 659.25, 1046.5].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);
      gain.gain.setValueAtTime(0.2, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.38);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + idx * 0.06); osc.stop(now + idx * 0.06 + 0.42);
    });
  }

  public playCounterspell() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(330, now);
    osc.frequency.exponentialRampToValueAtTime(1320, now + 0.12);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.28);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.32);
  }

  public playPhaseVeil() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [440, 554.37, 880].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);
      osc.frequency.linearRampToValueAtTime(freq * 1.25, now + idx * 0.08 + 0.15);
      gain.gain.setValueAtTime(0.18, now + idx * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.35);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + idx * 0.08); osc.stop(now + idx * 0.08 + 0.38);
    });
  }

  public playRunicMine() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(750, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.22);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.28);
  }

  public playAstralRift() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.45);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.52);
  }

  public playPrismaticField() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [659.25, 830.61, 987.77, 1318.51].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);
      gain.gain.setValueAtTime(0.18, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.45);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + idx * 0.06); osc.stop(now + idx * 0.06 + 0.48);
    });
  }

  // Backward compatibility alias methods for legacy callers
  public playArcaneBolt() { this.playInfernalOrb(); }
  public playLeyLineSense() { this.playGlacialLance(); }
  public playGravityWell() { this.playChainLightning(); }
  public playAstralStep() { this.playBlinkStep(); }
  public playSpellEcho() { this.playGravitationalCollapse(); }
  public playNullField() { this.playArcaneDisjunction(); }
  public playPrismaticCage() { this.playAegisWard(); }
  public playTemporalDistortion() { this.playCounterspell(); }
  public playArcaneConvergence() { this.playPhaseVeil(); }
  public playRiftCollapse() { this.playRunicMine(); }
  public playAstralOverload() { this.playAstralRift(); }
  public playRealityFracture() { this.playPrismaticField(); }

  // ==========================================
  // ROGUE 12 CORE SKILL SOUNDS
  // ==========================================

  public playQuickdraw() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(950, now);
    osc.frequency.exponentialRampToValueAtTime(300, now + 0.1);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.13);
  }

  public playShadowVeil() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.35);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.4);
  }

  public playMarkForDeath() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [220, 233.08].forEach((f) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.48);
    });
  }

  public playTripwire() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1200, now);
    osc.frequency.exponentialRampToValueAtTime(600, now + 0.08);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.12);
  }

  public playSmokeEscape() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(50, now + 0.28);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.35);
  }

  public playPickpocket() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [987.77, 1318.51].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.06);
      gain.gain.setValueAtTime(0.16, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.15);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + i * 0.06); osc.stop(now + i * 0.06 + 0.17);
    });
  }

  public playFalseOpening() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(680, now);
    osc.frequency.exponentialRampToValueAtTime(240, now + 0.15);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.2);
  }

  public playPoisonedEdge() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.linearRampToValueAtTime(780, now + 0.12);
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.22);
  }

  public playEvasiveRoll() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.22);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.27);
  }

  public playAmbushProtocol() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(750, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.14);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.18);
  }

  public playShadowExchange() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
    osc.frequency.exponentialRampToValueAtTime(200, now + 0.24);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.28);
  }

  public playPerfectExecution() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(850, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.25);
    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.32);
  }

  // ==========================================
  // PALADIN 12 CORE SKILL SOUNDS
  // ==========================================

  public playConsecratedStrike() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(280, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.25);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.34);
  }

  public playOathward() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(370, now);
    osc.frequency.exponentialRampToValueAtTime(554.37, now + 0.22);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.38);
  }

  public playSanctuaryRing() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [440, 659.25].forEach((f) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.58);
    });
  }

  public playJudgmentMark() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(587.33, now);
    osc.frequency.exponentialRampToValueAtTime(293.66, now + 0.2);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.28);
  }

  public playRadiantMend() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + i * 0.08);
      gain.gain.setValueAtTime(0.18, now + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.35);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + i * 0.08); osc.stop(now + i * 0.08 + 0.38);
    });
  }

  public playShieldOfConviction() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.16);
    gain.gain.setValueAtTime(0.32, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.22);
  }

  public playOathOfRestraint() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [329.63, 440, 587.33].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now + i * 0.06);
      gain.gain.setValueAtTime(0.18, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.28);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + i * 0.06); osc.stop(now + i * 0.06 + 0.3);
    });
  }

  public playSacredGround() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.4);
    gain.gain.setValueAtTime(0.38, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.5);
  }

  public playBurdenOfSin() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(45, now + 0.38);
    gain.gain.setValueAtTime(0.32, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.45);
  }

  public playBeaconOfHope() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [293.66, 369.99, 440, 587.33].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.07);
      gain.gain.setValueAtTime(0.18, now + i * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.4);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + i * 0.07); osc.stop(now + i * 0.07 + 0.42);
    });
  }

  public playDivineIntercession() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.35);
  }

  public playWrathOfTheRighteous() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(65, now + 0.5);
    gain.gain.setValueAtTime(0.42, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.62);
  }

  public playFinalJudgment() {
    this.playWrathOfTheRighteous();
  }

  // ==========================================
  // RANGER 12 CORE SKILL SOUNDS
  // ==========================================

  public playPrecisionShot() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(850, now);
    osc.frequency.exponentialRampToValueAtTime(260, now + 0.16);
    gain.gain.setValueAtTime(0.26, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.2);
  }

  public playHuntersInstinct() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(640, now + 0.2);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.32);
  }

  public playPinningArrow() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.18);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.24);
  }

  public playHuntingGround() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [392, 523.25].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now + i * 0.08);
      gain.gain.setValueAtTime(0.18, now + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.3);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + i * 0.08); osc.stop(now + i * 0.08 + 0.32);
    });
  }

  public playRicochetShot() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [880, 1174.66, 1480].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.06);
      gain.gain.setValueAtTime(0.2, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.12);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now + i * 0.06); osc.stop(now + i * 0.06 + 0.14);
    });
  }

  public playCamouflage() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(240, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.28);
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.35);
  }

  public playThornline() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(450, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.22);
    gain.gain.setValueAtTime(0.26, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.28);
  }

  public playBeastCall() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.linearRampToValueAtTime(320, now + 0.25);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.55);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.62);
  }

  public playWindrunner() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(350, now);
    osc.frequency.exponentialRampToValueAtTime(700, now + 0.15);
    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.28);
  }

  public playDeadfallTrap() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(280, now);
    osc.frequency.exponentialRampToValueAtTime(60, now + 0.28);
    gain.gain.setValueAtTime(0.36, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.38);
  }

  public playMarkedPrey() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(920, now);
    osc.frequency.exponentialRampToValueAtTime(460, now + 0.18);
    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.24);
  }

  public playNaturesDominion() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(50, now + 0.5);
    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.62);
  }

  // ==========================================
  // SPECIALIZATION 36 SKILL SOUNDS
  // ==========================================

  // --- Dawn Warden (6) ---
  public playSolarFlare() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'triangle'; osc.frequency.setValueAtTime(800, now); osc.frequency.exponentialRampToValueAtTime(200, now + 0.16);
    gain.gain.setValueAtTime(0.28, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.22);
  }

  public playAegisOfTheDawn() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(440, now); osc.frequency.exponentialRampToValueAtTime(880, now + 0.25);
    gain.gain.setValueAtTime(0.22, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.35);
  }

  public playDaybreakSmite() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(320, now); osc.frequency.exponentialRampToValueAtTime(640, now + 0.2);
    gain.gain.setValueAtTime(0.32, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.3);
  }

  public playSunwellAura() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [523.25, 659.25].forEach((f, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.type = 'sine'; osc.frequency.setValueAtTime(f, now + i * 0.08);
      gain.gain.setValueAtTime(0.18, now + i * 0.08); gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.35);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(now + i * 0.08); osc.stop(now + i * 0.08 + 0.38);
    });
  }

  public playRadiantBastion() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(240, now); osc.frequency.exponentialRampToValueAtTime(80, now + 0.35);
    gain.gain.setValueAtTime(0.35, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.45);
  }

  public playAvatarOfTheSun() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [329.63, 440, 659.25, 880].forEach((f, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.type = 'triangle'; osc.frequency.setValueAtTime(f, now + i * 0.06);
      gain.gain.setValueAtTime(0.2, now + i * 0.06); gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.5);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(now + i * 0.06); osc.stop(now + i * 0.06 + 0.52);
    });
  }

  // --- Vengeance Knight (6) ---
  public playRetributionStrike() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(420, now); osc.frequency.exponentialRampToValueAtTime(110, now + 0.2);
    gain.gain.setValueAtTime(0.35, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.28);
  }

  public playSpitefulWard() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'square'; osc.frequency.setValueAtTime(260, now); osc.frequency.exponentialRampToValueAtTime(100, now + 0.16);
    gain.gain.setValueAtTime(0.28, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.24);
  }

  public playDreadInscription() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(540, now); osc.frequency.exponentialRampToValueAtTime(180, now + 0.18);
    gain.gain.setValueAtTime(0.25, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.26);
  }

  public playUnrelentingVengeance() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(130, now); osc.frequency.linearRampToValueAtTime(220, now + 0.25);
    gain.gain.setValueAtTime(0.3, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.4);
  }

  public playExecutionersWrath() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(500, now); osc.frequency.exponentialRampToValueAtTime(60, now + 0.3);
    gain.gain.setValueAtTime(0.42, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.4);
  }

  public playOathOfTotalRuin() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(200, now); osc.frequency.exponentialRampToValueAtTime(45, now + 0.45);
    gain.gain.setValueAtTime(0.45, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.58);
  }

  // --- Crimson Savant (6) ---
  public playBloodSiphon() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(340, now); osc.frequency.exponentialRampToValueAtTime(120, now + 0.25);
    gain.gain.setValueAtTime(0.24, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.32);
  }

  public playBoilingVeins() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(620, now); osc.frequency.exponentialRampToValueAtTime(220, now + 0.16);
    gain.gain.setValueAtTime(0.25, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.22);
  }

  public playSanguineTransfusion() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'triangle'; osc.frequency.setValueAtTime(280, now); osc.frequency.linearRampToValueAtTime(440, now + 0.2);
    gain.gain.setValueAtTime(0.22, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.32);
  }

  public playHemorrhageCurse() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(480, now); osc.frequency.exponentialRampToValueAtTime(150, now + 0.2);
    gain.gain.setValueAtTime(0.24, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.28);
  }

  public playCrimsonMaelstrom() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(320, now); osc.frequency.exponentialRampToValueAtTime(70, now + 0.35);
    gain.gain.setValueAtTime(0.35, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.45);
  }

  public playHeartstopSovereign() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'square'; osc.frequency.setValueAtTime(110, now); osc.frequency.exponentialRampToValueAtTime(35, now + 0.25);
    gain.gain.setValueAtTime(0.4, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.35);
  }

  // --- Rift Chronomancer (6) ---
  public playTimeSlip() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(300, now); osc.frequency.linearRampToValueAtTime(900, now + 0.15);
    gain.gain.setValueAtTime(0.22, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.25);
  }

  public playChronostasis() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(1200, now); osc.frequency.exponentialRampToValueAtTime(400, now + 0.25);
    gain.gain.setValueAtTime(0.24, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.35);
  }

  public playAccelerateFlow() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'triangle'; osc.frequency.setValueAtTime(500, now); osc.frequency.exponentialRampToValueAtTime(1000, now + 0.15);
    gain.gain.setValueAtTime(0.2, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.25);
  }

  public playEchoesOfEternity() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [600, 900].forEach((f, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.type = 'sine'; osc.frequency.setValueAtTime(f, now + i * 0.08);
      gain.gain.setValueAtTime(0.16, now + i * 0.08); gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.25);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(now + i * 0.08); osc.stop(now + i * 0.08 + 0.28);
    });
  }

  public playParadoxNova() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(400, now); osc.frequency.exponentialRampToValueAtTime(80, now + 0.35);
    gain.gain.setValueAtTime(0.38, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.45);
  }

  public playTimeStop() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(880, now); osc.frequency.exponentialRampToValueAtTime(110, now + 0.45);
    gain.gain.setValueAtTime(0.35, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.58);
  }

  // --- Briar Stalker (6) ---
  public playAmbushSnare() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(450, now); osc.frequency.exponentialRampToValueAtTime(110, now + 0.16);
    gain.gain.setValueAtTime(0.26, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.24);
  }

  public playShadowThorn() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'triangle'; osc.frequency.setValueAtTime(900, now); osc.frequency.exponentialRampToValueAtTime(280, now + 0.12);
    gain.gain.setValueAtTime(0.24, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.18);
  }

  public playBrambleStride() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(320, now); osc.frequency.exponentialRampToValueAtTime(180, now + 0.18);
    gain.gain.setValueAtTime(0.2, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.26);
  }

  public playVenomousBramble() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(380, now); osc.frequency.exponentialRampToValueAtTime(90, now + 0.25);
    gain.gain.setValueAtTime(0.28, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.32);
  }

  public playLurkerInTheFoliage() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(220, now); osc.frequency.exponentialRampToValueAtTime(80, now + 0.28);
    gain.gain.setValueAtTime(0.18, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.35);
  }

  public playWrathOfThePrimordialGrove() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(240, now); osc.frequency.exponentialRampToValueAtTime(50, now + 0.45);
    gain.gain.setValueAtTime(0.42, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.58);
  }

  // --- Ironbough Sentinel (6) ---
  public playIronwoodBrace() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'square'; osc.frequency.setValueAtTime(180, now); osc.frequency.exponentialRampToValueAtTime(70, now + 0.2);
    gain.gain.setValueAtTime(0.3, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.28);
  }

  public playRootingCleave() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(360, now); osc.frequency.exponentialRampToValueAtTime(95, now + 0.24);
    gain.gain.setValueAtTime(0.32, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.32);
  }

  public playGroundedBastion() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(160, now); osc.frequency.exponentialRampToValueAtTime(60, now + 0.25);
    gain.gain.setValueAtTime(0.28, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.35);
  }

  public playTimberfallSlam() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(300, now); osc.frequency.exponentialRampToValueAtTime(55, now + 0.32);
    gain.gain.setValueAtTime(0.38, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.42);
  }

  public playHeartOfTheAncientBough() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    [261.63, 329.63, 392].forEach((f, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.type = 'sine'; osc.frequency.setValueAtTime(f, now + i * 0.08);
      gain.gain.setValueAtTime(0.18, now + i * 0.08); gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.4);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(now + i * 0.08); osc.stop(now + i * 0.08 + 0.42);
    });
  }

  public playColossusOfTheVale() {
    const ctx = this.ensureContext(); if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(160, now); osc.frequency.exponentialRampToValueAtTime(40, now + 0.5);
    gain.gain.setValueAtTime(0.44, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.62);
  }
}

export const soundEngine = new SoundEngine();
