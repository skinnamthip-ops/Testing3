import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  CharacterRaceId,
  CHARACTER_RACES,
  CHARACTER_CLASSES,
  CHARACTER_SUBCLASSES,
  computeCharacterBuildPreview,
  applyCharacterBuildToParty,
  createDefaultCharacterBuild,
  createInitialRelationships,
  createInitialWorldState,
  createEncounterUnits,
} from './rules';
import {
  BODY_PRESETS,
  FACE_PRESETS_BY_RACE,
  HAIRSTYLE_LIBRARY,
  HAIR_COLORS,
  SECONDARY_HAIR_HIGHLIGHTS,
  FACIAL_HAIR_OPTIONS,
  EYE_COLORS,
  SCARS_LIBRARY,
  TATTOOS_LIBRARY,
  MARKINGS_LIBRARY,
  TIEFLING_HORNS,
  HORN_COLORS,
  NARRATIVE_BACKGROUNDS,
  PERSONALITY_OPTIONS,
  VOICE_OPTIONS,
  PLAYABLE_CLASS_PROFILES,
  ATTRIBUTE_METADATA,
  ATTRIBUTE_POINT_BUDGET,
  MAX_ALLOC_PER_STAT,
  SPECIALIZATION_ROADMAP,
  SPECIALIZATION_PROFILES,
  getCompatibleSpecializations,
  RACE_EXTENDED_DETAILS,
  RACE_RANDOM_NAMES,
  createDefaultDetailedAppearance,
  randomizeDetailedAppearance,
  getD20Modifier,
  formatD20Modifier,
  PersistentCharacterConfiguration,
  CREATION_PROGRESS_STEPS,
} from './characterCreationData';
import { createInitialGloamrestState } from './gloamrestEngine';

// ============================================================================
// SUITE: MASTER CHARACTER CREATION SYSTEM (BALDUR'S GATE 3 DEPTH & DIMRAETH IDENTITY)
// ============================================================================

test('1. Eleven Progression Steps: exactly 11 numbered accessible steps from Begin to Review (including 08. Specialization)', () => {
  assert.equal(CREATION_PROGRESS_STEPS.length, 11, 'Must have exactly 11 creation steps');

  const expectedSteps = [
    { stepNum: '01', id: 'begin', label: 'Begin' },
    { stepNum: '02', id: 'ancestry', label: 'Ancestry' },
    { stepNum: '03', id: 'body', label: 'Body' },
    { stepNum: '04', id: 'face', label: 'Face' },
    { stepNum: '05', id: 'appearance', label: 'Appearance' },
    { stepNum: '06', id: 'identity', label: 'Identity' },
    { stepNum: '07', id: 'class', label: 'Class' },
    { stepNum: '08', id: 'subclass', label: 'Specialization' },
    { stepNum: '09', id: 'attributes', label: 'Attributes' },
    { stepNum: '10', id: 'combat_identity', label: 'Combat Loadout' },
    { stepNum: '11', id: 'review', label: 'Review' },
  ];

  expectedSteps.forEach((exp, idx) => {
    const actual = CREATION_PROGRESS_STEPS[idx];
    assert.equal(actual.stepNum, exp.stepNum, `Step ${idx} must have number ${exp.stepNum}`);
    assert.equal(actual.id, exp.id, `Step ${idx} must have id ${exp.id}`);
    assert.equal(actual.label, exp.label, `Step ${idx} must have label ${exp.label}`);
  });
});

test('2. Ancestry Integrity: all four playable races have distinct anatomical characteristics and compatible palettes', () => {
  const races: CharacterRaceId[] = ['half_elf', 'tiefling', 'wood_kin', 'astral_human'];

  races.forEach((rId) => {
    const meta = RACE_EXTENDED_DETAILS[rId];
    assert.ok(meta, `Metadata must exist for race: ${rId}`);
    assert.ok(meta.name.length > 0, `Race ${rId} must have a name`);
    assert.ok(meta.physicalCharacteristics.length >= 3, `Race ${rId} must define physical traits`);
    assert.ok(meta.compatibleSkinTones.length >= 4, `Race ${rId} must provide compatible skin tones`);

    // Verify distinct racial trait in base rules
    const baseRace = CHARACTER_RACES[rId];
    assert.ok(baseRace, `Base CHARACTER_RACES must define ${rId}`);
    assert.ok(baseRace.traitName.length > 0);
    assert.ok(baseRace.traitSummary.length > 0);
  });

  // Verify random names exist for all 4 races
  races.forEach((rId) => {
    const names = RACE_RANDOM_NAMES[rId];
    assert.ok(Array.isArray(names) && names.length >= 10, `Race ${rId} must have at least 10 names`);
  });
});

test('3. Body Customization: 5 base body presets and individual slider proportions', () => {
  assert.equal(BODY_PRESETS.length, 5, 'Must provide 5 base body presets');
  const expectedPresetIds = ['slim', 'balanced', 'athletic', 'muscular', 'heavyset'];

  expectedPresetIds.forEach((id) => {
    const preset = BODY_PRESETS.find((p) => p.id === id);
    assert.ok(preset, `Preset ${id} must exist`);
    assert.ok(preset.proportions.height >= 0.85 && preset.proportions.height <= 1.15);
    assert.ok(preset.proportions.shoulderWidth >= 0.8 && preset.proportions.shoulderWidth <= 1.25);
    assert.ok(preset.proportions.chest >= 0.8 && preset.proportions.chest <= 1.25);
    assert.ok(preset.proportions.waist >= 0.8 && preset.proportions.waist <= 1.25);
    assert.ok(preset.proportions.muscularity >= 0.0 && preset.proportions.muscularity <= 1.0);
  });
});

test('4. Facial Customization: at least 12 distinct face presets per race (48 presets total)', () => {
  const races: CharacterRaceId[] = ['half_elf', 'tiefling', 'wood_kin', 'astral_human'];

  races.forEach((rId) => {
    const presets = FACE_PRESETS_BY_RACE[rId];
    assert.ok(presets, `Presets must exist for ${rId}`);
    assert.equal(presets.length, 12, `Race ${rId} must have exactly 12 distinct face presets`);

    // Ensure presets are non-identical (different face width or cheekbone height or jaw)
    const signatures = new Set<string>();
    presets.forEach((p) => {
      assert.ok(p.name.length > 0);
      assert.ok(p.archetype.length > 0);
      const sig = `${p.proportions.faceWidth.toFixed(2)}-${p.proportions.jawWidth.toFixed(2)}-${p.proportions.cheekboneHeight.toFixed(2)}`;
      signatures.add(sig);
    });

    assert.ok(signatures.size >= 10, `Race ${rId} must have distinct facial geometry signatures`);
  });
});

test('5. Hairstyle Library: at least 20 distinct hairstyles across defined categories', () => {
  assert.ok(HAIRSTYLE_LIBRARY.length >= 20, 'Hairstyle library must contain at least 20 hairstyles');

  const categories = new Set(HAIRSTYLE_LIBRARY.map((h) => h.category));
  const expectedCategories = [
    'Short',
    'Medium',
    'Long',
    'Braided',
    'Tied-Back',
    'Loose',
    'Undercut',
    'Warrior',
    'Travel-Ready',
  ];

  expectedCategories.forEach((cat) => {
    assert.ok(categories.has(cat as any), `Category ${cat} must be represented in hairstyle library`);
  });

  // Verify unique hairstyle IDs
  const idSet = new Set(HAIRSTYLE_LIBRARY.map((h) => h.id));
  assert.equal(idSet.size, HAIRSTYLE_LIBRARY.length, 'Hairstyle IDs must all be unique');
});

test('6. Appearance Customization: colors, facial hair, eye colors, scars, tattoos, and horns', () => {
  assert.ok(HAIR_COLORS.length >= 8, 'Must have at least 8 hair colors');
  assert.ok(SECONDARY_HAIR_HIGHLIGHTS.length >= 5, 'Must have secondary highlights');
  assert.ok(FACIAL_HAIR_OPTIONS.length >= 5, 'Must have at least 5 facial hair styles');
  assert.ok(EYE_COLORS.length >= 8, 'Must have at least 8 eye colors');
  assert.ok(SCARS_LIBRARY.length >= 5, 'Must have at least 5 scars options');
  assert.ok(TATTOOS_LIBRARY.length >= 5, 'Must have at least 5 tattoos options');
  assert.ok(MARKINGS_LIBRARY.length >= 5, 'Must have markings options');
  assert.ok(TIEFLING_HORNS.length >= 4, 'Must have at least 4 Tiefling horn styles');
  assert.ok(HORN_COLORS.length >= 4, 'Must have horn color choices');
});

test('7. Identity & Origins: 7 narrative backgrounds, 6 personalities, and 4 voices', () => {
  assert.equal(NARRATIVE_BACKGROUNDS.length, 7, 'Must have exactly 7 narrative backgrounds');
  const expectedBgIds = [
    'the_dispossessed',
    'the_soldier',
    'the_scholar',
    'the_outcast',
    'the_wanderer',
    'the_devout',
    'the_survivor',
  ];

  expectedBgIds.forEach((id) => {
    const match = NARRATIVE_BACKGROUNDS.find((b) => b.id === id);
    assert.ok(match, `Background ${id} must exist`);
    assert.ok(match.name.length > 0);
    assert.ok(match.emblem.length > 0);
    assert.ok(match.lore.length > 0);
    assert.ok(match.perspective.length > 0);
    assert.ok(match.dialogueBenefits.length > 0);
  });

  assert.equal(PERSONALITY_OPTIONS.length, 6, 'Must have exactly 6 personalities');
  const expectedPersonalities = [
    'compassionate',
    'pragmatic',
    'ambitious',
    'reserved',
    'defiant',
    'curious',
  ];
  expectedPersonalities.forEach((id) => {
    assert.ok(PERSONALITY_OPTIONS.some((p) => p.id === id), `Personality ${id} must exist`);
  });

  assert.equal(VOICE_OPTIONS.length, 4, 'Must have 4 voice options');
});

test('8. Five Playable Classes: equipment, combat identity, and engine mappings', () => {
  assert.equal(PLAYABLE_CLASS_PROFILES.length, 5, 'Must have 5 playable class profiles');
  const expectedClasses = ['warrior', 'mage', 'rogue', 'paladin', 'ranger'];

  const expectedDescriptions: Record<string, string> = {
    warrior:
      'A disciplined frontline fighter who dominates the battlefield through weapon mastery, physical strength, and defensive technique.',
    mage:
      'A practitioner of arcane forces who manipulates magical energy, controls space, and reshapes encounters.',
    rogue:
      'A tactical infiltrator who relies on precision, mobility, deception, and exploiting enemy weaknesses.',
    paladin:
      'An oathbound protector who combines martial discipline with sacred power and battlefield protection.',
    ranger:
      'A wilderness specialist who controls space through precision attacks, preparation, and ranged combat.',
  };

  expectedClasses.forEach((archetypeId) => {
    const prof = PLAYABLE_CLASS_PROFILES.find((p) => p.archetypeId === archetypeId);
    assert.ok(prof, `Profile ${archetypeId} must exist`);
    assert.equal(prof.description, expectedDescriptions[archetypeId], `Class ${archetypeId} must match official prompt description`);
    assert.ok(prof.title.length > 0, `Class ${archetypeId} must have a title`);
    assert.ok(prof.icon.length > 0, `Class ${archetypeId} must have an icon`);
    assert.ok(prof.oneLineIdentity.length > 0, `Class ${archetypeId} must have one-line combat identity`);
    assert.ok(prof.tacticalStrengths.length >= 3, `Class ${archetypeId} must have at least 3 tactical strengths`);
    assert.ok(prof.weaponIdentity.length > 0, `Class ${archetypeId} must have weapon identity`);
    assert.ok(prof.armorIdentity.length > 0, `Class ${archetypeId} must have armor identity`);
    assert.ok(prof.compatibleSubclassIds.length >= 1, `Class ${archetypeId} must have compatible subclasses`);
    assert.ok(prof.startingEquipment.length >= 3, 'Must have starting equipment');
    assert.equal(prof.startingAbilities.length, 2, 'Must have 2 starting abilities');
    assert.ok(CHARACTER_CLASSES[prof.mappedClassId], `Mapped engine class must exist: ${prof.mappedClassId}`);
    assert.ok(CHARACTER_SUBCLASSES[prof.defaultSubclassId], `Default subclass must exist: ${prof.defaultSubclassId}`);
  });
});

test('9. D20 Attribute Modifier Formula: strict adherence to floor((score - 10) / 2)', () => {
  const testCases = [
    { score: 6, expectedMod: -2 },
    { score: 8, expectedMod: -1 },
    { score: 9, expectedMod: -1 },
    { score: 10, expectedMod: 0 },
    { score: 11, expectedMod: 0 },
    { score: 12, expectedMod: 1 },
    { score: 13, expectedMod: 1 },
    { score: 14, expectedMod: 2 },
    { score: 15, expectedMod: 2 },
    { score: 16, expectedMod: 3 },
    { score: 18, expectedMod: 4 },
    { score: 20, expectedMod: 5 },
  ];

  testCases.forEach(({ score, expectedMod }) => {
    const mod = getD20Modifier(score);
    assert.equal(mod, expectedMod, `Score ${score} must yield modifier ${expectedMod}, got ${mod}`);
  });

  assert.equal(formatD20Modifier(2), '+2');
  assert.equal(formatD20Modifier(0), '+0');
  assert.equal(formatD20Modifier(-1), '-1');

  // Verify Attribute Point Budget & Limits
  assert.equal(ATTRIBUTE_POINT_BUDGET, 4);
  assert.equal(MAX_ALLOC_PER_STAT, 3);
  assert.equal(ATTRIBUTE_METADATA.length, 4);
});

test('10. Specialization Roadmap & Detailed Profiles: all 6 subclasses preserved, compatible filtering, and comparison metrics', () => {
  assert.equal(SPECIALIZATION_ROADMAP.length, 6, 'Must preserve all 6 specialization identities');
  const expectedSubclasses = [
    'dawn_warden',
    'vengeance_knight',
    'crimson_savant',
    'rift_chronomancer',
    'briar_stalker',
    'ironbough_sentinel',
  ];

  expectedSubclasses.forEach((subId) => {
    const spec = SPECIALIZATION_ROADMAP.find((s) => s.id === subId);
    assert.ok(spec, `Specialization ${subId} must exist in roadmap`);
    assert.equal(spec.unlockLevel, 3, 'Must unlock at Level 3');
    assert.ok(CHARACTER_SUBCLASSES[spec.id], 'Must correspond to CHARACTER_SUBCLASSES');

    // Test Detailed Profile
    const detailed = SPECIALIZATION_PROFILES[subId as keyof typeof SPECIALIZATION_PROFILES];
    assert.ok(detailed, `Detailed profile must exist for ${subId}`);
    assert.equal(detailed.availabilityState, 'Unlocks at Level 3 · Future Path');
    assert.ok(detailed.loreDescription.length > 20);
    assert.ok(detailed.combatIdentity.length > 0);
    assert.ok(detailed.tacticalRole.length > 0);
    assert.ok(detailed.equipmentCompatibility.length >= 2);
    assert.ok(detailed.unlockRequirements.includes('Level 3'));

    // Signature Skill
    assert.ok(detailed.signatureSkill.name.length > 0);
    assert.ok(detailed.signatureSkill.apCost > 0);

    // Abilities Roadmap
    assert.equal(detailed.specializationAbilities.length, 4, `Subclass ${subId} must define 4 progression abilities`);

    // Comparison Metrics (without fake numerical stats)
    assert.ok(detailed.comparison.coreIdentity.length > 0);
    assert.ok(detailed.comparison.combatRole.length > 0);
    assert.ok(detailed.comparison.skillThemes.length >= 2);
    assert.ok(detailed.comparison.defensiveStrengths.length > 0);
    assert.ok(detailed.comparison.offensiveStrengths.length > 0);
    assert.ok(detailed.comparison.utilityStrengths.length > 0);
  });
});

test('11. Detailed Appearance Factory & Randomization: produces complete schema', () => {
  const defaultAppearance = createDefaultDetailedAppearance('half_elf');
  assert.equal(defaultAppearance.bodyPreset, 'athletic');
  assert.ok(defaultAppearance.height >= 0.85);
  assert.ok(defaultAppearance.facePresetId >= 1);
  assert.ok(defaultAppearance.hairStyleId.length > 0);
  assert.ok(defaultAppearance.skinToneHex.startsWith('#'));

  const randomized = randomizeDetailedAppearance('tiefling');
  assert.ok(randomized.facePresetId >= 1 && randomized.facePresetId <= 12);
  assert.ok(randomized.hornStyle.length > 0);
  assert.ok(randomized.hornColor.startsWith('#'));
  assert.ok(randomized.hairStyleId.length > 0);
});

test('12. Full Save/Load Persistence Round-Trip: captures complete character configuration', () => {
  const defaultBuild = createDefaultCharacterBuild();
  const detailedAppearance = createDefaultDetailedAppearance('tiefling');

  const config: PersistentCharacterConfiguration = {
    character_name: 'Mordecai Ashveil',
    race: 'tiefling',
    appearance: detailedAppearance,
    detailedAppearance,
    class: 'warrior',
    background: 'the_soldier',
    personality: 'defiant',
    voice: 'weathered_veteran',
    attributes: { str: 14, dex: 12, int: 10, cha: 12 },
    starting_equipment: ['Bastion Greatsword', 'Tempered Half-Plate'],
    starting_abilities: [{ name: 'Sunblade Cleave', summary: 'Cleave arc' }],
  };

  // Simulate JSON serialize & deserialize (Save & Load)
  const serialized = JSON.stringify(config);
  const deserialized: PersistentCharacterConfiguration = JSON.parse(serialized);

  assert.equal(deserialized.character_name, config.character_name);
  assert.equal(deserialized.race, config.race);
  assert.equal(deserialized.class, config.class);
  assert.equal(deserialized.background, config.background);
  assert.equal(deserialized.personality, config.personality);
  assert.equal(deserialized.voice, config.voice);
  assert.equal(deserialized.attributes.str, 14);
  assert.equal(deserialized.detailedAppearance?.hornStyle, detailedAppearance.hornStyle);
  assert.equal(deserialized.detailedAppearance?.facePresetId, detailedAppearance.facePresetId);
  assert.equal(deserialized.detailedAppearance?.hairStyleId, detailedAppearance.hairStyleId);
});

test('13. Game Entry Integration: character creation build applies cleanly to combat party and Gloamrest engine', () => {
  const build = {
    commanderName: 'Cassian Thorne',
    raceId: 'astral_human' as CharacterRaceId,
    classId: 'paladin' as const,
    subclassId: 'vengeance_knight' as const,
    allocatedStats: { str: 2, dex: 1, int: 0, cha: 1 },
    backgroundId: 'the_soldier',
    personalityId: 'pragmatic',
    voiceId: 'weathered_veteran',
  };

  const preview = computeCharacterBuildPreview(build);
  assert.equal(preview.commanderName, 'Cassian Thorne');
  assert.ok(preview.stats.str >= 12);
  assert.ok(preview.maxHp > 20);

  // Initialize Gloamrest State
  const initialGloamrest = createInitialGloamrestState(build);
  assert.ok(initialGloamrest, 'Gloamrest initial state must be initialized');
  assert.equal(initialGloamrest.currentSceneId, 'exterior');
  assert.ok(initialGloamrest.discoveredDistricts.includes('hearth_square'));
  assert.equal(initialGloamrest.activeTrackedQuestId, 'mq01_stranger_at_gloamrest');

  // Verify Party Unit Application
  const rawUnits = createEncounterUnits(0, createInitialWorldState());
  const rawRels = createInitialRelationships();

  const applied = applyCharacterBuildToParty(rawUnits, rawRels, build);
  const commander = applied.units.find((u) => u.id === 'seraphina')!;
  assert.equal(commander.name, 'Cassian Thorne');
  assert.equal(commander.hp, preview.maxHp);
  assert.equal(commander.armorClass, preview.armorClass);
  assert.equal(commander.moveRange, preview.moveRange);
});

test('14. Subclass Selection Screen Compatibility: Rogue has 1 centered option; Mage, Paladin, Warrior, Ranger have multiple compatible paths', () => {
  // Rogue has exactly 1 valid specialization -> centered layout
  const rogueSpecs = getCompatibleSpecializations('rogue');
  assert.equal(rogueSpecs.length, 1, 'Rogue must have exactly 1 compatible specialization');
  assert.equal(rogueSpecs[0].id, 'briar_stalker', 'Rogue specialization must be briar_stalker');

  // Mage has exactly 2 valid specializations -> 2-column layout
  const mageSpecs = getCompatibleSpecializations('mage');
  assert.equal(mageSpecs.length, 2, 'Mage must have 2 compatible specializations');
  assert.deepEqual(
    mageSpecs.map((s) => s.id).sort(),
    ['crimson_savant', 'rift_chronomancer'].sort()
  );

  // Paladin has 2 valid specializations -> 2-column layout
  const paladinSpecs = getCompatibleSpecializations('paladin');
  assert.equal(paladinSpecs.length, 2, 'Paladin must have 2 compatible specializations');
  assert.deepEqual(
    paladinSpecs.map((s) => s.id).sort(),
    ['dawn_warden', 'vengeance_knight'].sort()
  );

  // Warrior has 2 valid specializations -> 2-column layout
  const warriorSpecs = getCompatibleSpecializations('warrior');
  assert.equal(warriorSpecs.length, 2, 'Warrior must have 2 compatible specializations');
  assert.deepEqual(
    warriorSpecs.map((s) => s.id).sort(),
    ['ironbough_sentinel', 'vengeance_knight'].sort()
  );

  // Ranger has 2 valid specializations -> 2-column layout
  const rangerSpecs = getCompatibleSpecializations('ranger');
  assert.equal(rangerSpecs.length, 2, 'Ranger must have 2 compatible specializations');
  assert.deepEqual(
    rangerSpecs.map((s) => s.id).sort(),
    ['briar_stalker', 'ironbough_sentinel'].sort()
  );
});
