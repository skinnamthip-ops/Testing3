import { CharacterClassId } from './rules';

export type ItemRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

export type ItemCategory =
  | 'weapon'
  | 'armor'
  | 'shield'
  | 'accessory'
  | 'consumable'
  | 'ingredient'
  | 'material'
  | 'tool'
  | 'quest';

export type EquipmentSlot = 'weapon' | 'armor' | 'shield' | 'accessory';

export interface ItemStats {
  attackBonus?: number;
  damageBonus?: number;
  acBonus?: number;
  maxHpBonus?: number;
  statBonus?: Partial<Record<'str' | 'dex' | 'int' | 'cha', number>>;
}

export interface ItemConsumableEffect {
  healHp?: number;
  grantTempHp?: number;
  cleanseDebuffs?: boolean;
  partyWide?: boolean;
}

export interface ItemDefinition {
  id: string;
  name: string;
  category: ItemCategory;
  rarity: ItemRarity;
  value: number; // Base gold value (buy price; sell price is ~55% rounded)
  iconKind:
    | 'sword'
    | 'bow'
    | 'staff'
    | 'dagger'
    | 'armor'
    | 'shield'
    | 'amulet'
    | 'potion_green'
    | 'potion_amber'
    | 'potion_blue'
    | 'food'
    | 'drink'
    | 'herb'
    | 'blight_herb'
    | 'ingot'
    | 'timber'
    | 'oil'
    | 'tool'
    | 'key'
    | 'book'
    | 'relic';
  description: string;
  loreNote?: string;
  equipSlot?: EquipmentSlot;
  preferredClasses?: CharacterClassId[];
  stats?: ItemStats;
  maxDurability?: number;
  consumableEffect?: ItemConsumableEffect;
  questItem?: boolean;
}

export const RARITY_COLOR_MAP: Record<ItemRarity, string> = {
  common: '#9CA3AF',
  uncommon: '#22C55E',
  rare: '#3B82F6',
  epic: '#A855F7',
  legendary: '#F59E0B',
};

/**
 * Canonical single-source Item Definitions for Dimraeth & Gloamrest.
 * Shared across Character Starting Gear, Loot Containers, Gathering Nodes, Quests, and all 5 Merchants.
 */
export const GLOAMREST_ITEMS: Record<string, ItemDefinition> = {
  // ==================== WEAPONS ====================
  ironroot_longsword: {
    id: 'ironroot_longsword',
    name: 'Ironroot Broadsword',
    category: 'weapon',
    rarity: 'common',
    value: 28,
    iconKind: 'sword',
    equipSlot: 'weapon',
    preferredClasses: ['paladin'],
    stats: { attackBonus: 1, damageBonus: 1 },
    maxDurability: 100,
    description: 'Balanced bog-iron broadsword forged on Garron Holt’s anvil.',
  },
  sunsteel_covenant_blade: {
    id: 'sunsteel_covenant_blade',
    name: 'Sunsteel Covenant Greatsword',
    category: 'weapon',
    rarity: 'rare',
    value: 68,
    iconKind: 'sword',
    equipSlot: 'weapon',
    preferredClasses: ['paladin'],
    stats: { attackBonus: 2, damageBonus: 2, statBonus: { cha: 1 } },
    maxDurability: 120,
    description:
      'Masterwork meteoric blade quenched in sacred spring water after Ironroot’s shipment was recovered.',
  },
  whisperwood_recurve: {
    id: 'whisperwood_recurve',
    name: 'Whisperwood Recurve Bow',
    category: 'weapon',
    rarity: 'common',
    value: 26,
    iconKind: 'bow',
    equipSlot: 'weapon',
    preferredClasses: ['warden'],
    stats: { attackBonus: 1, damageBonus: 1 },
    maxDurability: 100,
    description: 'Supple yew-and-ash hunting bow favored by Whispering Vale scouts.',
  },
  thornwatch_greatbow: {
    id: 'thornwatch_greatbow',
    name: 'Thornwatch Composite Greatbow',
    category: 'weapon',
    rarity: 'rare',
    value: 64,
    iconKind: 'bow',
    equipSlot: 'weapon',
    preferredClasses: ['warden'],
    stats: { attackBonus: 2, damageBonus: 2, statBonus: { dex: 1 } },
    maxDurability: 120,
    description:
      'Reinforced ironpine limbs tipped with Garron’s recovered meteoric arrowheads.',
  },
  ashwood_focus_staff: {
    id: 'ashwood_focus_staff',
    name: 'Ashwood Conduit Staff',
    category: 'weapon',
    rarity: 'common',
    value: 28,
    iconKind: 'staff',
    equipSlot: 'weapon',
    preferredClasses: ['arcanist'],
    stats: { attackBonus: 1, damageBonus: 1 },
    maxDurability: 100,
    description: 'Runed ashwood staff bound in copper wire to steady ley-line surges.',
  },
  starforged_spellrod: {
    id: 'starforged_spellrod',
    name: 'Starforged Astral Scepter',
    category: 'weapon',
    rarity: 'rare',
    value: 66,
    iconKind: 'staff',
    equipSlot: 'weapon',
    preferredClasses: ['arcanist'],
    stats: { attackBonus: 2, damageBonus: 2, statBonus: { int: 1 } },
    maxDurability: 120,
    description:
      'Spire-iron focus forged by Garron Holt from recovered star-metal ingots.',
  },
  manor_first_vigil_blade: {
    id: 'manor_first_vigil_blade',
    name: 'Oathblade of the First Vigil',
    category: 'weapon',
    rarity: 'epic',
    value: 95,
    iconKind: 'sword',
    equipSlot: 'weapon',
    stats: { attackBonus: 2, damageBonus: 3, maxHpBonus: 4 },
    maxDurability: 140,
    description:
      'Ancient silvered relic recovered from the hidden basement vault beneath the Abandoned Manor.',
    loreNote:
      'Engraved along the fuller: "Before the Crown of Echoes, we kept the spring."',
  },

  // ==================== ARMOR & SHIELDS ====================
  frontier_brigandine: {
    id: 'frontier_brigandine',
    name: 'Frontier Brigandine Coat',
    category: 'armor',
    rarity: 'common',
    value: 32,
    iconKind: 'armor',
    equipSlot: 'armor',
    stats: { acBonus: 1, maxHpBonus: 3 },
    maxDurability: 100,
    description: 'Riveted steel plates stitched inside oiled buckskin against forest claws.',
  },
  ironroot_halfplate: {
    id: 'ironroot_halfplate',
    name: 'Ironroot Vanguard Half-Plate',
    category: 'armor',
    rarity: 'rare',
    value: 72,
    iconKind: 'armor',
    equipSlot: 'armor',
    stats: { acBonus: 2, maxHpBonus: 6 },
    maxDurability: 130,
    description:
      'Fluted sanctum steel forged after restoring Ironroot Forge’s missing ingot supply.',
  },
  woven_ley_mantle: {
    id: 'woven_ley_mantle',
    name: 'Woven Ley-Ward Mantle',
    category: 'armor',
    rarity: 'uncommon',
    value: 42,
    iconKind: 'armor',
    equipSlot: 'armor',
    preferredClasses: ['arcanist', 'warden'],
    stats: { acBonus: 1, maxHpBonus: 4, statBonus: { int: 1 } },
    maxDurability: 100,
    description: 'Dark wool cloak threaded with silver warding filaments.',
  },
  oak_heater_shield: {
    id: 'oak_heater_shield',
    name: 'Ironbound Oak Shield',
    category: 'shield',
    rarity: 'common',
    value: 24,
    iconKind: 'shield',
    equipSlot: 'shield',
    stats: { acBonus: 1 },
    maxDurability: 100,
    description: 'Seasoned timber shield rimmed with forged iron.',
  },
  bastion_kite_shield: {
    id: 'bastion_kite_shield',
    name: 'Covenant Bastion Kite Shield',
    category: 'shield',
    rarity: 'uncommon',
    value: 48,
    iconKind: 'shield',
    equipSlot: 'shield',
    stats: { acBonus: 2, maxHpBonus: 3 },
    maxDurability: 120,
    description: 'Heavy kite shield bearing the pre-schism sun-and-well crest of Gloamrest.',
  },

  // ==================== ACCESSORIES & BACKGROUND TRINKETS ====================
  consecrated_censer: {
    id: 'consecrated_censer',
    name: 'Consecrated Incense Censer',
    category: 'accessory',
    rarity: 'uncommon',
    value: 30,
    iconKind: 'amulet',
    equipSlot: 'accessory',
    stats: { maxHpBonus: 3, statBonus: { cha: 1 } },
    description: 'Bronze reliquary censer carried by Sanctum Acolytes; steadies allied resolve.',
  },
  wayfinder_compass: {
    id: 'wayfinder_compass',
    name: 'Wayfinder’s Brass Compass',
    category: 'accessory',
    rarity: 'uncommon',
    value: 30,
    iconKind: 'amulet',
    equipSlot: 'accessory',
    stats: { attackBonus: 1, statBonus: { dex: 1 } },
    description: 'Borderland Outrider’s needle compass that trembles near Astral Rifts.',
  },
  obsidian_signet: {
    id: 'obsidian_signet',
    name: 'Sealed Obsidian Signet',
    category: 'accessory',
    rarity: 'uncommon',
    value: 30,
    iconKind: 'amulet',
    equipSlot: 'accessory',
    stats: { damageBonus: 1, statBonus: { int: 1 } },
    description: 'Planar signet ring worn by Ashen Exiles; warm to the touch.',
  },
  archivist_folio: {
    id: 'archivist_folio',
    name: 'Archivist’s Leather Folio',
    category: 'accessory',
    rarity: 'uncommon',
    value: 30,
    iconKind: 'book',
    equipSlot: 'accessory',
    stats: { maxHpBonus: 2, statBonus: { int: 1 } },
    description: 'Court Chronicler’s lineage ledger recording pre-shattering treaties.',
  },
  veyne_family_signet: {
    id: 'veyne_family_signet',
    name: 'Signet of the Well-Keepers',
    category: 'accessory',
    rarity: 'epic',
    value: 75,
    iconKind: 'relic',
    equipSlot: 'accessory',
    stats: { acBonus: 1, attackBonus: 1, maxHpBonus: 4 },
    description:
      'Forgotten crest ring of the ancient Veyne-Holloway wardens, sealed in the Abandoned Manor.',
  },

  // ==================== CONSUMABLES (HERBALIST & TAVERN) ====================
  silverleaf_healing_draught: {
    id: 'silverleaf_healing_draught',
    name: 'Silverleaf Healing Draught',
    category: 'consumable',
    rarity: 'common',
    value: 14,
    iconKind: 'potion_green',
    consumableEffect: { healHp: 12 },
    description: 'Elowen Mire’s signature herbal infusion. Restores 12 HP to a party member.',
  },
  sun_dew_purifying_tonic: {
    id: 'sun_dew_purifying_tonic',
    name: 'Sun-Dew Purifying Tonic',
    category: 'consumable',
    rarity: 'uncommon',
    value: 22,
    iconKind: 'potion_amber',
    consumableEffect: { healHp: 8, grantTempHp: 5, cleanseDebuffs: true },
    description: 'Restores 8 HP, grants +5 Temp HP, and purges lingering afflictions.',
  },
  astral_clarity_elixir: {
    id: 'astral_clarity_elixir',
    name: 'Astral Clarity Elixir',
    category: 'consumable',
    rarity: 'rare',
    value: 32,
    iconKind: 'potion_blue',
    consumableEffect: { healHp: 10, grantTempHp: 8 },
    description: 'Distilled spring-water tonic warding the mind (+10 HP & +8 Temp HP).',
  },
  stag_roast_meal: {
    id: 'stag_roast_meal',
    name: 'Wandering Stag Roast & Loaf',
    category: 'consumable',
    rarity: 'common',
    value: 9,
    iconKind: 'food',
    consumableEffect: { healHp: 8, partyWide: true },
    description: 'Hot venison stew and hearth bread from Mara Fenwick’s kitchen. Restores 8 HP to all companions.',
  },
  mulled_vale_cider: {
    id: 'mulled_vale_cider',
    name: 'Mulled Whispering Cider',
    category: 'consumable',
    rarity: 'common',
    value: 7,
    iconKind: 'drink',
    consumableEffect: { healHp: 4, grantTempHp: 4 },
    description: 'Spiced orchard cider steamed over the tavern hearth (+4 HP & +4 Temp HP).',
  },
  wayfarer_rations: {
    id: 'wayfarer_rations',
    name: 'Wayfarer Trail Rations',
    category: 'consumable',
    rarity: 'common',
    value: 10,
    iconKind: 'food',
    consumableEffect: { healHp: 6, partyWide: true },
    description: 'Smoked provisions wrapped in waxed linen for long marches (+6 Party HP).',
  },

  // ==================== GATHERED HERBS & INGREDIENTS ====================
  silverleaf_herb: {
    id: 'silverleaf_herb',
    name: 'Fresh Silverleaf Sprig',
    category: 'ingredient',
    rarity: 'common',
    value: 6,
    iconKind: 'herb',
    description: 'Pale-veined medicinal leaf thriving near cool stone and riverbanks.',
  },
  bitterroot_stalk: {
    id: 'bitterroot_stalk',
    name: 'Vale Bitterroot Stalk',
    category: 'ingredient',
    rarity: 'common',
    value: 7,
    iconKind: 'herb',
    description: 'Pungent root prized by Elowen Mire for fever and wound poultices.',
  },
  blight_nightshade: {
    id: 'blight_nightshade',
    name: 'Rift-Touched Nightshade',
    category: 'ingredient',
    rarity: 'rare',
    value: 18,
    iconKind: 'blight_herb',
    description:
      'Unnatural blue-veined bloom warped by subterranean Astral seepage beneath Gloamrest.',
  },

  // ==================== TOOLS, SUPPLIES & CARPENTRY MATERIALS ====================
  iron_lockpicks: {
    id: 'iron_lockpicks',
    name: 'Thieves’ Tempered Picks',
    category: 'tool',
    rarity: 'uncommon',
    value: 16,
    iconKind: 'tool',
    description: 'Fine steel tension hooks sold by Tessa Reed; aids in forcing rusted manor locks.',
  },
  lamp_oil_flask: {
    id: 'lamp_oil_flask',
    name: 'Refined Lamp Oil Flask',
    category: 'tool',
    rarity: 'common',
    value: 10,
    iconKind: 'oil',
    description: 'Clean-burning whale-and-pine oil used for lanterns and tactical braziers.',
  },
  artisan_repair_kit: {
    id: 'artisan_repair_kit',
    name: 'Smith’s Whetting & Repair Kit',
    category: 'tool',
    rarity: 'common',
    value: 15,
    iconKind: 'tool',
    description: 'Whetstone, rivets, and leather straps to restore equipment durability to 100%.',
  },
  seasoned_ironpine_plank: {
    id: 'seasoned_ironpine_plank',
    name: 'Seasoned Ironpine Planks',
    category: 'material',
    rarity: 'common',
    value: 8,
    iconKind: 'timber',
    description: 'Dense timber milled in Bram Alder’s yard for carts, shields, and gate barricades.',
  },
  pitch_resin_cask: {
    id: 'pitch_resin_cask',
    name: 'Sealed Pitch-Resin Cask',
    category: 'material',
    rarity: 'uncommon',
    value: 14,
    iconKind: 'oil',
    description: 'Waterproof pine pitch used by carpenters and town watch defenders.',
  },

  // ==================== QUEST & MYSTERY ITEMS ====================
  meteoric_ironroot_ingots: {
    id: 'meteoric_ironroot_ingots',
    name: 'Crate of Meteoric Ironroot Ingots',
    category: 'quest',
    rarity: 'rare',
    value: 45,
    iconKind: 'ingot',
    questItem: true,
    description:
      'Garron Holt’s missing shipment of star-flecked iron ore recovered from the ambushed roadside ravine.',
  },
  manor_rusted_key: {
    id: 'manor_rusted_key',
    name: 'Tarnished Veyne Manor Key',
    category: 'quest',
    rarity: 'uncommon',
    value: 0,
    iconKind: 'key',
    questItem: true,
    description:
      'Heavy iron ward-key bearing a worn stag-and-chalice crest; fits the front doors of the Abandoned Manor.',
  },
  well_rubbing_parchment: {
    id: 'well_rubbing_parchment',
    name: 'Charcoal Rubbing of the Well Sigil',
    category: 'quest',
    rarity: 'uncommon',
    value: 0,
    iconKind: 'book',
    questItem: true,
    description:
      'Tracing of the glowing pre-schism Covenant rune etched inside Hearth Square’s ancient stone well.',
  },
  sanctum_gate_writ: {
    id: 'sanctum_gate_writ',
    name: 'Elder’s Sealed Writ of Passage',
    category: 'quest',
    rarity: 'rare',
    value: 0,
    iconKind: 'book',
    questItem: true,
    description:
      'Aldric Veyne’s wax-sealed authorization instructing Sera Wren to unbar the road to the Sanctum of the Shattered Oath.',
  },
};

export interface MerchantStockEntry {
  itemId: string;
  quantity: number;
  unlockedByFlag?: string; // e.g. 'forge_shipment_restored'
}

export type MerchantId =
  | 'tavern_mara'
  | 'forge_garron'
  | 'herbalist_elowen'
  | 'general_tessa'
  | 'carpenter_bram';

export interface MerchantDefinition {
  id: MerchantId;
  npcId: string;
  shopName: string;
  ownerName: string;
  subtitle: string;
  districtName: string;
  supportsRepair?: boolean;
  supportsRoomRest?: boolean;
  roomRestCost?: number;
  initialStock: MerchantStockEntry[];
}

export const GLOAMREST_MERCHANTS: Record<MerchantId, MerchantDefinition> = {
  tavern_mara: {
    id: 'tavern_mara',
    npcId: 'mara_fenwick',
    shopName: 'The Wandering Stag Hearth & Taproom',
    ownerName: 'Mara Fenwick',
    subtitle: 'Hot Meals, Mulled Cider & Upstairs Guest Rooms',
    districtName: 'Wandering Stag Tavern',
    supportsRoomRest: true,
    roomRestCost: 10,
    initialStock: [
      { itemId: 'stag_roast_meal', quantity: 6 },
      { itemId: 'mulled_vale_cider', quantity: 8 },
      { itemId: 'wayfarer_rations', quantity: 5 },
    ],
  },
  forge_garron: {
    id: 'forge_garron',
    npcId: 'garron_holt',
    shopName: 'Ironroot Forge & Armory',
    ownerName: 'Garron Holt',
    subtitle: 'Tempered Blades, Vanguard Plate & Equipment Repair',
    districtName: 'Ironroot Forge',
    supportsRepair: true,
    initialStock: [
      { itemId: 'ironroot_longsword', quantity: 2 },
      { itemId: 'whisperwood_recurve', quantity: 2 },
      { itemId: 'ashwood_focus_staff', quantity: 2 },
      { itemId: 'frontier_brigandine', quantity: 2 },
      { itemId: 'oak_heater_shield', quantity: 3 },
      { itemId: 'artisan_repair_kit', quantity: 4 },
      // Unlocked once Main Quest 02 ("The Trouble at Ironroot") completes!
      {
        itemId: 'sunsteel_covenant_blade',
        quantity: 1,
        unlockedByFlag: 'forge_shipment_restored',
      },
      {
        itemId: 'thornwatch_greatbow',
        quantity: 1,
        unlockedByFlag: 'forge_shipment_restored',
      },
      {
        itemId: 'starforged_spellrod',
        quantity: 1,
        unlockedByFlag: 'forge_shipment_restored',
      },
      {
        itemId: 'ironroot_halfplate',
        quantity: 1,
        unlockedByFlag: 'forge_shipment_restored',
      },
      {
        itemId: 'bastion_kite_shield',
        quantity: 2,
        unlockedByFlag: 'forge_shipment_restored',
      },
    ],
  },
  herbalist_elowen: {
    id: 'herbalist_elowen',
    npcId: 'elowen_mire',
    shopName: 'The Green Vessel Apothecary',
    ownerName: 'Elowen Mire',
    subtitle: 'Botanical Tinctures, Salves & Gathered Vale Herbs',
    districtName: 'The Green Vessel',
    initialStock: [
      { itemId: 'silverleaf_healing_draught', quantity: 5 },
      { itemId: 'sun_dew_purifying_tonic', quantity: 3 },
      { itemId: 'astral_clarity_elixir', quantity: 2 },
      { itemId: 'silverleaf_herb', quantity: 3 },
      { itemId: 'bitterroot_stalk', quantity: 3 },
    ],
  },
  general_tessa: {
    id: 'general_tessa',
    npcId: 'tessa_reed',
    shopName: 'Reed’s Sundries & Provision Stall',
    ownerName: 'Tessa Reed',
    subtitle: 'Travel Gear, Lockpicks, Lantern Oil & Field Tools',
    districtName: 'Hearth Square',
    initialStock: [
      { itemId: 'wayfarer_rations', quantity: 6 },
      { itemId: 'iron_lockpicks', quantity: 4 },
      { itemId: 'lamp_oil_flask', quantity: 5 },
      { itemId: 'woven_ley_mantle', quantity: 1 },
      { itemId: 'artisan_repair_kit', quantity: 3 },
    ],
  },
  carpenter_bram: {
    id: 'carpenter_bram',
    npcId: 'bram_alder',
    shopName: 'Alder’s Timber & Joinery Yard',
    ownerName: 'Bram Alder',
    subtitle: 'Seasoned Ironpine, Barricade Timber & Pitch Casks',
    districtName: 'Timber Yard',
    initialStock: [
      { itemId: 'seasoned_ironpine_plank', quantity: 10 },
      { itemId: 'pitch_resin_cask', quantity: 4 },
      { itemId: 'oak_heater_shield', quantity: 2 },
      { itemId: 'artisan_repair_kit', quantity: 2 },
    ],
  },
};

// ============================================================================
// QUEST DEFINITIONS (6 Core Opening Quests + 1 Optional Manor Investigation)
// ============================================================================

export type QuestId =
  | 'mq01_stranger_at_gloamrest'
  | 'mq02_trouble_at_ironroot'
  | 'sq01_bitter_remedy'
  | 'mq03_shadows_beyond_gate'
  | 'sq02_echoes_beneath_well'
  | 'mq04_road_to_whispering_vale'
  | 'opt01_manor_of_shattered_vows';

export type QuestStatus = 'not_started' | 'active' | 'completed';

export interface QuestStepDefinition {
  id: string;
  label: string;
  optional?: boolean;
  targetDistrictId?: string;
}

export interface QuestDefinition {
  id: QuestId;
  code: string;
  title: string;
  kind: 'main' | 'side' | 'exploration';
  giverName: string;
  summary: string;
  journalLore: string;
  teachesSystems: string[];
  steps: QuestStepDefinition[];
  rewards: {
    gold: number;
    items?: { itemId: string; quantity: number }[];
    unlockNote?: string;
  };
}

export const GLOAMREST_QUESTS: Record<QuestId, QuestDefinition> = {
  mq01_stranger_at_gloamrest: {
    id: 'mq01_stranger_at_gloamrest',
    code: 'MAIN QUEST 01',
    title: 'A Stranger at Gloamrest',
    kind: 'main',
    giverName: 'Aldric Veyne',
    summary: 'Meet Town Elder Aldric Veyne and investigate the quiet unease settling over Gloamrest.',
    journalLore:
      'You have arrived at the secluded river settlement of Gloamrest on the edge of Whispering Vale. Though hearth-fires still warm the cobblestones, worried glances linger near the ancient stone well and the northern forest road.',
    teachesSystems: ['Settlement Navigation', 'Landmarks & Map', 'NPC Dialogue & D20 Checks'],
    steps: [
      {
        id: 'enter_town',
        label: 'Enter Gloamrest through the south pilgrim road',
        targetDistrictId: 'hearth_square',
      },
      {
        id: 'explore_square',
        label: 'Reach Hearth Square at the heart of the settlement',
        targetDistrictId: 'hearth_square',
      },
      {
        id: 'speak_aldric',
        label: 'Speak with Town Elder Aldric Veyne near the ancient well',
        targetDistrictId: 'hearth_square',
      },
      {
        id: 'visit_tavern',
        label: 'Enter the Wandering Stag Tavern',
        targetDistrictId: 'wandering_stag_tavern',
      },
      {
        id: 'learn_missing_travelers',
        label: 'Gather accounts of the missing travelers from Mara Fenwick or Lysa Thorn',
        targetDistrictId: 'wandering_stag_tavern',
      },
    ],
    rewards: {
      gold: 25,
      items: [{ itemId: 'wayfarer_rations', quantity: 1 }],
      unlockNote: 'Opens Gate Reconnaissance with Scout Sera Wren and Forge Aid with Garron Holt.',
    },
  },

  mq02_trouble_at_ironroot: {
    id: 'mq02_trouble_at_ironroot',
    code: 'MAIN QUEST 02',
    title: 'The Trouble at Ironroot',
    kind: 'main',
    giverName: 'Garron Holt',
    summary: 'Track down Garron Holt’s ambushed ore cart and recover Ironroot Forge’s missing ingots.',
    journalLore:
      'Blacksmith Garron Holt cannot temper blades for the Town Watch without his shipment of meteoric ironroot ore. The supply wagon limped back to Whispering Gate splintered, its heavy ingot chest dragged down the roadside ravine.',
    teachesSystems: ['Inventory', 'Loot Containers', 'Equipment Stats', 'Merchant Stock Unlocks'],
    steps: [
      {
        id: 'speak_garron',
        label: 'Speak with Blacksmith Garron Holt at Ironroot Forge',
        targetDistrictId: 'ironroot_forge',
      },
      {
        id: 'inspect_cart',
        label: 'Inspect the damaged supply cart staged near Whispering Gate',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'travel_roadside',
        label: 'Follow the wheel-ruts beyond Whispering Gate to the roadside ravine cache',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'recover_ingots',
        label: 'Recover the Crate of Meteoric Ironroot Ingots',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'return_garron',
        label: 'Deliver the recovered ingots to Garron Holt at Ironroot Forge',
        targetDistrictId: 'ironroot_forge',
      },
    ],
    rewards: {
      gold: 40,
      items: [{ itemId: 'artisan_repair_kit', quantity: 1 }],
      unlockNote: 'Unlocks Rare Sunsteel, Thornwatch & Starforged equipment at Ironroot Forge.',
    },
  },

  sq01_bitter_remedy: {
    id: 'sq01_bitter_remedy',
    code: 'SIDE QUEST 01',
    title: 'A Bitter Remedy',
    kind: 'side',
    giverName: 'Elowen Mire',
    summary: 'Gather fresh medicinal herbs around Gloamrest for Herbalist Elowen Mire.',
    journalLore:
      'Nightmares and chill fevers have afflicted several townsfolk living closest to the river and old well. Elowen Mire needs fresh Silverleaf and Vale Bitterroot—and suspects darker soil corruption near the walls.',
    teachesSystems: ['Resource Gathering', 'Environmental Herb Nodes', 'Consumable Potions'],
    steps: [
      {
        id: 'speak_elowen',
        label: 'Speak with Elowen Mire at The Green Vessel',
        targetDistrictId: 'green_vessel',
      },
      {
        id: 'gather_herbs',
        label: 'Harvest 3 medicinal herbs (Silverleaf or Bitterroot) around town',
        targetDistrictId: 'green_vessel',
      },
      {
        id: 'inspect_blight_herb',
        label: '(Optional) Discover the Rift-Touched Nightshade growing by the shaded stones',
        optional: true,
        targetDistrictId: 'abandoned_manor',
      },
      {
        id: 'deliver_herbs',
        label: 'Bring the gathered herbs back to Elowen Mire',
        targetDistrictId: 'green_vessel',
      },
    ],
    rewards: {
      gold: 20,
      items: [
        { itemId: 'silverleaf_healing_draught', quantity: 2 },
        { itemId: 'sun_dew_purifying_tonic', quantity: 1 },
      ],
      unlockNote: 'Brewed healing draughts added to your pack for wilderness expeditions.',
    },
  },

  mq03_shadows_beyond_gate: {
    id: 'mq03_shadows_beyond_gate',
    code: 'MAIN QUEST 03',
    title: 'Shadows Beyond the Gate',
    kind: 'main',
    giverName: 'Sera Wren',
    summary: 'Venture beyond Whispering Gate, trace the vanished travelers, and survive the ambush.',
    journalLore:
      'Scout Sera Wren has found scorched Covenant waymarkers and unnatural tracks just beyond the stone bridge of Whispering Gate. Something organized—and touched by the Astral Rift—is hunting the forest road.',
    teachesSystems: [
      'Initiative Order',
      'Action Points (AP)',
      'Grid Movement',
      'Skill Targeting',
      'Enemy Telegraphs',
      'Environmental Oil & Runestone Tactics',
    ],
    steps: [
      {
        id: 'speak_sera',
        label: 'Speak with Scout Sera Wren at Whispering Gate',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'inspect_forest_clues',
        label: 'Examine the clawed boundary marker & scorch tracks at Whispering Gate',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'leave_through_gate',
        label: 'Depart through Whispering Gate onto the Whispering Woods trail',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'win_outskirts_combat',
        label: 'Defeat the hostile vanguard in the Whispering Outskirts tactical encounter',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'return_to_town',
        label: 'Return safely to Gloamrest and witness the town’s heightened alert',
        targetDistrictId: 'hearth_square',
      },
    ],
    rewards: {
      gold: 55,
      items: [{ itemId: 'silverleaf_healing_draught', quantity: 1 }],
      unlockNote: 'Advances Gloamrest world-state and unlocks Main Quest 04.',
    },
  },

  sq02_echoes_beneath_well: {
    id: 'sq02_echoes_beneath_well',
    code: 'SIDE QUEST 02',
    title: 'Echoes Beneath the Well',
    kind: 'side',
    giverName: 'Brother Cael',
    summary: 'Uncover the meaning of the faint blue runes glowing beneath Gloamrest’s central well.',
    journalLore:
      'At nightfall a cold azure shimmer rises from the sacred spring beneath Hearth Square, carrying whispers older than the village itself. Brother Cael and Former Scholar Edrin Vale hold fragments of the truth.',
    teachesSystems: ['D20 Arcana & Insight Checks', 'Multi-NPC Investigation', 'World Lore'],
    steps: [
      {
        id: 'discover_well_symbol',
        label: 'Inspect the Ancient Stone Well in Hearth Square to spot the submerged sigil',
        targetDistrictId: 'hearth_square',
      },
      {
        id: 'speak_brother_cael',
        label: 'Consult Brother Cael at the Chapel of the Last Light',
        targetDistrictId: 'chapel_last_light',
      },
      {
        id: 'find_edrin_vale',
        label: 'Speak with Former Scholar Edrin Vale about the pre-schism inscriptions',
        targetDistrictId: 'chapel_last_light',
      },
      {
        id: 'pass_well_check',
        label: 'Decipher the subterranean conduit via an Arcana or Investigation check',
        targetDistrictId: 'hearth_square',
      },
      {
        id: 'confirm_oath_link',
        label: 'Reveal how Gloamrest’s spring connects directly to the Sanctum of the Shattered Oath',
        targetDistrictId: 'chapel_last_light',
      },
    ],
    rewards: {
      gold: 35,
      items: [{ itemId: 'astral_clarity_elixir', quantity: 1 }],
      unlockNote: 'Awakens ancient warding runes around the well and deepens Sanctum lore.',
    },
  },

  mq04_road_to_whispering_vale: {
    id: 'mq04_road_to_whispering_vale',
    code: 'MAIN QUEST 04',
    title: 'The Road to Whispering Vale',
    kind: 'main',
    giverName: 'Aldric Veyne',
    summary: 'Rally your companions, equip your party, and march for the Sanctum of the Shattered Oath.',
    journalLore:
      'The attacks on the forest road and the whispers beneath Gloamrest stem from the same fracture: the Silver Covenant’s broken seal inside the Sanctum of the Shattered Oath. Prepare your party before departing into deep Whispering Vale.',
    teachesSystems: ['Party Preparation', 'Companion Bonds', 'Act I Campaign Transition'],
    steps: [
      {
        id: 'report_to_aldric',
        label: 'Report your wilderness findings to Elder Aldric Veyne',
        targetDistrictId: 'hearth_square',
      },
      {
        id: 'prepare_equipment',
        label: 'Equip a weapon or armor piece (or stock provisions from a Gloamrest merchant)',
        targetDistrictId: 'ironroot_forge',
      },
      {
        id: 'speak_companions',
        label: 'Speak with Seraphina, Kaelen, or Thorne in Gloamrest (or at Camp)',
        targetDistrictId: 'wandering_stag_tavern',
      },
      {
        id: 'complete_preparations',
        label: 'Rest at the Tavern/Chapel or confirm expedition readiness with Scout Sera Wren',
        targetDistrictId: 'whispering_gate',
      },
      {
        id: 'depart_sanctum',
        label: 'March through Whispering Gate to the Sanctum of the Shattered Oath (Act I)',
        targetDistrictId: 'whispering_gate',
      },
    ],
    rewards: {
      gold: 60,
      unlockNote: 'Unlocks the main Act I campaign at the Sanctum of the Shattered Oath.',
    },
  },

  opt01_manor_of_shattered_vows: {
    id: 'opt01_manor_of_shattered_vows',
    code: 'EXPLORATION MYSTERY',
    title: 'The Forgotten Crest of Veyne Manor',
    kind: 'exploration',
    giverName: 'Old Nym / Exploration',
    summary: 'Unlock the overgrown Abandoned Manor and uncover the secret beneath its ruined library.',
    journalLore:
      'Behind broken iron railings on Gloamrest’s southeastern rise stands the shuttered ancestral manor. Villagers avoid its collapsed balcony, claiming a sealed vault beneath the library still guards a relic of the First Vigil.',
    teachesSystems: ['Locked Doors', 'Perception & Lockpicking', 'Environmental Puzzles', 'Secret Rooms'],
    steps: [
      {
        id: 'unlock_manor_door',
        label: 'Unlock the Abandoned Manor entrance (Garden Crypt Key or Lockpick Check)',
        targetDistrictId: 'abandoned_manor',
      },
      {
        id: 'search_library',
        label: 'Investigate the damaged library and forgotten family crest inside the manor',
        targetDistrictId: 'abandoned_manor',
      },
      {
        id: 'open_secret_basement',
        label: 'Trigger the hidden hearth-shelf mechanism to reveal the secret basement',
        targetDistrictId: 'abandoned_manor',
      },
      {
        id: 'claim_manor_relic',
        label: 'Open the First Vigil Reliquary Chest in the hidden basement',
        targetDistrictId: 'abandoned_manor',
      },
    ],
    rewards: {
      gold: 45,
      items: [
        { itemId: 'manor_first_vigil_blade', quantity: 1 },
        { itemId: 'veyne_family_signet', quantity: 1 },
      ],
      unlockNote: 'Recovers epic First Vigil heirlooms and reveals Elder Aldric’s lineage secret.',
    },
  },
};
