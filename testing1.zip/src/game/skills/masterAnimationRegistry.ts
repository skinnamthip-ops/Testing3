import { WARRIOR_ANIMATION_REGISTRY, WarriorSkillId } from '../warriorAnimations';
import { MAGE_ANIMATIONS } from './mageAnimations';
import { ROGUE_ANIMATIONS } from './rogueAnimations';
import { PALADIN_ANIMATIONS } from './paladinAnimations';
import { RANGER_ANIMATIONS } from './rangerAnimations';
import { SPECIALIZATION_ANIMATIONS } from './specializationAnimations';
import { AnimationPhase, RigTransform, SkillAnimationConfig } from './types';

/**
 * Unified Master Animation Registry for DIMRAETH: THE SHATTERED OATH
 * Consolidates all 96 distinct skill animations:
 * - 12 Warrior core skills
 * - 12 Mage core skills
 * - 12 Rogue core skills
 * - 12 Paladin core skills
 * - 12 Ranger core skills
 * - 36 Specialization skills (Dawn Warden, Vengeance Knight, Crimson Savant,
 *   Rift Chronomancer, Briar Stalker, Ironbough Sentinel)
 */
export const MASTER_ANIMATION_REGISTRY: Record<string, SkillAnimationConfig> = {
  ...WARRIOR_ANIMATION_REGISTRY,
  ...MAGE_ANIMATIONS,
  ...ROGUE_ANIMATIONS,
  ...PALADIN_ANIMATIONS,
  ...RANGER_ANIMATIONS,
  ...SPECIALIZATION_ANIMATIONS,
};

export function getMasterAnimationConfig(skillId: string): SkillAnimationConfig | undefined {
  return MASTER_ANIMATION_REGISTRY[skillId];
}

export function getMasterAnimationPhase(skillId: string, elapsedSeconds: number): AnimationPhase {
  const config = MASTER_ANIMATION_REGISTRY[skillId] || MASTER_ANIMATION_REGISTRY.sundering_strike;
  if (!config) return 'recovery';

  if (elapsedSeconds < config.anticipationDuration) {
    return 'anticipation';
  }
  if (Math.abs(elapsedSeconds - config.impactTiming) <= 0.05) {
    return 'impact';
  }
  const execEnd = config.anticipationDuration + config.executionDuration;
  if (elapsedSeconds < execEnd) {
    return 'execution';
  }
  const impactWindow = 0.08;
  if (elapsedSeconds < execEnd + impactWindow) {
    return 'impact';
  }
  return 'recovery';
}

export function isMasterAnimationFinished(skillId: string, elapsedSeconds: number): boolean {
  const config = MASTER_ANIMATION_REGISTRY[skillId] || MASTER_ANIMATION_REGISTRY.sundering_strike;
  if (!config) return true;
  return elapsedSeconds >= config.totalDuration;
}

export function sampleMasterRigTransform(
  skillId: string,
  elapsedSeconds: number,
  isMiss = false
): { transform: RigTransform; phase: AnimationPhase; isFinished: boolean } {
  const config = MASTER_ANIMATION_REGISTRY[skillId] || MASTER_ANIMATION_REGISTRY.sundering_strike;
  if (!config) {
    return {
      transform: {
        bodyPos: [0, 0, 0],
        bodyRot: [0, 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, 0, 0],
        weaponRot: [0, 0, 0],
      },
      phase: 'recovery',
      isFinished: true,
    };
  }

  const phase = getMasterAnimationPhase(skillId, elapsedSeconds);
  let progress = 0;

  if (phase === 'anticipation') {
    progress = Math.min(1, elapsedSeconds / config.anticipationDuration);
  } else if (phase === 'execution') {
    const elapsedInExec = elapsedSeconds - config.anticipationDuration;
    progress = Math.min(1, elapsedInExec / config.executionDuration);
  } else if (phase === 'impact') {
    const elapsedInExec = elapsedSeconds - config.anticipationDuration;
    progress = Math.min(1, elapsedInExec / (config.executionDuration + 0.08));
  } else {
    const recStart = config.anticipationDuration + config.executionDuration;
    const elapsedInRec = elapsedSeconds - recStart;
    progress = Math.min(1, elapsedInRec / Math.max(0.001, config.recoveryDuration));
  }

  const transform = config.samplePose(progress, phase, isMiss);
  const isFinished = elapsedSeconds >= config.totalDuration;

  return { transform, phase, isFinished };
}
