import { AnimationPhase, RigTransform, SkillAnimationConfig } from './types';

function easeOutQuad(t: number): number {
  return 1 - (1 - t) * (1 - t);
}
function easeInQuad(t: number): number {
  return t * t;
}
function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export const RANGER_ANIMATIONS: Record<string, SkillAnimationConfig> = {
  // 1. Precision Shot: Sideways bow draw and lethal release
  precision_shot: {
    skillId: 'precision_shot',
    name: 'Precision Shot',
    animationId: 'anim_ranger_precision_shot',
    anticipationDuration: 0.22,
    executionDuration: 0.18,
    impactTiming: 0.28,
    recoveryDuration: 0.26,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: true,
      colorHex: 0x84cc16,
      trailType: 'arrow_flight',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0x84cc16,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playPrecisionShot',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Draw tension committed upon full extension.',
    combatEventSync: 'Fires high-velocity piercing arrow; +3 to hit if unmoved.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, -0.08 * t],
          bodyRot: [0, -0.6 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.2 * t, 0.25 * t, -0.15 * t],
          weaponRot: [0.1 * t, -0.8 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missOffset = isMiss ? 0.25 : 0;
        return {
          bodyPos: [0, 0, lerp(-0.08, 0.12, t)],
          bodyRot: [0, lerp(-0.6, 0.15 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.2, 0.35, t), lerp(0.25, 0.2, t), lerp(-0.15, 0.85, t)],
          weaponRot: [0.1, lerp(-0.8, 0.3, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.15],
          bodyRot: [0, 0.18, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.38, 0.22, 0.92],
          weaponRot: [0.1, 0.35, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.15, 0, t)],
        bodyRot: [0, lerp(0.18, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.38, 0, t), lerp(0.22, 0, t), lerp(0.92, 0, t)],
        weaponRot: [lerp(0.1, 0, t), lerp(0.35, 0, t), 0],
      };
    },
  },

  // 2. Hunter's Instinct: Low tracking crouch touching terrain
  hunters_instinct: {
    skillId: 'hunters_instinct',
    name: 'Hunter\'s Instinct',
    animationId: 'anim_ranger_hunters_instinct',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: {
      enabled: false,
      colorHex: 0x22c55e,
      trailType: 'track_pulse',
      intensity: 0.6,
    },
    vfx: {
      particleCount: 18,
      particleColorHex: 0x22c55e,
      dustBurst: true,
      sparkBurst: false,
    },
    soundMethod: 'playHuntersInstinct',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Tracking focus engages immediately.',
    combatEventSync: 'Gains +2 Move and +10% Crit against prey below 50% HP.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.15 * t, 0],
          bodyRot: [0.3 * t, -0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.1 * t, -0.15 * t, 0.1 * t],
          weaponRot: [0.4 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.15, -0.35, t), 0.1 * t],
          bodyRot: [lerp(0.3, 0.48, t), lerp(-0.2, 0.1, t), 0],
          bodyScale: [1, 0.85, 1],
          weaponPos: [-0.1, lerp(-0.15, -0.38, t), lerp(0.1, 0.3, t)],
          weaponRot: [lerp(0.4, 0.7, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.38, 0.12],
          bodyRot: [0.52, 0.12, 0],
          bodyScale: [1.02, 0.82, 1.02],
          weaponPos: [-0.1, -0.42, 0.35],
          weaponRot: [0.75, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.38, 0, t), lerp(0.12, 0, t)],
        bodyRot: [lerp(0.52, 0, t), lerp(0.12, 0, t), 0],
        bodyScale: [lerp(1.02, 1, t), lerp(0.82, 1, t), lerp(1.02, 1, t)],
        weaponPos: [lerp(-0.1, 0, t), lerp(-0.42, 0, t), lerp(0.35, 0, t)],
        weaponRot: [lerp(0.75, 0, t), 0, 0],
      };
    },
  },

  // 3. Pinning Arrow: Heavy downward draw aimed at target feet
  pinning_arrow: {
    skillId: 'pinning_arrow',
    name: 'Pinning Arrow',
    animationId: 'anim_ranger_pinning_arrow',
    anticipationDuration: 0.22,
    executionDuration: 0.22,
    impactTiming: 0.32,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: {
      enabled: true,
      colorHex: 0x65a30d,
      trailType: 'heavy_bodkin',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0x65a30d,
      dustBurst: true,
      sparkBurst: true,
    },
    soundMethod: 'playPinningArrow',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Bodkin shaft fired at high tension.',
    combatEventSync: 'Deals physical damage and inflicts Rooted for 2 turns.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.05 * t, -0.08 * t],
          bodyRot: [0.15 * t, -0.45 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0.35 * t, -0.1 * t],
          weaponRot: [0.35 * t, -0.6 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missOffset = isMiss ? 0.25 : 0;
        return {
          bodyPos: [0, 0, lerp(-0.08, 0.12, t)],
          bodyRot: [0.15, lerp(-0.45, 0.2 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.32, t), lerp(0.35, -0.1, t), lerp(-0.1, 0.82, t)],
          weaponRot: [0.35, lerp(-0.6, 0.4, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.15],
          bodyRot: [0.18, 0.22, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.35, -0.15, 0.88],
          weaponRot: [0.4, 0.45, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.15, 0, t)],
        bodyRot: [lerp(0.18, 0, t), lerp(0.22, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.35, 0, t), lerp(-0.15, 0, t), lerp(0.88, 0, t)],
        weaponRot: [lerp(0.4, 0, t), lerp(0.45, 0, t), 0],
      };
    },
  },

  // 4. Hunting Ground: Raising bow overhead and signaling tactical killzone
  hunting_ground: {
    skillId: 'hunting_ground',
    name: 'Hunting Ground',
    animationId: 'anim_ranger_hunting_ground',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: {
      enabled: false,
      colorHex: 0x84cc16,
      trailType: 'killzone_flare',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0x84cc16,
      dustBurst: false,
      sparkBurst: true,
      shockwaveRadius: 2.4,
      allyPulse: true,
    },
    soundMethod: 'playHuntingGround',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Killzone marked across 3x3 grid.',
    combatEventSync: 'Designates 3x3 killzone: High Ground bonus (+2 Hit) & reveals stealth.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.08 * t, 0],
          bodyRot: [-0.15 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.5 * t, 0],
          weaponRot: [-0.2 * t, 0, 0.3 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.08, 0.18, t), 0],
          bodyRot: [lerp(-0.15, -0.28, t), 0, 0],
          bodyScale: [1, 1.03, 1],
          weaponPos: [lerp(0.1, 0.22, t), lerp(0.5, 0.85, t), 0.1 * t],
          weaponRot: [lerp(-0.2, 0.1, t), 0, lerp(0.3, 0.5, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.2, 0],
          bodyRot: [-0.3, 0, 0],
          bodyScale: [1.05, 1.05, 1.05],
          weaponPos: [0.25, 0.9, 0.12],
          weaponRot: [0.15, 0, 0.55],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.2, 0, t), 0],
        bodyRot: [lerp(-0.3, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.25, 0, t), lerp(0.9, 0, t), lerp(0.12, 0, t)],
        weaponRot: [lerp(0.15, 0, t), 0, lerp(0.55, 0, t)],
      };
    },
  },

  // 5. Ricochet Shot: Banking trick shot curved draw
  ricochet_shot: {
    skillId: 'ricochet_shot',
    name: 'Ricochet Shot',
    animationId: 'anim_ranger_ricochet_shot',
    anticipationDuration: 0.18,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.26,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: true,
      colorHex: 0xeab308,
      trailType: 'curved_ricochet',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0xeab308,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playRicochetShot',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Curved flight ricochets automatically upon strike.',
    combatEventSync: 'Hits primary target and chains to up to 2 adjacent enemies.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, -0.06 * t],
          bodyRot: [0.1 * t, -0.5 * t, 0.2 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0.2 * t, -0.15 * t],
          weaponRot: [0.2 * t, -0.7 * t, 0.3 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missOffset = isMiss ? 0.3 : 0;
        return {
          bodyPos: [0, 0, lerp(-0.06, 0.14, t)],
          bodyRot: [0.1, lerp(-0.5, 0.35 + missOffset, t), lerp(0.2, -0.2, t)],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.35, t), lerp(0.2, 0.18, t), lerp(-0.15, 0.85, t)],
          weaponRot: [0.2, lerp(-0.7, 0.5, t), lerp(0.3, -0.25, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.16],
          bodyRot: [0.12, 0.38, -0.22],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.38, 0.2, 0.9],
          weaponRot: [0.22, 0.55, -0.28],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.16, 0, t)],
        bodyRot: [lerp(0.12, 0, t), lerp(0.38, 0, t), lerp(-0.22, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.38, 0, t), lerp(0.2, 0, t), lerp(0.9, 0, t)],
        weaponRot: [lerp(0.22, 0, t), lerp(0.55, 0, t), lerp(-0.28, 0, t)],
      };
    },
  },

  // 6. Camouflage: Low crouch and foliage wrap
  camouflage: {
    skillId: 'camouflage',
    name: 'Camouflage',
    animationId: 'anim_ranger_camouflage',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.26,
    totalDuration: 0.68,
    weaponTrail: {
      enabled: false,
      colorHex: 0x15803d,
      trailType: 'foliage_cloak',
      intensity: 0.6,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0x15803d,
      dustBurst: false,
      sparkBurst: false,
    },
    soundMethod: 'playCamouflage',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Camouflage active while adjacent to obstacle.',
    combatEventSync: 'Cannot be targeted by ranged attacks while near cover.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.15 * t, 0],
          bodyRot: [0.25 * t, -0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.1 * t, -0.1 * t, 0.1 * t],
          weaponRot: [0.3 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.15, -0.32, t), 0],
          bodyRot: [lerp(0.25, 0.42, t), lerp(-0.2, -0.3, t), 0],
          bodyScale: [1, 0.85, 1],
          weaponPos: [-0.1, lerp(-0.1, -0.25, t), 0.15],
          weaponRot: [lerp(0.3, 0.6, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.35, 0],
          bodyRot: [0.45, -0.32, 0],
          bodyScale: [1.02, 0.82, 1.02],
          weaponPos: [-0.12, -0.28, 0.18],
          weaponRot: [0.65, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.35, 0, t), 0],
        bodyRot: [lerp(0.45, 0, t), lerp(-0.32, 0, t), 0],
        bodyScale: [lerp(1.02, 1, t), lerp(0.82, 1, t), lerp(1.02, 1, t)],
        weaponPos: [lerp(-0.12, 0, t), lerp(-0.28, 0, t), lerp(0.18, 0, t)],
        weaponRot: [lerp(0.65, 0, t), 0, 0],
      };
    },
  },

  // 7. Thornline: Throwing thorn cartridge forward that erupts into bramble wall
  thornline: {
    skillId: 'thornline',
    name: 'Thornline',
    animationId: 'anim_ranger_thornline',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.26,
    totalDuration: 0.68,
    weaponTrail: {
      enabled: true,
      colorHex: 0x16a34a,
      trailType: 'thorn_wall',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 26,
      particleColorHex: 0x16a34a,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 2.2,
    },
    soundMethod: 'playThornline',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Bramble wall sprouts permanently on tile row.',
    combatEventSync: 'Sprouts 3-tile razor bramble wall, damaging and rooting trespassers.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.1 * t, -0.05 * t],
          bodyRot: [0.2 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, -0.2 * t, 0.1 * t],
          weaponRot: [0.5 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.1, 0.05, t), lerp(-0.05, 0.2, t)],
          bodyRot: [lerp(0.2, 0.1, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, lerp(-0.2, 0.15, t), lerp(0.1, 0.75, t)],
          weaponRot: [lerp(0.5, 0.2, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.06, 0.22],
          bodyRot: [0.12, 0, 0],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0, 0.18, 0.8],
          weaponRot: [0.25, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.06, 0, t), lerp(0.22, 0, t)],
        bodyRot: [lerp(0.12, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, lerp(0.18, 0, t), lerp(0.8, 0, t)],
        weaponRot: [lerp(0.25, 0, t), 0, 0],
      };
    },
  },

  // 8. Beast Call: Two-finger whistle and forward commanding arm sweep
  beast_call: {
    skillId: 'beast_call',
    name: 'Beast Call',
    animationId: 'anim_ranger_beast_call',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: {
      enabled: false,
      colorHex: 0x4ade80,
      trailType: 'spirit_wolf',
      intensity: 0.75,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0x4ade80,
      dustBurst: true,
      sparkBurst: false,
      allyPulse: true,
    },
    soundMethod: 'playBeastCall',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Astral timber-wolf summoned at target location.',
    combatEventSync: 'Summons astral wolf companion to flank and attack.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.05 * t, 0],
          bodyRot: [-0.15 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0.3 * t, 0.1 * t],
          weaponRot: [-0.2 * t, 0, 0.4 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, 0.15 * t],
          bodyRot: [lerp(-0.15, 0.2, t), 0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.25, t), lerp(0.3, 0.2, t), lerp(0.1, 0.75, t)],
          weaponRot: [lerp(-0.2, 0.2, t), 0.3 * t, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.18],
          bodyRot: [0.22, 0.22, 0],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0.28, 0.22, 0.8],
          weaponRot: [0.25, 0.32, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.18, 0, t)],
        bodyRot: [lerp(0.22, 0, t), lerp(0.22, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.28, 0, t), lerp(0.22, 0, t), lerp(0.8, 0, t)],
        weaponRot: [lerp(0.25, 0, t), lerp(0.32, 0, t), 0],
      };
    },
  },

  // 9. Windrunner: High-speed sprint stride with wind slipstream
  windrunner: {
    skillId: 'windrunner',
    name: 'Windrunner',
    animationId: 'anim_ranger_windrunner',
    anticipationDuration: 0.14,
    executionDuration: 0.24,
    impactTiming: 0.26,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: {
      enabled: true,
      colorHex: 0x38bdf8,
      trailType: 'wind_slipstream',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0x38bdf8,
      dustBurst: true,
      sparkBurst: false,
    },
    soundMethod: 'playWindrunner',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'rush_forward',
    cancellationRules: 'Kinetic momentum converts to bonus damage.',
    combatEventSync: 'For every 2 tiles moved, next arrow deals +2 damage.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, -0.15 * t],
          bodyRot: [0.3 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.1 * t, 0.1 * t, -0.2 * t],
          weaponRot: [0.4 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, lerp(-0.15, 0.45, t)],
          bodyRot: [0.3, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.15 * t, lerp(-0.2, 0.65, t)],
          weaponRot: [0.3, 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.48],
          bodyRot: [0.32, 0, 0],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0.12, 0.18, 0.7],
          weaponRot: [0.32, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.48, 0, t)],
        bodyRot: [lerp(0.32, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.12, 0, t), lerp(0.18, 0, t), lerp(0.7, 0, t)],
        weaponRot: [lerp(0.32, 0, t), 0, 0],
      };
    },
  },

  // 10. Deadfall Trap: Pulling pin on counterweight mechanism
  deadfall_trap: {
    skillId: 'deadfall_trap',
    name: 'Deadfall Trap',
    animationId: 'anim_ranger_deadfall_trap',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: {
      enabled: false,
      colorHex: 0x78716c,
      trailType: 'deadfall_rig',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0x78716c,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.8,
    },
    soundMethod: 'playDeadfallTrap',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Deadfall counterweight armed upon pin pull.',
    combatEventSync: 'Deals 16-24 crushing damage and permanently sunders armor by -3.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.15 * t, 0.05 * t],
          bodyRot: [0.3 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, -0.25 * t, 0.2 * t],
          weaponRot: [0.6 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(-0.15, -0.38, t), lerp(0.05, 0.2, t)],
          bodyRot: [lerp(0.3, 0.5, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, lerp(-0.25, -0.5, t), lerp(0.2, 0.5, t)],
          weaponRot: [lerp(0.6, 1.05, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.4, 0.22],
          bodyRot: [0.55, 0, 0],
          bodyScale: [1.06, 0.88, 1.06],
          weaponPos: [0, -0.52, 0.55],
          weaponRot: [1.1, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.4, 0, t), lerp(0.22, 0, t)],
        bodyRot: [lerp(0.55, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, lerp(-0.52, 0, t), lerp(0.55, 0, t)],
        weaponRot: [lerp(1.1, 0, t), 0, 0],
      };
    },
  },

  // 11. Marked Prey: Extreme long-range tracer dart with green glowing marker
  marked_prey: {
    skillId: 'marked_prey',
    name: 'Marked Prey',
    animationId: 'anim_ranger_marked_prey',
    anticipationDuration: 0.2,
    executionDuration: 0.22,
    impactTiming: 0.3,
    recoveryDuration: 0.24,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: true,
      colorHex: 0x4ade80,
      trailType: 'tracer_dart',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0x4ade80,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playMarkedPrey',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Tracer paints target across 6 tiles.',
    combatEventSync: 'Target takes +4 damage from all attacks and loses cover bonuses.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, -0.06 * t],
          bodyRot: [0, -0.45 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0.25 * t, -0.1 * t],
          weaponRot: [0.1 * t, -0.6 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, lerp(-0.06, 0.12, t)],
          bodyRot: [0, lerp(-0.45, 0.2, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.35, t), lerp(0.25, 0.22, t), lerp(-0.1, 0.85, t)],
          weaponRot: [0.1, lerp(-0.6, 0.35, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.15],
          bodyRot: [0, 0.24, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.38, 0.24, 0.9],
          weaponRot: [0.12, 0.38, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.15, 0, t)],
        bodyRot: [0, lerp(0.24, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.38, 0, t), lerp(0.24, 0, t), lerp(0.9, 0, t)],
        weaponRot: [lerp(0.12, 0, t), lerp(0.38, 0, t), 0],
      };
    },
  },

  // 12. Nature's Dominion: Plunging stave into bedrock, colossal forest root eruption
  natures_dominion: {
    skillId: 'natures_dominion',
    name: 'Nature\'s Dominion',
    animationId: 'anim_ranger_natures_dominion',
    anticipationDuration: 0.28,
    executionDuration: 0.38,
    impactTiming: 0.54,
    recoveryDuration: 0.42,
    totalDuration: 1.08,
    weaponTrail: {
      enabled: true,
      colorHex: 0x15803d,
      trailType: 'primordial_roots',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 45,
      particleColorHex: 0x15803d,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 3.4,
      allyPulse: true,
    },
    soundMethod: 'playNaturesDominion',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Colossal primordial root eruption is unstoppable.',
    combatEventSync: 'Roots all enemies, deals 24-34 Nature damage, grants party +3 Move.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.15 * t, -0.15 * t],
          bodyRot: [-0.35 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, 0.7 * t, -0.2 * t],
          weaponRot: [-0.8 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(0.15, -0.25, t), lerp(-0.15, 0.25, t)],
          bodyRot: [lerp(-0.35, 0.52, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, lerp(0.7, -0.45, t), lerp(-0.2, 0.75, t)],
          weaponRot: [lerp(-0.8, 1.2, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.28, 0.3],
          bodyRot: [0.58, 0, 0],
          bodyScale: [1.12, 0.88, 1.12],
          weaponPos: [0, -0.5, 0.82],
          weaponRot: [1.25, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.28, 0, t), lerp(0.3, 0, t)],
        bodyRot: [lerp(0.58, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, lerp(-0.5, 0, t), lerp(0.82, 0, t)],
        weaponRot: [lerp(1.25, 0, t), 0, 0],
      };
    },
  },
};
