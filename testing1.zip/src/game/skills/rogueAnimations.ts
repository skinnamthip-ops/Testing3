import { AnimationPhase, RigTransform, SkillAnimationConfig } from './types';

function easeOutQuad(t: number): number {
  return 1 - (1 - t) * (1 - t);
}
function easeInQuad(t: number): number {
  return t * t;
}
function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export const ROGUE_ANIMATIONS: Record<string, SkillAnimationConfig> = {
  // 1. Quickdraw: Instant snap-fire hip draw dart
  quickdraw: {
    skillId: 'quickdraw',
    name: 'Quickdraw',
    animationId: 'anim_rogue_quickdraw',
    anticipationDuration: 0.1,
    executionDuration: 0.16,
    impactTiming: 0.18,
    recoveryDuration: 0.22,
    totalDuration: 0.48,
    weaponTrail: {
      enabled: true,
      colorHex: 0xfacc15,
      trailType: 'snap_flick',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 12,
      particleColorHex: 0xfacc15,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playQuickdraw',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Sub-second snapshot cannot be interrupted.',
    combatEventSync: 'Releases high-velocity throwing dart on impact timing.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.05 * t, -0.05 * t],
          bodyRot: [0.1 * t, -0.3 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, -0.15 * t, -0.2 * t],
          weaponRot: [0.4 * t, -0.3 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missOffset = isMiss ? 0.25 : 0;
        return {
          bodyPos: [0, lerp(-0.05, 0.02, t), lerp(-0.05, 0.15, t)],
          bodyRot: [lerp(0.1, 0.05, t), lerp(-0.3, 0.4 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.35, t), lerp(-0.15, 0.12, t), lerp(-0.2, 0.85, t)],
          weaponRot: [lerp(0.4, -0.25, t), lerp(-0.3, 0.6, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.02, 0.18],
          bodyRot: [0.05, 0.45, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.38, 0.14, 0.92],
          weaponRot: [-0.28, 0.65, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.02, 0, t), lerp(0.18, 0, t)],
        bodyRot: [lerp(0.05, 0, t), lerp(0.45, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.38, 0, t), lerp(0.14, 0, t), lerp(0.92, 0, t)],
        weaponRot: [lerp(-0.28, 0, t), lerp(0.65, 0, t), 0],
      };
    },
  },

  // 2. Shadow Veil: Low crouch drop and stealth cloaking
  shadow_veil: {
    skillId: 'shadow_veil',
    name: 'Shadow Veil',
    animationId: 'anim_rogue_shadow_veil',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: {
      enabled: false,
      colorHex: 0x475569,
      trailType: 'shadow_shroud',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0x334155,
      dustBurst: false,
      sparkBurst: false,
    },
    soundMethod: 'playShadowVeil',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Stealth state established at impact timing.',
    combatEventSync: 'Enters stealth state and primes sneak attack damage at impact.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.15 * t, 0],
          bodyRot: [0.25 * t, -0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.1 * t, -0.15 * t, 0.1 * t],
          weaponRot: [-0.5 * t, 0.3 * t, 0.8 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.15, -0.32, t), 0],
          bodyRot: [lerp(0.25, 0.45, t), lerp(-0.2, -0.35, t), 0],
          bodyScale: [lerp(1, 0.92, t), lerp(1, 0.82, t), lerp(1, 0.92, t)],
          weaponPos: [lerp(-0.1, -0.25, t), lerp(-0.15, -0.28, t), lerp(0.1, 0.15, t)],
          weaponRot: [lerp(-0.5, -0.9, t), lerp(0.3, 0.5, t), lerp(0.8, 1.4, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.35, 0],
          bodyRot: [0.48, -0.38, 0],
          bodyScale: [0.9, 0.8, 0.9],
          weaponPos: [-0.28, -0.3, 0.18],
          weaponRot: [-0.95, 0.55, 1.45],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.35, 0, t), 0],
        bodyRot: [lerp(0.48, 0, t), lerp(-0.38, 0, t), 0],
        bodyScale: [lerp(0.9, 1, t), lerp(0.8, 1, t), lerp(0.9, 1, t)],
        weaponPos: [lerp(-0.28, 0, t), lerp(-0.3, 0, t), lerp(0.18, 0, t)],
        weaponRot: [lerp(-0.95, 0, t), lerp(0.55, 0, t), lerp(1.45, 0, t)],
      };
    },
  },

  // 3. Mark for Death: Sinister forward dagger point branding quarry
  mark_for_death: {
    skillId: 'mark_for_death',
    name: 'Mark for Death',
    animationId: 'anim_rogue_mark_for_death',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: {
      enabled: true,
      colorHex: 0xef4444,
      trailType: 'blood_tracer',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 18,
      particleColorHex: 0xef4444,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playMarkForDeath',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Mark applies once target is singled out.',
    combatEventSync: 'Applies squad quarry vulnerability at impact.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.05 * t, -0.08 * t],
          bodyRot: [0.1 * t, -0.15 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.05 * t, 0.15 * t, -0.15 * t],
          weaponRot: [-0.4 * t, 0.2 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.05, 0.05, t), lerp(-0.08, 0.2, t)],
          bodyRot: [lerp(0.1, 0.18, t), lerp(-0.15, 0.2, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.05, 0.32, t), lerp(0.15, 0.25, t), lerp(-0.15, 0.88, t)],
          weaponRot: [lerp(-0.4, -0.1, t), lerp(0.2, 0.35, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.06, 0.22],
          bodyRot: [0.2, 0.22, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.35, 0.28, 0.95],
          weaponRot: [-0.12, 0.38, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.06, 0, t), lerp(0.22, 0, t)],
        bodyRot: [lerp(0.2, 0, t), lerp(0.22, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.35, 0, t), lerp(0.28, 0, t), lerp(0.95, 0, t)],
        weaponRot: [lerp(-0.12, 0, t), lerp(0.38, 0, t), 0],
      };
    },
  },

  // 4. Tripwire: Deep kneeling squat mechanism rigging
  tripwire: {
    skillId: 'tripwire',
    name: 'Tripwire',
    animationId: 'anim_rogue_tripwire',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: {
      enabled: false,
      colorHex: 0x94a3b8,
      trailType: 'wire_rig',
      intensity: 0.5,
    },
    vfx: {
      particleCount: 14,
      particleColorHex: 0x94a3b8,
      dustBurst: true,
      sparkBurst: true,
    },
    soundMethod: 'playTripwire',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Trap deployed upon peg strike.',
    combatEventSync: 'Places concealed tripwire hazard on target grid tile.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.2 * t, 0.05 * t],
          bodyRot: [0.35 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, -0.3 * t, 0.2 * t],
          weaponRot: [0.6 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(-0.2, -0.42, t), lerp(0.05, 0.18, t)],
          bodyRot: [lerp(0.35, 0.55, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, lerp(-0.3, -0.55, t), lerp(0.2, 0.45, t)],
          weaponRot: [lerp(0.6, 1.1, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.45, 0.2],
          bodyRot: [0.6, 0, 0],
          bodyScale: [1.05, 0.85, 1.05],
          weaponPos: [0, -0.58, 0.48],
          weaponRot: [1.15, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.45, 0, t), lerp(0.2, 0, t)],
        bodyRot: [lerp(0.6, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0, 0, t), lerp(-0.58, 0, t), lerp(0.48, 0, t)],
        weaponRot: [lerp(1.15, 0, t), 0, 0],
      };
    },
  },

  // 5. Smoke Escape: Throw smoke canister downward and back-vault
  smoke_escape: {
    skillId: 'smoke_escape',
    name: 'Smoke Escape',
    animationId: 'anim_rogue_smoke_escape',
    anticipationDuration: 0.14,
    executionDuration: 0.24,
    impactTiming: 0.28,
    recoveryDuration: 0.26,
    totalDuration: 0.64,
    weaponTrail: {
      enabled: false,
      colorHex: 0x64748b,
      trailType: 'smoke_blast',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 35,
      particleColorHex: 0x94a3b8,
      dustBurst: true,
      sparkBurst: false,
      shockwaveRadius: 2.0,
    },
    soundMethod: 'playSmokeEscape',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'leaping_stride',
    cancellationRules: 'Smoke bursts instantly, obscuring vision.',
    combatEventSync: 'Spawns smoke cloud and vaults rogue 2 tiles backward.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.15 * t, 0],
          bodyRot: [0.25 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, -0.3 * t, 0.2 * t],
          weaponRot: [0.8 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.15, 0.35, t), lerp(0, -0.65, t)],
          bodyRot: [lerp(0.25, -0.45, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, 0.1 * t, -0.2 * t],
          weaponRot: [-0.4 * t, 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.38, -0.72],
          bodyRot: [-0.5, 0, 0],
          bodyScale: [0.95, 1.1, 0.95],
          weaponPos: [0, 0.15, -0.25],
          weaponRot: [-0.45, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.38, 0, t), lerp(-0.72, 0, t)],
        bodyRot: [lerp(-0.5, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0, 0, t), lerp(0.15, 0, t), lerp(-0.25, 0, t)],
        weaponRot: [lerp(-0.45, 0, t), 0, 0],
      };
    },
  },

  // 6. Pickpocket: Low lunging sleight of hand snatch
  pickpocket: {
    skillId: 'pickpocket',
    name: 'Pickpocket',
    animationId: 'anim_rogue_pickpocket',
    anticipationDuration: 0.12,
    executionDuration: 0.18,
    impactTiming: 0.22,
    recoveryDuration: 0.22,
    totalDuration: 0.52,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'sleight_arc',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0xf59e0b,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playPickpocket',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'AP transfer resolves upon contact.',
    combatEventSync: 'Steals 1 AP from target enemy at impact.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, -0.05 * t],
          bodyRot: [0.15 * t, -0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0, -0.1 * t],
          weaponRot: [0.3 * t, -0.4 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.08, 0.05, t), lerp(-0.05, 0.3, t)],
          bodyRot: [lerp(0.15, 0.22, t), lerp(-0.2, 0.35, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.38, t), lerp(0, 0.15, t), lerp(-0.1, 0.8, t)],
          weaponRot: [lerp(0.3, -0.3, t), lerp(-0.4, 0.7, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.06, 0.32],
          bodyRot: [0.24, 0.38, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.4, 0.18, 0.85],
          weaponRot: [-0.35, 0.75, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.06, 0, t), lerp(0.32, 0, t)],
        bodyRot: [lerp(0.24, 0, t), lerp(0.38, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.4, 0, t), lerp(0.18, 0, t), lerp(0.85, 0, t)],
        weaponRot: [lerp(-0.35, 0, t), lerp(0.75, 0, t), 0],
      };
    },
  },

  // 7. False Opening: Relaxed high feint and lightning upward counter-riposte
  false_opening: {
    skillId: 'false_opening',
    name: 'False Opening',
    animationId: 'anim_rogue_false_opening',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.24,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: true,
      colorHex: 0x38bdf8,
      trailType: 'riposte_arc',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0x38bdf8,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playFalseOpening',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Bait stance primed for automatic dodge-riposte.',
    combatEventSync: 'Grants auto-dodge buff and counters attacker on impact.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.05 * t, -0.05 * t],
          bodyRot: [-0.15 * t, 0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.2 * t, 0.35 * t, 0.1 * t],
          weaponRot: [-0.3 * t, 0.4 * t, -0.4 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(0.05, -0.15, t), lerp(-0.05, 0.2, t)],
          bodyRot: [lerp(-0.15, 0.35, t), lerp(0.2, -0.3, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.2, 0.35, t), lerp(0.35, 0.1, t), lerp(0.1, 0.75, t)],
          weaponRot: [lerp(-0.3, 0.6, t), lerp(0.4, -0.5, t), lerp(-0.4, 0.3, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.16, 0.22],
          bodyRot: [0.38, -0.32, 0],
          bodyScale: [1.05, 0.95, 1.05],
          weaponPos: [0.38, 0.12, 0.82],
          weaponRot: [0.65, -0.55, 0.35],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.16, 0, t), lerp(0.22, 0, t)],
        bodyRot: [lerp(0.38, 0, t), lerp(-0.32, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.38, 0, t), lerp(0.12, 0, t), lerp(0.82, 0, t)],
        weaponRot: [lerp(0.65, 0, t), lerp(-0.55, 0, t), lerp(0.35, 0, t)],
      };
    },
  },

  // 8. Poisoned Edge: Scraping blade across toxic vial
  poisoned_edge: {
    skillId: 'poisoned_edge',
    name: 'Poisoned Edge',
    animationId: 'anim_rogue_poisoned_edge',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.24,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: true,
      colorHex: 0x22c55e,
      trailType: 'toxic_venom',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 18,
      particleColorHex: 0x22c55e,
      dustBurst: false,
      sparkBurst: false,
    },
    soundMethod: 'playPoisonedEdge',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Venom coats edge permanently until expended.',
    combatEventSync: 'Enchants next 2 melee attacks with nature damage & healing cut.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.05 * t, 0],
          bodyRot: [0.1 * t, -0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0.25 * t, 0.15 * t],
          weaponRot: [0.4 * t, -0.5 * t, 0.6 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.05, 0],
          bodyRot: [0.1, lerp(-0.2, 0.25, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.15, 0.25, t), lerp(0.25, 0.15, t), 0.15],
          weaponRot: [0.4, lerp(-0.5, 0.6, t), lerp(0.6, -0.3, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.05, 0],
          bodyRot: [0.1, 0.28, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.28, 0.14, 0.15],
          weaponRot: [0.4, 0.65, -0.35],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.05, 0, t), 0],
        bodyRot: [lerp(0.1, 0, t), lerp(0.28, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.28, 0, t), lerp(0.14, 0, t), lerp(0.15, 0, t)],
        weaponRot: [lerp(0.4, 0, t), lerp(0.65, 0, t), lerp(-0.35, 0, t)],
      };
    },
  },

  // 9. Evasive Roll: Full forward athletic ground tumble
  evasive_roll: {
    skillId: 'evasive_roll',
    name: 'Evasive Roll',
    animationId: 'anim_rogue_evasive_roll',
    anticipationDuration: 0.12,
    executionDuration: 0.32,
    impactTiming: 0.26,
    recoveryDuration: 0.22,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: false,
      colorHex: 0x94a3b8,
      trailType: 'tumble_dust',
      intensity: 0.6,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0xa8a29e,
      dustBurst: true,
      sparkBurst: false,
    },
    soundMethod: 'playEvasiveRoll',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'tactical_tumble',
    cancellationRules: 'Invulnerable frames during roll rotation.',
    combatEventSync: 'Tumbles across 3 tiles and gains +3 AC (Warded).',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.2 * t, 0.1 * t],
          bodyRot: [0.6 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, -0.2 * t, 0.1 * t],
          weaponRot: [0.8 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        // Full 360 degree pitch tumble
        return {
          bodyPos: [0, lerp(-0.35, -0.1, t), lerp(0.1, 0.8, t)],
          bodyRot: [lerp(0.6, 6.28, t), 0, 0],
          bodyScale: [0.85, 0.85, 0.85],
          weaponPos: [0, -0.1, 0],
          weaponRot: [lerp(0.8, 6.28, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.15, 0.85],
          bodyRot: [0.2, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1, 0.1, 0.2],
          weaponRot: [0.2, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.15, 0, t), lerp(0.85, 0, t)],
        bodyRot: [lerp(0.2, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.1, 0, t), lerp(0.1, 0, t), lerp(0.2, 0, t)],
        weaponRot: [lerp(0.2, 0, t), 0, 0],
      };
    },
  },

  // 10. Ambush Protocol: High velocity shadow dash and neck-height dual slice
  ambush_protocol: {
    skillId: 'ambush_protocol',
    name: 'Ambush Protocol',
    animationId: 'anim_rogue_ambush_protocol',
    anticipationDuration: 0.14,
    executionDuration: 0.22,
    impactTiming: 0.26,
    recoveryDuration: 0.24,
    totalDuration: 0.6,
    weaponTrail: {
      enabled: true,
      colorHex: 0xef4444,
      trailType: 'throat_slash',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 26,
      particleColorHex: 0xef4444,
      dustBurst: true,
      sparkBurst: true,
    },
    soundMethod: 'playAmbushProtocol',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'rush_forward',
    cancellationRules: 'High-speed execution strikes immediately.',
    combatEventSync: 'Penetrates 4 AC and refunds 1 AP from flank/stealth.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.1 * t, -0.15 * t],
          bodyRot: [0.25 * t, -0.4 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.2 * t, 0.1 * t, -0.2 * t],
          weaponRot: [-0.4 * t, -0.6 * t, 0.4 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missOffset = isMiss ? 0.3 : 0;
        return {
          bodyPos: [0, 0, lerp(-0.15, 0.45, t)],
          bodyRot: [lerp(0.25, 0.15, t), lerp(-0.4, 0.7 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.2, 0.55, t), lerp(0.1, 0.25, t), lerp(-0.2, 0.85, t)],
          weaponRot: [lerp(-0.4, 0.1, t), lerp(-0.6, 1.3, t), lerp(0.4, -0.5, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.48],
          bodyRot: [0.18, 0.75, 0],
          bodyScale: [1.05, 1.05, 1.05],
          weaponPos: [0.58, 0.28, 0.9],
          weaponRot: [0.12, 1.35, -0.55],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.48, 0, t)],
        bodyRot: [lerp(0.18, 0, t), lerp(0.75, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.58, 0, t), lerp(0.28, 0, t), lerp(0.9, 0, t)],
        weaponRot: [lerp(0.12, 0, t), lerp(1.35, 0, t), lerp(-0.55, 0, t)],
      };
    },
  },

  // 11. Shadow Exchange: Inverted shadow spin grid position swap
  shadow_exchange: {
    skillId: 'shadow_exchange',
    name: 'Shadow Exchange',
    animationId: 'anim_rogue_shadow_exchange',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: {
      enabled: true,
      colorHex: 0xa855f7,
      trailType: 'shadow_vortex',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 28,
      particleColorHex: 0xa855f7,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playShadowExchange',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'phase_blink',
    cancellationRules: 'Positions swap instantly at apex.',
    combatEventSync: 'Swaps grid positions with target and inflicts Sundered.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.1 * t, 0],
          bodyRot: [0, 1.57 * t, 0],
          bodyScale: [lerp(1, 0.4, t), lerp(1, 1.3, t), lerp(1, 0.4, t)],
          weaponPos: [0, 0, 0],
          weaponRot: [0, 1.57 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.1, 0, t), lerp(0, 0.4, t)],
          bodyRot: [0, lerp(1.57, 3.14, t), 0],
          bodyScale: [lerp(0.4, 1.1, t), lerp(1.3, 0.9, t), lerp(0.4, 1.1, t)],
          weaponPos: [0.2 * t, 0.1 * t, 0.3 * t],
          weaponRot: [-0.3 * t, 0.5 * t, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.4],
          bodyRot: [0, 3.14, 0],
          bodyScale: [1.1, 0.95, 1.1],
          weaponPos: [0.25, 0.15, 0.4],
          weaponRot: [-0.35, 0.6, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.4, 0, t)],
        bodyRot: [0, lerp(3.14, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.25, 0, t), lerp(0.15, 0, t), lerp(0.4, 0, t)],
        weaponRot: [lerp(-0.35, 0, t), lerp(0.6, 0, t), 0],
      };
    },
  },

  // 12. Perfect Execution: Aerial cross-blade scissor dive decapitation
  perfect_execution: {
    skillId: 'perfect_execution',
    name: 'Perfect Execution',
    animationId: 'anim_rogue_perfect_execution',
    anticipationDuration: 0.22,
    executionDuration: 0.34,
    impactTiming: 0.46,
    recoveryDuration: 0.36,
    totalDuration: 0.92,
    weaponTrail: {
      enabled: true,
      colorHex: 0xdc2626,
      trailType: 'scissor_decapitate',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 40,
      particleColorHex: 0xdc2626,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 2.4,
    },
    soundMethod: 'playPerfectExecution',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'leaping_stride',
    cancellationRules: 'Lethal execution commitment is final.',
    combatEventSync: 'Deals 28-42 damage, executes foes below 35% HP, resets cooldowns.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.25 * t, -0.2 * t],
          bodyRot: [-0.3 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.2 * t, 0.65 * t, -0.2 * t],
          weaponRot: [-0.8 * t, 0.4 * t, -0.6 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        const missOffset = isMiss ? 0.3 : 0;
        return {
          bodyPos: [0, lerp(0.25, -0.2, t), lerp(-0.2, 0.5, t)],
          bodyRot: [lerp(-0.3, 0.45, t), missOffset, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.2, 0.45, t), lerp(0.65, -0.25, t), lerp(-0.2, 0.9, t)],
          weaponRot: [lerp(-0.8, 0.85, t), 0, lerp(-0.6, 0.8, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.24, 0.55],
          bodyRot: [0.48, 0, 0],
          bodyScale: [1.1, 0.88, 1.1],
          weaponPos: [0.48, -0.28, 0.95],
          weaponRot: [0.92, 0, 0.85],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.24, 0, t), lerp(0.55, 0, t)],
        bodyRot: [lerp(0.48, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.48, 0, t), lerp(-0.28, 0, t), lerp(0.95, 0, t)],
        weaponRot: [lerp(0.92, 0, t), 0, lerp(0.85, 0, t)],
      };
    },
  },
};
