import {
  CharacterCreationBuild,
  CompanionId,
  WorldReactivityState,
} from './rules';
import { GloamrestSaveState, TimeOfDayPhase } from './gloamrestEngineTypes';
import { MerchantId, QuestId } from './gloamrestItemsAndQuests';
import { TownSceneId } from './gloamrestMapAndInteriors';

export interface NpcVisualProfile {
  primaryHex: number; // Coat / Tunic / Armor (60%)
  secondaryHex: number; // Trim / Cloak / Apron (30%)
  accentHex: number; // Crest / Lantern / Emblem (10%)
  skinHex: number;
  hairHex: number;
  headgear:
    | 'elder_circlet'
    | 'hood'
    | 'smith_band'
    | 'herbal_wreath'
    | 'mitre_cowl'
    | 'guard_helm'
    | 'merchant_cap'
    | 'scout_cloak'
    | 'scholar_spectacles'
    | 'tricorne_hat'
    | 'none';
  heldProp:
    | 'staff'
    | 'mug'
    | 'hammer'
    | 'lantern'
    | 'tome'
    | 'sword_shield'
    | 'bow'
    | 'saw'
    | 'lute_scroll'
    | 'none';
}

export interface NpcScheduleSlot {
  sceneId: TownSceneId;
  waypoints: { x: number; z: number }[];
  activityLabel: string;
}

export interface GloamrestNpcDefinition {
  id: string;
  name: string;
  role: string;
  portraitId: string;
  personality: string;
  isCompanion?: CompanionId;
  isAmbientGuard?: boolean;
  merchantId?: MerchantId;
  relatedQuests: QuestId[];
  visual: NpcVisualProfile;
  schedule: Record<TimeOfDayPhase, NpcScheduleSlot>;
  highAlertOverride?: Partial<Record<TimeOfDayPhase, NpcScheduleSlot>>;
}

export interface TownDialogueCheckSpec {
  stat: 'str' | 'dex' | 'int' | 'cha';
  skillName: 'Persuasion' | 'Intimidation' | 'Arcana' | 'Insight';
  dc: number;
  speakerId: CompanionId;
  contextualBonusTag?: string; // e.g. "[Arcanist]" or "[Sanctum Acolyte]"
  contextualBonusValue?: number;
}

export interface TownDialogueActionEffect {
  addFlags?: string[];
  startQuests?: QuestId[];
  completeQuestSteps?: { questId: QuestId; stepId: string }[];
  giveItems?: { itemId: string; quantity: number }[];
  removeItems?: { itemId: string; quantity: number }[];
  goldDelta?: number;
  approvalDeltas?: Partial<Record<CompanionId, number>>;
  npcTrustDelta?: number;
  oathShift?: 'Mercy' | 'Dominion' | 'Balance';
  healPartyFull?: boolean;
  advanceTimePhase?: boolean;
  openMerchantId?: MerchantId;
  triggerAction?:
    | 'start_training_drill'
    | 'start_sparring_combat'
    | 'start_outskirts_combat'
    | 'depart_act1_sanctum';
  chronicleNote?: string;
}

export interface TownDialogueChoice {
  id: string;
  text: string;
  contextTag?: string; // e.g. "[Paladin]", "[Borderland Outrider]", "[Wood-Kin]"
  skillCheck?: TownDialogueCheckSpec;
  successReply: string;
  failureReply?: string;
  onSuccess?: TownDialogueActionEffect;
  onFailure?: TownDialogueActionEffect;
  closesDialogue?: boolean;
}

export interface ResolvedTownDialogue {
  npcId: string;
  speakerName: string;
  speakerRole: string;
  portraitId: string;
  locationLabel: string;
  activityStatus: string;
  greetingText: string;
  companionInterjections: {
    companionId: CompanionId;
    quote: string;
  }[];
  choices: TownDialogueChoice[];
}

/**
 * The 12 Mandatory Named NPCs of Gloamrest + 3 Party Companions + Reactive Gate Watch.
 */
export const GLOAMREST_NPCS: GloamrestNpcDefinition[] = [
  // 1. Aldric Veyne — Town Elder
  {
    id: 'aldric_veyne',
    name: 'Aldric Veyne',
    role: 'Town Elder',
    portraitId: 'aldric_veyne',
    personality: 'Measured, dignified, burdened by ancestral responsibility.',
    relatedQuests: [
      'mq01_stranger_at_gloamrest',
      'sq02_echoes_beneath_well',
      'mq04_road_to_whispering_vale',
    ],
    visual: {
      primaryHex: 0x3b352d,
      secondaryHex: 0x6b533b,
      accentHex: 0xe2b05a,
      skinHex: 0xd8bfa9,
      hairHex: 0xc8c5be,
      headgear: 'elder_circlet',
      heldProp: 'staff',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 23, z: 26 },
          { x: 25, z: 27 },
        ],
        activityLabel: 'Addressing petitioners beside the Ancient Well',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 22, z: 24 },
          { x: 24, z: 23 },
        ],
        activityLabel: 'Reviewing Hearth Square dispatches',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [
          { x: 5, z: 5 },
          { x: 6, z: 5 },
        ],
        activityLabel: 'Consulting townsfolk by the Wandering Stag hearth',
      },
      night: {
        sceneId: 'chapel',
        waypoints: [{ x: 5, z: 5 }],
        activityLabel: 'Keeping quiet vigil in the Chapel of the Last Light',
      },
    },
    highAlertOverride: {
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 25, z: 24 },
          { x: 26, z: 14 },
        ],
        activityLabel: 'Coordinating town defenses with Watch Barracks',
      },
    },
  },

  // 2. Mara Fenwick — Tavern Owner
  {
    id: 'mara_fenwick',
    name: 'Mara Fenwick',
    role: 'Tavern Owner · The Wandering Stag',
    portraitId: 'mara_fenwick',
    personality: 'Warm-hearted, sharp-eared, fiercely protective of her regulars.',
    merchantId: 'tavern_mara',
    relatedQuests: ['mq01_stranger_at_gloamrest'],
    visual: {
      primaryHex: 0x5c3428,
      secondaryHex: 0xc2ab8e,
      accentHex: 0xe2b05a,
      skinHex: 0xdead92,
      hairHex: 0x7c3a25,
      headgear: 'none',
      heldProp: 'mug',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 16, z: 24 },
          { x: 17, z: 23 },
        ],
        activityLabel: 'Sweeping the outdoor tavern tables & greeting morning carts',
      },
      afternoon: {
        sceneId: 'tavern',
        waypoints: [
          { x: 9, z: 5 },
          { x: 10, z: 2 },
        ],
        activityLabel: 'Tending the taproom counter & stew cauldron',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [
          { x: 9, z: 5 },
          { x: 8, z: 6 },
        ],
        activityLabel: 'Pouring mulled cider during the evening rush',
      },
      night: {
        sceneId: 'tavern',
        waypoints: [{ x: 10, z: 5 }],
        activityLabel: 'Counting silver & banking the hearth embers',
      },
    },
  },

  // 3. Garron Holt — Blacksmith
  {
    id: 'garron_holt',
    name: 'Garron Holt',
    role: 'Master Blacksmith · Ironroot Forge',
    portraitId: 'garron_holt',
    personality: 'Blunt, gruff, proud of every rivet and edge that leaves his anvil.',
    merchantId: 'forge_garron',
    relatedQuests: ['mq02_trouble_at_ironroot'],
    visual: {
      primaryHex: 0x2e2a28,
      secondaryHex: 0x6e432b,
      accentHex: 0xd97706,
      skinHex: 0xb88668,
      hairHex: 0x2a2321,
      headgear: 'smith_band',
      heldProp: 'hammer',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 15, z: 14 },
          { x: 16, z: 13 },
        ],
        activityLabel: 'Hammering steel at the outdoor Ironroot anvil',
      },
      afternoon: {
        sceneId: 'forge',
        waypoints: [
          { x: 6, z: 3 },
          { x: 5, z: 5 },
        ],
        activityLabel: 'Working the main smelting furnace inside Ironroot Forge',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [{ x: 5, z: 7 }],
        activityLabel: 'Taking an evening ale at the Wandering Stag',
      },
      night: {
        sceneId: 'forge',
        waypoints: [{ x: 4, z: 5 }],
        activityLabel: 'Guarding the forge stock & banking coal',
      },
    },
  },

  // 4. Elowen Mire — Herbalist
  {
    id: 'elowen_mire',
    name: 'Elowen Mire',
    role: 'Herbalist & Alchemist · The Green Vessel',
    portraitId: 'elowen_mire',
    personality: 'Observant, soft-spoken, deeply attuned to Whispering Vale’s flora.',
    merchantId: 'herbalist_elowen',
    relatedQuests: ['sq01_bitter_remedy'],
    visual: {
      primaryHex: 0x2d4a38,
      secondaryHex: 0x7e9c82,
      accentHex: 0xd4b46a,
      skinHex: 0xd8b89c,
      hairHex: 0x4f3728,
      headgear: 'herbal_wreath',
      heldProp: 'lantern',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 34, z: 30 },
          { x: 33, z: 32 },
        ],
        activityLabel: 'Tending medicinal beds in the Green Vessel herb garden',
      },
      afternoon: {
        sceneId: 'herbalist',
        waypoints: [
          { x: 5, z: 3 },
          { x: 7, z: 5 },
        ],
        activityLabel: 'Grinding silverleaf tinctures at the apothecary table',
      },
      evening: {
        sceneId: 'herbalist',
        waypoints: [{ x: 4, z: 6 }],
        activityLabel: 'Cataloguing nocturnal blooms by lantern light',
      },
      night: {
        sceneId: 'herbalist',
        waypoints: [{ x: 4, z: 3 }],
        activityLabel: 'Simmering fever remedies overnight',
      },
    },
  },

  // 5. Brother Cael — Chapel Keeper
  {
    id: 'brother_cael',
    name: 'Brother Cael',
    role: 'Chapel Keeper · Chapel of the Last Light',
    portraitId: 'brother_cael',
    personality: 'Compassionate, contemplative, haunted by pre-schism prophecies.',
    relatedQuests: ['sq02_echoes_beneath_well'],
    visual: {
      primaryHex: 0x3b3f4a,
      secondaryHex: 0xc8c0ae,
      accentHex: 0xe2b05a,
      skinHex: 0xcfa98e,
      hairHex: 0x9ca3af,
      headgear: 'mitre_cowl',
      heldProp: 'tome',
    },
    schedule: {
      morning: {
        sceneId: 'chapel',
        waypoints: [
          { x: 6, z: 4 },
          { x: 5, z: 7 },
        ],
        activityLabel: 'Lighting sanctuary tapers before the Altar of the Last Light',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 38, z: 19 },
          { x: 41, z: 21 },
        ],
        activityLabel: 'Blessing headstones & tending candles by the chapel yard',
      },
      evening: {
        sceneId: 'chapel',
        waypoints: [{ x: 6, z: 5 }],
        activityLabel: 'Leading evening vespers & tending the wounded',
      },
      night: {
        sceneId: 'chapel',
        waypoints: [{ x: 8, z: 4 }],
        activityLabel: 'Searching Covenant scrolls in the chapel archive',
      },
    },
  },

  // 6. Captain Roderic — Guard Captain
  {
    id: 'captain_roderic',
    name: 'Captain Roderic',
    role: 'Guard Captain · Watch Barracks',
    portraitId: 'captain_roderic',
    personality: 'Disciplined, pragmatic veteran who respects tested steel over speeches.',
    relatedQuests: ['mq03_shadows_beyond_gate', 'mq04_road_to_whispering_vale'],
    visual: {
      primaryHex: 0x333c48,
      secondaryHex: 0x7c2d12,
      accentHex: 0xe2b05a,
      skinHex: 0xba886a,
      hairHex: 0x3b2e26,
      headgear: 'guard_helm',
      heldProp: 'sword_shield',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 27, z: 12 },
          { x: 29, z: 12 },
        ],
        activityLabel: 'Drilling recruits in the Watch Barracks training yard',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 26, z: 13 },
          { x: 34, z: 8 },
        ],
        activityLabel: 'Inspecting the northern garrison road & gate watch',
      },
      evening: {
        sceneId: 'barracks',
        waypoints: [{ x: 6, z: 6 }],
        activityLabel: 'Charting patrol rotations over the barracks war table',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [
          { x: 26, z: 12 },
          { x: 36, z: 8 },
        ],
        activityLabel: 'Walking night sentry between Watchtower and Whispering Gate',
      },
    },
    highAlertOverride: {
      evening: {
        sceneId: 'exterior',
        waypoints: [
          { x: 35, z: 8 },
          { x: 37, z: 7 },
        ],
        activityLabel: 'Commanding reinforced barricades at Whispering Gate',
      },
    },
  },

  // 7. Tessa Reed — General Merchant
  {
    id: 'tessa_reed',
    name: 'Tessa Reed',
    role: 'General Merchant · Hearth Square Market',
    portraitId: 'tessa_reed',
    personality: 'Quick-witted, resourceful trader who knows every caravan rumor.',
    merchantId: 'general_tessa',
    relatedQuests: ['mq01_stranger_at_gloamrest'],
    visual: {
      primaryHex: 0x4b533b,
      secondaryHex: 0x9c7b4f,
      accentHex: 0xe2b05a,
      skinHex: 0xd9b39a,
      hairHex: 0x6b3f28,
      headgear: 'merchant_cap',
      heldProp: 'lantern',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 21, z: 26 },
          { x: 22, z: 27 },
        ],
        activityLabel: 'Arranging travel sundries beneath her Hearth Square stall',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 21, z: 26 },
          { x: 20, z: 25 },
        ],
        activityLabel: 'Trading provisions & lantern oil in Hearth Square',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [{ x: 6, z: 7 }],
        activityLabel: 'Swapping road gossip in the Wandering Stag',
      },
      night: {
        sceneId: 'tavern',
        waypoints: [{ x: 8, z: 8 }],
        activityLabel: 'Resting in the tavern common hall',
      },
    },
  },

  // 8. Bram Alder — Carpenter
  {
    id: 'bram_alder',
    name: 'Bram Alder',
    role: 'Master Carpenter · Timber Yard',
    portraitId: 'bram_alder',
    personality: 'Sturdy, practical craftsman who sees leverage and timber physics everywhere.',
    merchantId: 'carpenter_bram',
    relatedQuests: ['mq02_trouble_at_ironroot'],
    visual: {
      primaryHex: 0x574330,
      secondaryHex: 0x3b4d3b,
      accentHex: 0xc99a52,
      skinHex: 0xc49474,
      hairHex: 0x4f3728,
      headgear: 'none',
      heldProp: 'saw',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 15, z: 36 },
          { x: 16, z: 37 },
        ],
        activityLabel: 'Sawing ironpine beams in the Timber Yard',
      },
      afternoon: {
        sceneId: 'carpenter',
        waypoints: [{ x: 5, z: 3 }],
        activityLabel: 'Shaping barricade stakes at the joinery workbench',
      },
      evening: {
        sceneId: 'exterior',
        waypoints: [
          { x: 15, z: 34 },
          { x: 23, z: 28 },
        ],
        activityLabel: 'Checking bridge planks & walking toward Hearth Square',
      },
      night: {
        sceneId: 'carpenter',
        waypoints: [{ x: 7, z: 6 }],
        activityLabel: 'Securing tools in the carpentry shed',
      },
    },
  },

  // 9. Sera Wren — Scout
  {
    id: 'sera_wren',
    name: 'Sera Wren',
    role: 'Outrider Scout · Whispering Gate',
    portraitId: 'sera_wren',
    personality: 'Vigilant, fleet-footed ranger who reads every snapped twig along the vale.',
    relatedQuests: [
      'mq02_trouble_at_ironroot',
      'mq03_shadows_beyond_gate',
      'mq04_road_to_whispering_vale',
    ],
    visual: {
      primaryHex: 0x263d2d,
      secondaryHex: 0x4a3b2c,
      accentHex: 0x7e9c82,
      skinHex: 0xc79e7e,
      hairHex: 0x262224,
      headgear: 'scout_cloak',
      heldProp: 'bow',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 37, z: 8 },
          { x: 38, z: 6 },
        ],
        activityLabel: 'Scouting the forest road from Whispering Gate',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 36, z: 8 },
          { x: 35, z: 10 },
        ],
        activityLabel: 'Inspecting wagon tracks at the gate staging yard',
      },
      evening: {
        sceneId: 'exterior',
        waypoints: [
          { x: 38, z: 7 },
          { x: 37, z: 5 },
        ],
        activityLabel: 'Keeping dusk watch over the Whispering Gate bridge',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [{ x: 37, z: 7 }],
        activityLabel: 'Guarding the barred Whispering Gate by torchlight',
      },
    },
  },

  // 10. Old Nym — Storyteller
  {
    id: 'old_nym',
    name: 'Old Nym',
    role: 'Village Storyteller & Chronicler',
    portraitId: 'old_nym',
    personality: 'Wry, poetic elder whose folk ballads conceal real Covenant history.',
    relatedQuests: ['sq02_echoes_beneath_well', 'opt01_manor_of_shattered_vows'],
    visual: {
      primaryHex: 0x463a4a,
      secondaryHex: 0x7d6b52,
      accentHex: 0xe2b05a,
      skinHex: 0xcbb09a,
      hairHex: 0xd8d4cc,
      headgear: 'hood',
      heldProp: 'lute_scroll',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 26, z: 26 },
          { x: 27, z: 25 },
        ],
        activityLabel: 'Reciting old vale verses on the Hearth Square bench',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 26, z: 26 },
          { x: 37, z: 36 },
        ],
        activityLabel: 'Strolling toward the river bridge & gazing at Veyne Manor',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [{ x: 6, z: 3 }],
        activityLabel: 'Telling fireside legends in the Wandering Stag',
      },
      night: {
        sceneId: 'tavern',
        waypoints: [{ x: 5, z: 3 }],
        activityLabel: 'Humming quiet ballads beside the tavern hearth',
      },
    },
  },

  // 11. Edrin Vale — Former Scholar
  {
    id: 'edrin_vale',
    name: 'Edrin Vale',
    role: 'Former Covenant Scholar',
    portraitId: 'edrin_vale',
    personality: 'Nervous, encyclopedic academic who fled the high citadels with banned rubbings.',
    relatedQuests: ['sq02_echoes_beneath_well', 'opt01_manor_of_shattered_vows'],
    visual: {
      primaryHex: 0x2d3648,
      secondaryHex: 0x5a4b38,
      accentHex: 0x60a5fa,
      skinHex: 0xe0c4ad,
      hairHex: 0x4b4642,
      headgear: 'scholar_spectacles',
      heldProp: 'tome',
    },
    schedule: {
      morning: {
        sceneId: 'chapel',
        waypoints: [{ x: 8, z: 5 }],
        activityLabel: 'Cross-referencing stone rubbings in the Chapel Archive',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 37, z: 18 },
          { x: 25, z: 24 },
        ],
        activityLabel: 'Comparing the Chapel Oath Stele with Hearth Square’s well',
      },
      evening: {
        sceneId: 'chapel',
        waypoints: [{ x: 8, z: 5 }],
        activityLabel: 'Transcribing pre-schism runes in the Chapel Archive',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [{ x: 25, z: 24 }],
        activityLabel: 'Observing the faint nocturnal blue glow inside the Ancient Well',
      },
    },
  },

  // 12. Lysa Thorn — Missing-Person Investigator
  {
    id: 'lysa_thorn',
    name: 'Lysa Thorn',
    role: 'Missing-Person Investigator',
    portraitId: 'lysa_thorn',
    personality: 'Incisive, relentless tracker hired by families of the vanished caravans.',
    relatedQuests: ['mq01_stranger_at_gloamrest', 'mq03_shadows_beyond_gate'],
    visual: {
      primaryHex: 0x3b2c35,
      secondaryHex: 0x262926,
      accentHex: 0xd97706,
      skinHex: 0xc99c7e,
      hairHex: 0x221d1c,
      headgear: 'tricorne_hat',
      heldProp: 'lantern',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 22, z: 24 },
          { x: 35, z: 9 },
        ],
        activityLabel: 'Comparing notice board sketches with gate wagon tracks',
      },
      afternoon: {
        sceneId: 'tavern',
        waypoints: [{ x: 2, z: 6 }],
        activityLabel: 'Questioning travelers at a corner table in the Wandering Stag',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [{ x: 2, z: 8 }],
        activityLabel: 'Pinning witness notes in the tavern alcove',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [
          { x: 18, z: 24 },
          { x: 23, z: 26 },
        ],
        activityLabel: 'Listening for subterranean whispers along Hearth Square',
      },
    },
  },

  // ==================== PARTY COMPANIONS PRESENT IN GLOAMREST ====================
  {
    id: 'comp_seraphina',
    name: 'Seraphina Vane',
    role: 'Vanguard Companion · Oathbreaker Paladin',
    portraitId: 'seraphina',
    isCompanion: 'seraphina',
    personality: 'Steadfast shield-maiden weighing the Silver Covenant’s broken vows.',
    relatedQuests: ['mq04_road_to_whispering_vale'],
    visual: {
      primaryHex: 0x475569,
      secondaryHex: 0x78350f,
      accentHex: 0xe2b05a,
      skinHex: 0xe8cbb8,
      hairHex: 0xd8d0c5,
      headgear: 'elder_circlet',
      heldProp: 'sword_shield',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [{ x: 26, z: 24 }],
        activityLabel: 'Standing vigil near Hearth Square',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [{ x: 39, z: 20 }],
        activityLabel: 'Reflecting beside the Chapel of the Last Light',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [{ x: 7, z: 6 }],
        activityLabel: 'Resting armour-clad in the Wandering Stag',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [{ x: 36, z: 9 }],
        activityLabel: 'Watching the mist beyond Whispering Gate',
      },
    },
  },
  {
    id: 'comp_kaelen',
    name: 'Kaelen Vos',
    role: 'Arcanist Companion · Blood-Weave Savant',
    portraitId: 'kaelen',
    isCompanion: 'kaelen',
    personality: 'Sharp-tongued planar scholar fascinated by Gloamrest’s resonant spring.',
    relatedQuests: ['sq02_echoes_beneath_well', 'mq04_road_to_whispering_vale'],
    visual: {
      primaryHex: 0x6b1d24,
      secondaryHex: 0x262229,
      accentHex: 0xa855f7,
      skinHex: 0xb56e65,
      hairHex: 0x262224,
      headgear: 'none',
      heldProp: 'tome',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [{ x: 25, z: 26 }],
        activityLabel: 'Measuring ley-line harmonics around the Ancient Well',
      },
      afternoon: {
        sceneId: 'herbalist',
        waypoints: [{ x: 6, z: 7 }],
        activityLabel: 'Examining alchemical reagents in The Green Vessel',
      },
      evening: {
        sceneId: 'tavern',
        waypoints: [{ x: 8, z: 4 }],
        activityLabel: 'Sampling spiced cider at the Wandering Stag bar',
      },
      night: {
        sceneId: 'chapel',
        waypoints: [{ x: 9, z: 6 }],
        activityLabel: 'Studying pre-schism manuscripts in the Chapel Archive',
      },
    },
  },
  {
    id: 'comp_thorne',
    name: 'Thorne Ironbough',
    role: 'Warden Companion · Briar Stalker',
    portraitId: 'thorne',
    isCompanion: 'thorne',
    personality: 'Quiet woodland sentinel listening to the troubled pines of Whispering Vale.',
    relatedQuests: ['mq03_shadows_beyond_gate', 'mq04_road_to_whispering_vale'],
    visual: {
      primaryHex: 0x1e462b,
      secondaryHex: 0x4f3728,
      accentHex: 0x7e9c82,
      skinHex: 0xc79e7e,
      hairHex: 0x5c3c28,
      headgear: 'scout_cloak',
      heldProp: 'bow',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [{ x: 35, z: 7 }],
        activityLabel: 'Comparing forest sign with Scout Sera Wren',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [{ x: 16, z: 33 }],
        activityLabel: 'Fletching shafts near the Timber Yard',
      },
      evening: {
        sceneId: 'exterior',
        waypoints: [{ x: 18, z: 23 }],
        activityLabel: 'Keeping watch outside the Wandering Stag',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [{ x: 38, z: 8 }],
        activityLabel: 'Listening to the night wind at Whispering Gate',
      },
    },
  },

  // ==================== REACTIVE GATE / SQUARE WATCHMEN ====================
  {
    id: 'guard_halvard',
    name: 'Watchman Halvard',
    role: 'Gloamrest Gate Sentry',
    portraitId: 'captain_roderic',
    isAmbientGuard: true,
    personality: 'Alert spearman keeping watch over travelers.',
    relatedQuests: [],
    visual: {
      primaryHex: 0x2f3640,
      secondaryHex: 0x5a4b38,
      accentHex: 0x9ca3af,
      skinHex: 0xd0a88c,
      hairHex: 0x3b2e26,
      headgear: 'guard_helm',
      heldProp: 'sword_shield',
    },
    schedule: {
      morning: {
        sceneId: 'exterior',
        waypoints: [
          { x: 23, z: 43 },
          { x: 26, z: 43 },
        ],
        activityLabel: 'Guarding the South Pilgrim Gate',
      },
      afternoon: {
        sceneId: 'exterior',
        waypoints: [
          { x: 23, z: 43 },
          { x: 25, z: 38 },
        ],
        activityLabel: 'Patrolling Pilgrim’s Causeway',
      },
      evening: {
        sceneId: 'exterior',
        waypoints: [
          { x: 36, z: 7 },
          { x: 39, z: 7 },
        ],
        activityLabel: 'Reinforcing Whispering Gate watch',
      },
      night: {
        sceneId: 'exterior',
        waypoints: [{ x: 36, z: 6 }],
        activityLabel: 'Holding torch-watch at Whispering Gate',
      },
    },
  },
];

/**
 * Resolves an NPC's active schedule slot based on timeOfDay and townThreatPhase.
 */
export function getNpcActiveSchedule(
  npc: GloamrestNpcDefinition,
  timeOfDay: TimeOfDayPhase,
  townThreatPhase: GloamrestSaveState['townThreatPhase']
): NpcScheduleSlot {
  if (
    (townThreatPhase === 'uneasy' ||
      townThreatPhase === 'astral_resonance' ||
      townThreatPhase === 'fortified') &&
    npc.highAlertOverride?.[timeOfDay]
  ) {
    return npc.highAlertOverride[timeOfDay]!;
  }
  return npc.schedule[timeOfDay];
}

/**
 * Builds contextual, state-reactive dialogue & D20 skill check branches for any NPC in Gloamrest.
 */
export function buildGloamrestNpcDialogue(
  npcId: string,
  state: GloamrestSaveState,
  characterBuild: CharacterCreationBuild,
  worldState: WorldReactivityState
): ResolvedTownDialogue | null {
  const npc = GLOAMREST_NPCS.find((n) => n.id === npcId);
  if (!npc) return null;

  const schedule = getNpcActiveSchedule(npc, state.timeOfDay, state.townThreatPhase);
  const mq01 = state.quests.mq01_stranger_at_gloamrest;
  const mq02 = state.quests.mq02_trouble_at_ironroot;
  const sq01 = state.quests.sq01_bitter_remedy;
  const mq03 = state.quests.mq03_shadows_beyond_gate;
  const sq02 = state.quests.sq02_echoes_beneath_well;
  const mq04 = state.quests.mq04_road_to_whispering_vale;
  const flags = new Set(state.storyFlags);

  const hasItem = (id: string, minQty = 1) =>
    (state.inventory.items.find((i) => i.itemId === id)?.quantity ?? 0) >= minQty;

  const herbCount =
    (state.inventory.items.find((i) => i.itemId === 'silverleaf_herb')?.quantity ?? 0) +
    (state.inventory.items.find((i) => i.itemId === 'bitterroot_stalk')?.quantity ?? 0);

  // ==================== 1. ALDRIC VEYNE — TOWN ELDER ====================
  if (npc.id === 'aldric_veyne') {
    const postOutskirts = mq03.status === 'completed';
    const wellSolved = sq02.status === 'completed';
    const manorFound = state.quests.opt01_manor_of_shattered_vows.status === 'completed';

    let greeting =
      '“Welcome to Gloamrest, traveler. Our lanterns still burn warm beside the sacred spring, yet three caravans have vanished on the Whispering Vale road within a fortnight. Even the water in our ancient well shivers before dawn.”';
    if (postOutskirts && mq04.status !== 'completed') {
      greeting = wellSolved
        ? '“You pushed back the vanguard beyond Whispering Gate AND uncovered the aqueduct sigil beneath our well... Then the old Veyne annals spoke true: the Sanctum of the Shattered Oath is waking.”'
        : '“Word of your clash beyond Whispering Gate reached Hearth Square before you did. Those were no mere forest brigands—they bore remnants of the Silver Covenant. We must prepare for what lies deeper in Whispering Vale.”';
    } else if (mq04.completedStepIds.includes('report_to_aldric')) {
      greeting =
        '“You carry Gloamrest’s Sealed Writ of Passage. Equip your companions well, take rest if needed, and speak to Scout Sera Wren at Whispering Gate when you are ready to march on the Sanctum.”';
    }

    const choices: TownDialogueChoice[] = [];

    if (!mq01.completedStepIds.includes('speak_aldric')) {
      choices.push({
        id: 'aldric_mq01_intro',
        text: '“Tell me what has been happening in Gloamrest. My companions and I can investigate.”',
        successReply:
          '“A steady voice in dark times. Speak with Mara Fenwick and Investigator Lysa Thorn inside the Wandering Stag Tavern—they kept records of the missing travelers. And if you can spare aid, Garron Holt at Ironroot Forge and Scout Sera Wren at Whispering Gate are stretched thin.”',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'mq01_stranger_at_gloamrest', stepId: 'enter_town' },
            { questId: 'mq01_stranger_at_gloamrest', stepId: 'explore_square' },
            { questId: 'mq01_stranger_at_gloamrest', stepId: 'speak_aldric' },
          ],
          approvalDeltas: { seraphina: 4, thorne: 3 },
          npcTrustDelta: 10,
          chronicleNote: 'Pledged aid to Elder Aldric Veyne in Hearth Square.',
        },
      });
    }

    if (!flags.has('aldric_persuaded_ledger')) {
      const isChroniclerOrPaladin =
        characterBuild.backgroundId === 'court_chronicler' ||
        characterBuild.classId === 'paladin';
      choices.push({
        id: 'aldric_persuade_truth',
        text: '“You’re holding something back about the well and your family name, Elder. Trust me with the full truth.”',
        contextTag: isChroniclerOrPaladin ? '[Paladin / Chronicler +2]' : undefined,
        skillCheck: {
          stat: 'cha',
          skillName: 'Persuasion',
          dc: 12,
          speakerId: 'seraphina',
          contextualBonusTag: isChroniclerOrPaladin ? 'Oath & Heraldry' : undefined,
          contextualBonusValue: isChroniclerOrPaladin ? 2 : 0,
        },
        successReply:
          'Aldric lowers his voice. “My forebears were Wardens of the First Vigil. Beneath our shuttered ancestral manor in the southeast quarter lies proof that Gloamrest’s spring is tied directly to the Sanctum seal. Take these emergency Watch stipends—we need the truth brought to light.”',
        failureReply:
          'Aldric’s grip tightens on his staff. “A town elder cannot trade in half-remembered ghosts while families await word of their kin. Prove your dependability on the road first.”',
        onSuccess: {
          addFlags: ['aldric_persuaded_ledger'],
          goldDelta: 20,
          startQuests: ['opt01_manor_of_shattered_vows'],
          approvalDeltas: { seraphina: 5, kaelen: 4 },
          npcTrustDelta: 12,
        },
        onFailure: {
          addFlags: ['aldric_persuaded_ledger'],
          npcTrustDelta: -2,
        },
      });
    }

    if (postOutskirts && !mq04.completedStepIds.includes('report_to_aldric')) {
      choices.push({
        id: 'aldric_mq04_report',
        text: '“Rift-corrupted Covenant forces ambushed the road beyond Whispering Gate. The threat comes from the Sanctum.”',
        successReply:
          '“Then our quiet years are truly over. Take my Sealed Writ of Passage—it authorizes Sera Wren to open the high forest trail to the Sanctum of the Shattered Oath once your party has equipped, spoken together, and prepared.”',
        onSuccess: {
          startQuests: ['mq04_road_to_whispering_vale'],
          completeQuestSteps: [
            { questId: 'mq04_road_to_whispering_vale', stepId: 'report_to_aldric' },
          ],
          giveItems: [{ itemId: 'sanctum_gate_writ', quantity: 1 }],
          addFlags: ['aldric_issued_sanctum_writ'],
          approvalDeltas: { seraphina: 5, kaelen: 4, thorne: 5 },
          chronicleNote: 'Received Elder Aldric’s Sealed Writ to march on the Sanctum of the Shattered Oath.',
        },
      });
    }

    if (manorFound && !flags.has('aldric_manor_acknowledged')) {
      choices.push({
        id: 'aldric_manor_relic',
        text: '“We unsealed the vault beneath Veyne Manor and recovered the Oathblade of the First Vigil.”',
        successReply:
          'Aldric’s eyes glisten in the lantern light. “For three generations none of my blood dared descend those stairs. Carry that blade to the Sanctum—let it finish the vigil my house abandoned.”',
        onSuccess: {
          addFlags: ['aldric_manor_acknowledged'],
          goldDelta: 30,
          oathShift: 'Mercy',
          approvalDeltas: { seraphina: 6 },
        },
      });
    }

    choices.push({
      id: 'aldric_leave',
      text: '“Keep the watch fires lit, Elder. I will return with word.”',
      successReply: '“May the Last Light guide your step across the cobbles.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Hearth Square · Gloamrest',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'seraphina',
          quote: '“He carries the bearing of an old garrison commander. Gloamrest will hold if we give them hope.”',
        },
        {
          companionId: 'kaelen',
          quote: '“Listen to the resonance humming up that well-shaft. That isn’t ordinary spring water.”',
        },
        {
          companionId: 'thorne',
          quote: '“Missing caravans and spooked horses—the forest edge knows what took them.”',
        },
      ],
      choices,
    };
  }

  // ==================== 2. MARA FENWICK — TAVERN OWNER ====================
  if (npc.id === 'mara_fenwick') {
    const postOutskirts = mq03.status === 'completed';
    const greeting = postOutskirts
      ? '“Thank the hearth you’re back in one piece! Half the village has crowded into the taproom since the Watch doubled the gate sentries. Sit, take hot venison stew, or rest upstairs whenever you need.”'
      : '“Step in out of the vale mist, traveler! The Wandering Stag’s kettle is hot and the cider’s mulled with clove. If you’re asking after the vanished caravans, speak low—folks are jittery enough after dark.”';

    const choices: TownDialogueChoice[] = [
      {
        id: 'mara_open_shop',
        text: '“[Browse Tavern Provisions & Rent Room] Show me what’s hot on the hearth.”',
        successReply: '“Fresh stag roast, spiced cider, or a clean feather bed upstairs—take your pick!”',
        onSuccess: {
          openMerchantId: 'tavern_mara',
        },
        closesDialogue: true,
      },
    ];

    if (!mq01.completedStepIds.includes('learn_missing_travelers')) {
      choices.push({
        id: 'mara_missing_rumors',
        text: '“Elder Aldric sent me. What did the last travelers say before they vanished on the Vale road?”',
        successReply:
          '“Three peddlers and an iron-cart driver supped right at Table Two. Said they saw pale blue lanterns moving toward the old Sanctum ridge—and heard metallic chanting beneath the stone bridge. Scout Sera Wren at Whispering Gate has been tracking their trail since dawn.”',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'mq01_stranger_at_gloamrest', stepId: 'visit_tavern' },
            { questId: 'mq01_stranger_at_gloamrest', stepId: 'learn_missing_travelers' },
          ],
          startQuests: ['mq02_trouble_at_ironroot', 'mq03_shadows_beyond_gate'],
          addFlags: ['heard_tavern_rumors'],
          chronicleNote: 'Uncovered eyewitness accounts of blue Sanctum lanterns at the Wandering Stag Tavern.',
        },
      });
    }

    if (!flags.has('mara_insight_cellar')) {
      choices.push({
        id: 'mara_insight_whispers',
        text: '“[Insight] You keep glancing toward the cellar flagstones, Mara. Have you heard the whispers too?”',
        skillCheck: {
          stat: 'dex',
          skillName: 'Insight',
          dc: 11,
          speakerId: 'thorne',
        },
        successReply:
          'Mara exhales in relief. “Thought I was losing my wits! After midnight, a faint hum vibrates right through the cellar casks—coming from the direction of Hearth Square’s well. Brother Cael at the Chapel has been losing sleep over it too.”',
        failureReply:
          'Mara forces a brisk smile and wipes a tankard. “Only loose floorboards and hungry cellar mice, friend. Nothing a mug of cider won’t cure.”',
        onSuccess: {
          addFlags: ['mara_insight_cellar'],
          startQuests: ['sq02_echoes_beneath_well'],
          giveItems: [{ itemId: 'mulled_vale_cider', quantity: 1 }],
          approvalDeltas: { thorne: 3 },
        },
        onFailure: {
          addFlags: ['mara_insight_cellar'],
        },
      });
    }

    choices.push({
      id: 'mara_rest_room',
      text: `“[Rent Upstairs Room — 10g] Let our party rest until next watch and restore full HP.”`,
      successReply:
        state.inventory.gold >= 10
          ? '“Up the stairs, second door on the right. Fresh linen on the berth—sleep sound while the hearth burns.”'
          : '“Sorry love, a clean room and breakfast runs 10 gold crowns—though Brother Cael’s chapel font offers free solace to the wounded.”',
      onSuccess:
        state.inventory.gold >= 10
          ? {
              goldDelta: -10,
              healPartyFull: true,
              advanceTimePhase: true,
              completeQuestSteps:
                mq04.status === 'active'
                  ? [{ questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' }]
                  : undefined,
            }
          : undefined,
    });

    choices.push({
      id: 'mara_close',
      text: '“Thank you, Mara. Keep the hearth warm.”',
      successReply: '“Door’s never barred to friends of Gloamrest.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Wandering Stag Tavern',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'kaelen',
          quote: '“Clove-spiced cider and dry floorboards—civilization has its merits.”',
        },
        {
          companionId: 'seraphina',
          quote: '“Tavern keepers hear every tremor on the border roads before the generals do.”',
        },
      ],
      choices,
    };
  }

  // ==================== 3. GARRON HOLT — BLACKSMITH ====================
  if (npc.id === 'garron_holt') {
    const hasIngots = hasItem('meteoric_ironroot_ingots');
    const doneMq02 = mq02.status === 'completed';

    const greeting = doneMq02
      ? '“Hear that ring on the anvil? That’s meteoric Ironroot steel back in the furnace! Browse my rare Sunsteel, Thornwatch, and Starforged rack anytime, or let me oil your gear.”'
      : '“Bah! Half a dozen Watch halberds waiting for new heads, and my meteoric ironroot shipment lies scattered in a ditch outside Whispering Gate! My driver barely made it back with a splintered axle.”';

    const choices: TownDialogueChoice[] = [
      {
        id: 'garron_open_forge',
        text: '“[Trade & Repair] Show me Ironroot Forge’s weapons, armor, and repair bench.”',
        successReply: doneMq02
          ? '“Finest star-tempered steel west of the citadels. Pick your edge.”'
          : '“Standard frontier iron for now—bring back my missing ore crate and I’ll forge you masterwork arms!”',
        onSuccess: {
          openMerchantId: 'forge_garron',
        },
        closesDialogue: true,
      },
    ];

    if (mq02.status === 'not_started') {
      choices.push({
        id: 'garron_start_mq02',
        text: '“Where was your supply cart ambushed? I’ll track down your missing ironroot ingots.”',
        contextTag:
          characterBuild.backgroundId === 'guild_artisan' ? '[Guild Artisan]' : undefined,
        successReply:
          '“Now that’s spine! The damaged supply cart is parked at Whispering Gate’s staging yard. Check its broken axle-tracks—the heavy ingot crate rolled down into the roadside ravine just past the gatehouse bridge.”',
        onSuccess: {
          startQuests: ['mq02_trouble_at_ironroot'],
          completeQuestSteps: [
            { questId: 'mq02_trouble_at_ironroot', stepId: 'speak_garron' },
          ],
          npcTrustDelta: 8,
          chronicleNote: 'Agreed to recover Garron Holt’s ambushed meteoric ore shipment.',
        },
      });
    }

    if (hasIngots && !doneMq02) {
      choices.push({
        id: 'garron_deliver_ingots',
        text: '“[Deliver Meteoric Ironroot Ingots] Found your ore crate down the roadside ravine, intact.”',
        successReply:
          'Garron hefts the heavy ironbound crate with a booming laugh. “Not a single bar rusted! Here—40 gold crowns for the haul, a Smith’s Repair Kit, and I’m unlocking my masterwork Sunsteel, Thornwatch, and Starforged stock for your party immediately!”',
        onSuccess: {
          removeItems: [{ itemId: 'meteoric_ironroot_ingots', quantity: 1 }],
          completeQuestSteps: [
            { questId: 'mq02_trouble_at_ironroot', stepId: 'speak_garron' },
            { questId: 'mq02_trouble_at_ironroot', stepId: 'inspect_cart' },
            { questId: 'mq02_trouble_at_ironroot', stepId: 'travel_roadside' },
            { questId: 'mq02_trouble_at_ironroot', stepId: 'recover_ingots' },
            { questId: 'mq02_trouble_at_ironroot', stepId: 'return_garron' },
          ],
          addFlags: ['forge_shipment_restored'],
          approvalDeltas: { seraphina: 5, thorne: 4 },
          npcTrustDelta: 20,
          chronicleNote: 'Restored Ironroot Forge’s meteoric ore supply, unlocking masterwork arms.',
        },
      });
    }

    choices.push({
      id: 'garron_leave',
      text: '“May your furnace burn hot, Garron.”',
      successReply: '“Keep your guard high and your steel oiled.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Ironroot Forge',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'seraphina',
          quote: '“Good dwarven-style bellows work. Masterwork armor here could turn a fatal blow in the Sanctum.”',
        },
      ],
      choices,
    };
  }

  // ==================== 4. ELOWEN MIRE — HERBALIST ====================
  if (npc.id === 'elowen_mire') {
    const hasBlight = hasItem('blight_nightshade');
    const doneSq01 = sq01.status === 'completed';

    const greeting = doneSq01
      ? '“Your fresh Silverleaf and Bitterroot tinctures have already eased three fevers on Mill Lane. My apothecary shelves are always open if you need healing draughts or purifying tonics.”'
      : '“Tread gently near the garden beds, friend. Since the well began shimmering at night, common herbs wilt early—and strange blue-veined weeds creep through the shaded stones.”';

    const choices: TownDialogueChoice[] = [
      {
        id: 'elowen_open_shop',
        text: '“[Apothecary Trade] Let me browse your potions, salves, and herbal ingredients.”',
        successReply: '“Every phial is brewed from Whispering Vale spring water and clean sun-dried leaf.”',
        onSuccess: {
          openMerchantId: 'herbalist_elowen',
        },
        closesDialogue: true,
      },
    ];

    if (sq01.status === 'not_started') {
      choices.push({
        id: 'elowen_start_sq01',
        text: '“Do you need help gathering medicinal plants around Gloamrest?”',
        contextTag:
          characterBuild.raceId === 'wood_kin' || characterBuild.classId === 'warden'
            ? '[Wood-Kin / Warden]'
            : undefined,
        successReply:
          '“Bless you, yes! Bring me 3 fresh sprigs of Silverleaf or Vale Bitterroot—they grow in my garden bed, along the Silverbrook riverbank, near the Timber Yard stream, and below the Chapel slope. And if you spot any unnatural glowing nightshade near the Abandoned Manor, handle it carefully!”',
        onSuccess: {
          startQuests: ['sq01_bitter_remedy'],
          completeQuestSteps: [{ questId: 'sq01_bitter_remedy', stepId: 'speak_elowen' }],
          approvalDeltas: { thorne: 5 },
          chronicleNote: 'Offered to gather medicinal herbs for Herbalist Elowen Mire.',
        },
      });
    }

    if (sq01.status !== 'completed' && herbCount >= 3) {
      choices.push({
        id: 'elowen_deliver_herbs',
        text: `“[Deliver 3 Medicinal Herbs${hasBlight ? ' + Rift Nightshade Note' : ''}] Here are the fresh Silverleaf and Bitterroot stalks.”`,
        successReply: hasBlight
          ? '“Magnificent specimens—and by the First Leaf, this Rift-Touched Nightshade proves Astral corruption is seeping through the bedrock! Take these Silverleaf Draughts, a Sun-Dew Purifying Tonic, and extra coin for the warning.”'
          : '“Crisp leaves and potent roots! Let me bottle two Silverleaf Healing Draughts and a Sun-Dew Purifying Tonic for your pack right away.”',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'sq01_bitter_remedy', stepId: 'speak_elowen' },
            { questId: 'sq01_bitter_remedy', stepId: 'gather_herbs' },
            ...(hasBlight
              ? [{ questId: 'sq01_bitter_remedy' as QuestId, stepId: 'inspect_blight_herb' }]
              : []),
            { questId: 'sq01_bitter_remedy', stepId: 'deliver_herbs' },
          ],
          goldDelta: hasBlight ? 15 : 0,
          approvalDeltas: { thorne: 6, seraphina: 3 },
          npcTrustDelta: 18,
          chronicleNote: 'Brewed restorative remedies with Elowen Mire at The Green Vessel.',
        },
      });
    }

    choices.push({
      id: 'elowen_potion_lore',
      text: '“Tell me how your tonics interact with combat afflictions.”',
      successReply:
        '“Silverleaf Draughts knit torn flesh for 12 Vitality, while Sun-Dew Purifying Tonics weave a +5 Temporary HP ward and extinguish Burning, Rooted, or Sundered curses on the spot.”',
    });

    choices.push({
      id: 'elowen_close',
      text: '“Farewell, Elowen.”',
      successReply: '“Walk where the moss still grows green.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'The Green Vessel',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'thorne',
          quote: '“She respects the old root-craft. Stocking her salves before entering the Vale is wise.”',
        },
      ],
      choices,
    };
  }

  // ==================== 5. BROTHER CAEL — CHAPEL KEEPER ====================
  if (npc.id === 'brother_cael') {
    const wellDiscovered = sq02.completedStepIds.includes('discover_well_symbol');
    const wellSolved = sq02.status === 'completed';

    const greeting = wellSolved
      ? '“Now that you and Scholar Edrin deciphered the subterranean aqueduct rune, the Last Light’s purpose is unmistakable: Gloamrest was built as an early-warning beacon for the Sanctum of the Shattered Oath.”'
      : '“Peace of the Last Light upon you, child. Our little stone chapel predates the village walls by centuries. Kneel by the sanctuary font if your party carries wounds—or speak freely if the whispers beneath the square trouble your spirit.”';

    const choices: TownDialogueChoice[] = [
      {
        id: 'cael_heal_blessing',
        text: '“[Sanctuary Blessing] Pray by the Chapel Font to restore our party’s Vitality.”',
        successReply:
          'Brother Cael traces a warm golden sigil above the font. Cool spring light washes over your party, restoring full HP and steadying your resolve.',
        onSuccess: {
          healPartyFull: true,
          completeQuestSteps:
            mq04.status === 'active'
              ? [{ questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' }]
              : undefined,
        },
      },
    ];

    if (wellDiscovered && !sq02.completedStepIds.includes('speak_brother_cael')) {
      choices.push({
        id: 'cael_sq02_well',
        text: '“I saw a glowing pre-schism rune submerged inside Hearth Square’s well. What is it?”',
        contextTag:
          characterBuild.backgroundId === 'sanctum_acolyte' ? '[Sanctum Acolyte]' : undefined,
        successReply:
          'Brother Cael pales. “The Seal of the Seventh Conduit... According to our chapel annals, the spring below Hearth Square flows directly from the vaults beneath the Sanctum of the Shattered Oath! Speak with Former Scholar Edrin Vale—he has been studying our archive scrolls and can help you decipher the well’s resonance.”',
        onSuccess: {
          startQuests: ['sq02_echoes_beneath_well'],
          completeQuestSteps: [
            { questId: 'sq02_echoes_beneath_well', stepId: 'speak_brother_cael' },
          ],
          approvalDeltas: { seraphina: 4, kaelen: 4 },
        },
      });
    } else if (sq02.status === 'not_started') {
      choices.push({
        id: 'cael_hint_well',
        text: '“Villagers say the ancient well glows faintly at night. Have you investigated it?”',
        successReply:
          '“My old eyes cannot make out the masonry down the shaft, but something etched in the wet stone answers the Sanctum’s unrest. Inspect the Ancient Well in Hearth Square closely, then return to me.”',
        onSuccess: {
          startQuests: ['sq02_echoes_beneath_well'],
        },
      });
    }

    if (
      sq02.completedStepIds.includes('pass_well_check') &&
      !sq02.completedStepIds.includes('confirm_oath_link')
    ) {
      choices.push({
        id: 'cael_complete_sq02',
        text: '“Edrin and I deciphered the rubbing: the well’s blue glow is an Astral surge leaking from the fractured Sanctum seal.”',
        successReply:
          '“Then the Seventh Watch’s warning has sounded after four hundred years! Take this Astral Clarity Elixir and 35 gold from the reliquary alms. Report this to Elder Aldric—only closing the rift at the Sanctum will quiet our waters.”',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'sq02_echoes_beneath_well', stepId: 'confirm_oath_link' },
          ],
          addFlags: ['well_oath_conduit_revealed'],
          approvalDeltas: { seraphina: 6, kaelen: 6 },
          chronicleNote: 'Uncovered the sacred aqueduct linking Gloamrest’s Well to the Sanctum of the Shattered Oath.',
        },
      });
    }

    if (!flags.has('cael_oath_counsel')) {
      choices.push({
        id: 'cael_oath_mercy',
        text: '“[Oath Reflection] Swear before the altar to shield the innocent of Whispering Vale above all else.”',
        successReply:
          '“Mercy requires greater strength than wrath. Seraphina nods solemnly beside the candles as the Last Light warms your crest.”',
        onSuccess: {
          addFlags: ['cael_oath_counsel'],
          oathShift: 'Mercy',
          approvalDeltas: { seraphina: 6, thorne: 3 },
          chronicleNote: 'Reaffirmed an Oath of Mercy in the Chapel of the Last Light.',
        },
      });
      choices.push({
        id: 'cael_oath_dominion',
        text: '“[Oath Reflection] Declare that any power—even Astral fire—must be seized to crush the Sanctum’s enemies.”',
        successReply:
          'Brother Cael shudders at your iron resolve, while Kaelen smiles knowingly. “Pray the flame you wield does not consume the hand that holds it.”',
        onSuccess: {
          addFlags: ['cael_oath_counsel'],
          oathShift: 'Dominion',
          approvalDeltas: { kaelen: 7, seraphina: -2 },
          chronicleNote: 'Swore uncompromising Dominion before the Altar of the Last Light.',
        },
      });
    }

    choices.push({
      id: 'cael_close',
      text: '“Go in peace, Brother Cael.”',
      successReply: '“The Last Light endures while one oath holds.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Chapel of the Last Light',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'seraphina',
          quote: '“Pre-schism lithography... Before the Prelates twisted our order, chapels like this sheltered all travelers.”',
        },
      ],
      choices,
    };
  }

  // ==================== 6. CAPTAIN RODERIC — GUARD CAPTAIN ====================
  if (npc.id === 'captain_roderic') {
    const postOutskirts = mq03.status === 'completed';
    const greeting = postOutskirts
      ? '“Fine tactical work beyond Whispering Gate, Commander! My sentries saw how you broke their flank. I’ve ordered timber barricades raised along the north wall.”'
      : '“At ease, adventurer. Watch Barracks keeps Gloamrest breathing while the woods turn feral. Step into my training yard if you want a live refresher on Action Points, High Ground, Enemy Telegraphs, and Environmental Shoves.”';

    const choices: TownDialogueChoice[] = [
      {
        id: 'roderic_tactical_drill',
        text: '“[Interactive Combat Tutorial] Walk me through Dimraeth’s tactical combat mechanics in the yard.”',
        successReply:
          'Captain Roderic strikes the armored practice dummy with his shield rim: “Watch closely! Every round runs on Initiative. Each unit gets 4 AP: moving spends your stride, while Skills [1–4] spend AP. Take High Ground (+2 Hit / +2 DMG), flank with an ally (+2 Hit), watch red Enemy Telegraphs, shove Runestones onto Rifts, and ignite Oil Pools with Fire!”',
        onSuccess: {
          triggerAction: 'start_training_drill',
          addFlags: ['completed_barracks_drill'],
        },
      },
      {
        id: 'roderic_live_sparring',
        text: '“[Enter Live Sparring Bout] Put my party through a real tactical combat exercise!”',
        successReply:
          '“Now you’re speaking my language! Ready your stances—let’s test your positioning and skills in live turn-based combat!”',
        onSuccess: {
          triggerAction: 'start_sparring_combat',
        },
        closesDialogue: true,
      },
    ];

    if (!flags.has('roderic_intimidation_bounty')) {
      const isMartial =
        characterBuild.classId === 'paladin' || characterBuild.backgroundId === 'ashen_exile';
      choices.push({
        id: 'roderic_intimidate_armory',
        text: '“[Intimidation] Your Watchmen are outnumbered, Captain. Issue us garrison bounty steel now instead of letting it gather dust.”',
        contextTag: isMartial ? '[Martial Presence +2]' : undefined,
        skillCheck: {
          stat: 'str',
          skillName: 'Intimidation',
          dc: 12,
          speakerId: 'seraphina',
          contextualBonusTag: isMartial ? 'Vanguard Command' : undefined,
          contextualBonusValue: isMartial ? 2 : 0,
        },
        successReply:
          'Roderic measures your stance, then barks a short laugh. “Steel belongs in hands that won’t drop it. Take a flask of lamp oil and 20 gold from the emergency bounty chest.”',
        failureReply:
          'Roderic doesn’t blink. “I’ve stared down Void-wolves uglier than that scowl, stranger. Earn bounty coin outside the gate like everyone else.”',
        onSuccess: {
          addFlags: ['roderic_intimidation_bounty'],
          goldDelta: 20,
          giveItems: [{ itemId: 'lamp_oil_flask', quantity: 1 }],
          approvalDeltas: { kaelen: 3, seraphina: 2 },
        },
        onFailure: {
          addFlags: ['roderic_intimidation_bounty'],
        },
      });
    }

    choices.push({
      id: 'roderic_close',
      text: '“Hold the northern wall, Captain.”',
      successReply: '“Eyes sharp, shields overlapping.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Watch Barracks',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'thorne',
          quote: '“His watchtower commands good sightlines over the river crossings.”',
        },
      ],
      choices,
    };
  }

  // ==================== 7. TESSA REED — GENERAL MERCHANT ====================
  if (npc.id === 'tessa_reed') {
    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Hearth Square Market Stall',
      activityStatus: schedule.activityLabel,
      greetingText:
        '“Lantern oil, trail rations, tempered lockpicks, and woven ley-cloaks! With the forest roads acting strange, smart travelers stock twice before stepping past Whispering Gate.”',
      companionInterjections: [
        {
          companionId: 'kaelen',
          quote: '“Lockpicks and refined oil—both remarkably persuasive tools in ancient ruins.”',
        },
      ],
      choices: [
        {
          id: 'tessa_open_shop',
          text: '“[Trade General Supplies] Let me see your wares, Tessa.”',
          successReply: '“Fair weights and honest silver—browse as long as you like!”',
          onSuccess: { openMerchantId: 'general_tessa' },
          closesDialogue: true,
        },
        {
          id: 'tessa_manor_tip',
          text: '“Any curious treasures or locked places around Gloamrest worth investigating?”',
          successReply:
            '“See that overgrown noble manor across the southern footbridge? Folks say the old steward hid a tarnished ward-key in the garden sundial urn—though a set of my Tempered Picks can coax rusted locks too!”',
          onSuccess: {
            startQuests: ['opt01_manor_of_shattered_vows'],
          },
        },
        {
          id: 'tessa_close',
          text: '“Safe trading, Tessa.”',
          successReply: '“Come back with full pouches!”',
          closesDialogue: true,
        },
      ],
    };
  }

  // ==================== 8. BRAM ALDER — CARPENTER ====================
  if (npc.id === 'bram_alder') {
    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Timber Yard',
      activityStatus: schedule.activityLabel,
      greetingText:
        '“Mind the sawdust! Between patching Garron’s splintered ore cart and cutting ironpine stakes for Captain Roderic, my saws haven’t cooled since Tuesday.”',
      companionInterjections: [
        {
          companionId: 'thorne',
          quote: '“Seasoned ironpine—light enough to carry, strong enough to turn a boar’s tusk.”',
        },
      ],
      choices: [
        {
          id: 'bram_open_shop',
          text: '“[Trade Timber & Materials] Show me your seasoned planks, shields, and pitch casks.”',
          successReply: '“Good honest Whispering Vale heartwood—buy or sell surplus materials anytime.”',
          onSuccess: { openMerchantId: 'carpenter_bram' },
          closesDialogue: true,
        },
        {
          id: 'bram_env_lesson',
          text: '“You mentioned pitch casks and heavy blocks—how can we use those in battle?”',
          successReply:
            '“Simple leverage! In tactical encounters, any fighter can Shove heavy runestone blocks onto Astral Rifts to seal ’em—or hurl a fire spell into a pitch-oil cask to set the whole choke point ablaze. Try shoving the practice barrel right outside my shed!”',
          onSuccess: {
            addFlags: ['learned_timber_physics'],
          },
        },
        {
          id: 'bram_close',
          text: '“Back to your saws, Bram.”',
          successReply: '“Measure twice, strike once!”',
          closesDialogue: true,
        },
      ],
    };
  }

  // ==================== 9. SERA WREN — SCOUT ====================
  if (npc.id === 'sera_wren') {
    const mq03Done = mq03.status === 'completed';
    const cluesChecked = mq03.completedStepIds.includes('inspect_forest_clues');
    const hasSanctumWrit =
      hasItem('sanctum_gate_writ') || flags.has('aldric_issued_sanctum_writ');

    const greeting = mq03Done
      ? hasSanctumWrit
        ? '“You’ve got Elder Aldric’s Sealed Writ, and my scouts cleared the fallen pines along the ridge. Whenever your party is equipped and ready, say the word and I’ll unbar the road to the Sanctum of the Shattered Oath!”'
        : '“The immediate ambush pack is broken thanks to you, Commander. Speak with Elder Aldric in Hearth Square to plan the march toward the Sanctum itself.”'
      : '“Keep your voice low near the treeline. Two hours ago I found scorched waymarkers and unnatural boot-tracks just past our stone bridge—whatever took the travelers is massing in the Whispering Outskirts.”';

    const choices: TownDialogueChoice[] = [];

    if (!mq03.completedStepIds.includes('speak_sera')) {
      choices.push({
        id: 'sera_start_mq03',
        text: '“Tell me what you tracked beyond Whispering Gate. We’ll sweep the forest road.”',
        contextTag:
          characterBuild.backgroundId === 'borderland_outrider' ? '[Borderland Outrider]' : undefined,
        successReply:
          '“Sharp eyes welcome! First inspect the scorched waystone and clawed tracks just across the gatehouse bridge—and check Garron’s splintered supply cart in the yard if you haven’t yet. Then interact with the Forest Road or tell me when you’re ready to engage the ambushers!”',
        onSuccess: {
          startQuests: ['mq02_trouble_at_ironroot', 'mq03_shadows_beyond_gate'],
          completeQuestSteps: [
            { questId: 'mq03_shadows_beyond_gate', stepId: 'speak_sera' },
          ],
          approvalDeltas: { thorne: 5 },
        },
      });
    }

    if (!mq03Done) {
      choices.push({
        id: 'sera_launch_outskirts_skirmish',
        text: `“[Leave Through Whispering Gate — MQ03 Combat] Lead us onto the Whispering Outskirts trail to confront the hostile vanguard!”`,
        successReply:
          'Sera unbars the heavy iron gate-bolt. “Weapons free! Watch their red attack telegraphs, use the ruined bastions for High Ground, and ignite the spilled lamp-oil along the trail!”',
        onSuccess: {
          startQuests: ['mq02_trouble_at_ironroot', 'mq03_shadows_beyond_gate'],
          completeQuestSteps: [
            { questId: 'mq03_shadows_beyond_gate', stepId: 'speak_sera' },
            ...(cluesChecked
              ? []
              : [{ questId: 'mq03_shadows_beyond_gate' as QuestId, stepId: 'inspect_forest_clues' }]),
            { questId: 'mq03_shadows_beyond_gate', stepId: 'leave_through_gate' },
          ],
          triggerAction: 'start_outskirts_combat',
        },
        closesDialogue: true,
      });
    }

    if (mq03Done && hasSanctumWrit) {
      choices.push({
        id: 'sera_confirm_ready_mq04',
        text: '“Verify our trail provisions and mark the high ridge route to the Sanctum.”',
        successReply:
          '“Quivers full, straps tight, companions rallied. The route into Act I — Sanctum of the Shattered Oath is open whenever you give the order!”',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
          ],
          addFlags: ['sanctum_route_unlocked'],
        },
      });

      choices.push({
        id: 'sera_depart_sanctum',
        text: '“[Depart Gloamrest → Act I: Sanctum of the Shattered Oath] Open the gates! Our party marches for the Sanctum.”',
        successReply:
          'The watch-horn echoes across Silverbrook as Whispering Gate swings wide. Your party strides beneath the ancient pines toward the Sanctum of the Shattered Oath!',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
            { questId: 'mq04_road_to_whispering_vale', stepId: 'depart_sanctum' },
          ],
          addFlags: ['sanctum_route_unlocked'],
          triggerAction: 'depart_act1_sanctum',
          chronicleNote: 'Departed Gloamrest through Whispering Gate toward the Sanctum of the Shattered Oath.',
        },
        closesDialogue: true,
      });
    }

    choices.push({
      id: 'sera_close',
      text: '“Keep watch on the bridge, Sera.”',
      successReply: '“Nothing crosses Silverbrook unseen.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Whispering Gate',
      activityStatus: schedule.activityLabel,
      greetingText: greeting,
      companionInterjections: [
        {
          companionId: 'thorne',
          quote: '“Her tracks match mine: three armored Covenant scouts and a Rift-hound pack beyond the bridge.”',
        },
      ],
      choices,
    };
  }

  // ==================== 10. OLD NYM — STORYTELLER ====================
  if (npc.id === 'old_nym') {
    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Gloamrest · Hearth & Tavern',
      activityStatus: schedule.activityLabel,
      greetingText:
        '“‘When silver stars drink from the stone, the Seventh Watch shall wake alone...’ Ah, forgive an old ballad-spinner! Folks think my verses are fairy tales, till the well starts singing in the dark.”',
      companionInterjections: [
        {
          companionId: 'kaelen',
          quote: '“Folk rhymes preserve pre-schism history better than censored cathedral libraries.”',
        },
      ],
      choices: [
        {
          id: 'nym_manor_ballad',
          text: '“What do your ballads say about the Abandoned Manor on the southeastern rise?”',
          successReply:
            '“House Veyne’s old seat! Lord Halcyon locked the oak doors when the Oath broke. They say he tucked the iron key inside the overgrown garden sundial—and hid a First Vigil vault behind a turning sconce beside the library hearth!”',
          onSuccess: {
            startQuests: ['opt01_manor_of_shattered_vows'],
            addFlags: ['heard_nym_manor_clue'],
          },
        },
        {
          id: 'nym_well_verse',
          text: '“Tell me the verse about Hearth Square’s ancient well.”',
          successReply:
            '“‘Three waters bound by silver thread, from Sanctum spire to village bed.’ Peer inside the well rim yourself, traveler—then ask Scholar Edrin Vale what those old letters spell!”',
          onSuccess: {
            startQuests: ['sq02_echoes_beneath_well'],
          },
        },
        {
          id: 'nym_close',
          text: '“May your voice never tire, Nym.”',
          successReply: '“May your deeds make a finer stanza than the last!”',
          closesDialogue: true,
        },
      ],
    };
  }

  // ==================== 11. EDRIN VALE — FORMER SCHOLAR ====================
  if (npc.id === 'edrin_vale') {
    const spokeCael = sq02.completedStepIds.includes('speak_brother_cael');
    const hasRubbing = hasItem('well_rubbing_parchment') || sq02.completedStepIds.includes('discover_well_symbol');
    const passedCheck = sq02.completedStepIds.includes('pass_well_check');

    const choices: TownDialogueChoice[] = [];

    if (!sq02.completedStepIds.includes('find_edrin_vale')) {
      choices.push({
        id: 'edrin_sq02_consult',
        text: '“Brother Cael said you’ve been studying the pre-schism inscriptions around the chapel and well.”',
        successReply:
          hasRubbing
            ? '“Yes! Let me see that well-sigil rubbing—by the Astral Spire, the syntax matches the Sanctum’s Seventh Seal! Let’s decipher the harmonic formula right now!”'
            : '“Indeed! If you inspect the Ancient Well in Hearth Square to take a rubbing of its submerged rune, we can decipher the exact link to the Sanctum!”',
        onSuccess: {
          startQuests: ['sq02_echoes_beneath_well'],
          completeQuestSteps: [
            ...(spokeCael
              ? []
              : [{ questId: 'sq02_echoes_beneath_well' as QuestId, stepId: 'speak_brother_cael' }]),
            { questId: 'sq02_echoes_beneath_well', stepId: 'find_edrin_vale' },
          ],
        },
      });
    }

    if (hasRubbing && !passedCheck) {
      const isArcaneScholar =
        characterBuild.classId === 'arcanist' ||
        characterBuild.backgroundId === 'court_chronicler' ||
        characterBuild.raceId === 'tiefling';
      choices.push({
        id: 'edrin_arcana_check',
        text: '“[Arcana Check] Translate the submerged Covenant rune and trace the subterranean ley-conduit.”',
        contextTag: isArcaneScholar ? '[Arcanist / Scholar +2]' : undefined,
        skillCheck: {
          stat: 'int',
          skillName: 'Arcana',
          dc: 12,
          speakerId: 'kaelen',
          contextualBonusTag: isArcaneScholar ? 'Planar Linguistics' : undefined,
          contextualBonusValue: isArcaneScholar ? 2 : 0,
        },
        successReply:
          'The runes align cleanly! “Astonishing—the well sits atop an underground warded aqueduct running straight beneath Whispering Vale into the Sanctum of the Shattered Oath. Bring word to Brother Cael at once!”',
        failureReply:
          'The archaic glyphs blur at the edges, stinging your eyes with cold blue static—yet Edrin manages to piece together the final clause after a tense pause: “Even with the damaged cipher, the conduit leads unmistakably to the Sanctum! Tell Brother Cael!”',
        onSuccess: {
          completeQuestSteps: [
            { questId: 'sq02_echoes_beneath_well', stepId: 'find_edrin_vale' },
            { questId: 'sq02_echoes_beneath_well', stepId: 'pass_well_check' },
          ],
          approvalDeltas: { kaelen: 7, seraphina: 3 },
          goldDelta: 15,
        },
        onFailure: {
          // Still allows advancing the side quest after a genuine roll, without blocking story, but without the bonus gold/approval!
          completeQuestSteps: [
            { questId: 'sq02_echoes_beneath_well', stepId: 'find_edrin_vale' },
            { questId: 'sq02_echoes_beneath_well', stepId: 'pass_well_check' },
          ],
        },
      });
    }

    choices.push({
      id: 'edrin_close',
      text: '“Guard your notes carefully, Scholar.”',
      successReply: '“Knowledge is the one lantern the Rift cannot snuff out.”',
      closesDialogue: true,
    });

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Chapel Archive & Hearth Square',
      activityStatus: schedule.activityLabel,
      greetingText: passedCheck
        ? '“Our translation holds without flaw: every pulse of blue light in Hearth Square’s well mirrors a fracture in the Sanctum’s seal.”'
        : '“Adjusting spectacles... Fascinating! The mason-marks on Gloamrest’s well-stones are identical to Fourth-Era Covenant citadel wards!”',
      companionInterjections: [
        {
          companionId: 'kaelen',
          quote: '“Finally, someone in this valley who reads High Astral script properly.”',
        },
      ],
      choices,
    };
  }

  // ==================== 12. LYSA THORN — MISSING-PERSON INVESTIGATOR ====================
  if (npc.id === 'lysa_thorn') {
    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Gloamrest Investigation Post',
      activityStatus: schedule.activityLabel,
      greetingText:
        '“Seven vanished travelers, zero ransoms demanded. Bandits take silver and leave wagons—whoever stalks Whispering Vale leaves the silver and takes the people toward the old Sanctum.”',
      companionInterjections: [
        {
          companionId: 'thorne',
          quote: '“She knows how to separate panicked rumor from cold trail evidence.”',
        },
      ],
      choices: [
        {
          id: 'lysa_share_notes',
          text: '“Share your case notes on the disappearances—we’re heading past Whispering Gate.”',
          successReply:
            '“Every abduction happened where underground spring vents surface near the road. Speak with Scout Sera Wren at Whispering Gate—she’s pinned the ambush group’s perimeter right now.”',
          onSuccess: {
            completeQuestSteps: [
              { questId: 'mq01_stranger_at_gloamrest', stepId: 'visit_tavern' },
              { questId: 'mq01_stranger_at_gloamrest', stepId: 'learn_missing_travelers' },
            ],
            startQuests: ['mq02_trouble_at_ironroot', 'mq03_shadows_beyond_gate'],
            approvalDeltas: { thorne: 3, seraphina: 3 },
          },
        },
        {
          id: 'lysa_close',
          text: '“We’ll bring answers back from the Vale, Lysa.”',
          successReply: '“Watch your flanks in the mist.”',
          closesDialogue: true,
        },
      ],
    };
  }

  // ==================== PARTY COMPANIONS IN GLOAMREST ====================
  if (npc.isCompanion) {
    const compId = npc.isCompanion;
    const quotes: Record<CompanionId, { greeting: string; reply: string }> = {
      seraphina: {
        greeting: `“Gloamrest reminds me why I swore my first shield-oath, ${characterBuild.commanderName}. Ordinary folk tending hearths on the edge of an ancient storm. Whatever awaits us at the Sanctum of the Shattered Oath, my blade stands beside yours.”`,
        reply: '“Our formation is unbreakable. Let’s ensure our gear and supplies are ready before Whispering Gate opens.”',
      },
      kaelen: {
        greeting: `“Feel the hum beneath these flagstones, ${characterBuild.commanderName}? Gloamrest sits right over a dormant Covenant ley-artery. Stock up on Elowen’s tonics and Garron’s steel—once we march into Whispering Vale, the real arcane test begins.”`,
        reply: '“My spellbook is primed. Lead on, Commander.”',
      },
      thorne: {
        greeting: `“The pines beyond the north wall are restless, ${characterBuild.commanderName}. Birds stopped singing along the Sanctum road at dusk. Check in with Sera Wren when you’re ready—my bow won’t miss.”`,
        reply: '“Quiver’s full and bowstring’s waxed. Ready for the road.”',
      },
    };

    return {
      npcId: npc.id,
      speakerName: npc.name,
      speakerRole: npc.role,
      portraitId: npc.portraitId,
      locationLabel: 'Sworn Party Companion · Gloamrest',
      activityStatus: schedule.activityLabel,
      greetingText: quotes[compId].greeting,
      companionInterjections: [],
      choices: [
        {
          id: `comp_rally_${compId}`,
          text: '“Check your gear and stay sharp—we march into Whispering Vale together soon.”',
          successReply: quotes[compId].reply,
          onSuccess: {
            approvalDeltas: { [compId]: 4 },
            completeQuestSteps: [
              { questId: 'mq04_road_to_whispering_vale', stepId: 'speak_companions' },
            ],
            chronicleNote: `Rallied ${npc.name} in Gloamrest ahead of the Whispering Vale march.`,
          },
        },
        {
          id: `comp_close_${compId}`,
          text: '“Carry on for now.”',
          successReply: '“At your side, Commander.”',
          closesDialogue: true,
        },
      ],
    };
  }

  // ==================== AMBIENT WATCH GUARD ====================
  const threatMsg =
    state.townThreatPhase === 'peaceful'
      ? '“Keep to the lantern-lit cobbles after dusk, traveler. Hearth Square lies straight up Pilgrim’s Causeway.”'
      : state.townThreatPhase === 'uneasy'
      ? '“Captain Roderic doubled our shifts since your clash beyond Whispering Gate. Nobody leaves town unarmed.”'
      : '“Did you see the blue light rising from Hearth Square’s well? Even the Watch bell rang on its own at midnight!”';

  return {
    npcId: npc.id,
    speakerName: npc.name,
    speakerRole: npc.role,
    portraitId: npc.portraitId,
    locationLabel: 'Gloamrest Town Watch',
    activityStatus: schedule.activityLabel,
    greetingText: threatMsg,
    companionInterjections: [],
    choices: [
      {
        id: 'guard_ack',
        text: '“Stay vigilant, Watchman.”',
        successReply: '“For Gloamrest and the Vale.”',
        closesDialogue: true,
      },
    ],
  };
}
