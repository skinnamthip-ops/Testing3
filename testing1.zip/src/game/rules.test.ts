import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  ALL_SKILLS_DATABASE,
  CUMULATIVE_XP_TABLE,
  MAX_CHARACTER_LEVEL,
  calculateLevelFromXp,
  getXpProgressForLevel,
  awardXp,
  createInitialProgressionState,
  unlockSkill,
  equipSkillToSlot,
  unequipSkillSlot,
  sanitizeEquippedSkills,
  spendAttributePoint,
  selectClassMastery,
  CLASS_MASTERY_CHOICES,
  verifySkillUniquenessAudit,
  applyProgressionToCommander,
  toCombatAbility,
} from './progressionData';
import {
  CombatUnit,
  getRelationshipTier,
  getCompanionSynergyBonus,
  manhattanDistance,
  chebyshevDistance,
  generateTacticalGrid,
  getValidMoveTiles,
  resolveAbilityUse,
  resolveSkillCheck,
  buildCombatRollToast,
  buildSkillCheckRollToast,
  evaluateTacticalAdvantage,
  computeEnemyTurnAction,
  createInitialRelationships,
  createInitialWorldState,
  createEncounterUnits,
  createEncounterObjects,
  resolveEnvironmentalInteraction,
  buildUnitInspectProfile,
  computeInitiativeRibbonEntries,
  getStatusEffectTooltipData,
  createDefaultCharacterBuild,
  computeCharacterBuildPreview,
  applyCharacterBuildToParty,
  CHARACTER_SUBCLASSES,
  DIALOGUE_NODES,
  isLastStandConditionMet,
  resolveWarriorDefensiveReactions,
  createWarriorTrialGroundsEncounter,
} from './rules';
import {
  assignUnitSkillToSlot,
  buildSkillDetailViewModel,
  evaluateSkillSlotState,
  getAvailableSkillCategories,
  getUnitClassIdentity,
  getUnitSkillCatalog,
} from './skillSystemUi';
import {
  GLOAMREST_ITEMS,
  GLOAMREST_MERCHANTS,
  GLOAMREST_QUESTS,
} from './gloamrestItemsAndQuests';
import {
  BUILDING_EXTERIORS,
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  TOWN_GRID_SIZE,
  TOWN_TILE_WORLD_SIZE,
  findTownPath,
  generateGloamrestExteriorGrid,
  generateInteriorGrid,
} from './gloamrestMapAndInteriors';
import {
  GLOAMREST_NPCS,
  buildGloamrestNpcDialogue,
  getNpcActiveSchedule,
} from './gloamrestNpcsAndDialogue';
import {
  applyEquippedGearToPartyUnits,
  buyFromMerchant,
  completeOutskirtsWildernessEncounter,
  createInitialGloamrestState,
  equipItemOnPartyMember,
  getActiveSceneNpcs,
  getAvailableMerchantStock,
  getSceneInteractiveObjects,
  interactWithGloamrestObject,
  movePlayerInGloamrest,
  repairPartyEquipment,
  resolveTownDialogueChoice,
  sellToMerchant,
} from './gloamrestEngine';

test('companion relationship tiers and synergy bonuses scale accurately', () => {
  assert.equal(getRelationshipTier(10), 'Hostile');
  assert.equal(getRelationshipTier(35), 'Guarded');
  assert.equal(getRelationshipTier(60), 'Comrade');
  assert.equal(getRelationshipTier(80), 'Trusted');
  assert.equal(getRelationshipTier(95), 'Sworn Bond');

  const swornBonus = getCompanionSynergyBonus(92);
  assert.equal(swornBonus.attackBonus, 3);
  assert.equal(swornBonus.damageBonus, 4);
  assert.equal(swornBonus.critThreshold, 18);
});

test('tactical grid generation respects world reactivity flags', () => {
  const initialWorld = createInitialWorldState();
  const gridDefault = generateTacticalGrid(0, initialWorld);
  assert.equal(gridDefault[4][4].terrain, 'hazard_rift');
  assert.equal(gridDefault[2][4].walkable, false); // Pillar cover
  assert.equal(gridDefault[1][6].elevation, 1); // High ground bastion

  const purifiedWorld = {
    ...initialWorld,
    flags: ['sanctum_purified' as const],
  };
  const gridPurified = generateTacticalGrid(0, purifiedWorld);
  assert.notEqual(gridPurified[4][4].terrain, 'hazard_rift');
});

test('valid move tiles respect move range, obstacles, and occupied units', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const units = createEncounterUnits(0, world);
  const seraphina = units.find((u) => u.id === 'seraphina')!;

  const moves = getValidMoveTiles(seraphina, grid, units);
  assert.ok(moves.length > 0);
  for (const m of moves) {
    assert.ok(chebyshevDistance(seraphina.gridX, seraphina.gridZ, m.x, m.z) <= seraphina.moveRange);
    assert.equal(grid[m.x][m.z].walkable, true);
  }
});

test('combat resolution applies high ground, flanking, and companion synergy', () => {
  const world = createInitialWorldState();
  const relationships = createInitialRelationships();
  relationships.seraphina.approval = 90; // Sworn Bond (+3 attack, +4 dmg, crit on 18+)

  const units = createEncounterUnits(0, world);
  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const enemy = units.find((u) => u.faction === 'enemy')!;

  // Put Seraphina on high ground adjacent to enemy
  seraphina.gridX = 4;
  seraphina.gridZ = 2;
  seraphina.elevation = 1;
  enemy.gridX = 4;
  enemy.gridZ = 1;
  enemy.elevation = 0;

  // Put Thorne adjacent to enemy for flanking
  const thorne = units.find((u) => u.id === 'thorne')!;
  thorne.gridX = 3;
  thorne.gridZ = 1;

  const res = resolveAbilityUse(
    seraphina,
    enemy,
    seraphina.abilities[0],
    units,
    relationships,
    world,
    18 // Roll 18 -> Critical because Sworn Bond critThreshold is 18
  );

  assert.equal(res.hit, true);
  assert.equal(res.critical, true);
  assert.equal(res.highGroundBonus, 2);
  assert.equal(res.flankingBonus, 2);
  assert.equal(res.synergyBonus, 3);
  assert.ok(res.damage >= 20);

  const combatToast = buildCombatRollToast(seraphina, enemy, seraphina.abilities[0], res, 101);
  assert.equal(combatToast.d20Roll, 18);
  assert.equal(combatToast.critical, true);
  assert.equal(combatToast.outcomeBadge, 'CRITICAL HIT!');
  assert.ok(combatToast.equationText.includes('1d20 (18)'));
  assert.ok(combatToast.equationText.includes('High Ground (+2)'));
  assert.ok(combatToast.equationText.includes('Flanking (+2)'));
  assert.ok(combatToast.equationText.includes('Sworn Bond (+3)'));
});

test('D20 skill check resolution computes modifiers, DC threshold, and toast breakdown', () => {
  const world = createInitialWorldState();
  const units = createEncounterUnits(0, world);
  const relationships = createInitialRelationships();
  const choice = DIALOGUE_NODES.act1_sanctum_parley.choices[0]; // Persuasion DC 12

  const passResult = resolveSkillCheck(choice, units, relationships, 14);
  assert.equal(passResult.success, true);
  assert.ok(passResult.total >= 12);

  const skillToast = buildSkillCheckRollToast(choice, passResult, relationships, 202);
  assert.equal(skillToast.kind, 'skill');
  assert.equal(skillToast.d20Roll, 14);
  assert.equal(skillToast.success, true);
  assert.ok(skillToast.equationText.includes('1d20 (14)'));
  assert.ok(skillToast.equationText.includes('vs DC 12'));

  const failResult = resolveSkillCheck(choice, units, relationships, 2);
  assert.equal(failResult.success, false);
});

test('three enemy archetypes exhibit genuinely distinct movement and targeting policies', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const units = createEncounterUnits(0, world);

  // Give Kaelen lower HP so Stalker specifically hunts Kaelen while Inquisitor targets highest-HP Seraphina
  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const kaelen = units.find((u) => u.id === 'kaelen')!;
  seraphina.hp = 44;
  kaelen.hp = 15;

  const stalker = units.find((u) => u.archetype === 'stalker')!;
  const inquisitor = units.find((u) => u.archetype === 'inquisitor')!;
  const weaver = units.find((u) => u.archetype === 'weaver')!;

  const stalkerPlan = computeEnemyTurnAction(stalker, units, grid);
  const inquisitorPlan = computeEnemyTurnAction(inquisitor, units, grid);
  const weaverPlan = computeEnemyTurnAction(weaver, units, grid);

  assert.equal(stalkerPlan.targetUnitId, 'kaelen'); // Stalker hunts lowest HP target
  assert.equal(inquisitorPlan.targetUnitId, 'seraphina'); // Inquisitor confronts highest HP vanguard
  assert.ok(weaverPlan.ability.range >= 5); // Weaver uses ranged arcane barrage from high ground

  // Ensure enemy pathing does not step onto intact environmental objects
  const envObjects = createEncounterObjects(0);
  const stalkerPlanWithObjs = computeEnemyTurnAction(stalker, units, grid, envObjects);
  const occupiedByObj = envObjects.some(
    (o) => !o.destroyed && o.gridX === stalkerPlanWithObjs.moveTo.x && o.gridZ === stalkerPlanWithObjs.moveTo.z
  );
  assert.equal(occupiedByObj, false);
});

test('tactical advantage evaluator shifts cleanly between balanced, party ascendant, and enemy dominance', () => {
  const world = createInitialWorldState();
  const units = createEncounterUnits(0, world);

  // 1. Opening state is evenly matched
  const opening = evaluateTacticalAdvantage(units, world);
  assert.equal(opening.state, 'evenly_matched');
  assert.equal(opening.themeTitle, 'Clash of Oaths');

  // 2. When party weakens or KOs an enemy and gains Blessed, party has tactical advantage
  const partyEdgeUnits = units.map((u) => {
    if (u.archetype === 'stalker') return { ...u, hp: 0, isKO: true };
    if (u.id === 'seraphina') return { ...u, statuses: [{ type: 'blessed' as const, turnsLeft: 2 }] };
    return u;
  });
  const partyAdv = evaluateTacticalAdvantage(partyEdgeUnits, world);
  assert.equal(partyAdv.state, 'party_ascendant');
  assert.equal(partyAdv.themeTitle, 'Ascendant Dawn');

  // 3. When party takes heavy damage / KO and debuffs, enemy has tactical advantage
  const enemyEdgeUnits = units.map((u) => {
    if (u.id === 'kaelen') return { ...u, hp: 0, isKO: true };
    if (u.id === 'seraphina') return { ...u, hp: 10, statuses: [{ type: 'sundered' as const, turnsLeft: 2 }] };
    return u;
  });
  const enemyAdv = evaluateTacticalAdvantage(enemyEdgeUnits, world);
  assert.equal(enemyAdv.state, 'enemy_dominance');
  assert.equal(enemyAdv.themeTitle, 'Ashen Eclipse');
});

test('environmental interactions: fire abilities ignite connected oil pools and detonate volatile barrels', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const units = createEncounterUnits(0, world);
  const envObjects = createEncounterObjects(0);

  // Verify initial oil_pool surfaces at (3,2), (3,3) and (6,2), (6,3)
  assert.equal(grid[3][2].surface, 'oil_pool');
  assert.equal(grid[3][3].surface, 'oil_pool');
  assert.equal(grid[6][3].surface, 'oil_pool');

  // Place Stalker on oil tile (3,2)
  const stalker = units.find((u) => u.archetype === 'stalker')!;
  stalker.gridX = 3;
  stalker.gridZ = 2;
  const initialStalkerHp = stalker.hp;

  const kaelen = units.find((u) => u.id === 'kaelen')!;
  const fireAbility = kaelen.abilities.find((a) => a.id === 'crimson_tempest')!; // element: 'fire'

  // Cast fire ability on connected oil tile (3,3)
  const reaction = resolveEnvironmentalInteraction(
    kaelen,
    fireAbility,
    3,
    3,
    grid,
    envObjects,
    units
  );

  assert.ok(reaction.triggeredEvents.length > 0);
  assert.equal(reaction.updatedGrid[3][3].surface, 'fire_pool');
  assert.equal(reaction.updatedGrid[3][2].surface, 'fire_pool'); // Chain reaction ignited connected oil tile!
  const updatedStalker = reaction.updatedUnits.find((u) => u.id === stalker.id)!;
  assert.ok(updatedStalker.hp < initialStalkerHp);
  assert.ok(updatedStalker.statuses.some((s) => s.type === 'burning'));

  // Cast fire ability on Alchemical Oil Cask at (6,3)
  const barrelReaction = resolveEnvironmentalInteraction(
    kaelen,
    fireAbility,
    6,
    3,
    reaction.updatedGrid,
    reaction.updatedObjects,
    reaction.updatedUnits
  );
  assert.ok(barrelReaction.triggeredEvents.length > 0);
  const barrel = barrelReaction.updatedObjects.find((o) => o.kind === 'oil_barrel')!;
  assert.equal(barrel.destroyed, true);
  assert.equal(barrelReaction.updatedGrid[6][3].surface, 'fire_pool');
  assert.equal(barrelReaction.updatedGrid[6][2].surface, 'fire_pool');
});

test('environmental interactions: pushing runestone block seals astral rift or collides with enemy', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const units = createEncounterUnits(0, world);
  const envObjects = createEncounterObjects(0);

  // Runestone Push-Block starts at (4,5); tile (4,4) is 'hazard_rift'
  assert.equal(grid[4][4].terrain, 'hazard_rift');
  const seraphina = units.find((u) => u.id === 'seraphina')!;
  seraphina.gridX = 4;
  seraphina.gridZ = 6; // Standing South of (4,5) so shoving pushes North toward (4,4)
  const pushAbility = seraphina.abilities[0]; // sunblade_cleave has pushDistance: 1

  const shoveRes = resolveEnvironmentalInteraction(
    seraphina,
    pushAbility,
    4,
    5,
    grid,
    envObjects,
    units
  );

  assert.ok(shoveRes.triggeredEvents.length > 0);
  const monolith = shoveRes.updatedObjects.find((o) => o.kind === 'runestone_block')!;
  assert.equal(monolith.gridX, 4);
  assert.equal(monolith.gridZ, 4);
  assert.equal(shoveRes.updatedGrid[4][4].terrain, 'stone'); // Rift sealed!
  assert.ok(shoveRes.triggeredEvents.some((l) => l.includes('seals the Astral Rift')));
});

test('unit inspect profile computes attribute modifiers, effective AC, active statuses, and damage dice formulas', () => {
  const world = createInitialWorldState();
  world.flags.push('blood_weave_unleashed');
  world.oathAlignment = 'Mercy';

  const relationships = createInitialRelationships();
  relationships.seraphina.approval = 85; // Trusted (+2 Hit, +2 DMG, Crit 19-20)

  const units = createEncounterUnits(0, world);
  const seraphina = units.find((u) => u.id === 'seraphina')!;
  seraphina.elevation = 1;
  seraphina.statuses = [
    { type: 'blessed', turnsLeft: 2 },
    { type: 'warded', turnsLeft: 2 },
  ];

  const profile = buildUnitInspectProfile(seraphina, relationships, world);

  assert.equal(profile.unitId, 'seraphina');
  assert.equal(profile.effectiveAC, 17); // Base 15 + 2 Warded
  assert.ok(profile.acBreakdown.includes('+2 Warded'));
  assert.equal(profile.critRangeLabel, '19–20');
  assert.equal(profile.statuses.length, 2);
  assert.equal(profile.statuses[0].label, 'Blessed');

  const strStat = profile.stats.find((s) => s.key === 'str')!;
  assert.equal(strStat.isPrimary, true);
  assert.equal(strStat.formattedModifier, '+4');

  // Verify Sunblade Cleave [8, 13] -> 1d6 + 7 base + 2 Trusted + 3 Blood-Weave + 2 High Ground = 15-20 Fire DMG
  const cleave = profile.abilities.find((a) => a.id === 'sunblade_cleave')!;
  assert.ok(cleave.diceFormula.includes('1d6 + 7'));
  assert.ok(cleave.diceFormula.includes('+2 Trusted'));
  assert.ok(cleave.diceFormula.includes('+3 Blood-Weave'));
  assert.ok(cleave.diceFormula.includes('+2 High Ground'));
  assert.equal(cleave.effectiveOutputLabel, '15–20 Fire DMG');

  // Verify Dawnlight Mending heal ability includes Mercy Oath bonus
  const mend = profile.abilities.find((a) => a.id === 'lay_on_hands')!;
  assert.ok(mend.diceFormula.includes('+3 Mercy Oath'));
  assert.equal(mend.effectiveOutputLabel, '+17 HP Radiant Heal');
});

test('initiative ribbon retains units reaching 0 HP in collapsing state before removing them as KO', () => {
  const world = createInitialWorldState();
  const units = createEncounterUnits(0, world);
  const stalker = units.find((u) => u.archetype === 'stalker')!;

  // 1. All 6 units start active
  const initialRibbon = computeInitiativeRibbonEntries(units, new Set());
  assert.equal(initialRibbon.length, 6);
  assert.ok(initialRibbon.every((e) => e.collapseState === 'active'));

  // 2. Stalker reaches 0 HP and enters collapsing set -> still in ribbon with collapseState: 'collapsing'
  stalker.hp = 0;
  stalker.isKO = true;
  const duringCollapseRibbon = computeInitiativeRibbonEntries(units, new Set([stalker.id]));
  assert.equal(duringCollapseRibbon.length, 6);
  const stalkerEntry = duringCollapseRibbon.find((e) => e.unit.id === stalker.id)!;
  assert.equal(stalkerEntry.collapseState, 'collapsing');

  // 3. Once collapse animation finishes and ID leaves collapsing set -> removed from active initiative ribbon
  const afterCollapseRibbon = computeInitiativeRibbonEntries(units, new Set());
  assert.equal(afterCollapseRibbon.length, 5);
  assert.equal(
    afterCollapseRibbon.some((e) => e.unit.id === stalker.id),
    false
  );
});

test('getStatusEffectTooltipData returns full mechanical effect, category, and formatted turn duration', () => {
  const blessed = getStatusEffectTooltipData('blessed', 2);
  assert.equal(blessed.label, 'Blessed');
  assert.equal(blessed.isBuff, true);
  assert.equal(blessed.categoryLabel, 'Beneficial Buff');
  assert.equal(blessed.shortClue, '+2 Attack');
  assert.ok(blessed.mechanicalEffect.includes('+2 to Attack Rolls'));
  assert.equal(blessed.durationLabel, '2 Turns Remaining');

  const burning = getStatusEffectTooltipData('burning', 1);
  assert.equal(burning.label, 'Burning');
  assert.equal(burning.isBuff, false);
  assert.equal(burning.categoryLabel, 'Affliction Debuff');
  assert.equal(burning.shortClue, '-3 HP/turn');
  assert.ok(burning.mechanicalEffect.includes('3 Fire DMG at the start of each turn'));
  assert.equal(burning.durationLabel, '1 Turn Remaining');

  const sundered = getStatusEffectTooltipData('sundered', 3);
  assert.equal(sundered.label, 'Sundered');
  assert.equal(sundered.isBuff, false);
  assert.ok(sundered.mechanicalEffect.includes('-2 Armor Class penalty'));
  assert.equal(sundered.durationLabel, '3 Turns Remaining');

  const warded = getStatusEffectTooltipData('warded');
  assert.equal(warded.label, 'Warded');
  assert.equal(warded.isBuff, true);
  assert.equal(warded.durationLabel, 'Active until dispelled');
});

test('character creation build computes race, class, and subclass stats and applies them to the party commander', () => {
  const defaultBuild = createDefaultCharacterBuild();
  const defaultPreview = computeCharacterBuildPreview(defaultBuild);
  assert.equal(defaultPreview.commanderName, 'Seraphina Vane');
  assert.equal(defaultPreview.race.id, 'half_elf');
  assert.equal(defaultPreview.classDef.id, 'paladin');
  assert.equal(defaultPreview.subclass.id, 'vengeance_knight');

  // Test switching to Ashen Tiefling + Blood-Weave Arcanist + Crimson Savant
  const customBuild = {
    commanderName: 'Lyra Noctis',
    raceId: 'tiefling' as const,
    classId: 'arcanist' as const,
    subclassId: 'crimson_savant' as const,
  };
  const preview = computeCharacterBuildPreview(customBuild);
  assert.equal(preview.commanderName, 'Lyra Noctis');
  assert.equal(preview.stats.int, 21); // Base 16 + Tiefling 2 + Crimson Savant 3
  assert.equal(preview.moveRange, 5); // Base 4 + Tiefling 1
  assert.equal(preview.signatureAbility.name, 'Searing Blood-Nova');
  assert.equal(preview.startingStatus, 'blessed');

  const world = createInitialWorldState();
  const rawUnits = createEncounterUnits(0, world);
  const rawRels = createInitialRelationships();
  const applied = applyCharacterBuildToParty(rawUnits, rawRels, customBuild);

  const commander = applied.units.find((u) => u.id === 'seraphina')!;
  assert.equal(commander.name, 'Lyra Noctis');
  assert.equal(commander.title, 'Crimson Savant Arcanist');
  assert.equal(commander.stats.int, 21);
  assert.equal(commander.moveRange, 5);
  assert.ok(commander.statuses.some((s) => s.type === 'blessed' && s.turnsLeft === 2));
  assert.equal(commander.abilities[1].name, 'Searing Blood-Nova');
  assert.equal(commander.abilities[0].name, 'Astral Soul-Blade');
  assert.equal(commander.abilities[2].id, 'gravity_shackle');
  assert.equal(commander.abilities[3].id, 'arcane_conduit');
  assert.ok(applied.relationships.seraphina.raceClass.includes('Ashen Tiefling'));
  assert.ok(applied.relationships.seraphina.raceClass.includes('Crimson Savant'));
});

test('mechanical uniqueness audit: all 22 party, subclass, and enemy skills have unique IDs, mechanics, and standalone SVG icons', () => {
  const world = createInitialWorldState();
  const baseUnits = createEncounterUnits(0, world);
  const rels = createInitialRelationships();

  const subclassEntries = Object.values(CHARACTER_SUBCLASSES);
  const subclassSigIds = subclassEntries.map((s) => s.signatureAbility.id);
  assert.equal(
    new Set(subclassSigIds).size,
    subclassEntries.length,
    'Every subclass signature ability must have a distinct skill ID'
  );

  const subclassMechanics = subclassEntries.map((s) => s.signatureAbility.uniqueMechanicLabel);
  assert.equal(
    new Set(subclassMechanics).size,
    subclassEntries.length,
    'Every subclass signature ability must have a distinct central mechanic'
  );

  // Collect all 19 party/subclass skills + 3 enemy archetype skills = 22 total skills
  const allSkillsMap = new Map<string, string>();
  for (const u of baseUnits) {
    for (const ab of u.abilities) {
      allSkillsMap.set(ab.id, ab.uniqueMechanicLabel ?? ab.roleClue);
    }
  }
  for (const sub of subclassEntries) {
    allSkillsMap.set(
      sub.signatureAbility.id,
      sub.signatureAbility.uniqueMechanicLabel ?? sub.signatureAbility.roleClue
    );
  }
  for (const classId of ['paladin', 'arcanist', 'warden'] as const) {
    const subId =
      classId === 'paladin'
        ? 'dawn_warden'
        : classId === 'arcanist'
        ? 'rift_chronomancer'
        : 'briar_stalker';
    const built = applyCharacterBuildToParty(baseUnits, rels, {
      commanderName: 'Audit Hero',
      raceId: 'half_elf',
      classId,
      subclassId: subId,
    });
    const cmd = built.units.find((u) => u.id === 'seraphina')!;
    assert.equal(cmd.abilities.length, 4);
    for (const ab of cmd.abilities) {
      allSkillsMap.set(ab.id, ab.uniqueMechanicLabel ?? ab.roleClue);
    }
  }

  assert.equal(allSkillsMap.size, 22, 'Should register all 19 party/subclass skills + 3 enemy skills');
  assert.equal(
    new Set(allSkillsMap.values()).size,
    22,
    'All 22 skills must possess non-duplicate mechanical descriptions'
  );

  // Verify standalone individual SVG icon file exists for every single skill ID
  const iconDir = path.resolve(process.cwd(), 'public', 'assets', 'icons', 'skills');
  for (const skillId of allSkillsMap.keys()) {
    const svgPath = path.join(iconDir, `${skillId}.svg`);
    assert.equal(fs.existsSync(svgPath), true, `Missing standalone SVG icon for ${skillId}`);
    const content = fs.readFileSync(svgPath, 'utf8');
    assert.ok(content.includes('<svg'), `${skillId}.svg must be a valid vector SVG asset`);
  }
});

test('Class 1 — Paladin skills: Sweeping Arc cleave, 5-Tile Solar Cross, Vengeance Leap + Execution + AP Refund, Purge, and Squad Phalanx', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const envObjects = createEncounterObjects(0);
  const rels = createInitialRelationships();
  const units = createEncounterUnits(0, world);

  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const kaelen = units.find((u) => u.id === 'kaelen')!;
  const inquisitor = units.find((u) => u.archetype === 'inquisitor')!;
  const stalker = units.find((u) => u.archetype === 'stalker')!;

  // 1. Sunblade Cleave: Sweeping Vanguard Arc hits mutually adjacent secondary enemy + pushes primary
  seraphina.gridX = 4;
  seraphina.gridZ = 6;
  inquisitor.gridX = 4;
  inquisitor.gridZ = 5;
  stalker.gridX = 3;
  stalker.gridZ = 6; // Chebyshev <= 1 to both (4,6) and (4,5)
  const stalkerStartHp = stalker.hp;

  const cleaveEnv = resolveEnvironmentalInteraction(
    seraphina,
    seraphina.abilities[0],
    4,
    5,
    grid,
    [],
    units,
    inquisitor.id
  );
  const cleavedStalker = cleaveEnv.updatedUnits.find((u) => u.id === stalker.id)!;
  assert.equal(cleavedStalker.hp, stalkerStartHp - 5);
  assert.ok(cleavedStalker.statuses.some((s) => s.type === 'burning'));

  // 2. Dawnbreaker Judgment (Dawn Warden): 5-Tile Solar Cross purifies hazards & heals allies in cross
  const dawnJudgment = CHARACTER_SUBCLASSES.dawn_warden.signatureAbility;
  kaelen.gridX = 4;
  kaelen.gridZ = 4;
  kaelen.hp = 20;
  inquisitor.gridX = 5;
  inquisitor.gridZ = 4; // Center of cross; (4,4) and (5,4) are hazard_rift tiles!

  const crossRes = resolveEnvironmentalInteraction(
    seraphina,
    dawnJudgment,
    5,
    4,
    grid,
    envObjects,
    units,
    inquisitor.id
  );
  assert.equal(crossRes.updatedGrid[5][4].surface, 'sanctified_pool');
  assert.equal(crossRes.updatedGrid[4][4].surface, 'sanctified_pool');
  assert.equal(crossRes.updatedGrid[5][4].terrain, 'stone'); // Rift purified!
  const healedKaelen = crossRes.updatedUnits.find((u) => u.id === 'kaelen')!;
  assert.equal(healedKaelen.hp, 26); // +6 HP from Solar Cross!
  assert.ok(healedKaelen.statuses.some((s) => s.type === 'blessed'));

  // 3. Oathbreaker Smite (Vengeance Knight): +6 Bloodied Execution, +1 AP Refund on KO, and Range-2 Gap-Close Leap
  const vengeanceSmite = CHARACTER_SUBCLASSES.vengeance_knight.signatureAbility;
  seraphina.gridX = 3;
  seraphina.gridZ = 7;
  stalker.gridX = 3;
  stalker.gridZ = 5; // Distance 2 -> triggers leap to (3,6)!
  stalker.hp = 10; // <= 50% of 24 Max HP -> triggers +6 Execution & KO!

  const smiteHit = resolveAbilityUse(seraphina, stalker, vengeanceSmite, units, rels, world, 15);
  assert.equal(smiteHit.hit, true);
  assert.equal(smiteHit.bonusConditionalDamage, 6);
  assert.equal(smiteHit.targetKO, true);
  assert.equal(smiteHit.apRefunded, 1);

  const smiteLeap = resolveEnvironmentalInteraction(
    seraphina,
    vengeanceSmite,
    3,
    5,
    grid,
    [],
    units,
    stalker.id
  );
  const leapedPaladin = smiteLeap.updatedUnits.find((u) => u.id === 'seraphina')!;
  assert.equal(manhattanDistance(leapedPaladin.gridX, leapedPaladin.gridZ, 3, 5), 1);

  // 4. Dawnlight Mending: Full affliction purge (burning, rooted, sundered) + tile consecration
  kaelen.statuses = [
    { type: 'burning', turnsLeft: 2 },
    { type: 'rooted', turnsLeft: 2 },
    { type: 'sundered', turnsLeft: 2 },
  ];
  const mendAbility = seraphina.abilities.find((a) => a.id === 'lay_on_hands')!;
  const mendRes = resolveAbilityUse(seraphina, kaelen, mendAbility, units, rels, world, 12);
  assert.deepEqual(mendRes.cleansedStatuses, ['burning', 'rooted', 'sundered']);
  const mendEnv = resolveEnvironmentalInteraction(
    seraphina,
    mendAbility,
    kaelen.gridX,
    kaelen.gridZ,
    grid,
    [],
    units,
    kaelen.id
  );
  const cleansedKaelen = mendEnv.updatedUnits.find((u) => u.id === 'kaelen')!;
  assert.equal(cleansedKaelen.statuses.length, 1);
  assert.equal(cleansedKaelen.statuses[0].type, 'blessed');
  assert.equal(mendEnv.updatedGrid[kaelen.gridX][kaelen.gridZ].surface, 'sanctified_pool');

  // 5. Sovereign Aegis: +8 Self Temp HP + Radius-2 Squad Phalanx (+4 Temp HP to nearby ally)
  seraphina.gridX = 4;
  seraphina.gridZ = 7;
  kaelen.gridX = 5;
  kaelen.gridZ = 7; // Distance 1 <= 2
  const aegisAbility = seraphina.abilities.find((a) => a.id === 'aegis_bulwark')!;
  const aegisEnv = resolveEnvironmentalInteraction(
    seraphina,
    aegisAbility,
    4,
    7,
    grid,
    [],
    units,
    seraphina.id
  );
  assert.equal(aegisEnv.updatedUnits.find((u) => u.id === 'seraphina')!.tempHp, 8);
  assert.equal(aegisEnv.updatedUnits.find((u) => u.id === 'kaelen')!.tempHp, 4);
});

test('Class 2 — Arcanist skills: Linear Piercing Ray, Thermal Resonance 3x3 Blast, Vacuum Implosion, Tether Pull, and Phase Move Reset', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const rels = createInitialRelationships();
  const units = createEncounterUnits(0, world);

  const kaelen = units.find((u) => u.id === 'kaelen')!;
  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const inquisitor = units.find((u) => u.archetype === 'inquisitor')!;
  const weaver = units.find((u) => u.archetype === 'weaver')!;
  const stalker = units.find((u) => u.archetype === 'stalker')!;

  // 1. Astral Lance: Linear Piercing Ray hits enemy behind primary target along vector
  kaelen.gridX = 5;
  kaelen.gridZ = 7;
  inquisitor.gridX = 5;
  inquisitor.gridZ = 4;
  stalker.gridX = 5;
  stalker.gridZ = 3; // 1 tile directly behind inquisitor along (0, -1) ray!
  const stalkerHpBefore = stalker.hp;

  const rayEnv = resolveEnvironmentalInteraction(
    kaelen,
    kaelen.abilities[0],
    5,
    4,
    grid,
    [],
    units,
    inquisitor.id
  );
  assert.equal(rayEnv.updatedUnits.find((u) => u.id === stalker.id)!.hp, stalkerHpBefore - 5);

  // 2. Crimson Singularity / Searing Blood-Nova: +5 Thermal Resonance vs Burning + 3x3 Blast
  inquisitor.statuses = [{ type: 'burning', turnsLeft: 2 }];
  const bloodNova = CHARACTER_SUBCLASSES.crimson_savant.signatureAbility;
  const novaHit = resolveAbilityUse(kaelen, inquisitor, bloodNova, units, rels, world, 15);
  assert.equal(novaHit.bonusConditionalDamage, 5);
  assert.ok(novaHit.conditionalMechanicNote?.includes('Thermal Resonance'));

  // 3. Chrono-Rift Collapse (Rift Chronomancer): Vacuums enemies within Chebyshev 2 inward
  const chronoCollapse = CHARACTER_SUBCLASSES.rift_chronomancer.signatureAbility;
  inquisitor.gridX = 5;
  inquisitor.gridZ = 5;
  stalker.gridX = 3;
  stalker.gridZ = 5; // Chebyshev distance 2 -> pulled inward to (4,5)!
  const vacuumEnv = resolveEnvironmentalInteraction(
    kaelen,
    chronoCollapse,
    5,
    5,
    grid,
    [],
    units,
    inquisitor.id
  );
  const pulledStalker = vacuumEnv.updatedUnits.find((u) => u.id === stalker.id)!;
  assert.equal(pulledStalker.gridX, 4);
  assert.equal(pulledStalker.gridZ, 5);

  // 4. Rift Singularity Bind (gravity_shackle): Yanks Weaver off High Ground bastion (+4 Shear DMG & Rooted)
  weaver.gridX = 7;
  weaver.gridZ = 2;
  weaver.elevation = 1; // High ground bastion
  kaelen.gridX = 7;
  kaelen.gridZ = 6; // South of Weaver -> pulls Weaver South to (7,4)? Wait: (7,3) is bastion, so put Weaver at (7,3) elev 1 -> pulled to (7,4) pillar? Let's use (8,3) elev 1 -> pulled to (8,4) elev 0!
  weaver.gridX = 8;
  weaver.gridZ = 3;
  weaver.elevation = 1;
  kaelen.gridX = 8;
  kaelen.gridZ = 6;
  const weaverHpBefore = weaver.hp;
  const shackle = kaelen.abilities.find((a) => a.id === 'gravity_shackle')!;
  const pullEnv = resolveEnvironmentalInteraction(
    kaelen,
    shackle,
    8,
    3,
    grid,
    [],
    units,
    weaver.id
  );
  const yankedWeaver = pullEnv.updatedUnits.find((u) => u.id === weaver.id)!;
  assert.equal(yankedWeaver.gridX, 8);
  assert.equal(yankedWeaver.gridZ, 4);
  assert.equal(yankedWeaver.elevation, 0); // Pulled off high ground!
  assert.equal(yankedWeaver.hp, weaverHpBefore - 4); // +4 Gravitational Shear DMG!
  assert.ok(yankedWeaver.statuses.some((s) => s.type === 'rooted'));

  // 5. Weave Transfusion (arcane_conduit): Resets target ally's movedThisTurn + cleanses Rooted + grants +5 Temp HP
  seraphina.movedThisTurn = true;
  seraphina.statuses = [{ type: 'rooted', turnsLeft: 2 }];
  const conduit = kaelen.abilities.find((a) => a.id === 'arcane_conduit')!;
  const conduitRes = resolveAbilityUse(kaelen, seraphina, conduit, units, rels, world, 14);
  assert.equal(conduitRes.resetTargetMove, true);
  assert.equal(conduitRes.tempHpGranted, 5);

  const conduitEnv = resolveEnvironmentalInteraction(
    kaelen,
    conduit,
    seraphina.gridX,
    seraphina.gridZ,
    grid,
    [],
    units,
    seraphina.id
  );
  const refreshedSeraphina = conduitEnv.updatedUnits.find((u) => u.id === 'seraphina')!;
  assert.equal(refreshedSeraphina.movedThisTurn, false);
  assert.equal(refreshedSeraphina.tempHp, 5);
  assert.equal(refreshedSeraphina.statuses.some((s) => s.type === 'rooted'), false);
});

test('Class 3 — Warden skills: Deadeye Range, Predator Exploit, 3-Tile Briar Wall, Ironwood Shockwave, Backstep Vault, and Wild-Balm', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const rels = createInitialRelationships();
  const rawUnits = createEncounterUnits(0, world);

  const thorne = rawUnits.find((u) => u.id === 'thorne')!;
  const inquisitor = rawUnits.find((u) => u.archetype === 'inquisitor')!;
  const stalker = rawUnits.find((u) => u.archetype === 'stalker')!;

  // 1. Heartseeker Arrow: +3 Deadeye Sniper DMG at distance >= 4 vs 0 bonus at distance 2
  thorne.gridX = 7;
  thorne.gridZ = 7;
  inquisitor.gridX = 7;
  inquisitor.gridZ = 2; // Distance 5 >= 4
  const longShot = resolveAbilityUse(thorne, inquisitor, thorne.abilities[0], rawUnits, rels, world, 16);
  assert.equal(longShot.bonusConditionalDamage, 3);

  inquisitor.gridX = 7;
  inquisitor.gridZ = 5; // Distance 2 < 4
  const closeShot = resolveAbilityUse(thorne, inquisitor, thorne.abilities[0], rawUnits, rels, world, 16);
  assert.equal(closeShot.bonusConditionalDamage, 0);
  assert.equal(longShot.damage - closeShot.damage, 3);

  // 2. Briar-Thorn Volley: Proactive empty-ground choke-point trap placement
  const snareAbility = thorne.abilities.find((a) => a.id === 'bramble_snare')!;
  const trapEnv = resolveEnvironmentalInteraction(thorne, snareAbility, 6, 5, grid, [], rawUnits);
  assert.equal(trapEnv.updatedGrid[6][5].surface, 'bramble_snare');

  // 3. Briarfang Strike (Warden Commander): +4 Predator Exploit against Rooted/Sundered targets
  const wardenParty = applyCharacterBuildToParty(rawUnits, rels, {
    commanderName: 'Sylvan Hero',
    raceId: 'wood_kin',
    classId: 'warden',
    subclassId: 'briar_stalker',
  });
  const wardenCmd = wardenParty.units.find((u) => u.id === 'seraphina')!;
  assert.equal(wardenCmd.abilities[0].id, 'briarfang_strike');
  inquisitor.statuses = [{ type: 'rooted', turnsLeft: 2 }];
  const predatorHit = resolveAbilityUse(
    wardenCmd,
    inquisitor,
    wardenCmd.abilities[0],
    wardenParty.units,
    wardenParty.relationships,
    world,
    16
  );
  assert.equal(predatorHit.bonusConditionalDamage, 4);

  // 4. Heart-Briar Volley (Gloom-Briar Stalker): +5 Isolated Ambush & 3-Tile Perpendicular Briar Wall
  inquisitor.gridX = 5;
  inquisitor.gridZ = 3;
  stalker.gridX = 1;
  stalker.gridZ = 1; // Far away -> inquisitor is isolated!
  wardenCmd.gridX = 5;
  wardenCmd.gridZ = 7; // Shooting North (vz = -1) -> perpendicular wall along East-West (4,3), (5,3), (6,3)
  const briarVolley = CHARACTER_SUBCLASSES.briar_stalker.signatureAbility;
  const ambushHit = resolveAbilityUse(
    wardenCmd,
    inquisitor,
    briarVolley,
    wardenParty.units,
    wardenParty.relationships,
    world,
    16
  );
  assert.equal(ambushHit.bonusConditionalDamage, 5);

  const wallEnv = resolveEnvironmentalInteraction(
    wardenCmd,
    briarVolley,
    5,
    3,
    grid,
    [],
    wardenParty.units,
    inquisitor.id
  );
  assert.equal(wallEnv.updatedGrid[4][3].surface, 'bramble_snare');
  assert.equal(wallEnv.updatedGrid[5][3].surface, 'bramble_snare');
  assert.equal(wallEnv.updatedGrid[6][3].surface, 'bramble_snare');

  // 5. Ironwood Tempest (Ironbough Sentinel): Orthogonal shockwave + Self Warded & +5 Temp HP
  const tempest = CHARACTER_SUBCLASSES.ironbough_sentinel.signatureAbility;
  stalker.gridX = 6;
  stalker.gridZ = 3; // Orthogonally adjacent to (5,3)
  const stalkerHp = stalker.hp;
  const tempestEnv = resolveEnvironmentalInteraction(
    wardenCmd,
    tempest,
    5,
    3,
    grid,
    [],
    wardenParty.units,
    inquisitor.id
  );
  assert.equal(tempestEnv.updatedUnits.find((u) => u.id === stalker.id)!.hp, stalkerHp - 5);
  const wardedCmd = tempestEnv.updatedUnits.find((u) => u.id === 'seraphina')!;
  assert.equal(wardedCmd.tempHp, 5);
  assert.ok(wardedCmd.statuses.some((s) => s.type === 'warded'));

  // 6. Tempest Twin-Barrage (viper_twinshot): 1-Tile Evasive Backstep Vault (and blocked if Rooted)
  thorne.gridX = 6;
  thorne.gridZ = 6;
  inquisitor.gridX = 6;
  inquisitor.gridZ = 5;
  const twinshot = thorne.abilities.find((a) => a.id === 'viper_twinshot')!;
  const vaultEnv = resolveEnvironmentalInteraction(
    thorne,
    twinshot,
    6,
    5,
    grid,
    [],
    rawUnits,
    inquisitor.id
  );
  const vaultedThorne = vaultEnv.updatedUnits.find((u) => u.id === 'thorne')!;
  assert.equal(vaultedThorne.gridX, 6);
  assert.equal(vaultedThorne.gridZ, 7); // Vaulted 1 tile away!

  // Verify Rooted restriction prevents Evasive Vault
  thorne.statuses = [{ type: 'rooted', turnsLeft: 2 }];
  const rootedVaultEnv = resolveEnvironmentalInteraction(
    thorne,
    twinshot,
    6,
    5,
    grid,
    [],
    rawUnits,
    inquisitor.id
  );
  assert.equal(rootedVaultEnv.updatedUnits.find((u) => u.id === 'thorne')!.gridZ, 6);

  // 7. Sylvan Wild-Balm (warden_salve): Cleanses Burning/Sundered, grants Warded, and restores fire_pool to moss (never roots ally!)
  const kaelen = rawUnits.find((u) => u.id === 'kaelen')!;
  kaelen.gridX = 3;
  kaelen.gridZ = 3;
  grid[3][3].surface = 'fire_pool';
  kaelen.statuses = [
    { type: 'burning', turnsLeft: 2 },
    { type: 'sundered', turnsLeft: 2 },
  ];
  const salve = thorne.abilities.find((a) => a.id === 'warden_salve')!;
  const salveEnv = resolveEnvironmentalInteraction(
    thorne,
    salve,
    3,
    3,
    grid,
    [],
    rawUnits,
    kaelen.id
  );
  const mendedKaelen = salveEnv.updatedUnits.find((u) => u.id === 'kaelen')!;
  assert.equal(mendedKaelen.statuses.some((s) => s.type === 'burning'), false);
  assert.equal(mendedKaelen.statuses.some((s) => s.type === 'sundered'), false);
  assert.equal(mendedKaelen.statuses.some((s) => s.type === 'rooted'), false);
  assert.equal(mendedKaelen.statuses.some((s) => s.type === 'warded'), true);
  assert.equal(salveEnv.updatedGrid[3][3].surface, 'none');
  assert.equal(salveEnv.updatedGrid[3][3].terrain, 'moss');
});

test('Enemy archetype interactions: Stalker Shadowstep Opportunist bonus against wounded prey', () => {
  const world = createInitialWorldState();
  const rels = createInitialRelationships();
  const units = createEncounterUnits(0, world);

  const stalker = units.find((u) => u.archetype === 'stalker')!;
  const kaelen = units.find((u) => u.id === 'kaelen')!;

  // Healthy Kaelen (32/32 HP, no debuffs) -> 0 Opportunist bonus
  const healthyStrike = resolveAbilityUse(
    stalker,
    kaelen,
    stalker.abilities[0],
    units,
    rels,
    world,
    15
  );
  assert.equal(healthyStrike.bonusConditionalDamage, 0);

  // Wounded Kaelen (15/32 HP <= 60%) -> +3 Opportunist Backstab bonus
  kaelen.hp = 15;
  const woundedStrike = resolveAbilityUse(
    stalker,
    kaelen,
    stalker.abilities[0],
    units,
    rels,
    world,
    15
  );
  assert.equal(woundedStrike.bonusConditionalDamage, 3);
  assert.equal(woundedStrike.damage - healthyStrike.damage, 3);
});

test('Cross-class tactical combo chain: Chronomancer Vacuum -> Arcanist 3x3 Singularity -> Paladin Execution Leap', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const rels = createInitialRelationships();
  const units = createEncounterUnits(0, world);

  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const kaelen = units.find((u) => u.id === 'kaelen')!;
  const inquisitor = units.find((u) => u.archetype === 'inquisitor')!;
  const stalker = units.find((u) => u.archetype === 'stalker')!;
  const weaver = units.find((u) => u.archetype === 'weaver')!;

  // Scatter enemies within radius 2 of (5,4)
  inquisitor.gridX = 5;
  inquisitor.gridZ = 4;
  stalker.gridX = 3;
  stalker.gridZ = 4; // 2 tiles West -> will vacuum into (4,4)
  weaver.gridX = 7;
  weaver.gridZ = 3; // Chebyshev 2 -> will vacuum into (6,3)

  // Step 1: Rift Chronomancer collapses spacetime at (5,4), clustering all 3 enemies into 3x3 around (5,4)
  const vacuumStep = resolveEnvironmentalInteraction(
    kaelen,
    CHARACTER_SUBCLASSES.rift_chronomancer.signatureAbility,
    5,
    4,
    grid,
    [],
    units,
    inquisitor.id
  );
  const step1Units = vacuumStep.updatedUnits;
  assert.equal(step1Units.find((u) => u.id === stalker.id)!.gridX, 4);
  assert.equal(step1Units.find((u) => u.id === weaver.id)!.gridX, 6);

  // Step 2: Kaelen casts Crimson Singularity on clustered (5,4) -> scorches both pulled Stalker & Weaver in 3x3!
  const crimsonAbility = kaelen.abilities.find((a) => a.id === 'crimson_tempest')!;
  const blastStep = resolveEnvironmentalInteraction(
    kaelen,
    crimsonAbility,
    5,
    4,
    vacuumStep.updatedGrid,
    [],
    step1Units,
    inquisitor.id
  );
  const burnedStalker = blastStep.updatedUnits.find((u) => u.id === stalker.id)!;
  const burnedWeaver = blastStep.updatedUnits.find((u) => u.id === weaver.id)!;
  assert.ok(burnedStalker.statuses.some((s) => s.type === 'burning'));
  assert.ok(burnedWeaver.statuses.some((s) => s.type === 'burning'));

  // Step 3: Seraphina leaps from (4,6) to execute bloodied Stalker at (4,4) with Oathbreaker Smite (+1 AP refund)
  const step2Paladin = blastStep.updatedUnits.find((u) => u.id === 'seraphina')!;
  step2Paladin.gridX = 4;
  step2Paladin.gridZ = 6;
  burnedStalker.hp = 10; // Bloodied (<= 50% of 24)
  const execRes = resolveAbilityUse(
    step2Paladin,
    burnedStalker,
    step2Paladin.abilities[1],
    blastStep.updatedUnits,
    rels,
    world,
    16
  );
  assert.equal(execRes.bonusConditionalDamage, 6);
  assert.equal(execRes.targetKO, true);
  assert.equal(execRes.apRefunded, 1);
});

test('Skill Icon Art Direction (Part 7): all 22 standalone SVG icons are 128x128 square textured compositions with zero text', () => {
  const iconDir = path.resolve(process.cwd(), 'public', 'assets', 'icons', 'skills');
  const files = fs.readdirSync(iconDir).filter((f) => f.endsWith('.svg'));
  assert.equal(files.length, 22, 'Expected 22 standalone SVG skill icons');

  const bodySignatures = new Set<string>();
  for (const file of files) {
    const content = fs.readFileSync(path.join(iconDir, file), 'utf8');
    assert.ok(content.includes('width="128"'), `${file} must have 128px source width`);
    assert.ok(content.includes('height="128"'), `${file} must have 128px source height`);
    assert.ok(content.includes('viewBox="0 0 128 128"'), `${file} must use square 0 0 128 128 viewBox`);
    assert.ok(content.includes('<radialGradient'), `${file} must include dark textured background gradient`);
    assert.equal(content.includes('<text'), false, `${file} must not contain words or text elements`);
    bodySignatures.add(content.replace(/bg_[a-z_]+|aura_[a-z_]+/g, ''));
  }
  assert.equal(bodySignatures.size, 22, 'Every ability must have its own unique icon artwork');
});

test('Combat Skill Bar states (Part 2.4 & Part 9): accurately distinguishes available, selected, out_of_range, insufficient_ap, cooldown, locked, and disabled', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const envObjects = createEncounterObjects(0);
  const units = createEncounterUnits(0, world);

  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const kaelen = units.find((u) => u.id === 'kaelen')!;
  const inquisitor = units.find((u) => u.archetype === 'inquisitor')!;

  // 1. At spawn (3,7), Seraphina's melee Sunblade Cleave (Range 2) has no enemy or object within 2 tiles -> OUT OF RANGE
  const cleaveOut = evaluateSkillSlotState(seraphina, seraphina.abilities[0], units, grid, envObjects);
  assert.equal(cleaveOut.state, 'out_of_range');
  assert.equal(cleaveOut.canSelect, true);
  assert.equal(cleaveOut.canActivate, false);
  assert.ok(cleaveOut.restrictionReason?.includes('Range 2'));

  // 2. Move Seraphina adjacent to Inquisitor -> AVAILABLE, and when selected -> SELECTED
  seraphina.gridX = inquisitor.gridX;
  seraphina.gridZ = inquisitor.gridZ + 1;
  const cleaveAvail = evaluateSkillSlotState(seraphina, seraphina.abilities[0], units, grid, envObjects);
  assert.equal(cleaveAvail.state, 'available');
  assert.equal(cleaveAvail.canActivate, true);

  const cleaveSelected = evaluateSkillSlotState(
    seraphina,
    seraphina.abilities[0],
    units,
    grid,
    envObjects,
    { isSelected: true }
  );
  assert.equal(cleaveSelected.state, 'selected');

  // 3. Spend 1 AP so Seraphina has 1 AP left -> Oathbreaker Smite (2 AP) becomes INSUFFICIENT AP (not confused with out_of_range)
  seraphina.ap = 1;
  const smiteLowAp = evaluateSkillSlotState(seraphina, seraphina.abilities[1], units, grid, envObjects);
  assert.equal(smiteLowAp.state, 'insufficient_ap');
  assert.equal(smiteLowAp.canSelect, false);
  assert.equal(smiteLowAp.canActivate, false);
  assert.ok(smiteLowAp.restrictionReason?.includes('Insufficient Action Points'));

  // 4. Put Dawnlight Mending on 2-turn cooldown -> COOLDOWN state
  seraphina.ap = 2;
  seraphina.cooldowns.lay_on_hands = 2;
  const mendCd = evaluateSkillSlotState(seraphina, seraphina.abilities[2], units, grid, envObjects);
  assert.equal(mendCd.state, 'cooldown');
  assert.equal(mendCd.cooldownRemaining, 2);
  assert.equal(mendCd.canSelect, false);

  // 5. Turn refresh restores AP and clears cooldown -> Dawnlight Mending becomes AVAILABLE again
  seraphina.cooldowns = {};
  const mendReady = evaluateSkillSlotState(seraphina, seraphina.abilities[2], units, grid, envObjects);
  assert.equal(mendReady.state, 'available');

  // 6. Locked opposing subclass skill -> LOCKED state
  const lockedEval = evaluateSkillSlotState(
    kaelen,
    CHARACTER_SUBCLASSES.rift_chronomancer.signatureAbility,
    units,
    grid,
    envObjects,
    { isLocked: true, unlockRequirement: 'Requires Rift Chronomancer Subclass' }
  );
  assert.equal(lockedEval.state, 'locked');
  assert.equal(lockedEval.canSelect, false);
  assert.equal(lockedEval.restrictionReason, 'Requires Rift Chronomancer Subclass');

  // 7. Enemy unit -> DISABLED state on player HUD
  const enemyDisabled = evaluateSkillSlotState(
    inquisitor,
    inquisitor.abilities[0],
    units,
    grid,
    envObjects
  );
  assert.equal(enemyDisabled.state, 'disabled');
  assert.equal(enemyDisabled.canSelect, false);
});

test('Skill Menu Catalog, Categories, Character Switching & Detail Panel (Parts 4, 5, 6, 9)', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const envObjects = createEncounterObjects(0);
  const rels = createInitialRelationships();
  const defaultBuild = createDefaultCharacterBuild();
  const units = applyCharacterBuildToParty(
    createEncounterUnits(0, world),
    rels,
    defaultBuild
  ).units;

  const seraphina = units.find((u) => u.id === 'seraphina')!;
  const kaelen = units.find((u) => u.id === 'kaelen')!;
  const thorne = units.find((u) => u.id === 'thorne')!;

  // Verify character switching produces distinct class identities & catalogs
  assert.equal(getUnitClassIdentity(seraphina, defaultBuild).classId, 'paladin');
  assert.equal(getUnitClassIdentity(kaelen, defaultBuild).classId, 'arcanist');
  assert.equal(getUnitClassIdentity(thorne, defaultBuild).classId, 'warden');

  const palCatalog = getUnitSkillCatalog(seraphina, world, defaultBuild);
  const arcCatalog = getUnitSkillCatalog(kaelen, world, defaultBuild);
  const warCatalog = getUnitSkillCatalog(thorne, world, defaultBuild);

  assert.equal(palCatalog.length, 5); // 4 unlocked Paladin + 1 locked opposing Oath
  assert.equal(arcCatalog.length, 7); // 6 unlocked Arcanist + 1 locked Chronomancer
  assert.equal(warCatalog.length, 7); // 6 unlocked Warden + 1 locked Ironbough

  // Verify zero empty categories are displayed (Passive Abilities omitted since 0)
  for (const catList of [
    getAvailableSkillCategories(palCatalog),
    getAvailableSkillCategories(arcCatalog),
    getAvailableSkillCategories(warCatalog),
  ]) {
    assert.ok(catList.length >= 5);
    assert.ok(catList.every((c) => c.count > 0));
    assert.equal(
      catList.some((c) => c.id === 'passive'),
      false,
      'Categories with 0 skills must not be shown'
    );
  }

  // Verify Skill Detail ViewModel separates flavor & mechanical descriptions and omits inapplicable properties
  const cleaveEntry = palCatalog.find((e) => e.ability.id === 'sunblade_cleave')!;
  const cleaveDetail = buildSkillDetailViewModel(
    seraphina,
    cleaveEntry,
    units,
    rels,
    world,
    grid,
    envObjects
  );
  assert.ok(cleaveDetail.flavorText.length > 20);
  assert.notEqual(cleaveDetail.flavorText, cleaveDetail.mechanicalDescription);
  assert.ok(cleaveDetail.combatStats.some((s) => s.label === 'Damage'));
  assert.ok(cleaveDetail.combatStats.some((s) => s.label === 'Area'));
  assert.equal(
    cleaveDetail.combatStats.some((s) => s.label === 'Healing'),
    false,
    'Attack skill must not display Healing property'
  );
  assert.ok(
    cleaveDetail.effects.some((eff) => eff.statusType === 'burning' && eff.durationLabel === '2 Turns')
  );

  const mendEntry = palCatalog.find((e) => e.ability.id === 'lay_on_hands')!;
  const mendDetail = buildSkillDetailViewModel(
    seraphina,
    mendEntry,
    units,
    rels,
    world,
    grid,
    envObjects
  );
  assert.ok(mendDetail.combatStats.some((s) => s.label === 'Healing'));
  assert.equal(
    mendDetail.combatStats.some((s) => s.label === 'Damage'),
    false,
    'Pure healing skill must not display Damage property'
  );
  assert.equal(
    mendDetail.combatStats.some((s) => s.label === 'Area'),
    false,
    'Single-target skill must omit Area property'
  );
});

test('Skill Assignment & Environmental Preservation (Part 5F & Part 12): replaces/swaps cleanly without duplicating or corrupting abilities', () => {
  const world = createInitialWorldState();
  const grid = generateTacticalGrid(0, world);
  const envObjects = createEncounterObjects(0);
  const units = createEncounterUnits(0, world);
  const kaelen = units.find((u) => u.id === 'kaelen')!;

  const initialCatalog = getUnitSkillCatalog(kaelen, world);
  const soulBladeEntry = initialCatalog.find((e) => e.ability.id === 'astral_soul_blade')!;
  assert.equal(soulBladeEntry.equippedSlotKey, null);
  assert.equal(soulBladeEntry.isLocked, false);

  // 1. Equip unequipped Astral Soul-Blade into Slot 1 (replaces Astral Lance)
  const replaceRes = assignUnitSkillToSlot(kaelen, soulBladeEntry, '1');
  assert.equal(replaceRes.changed, true);
  assert.equal(replaceRes.replacedAbility?.id, 'astral_bolt');
  assert.equal(replaceRes.updatedUnit.abilities.length, 4);
  assert.equal(replaceRes.updatedUnit.abilities[0].id, 'astral_soul_blade');
  assert.equal(replaceRes.updatedUnit.abilities[0].key, '1');

  // Displaced Astral Lance is NOT erased from Kaelen's class catalog!
  const updatedCatalog = getUnitSkillCatalog(replaceRes.updatedUnit, world);
  assert.equal(updatedCatalog.length, 7);
  const displacedBolt = updatedCatalog.find((e) => e.ability.id === 'astral_bolt')!;
  assert.equal(displacedBolt.equippedSlotKey, null);

  // 2. Equip already-equipped Astral Soul-Blade from Slot 1 into Slot 3 -> SWAPS with Rift Singularity Bind (zero duplicates!)
  const equippedSoulEntry = updatedCatalog.find((e) => e.ability.id === 'astral_soul_blade')!;
  const swapRes = assignUnitSkillToSlot(replaceRes.updatedUnit, equippedSoulEntry, '3');
  assert.equal(swapRes.changed, true);
  assert.equal(swapRes.swappedFromSlot, '1');
  const slotIds = swapRes.updatedUnit.abilities.map((a) => a.id);
  assert.equal(new Set(slotIds).size, 4, 'Must never assign duplicate active abilities across slots');
  assert.equal(swapRes.updatedUnit.abilities.find((a) => a.key === '1')?.id, 'gravity_shackle');
  assert.equal(swapRes.updatedUnit.abilities.find((a) => a.key === '3')?.id, 'astral_soul_blade');

  // 3. Attempting to assign a LOCKED subclass skill is rejected
  const lockedChrono = updatedCatalog.find((e) => e.ability.id === 'chrono_rift_collapse')!;
  assert.equal(lockedChrono.isLocked, true);
  const lockedAttempt = assignUnitSkillToSlot(swapRes.updatedUnit, lockedChrono, '2');
  assert.equal(lockedAttempt.changed, false);

  // 4. Newly assigned Astral Soul-Blade (Fire) still triggers environmental oil-pool ignition!
  const reassignedKaelen = swapRes.updatedUnit;
  reassignedKaelen.gridX = 3;
  reassignedKaelen.gridZ = 4;
  const newlyEquippedFireBlade = reassignedKaelen.abilities.find((a) => a.key === '3')!;
  const envRes = resolveEnvironmentalInteraction(
    reassignedKaelen,
    newlyEquippedFireBlade,
    3,
    3,
    grid,
    envObjects,
    units
  );
  assert.ok(envRes.triggeredEvents.length > 0);
  assert.equal(envRes.updatedGrid[3][3].surface, 'fire_pool');
  assert.equal(envRes.updatedGrid[3][2].surface, 'fire_pool');
});

// ============================================================================
// GLOAMREST BEGINNER SETTLEMENT HUB — SECTION 15 ACCEPTANCE SUITE (TESTS 24-28)
// ============================================================================

test('Gloamrest World Scale, 9 Interconnected Districts & Unblocked Pathfinding (Acceptance #1, #2, #3, #18)', () => {
  assert.equal(TOWN_GRID_SIZE, 50);
  assert.equal(TOWN_TILE_WORLD_SIZE, 2.0);
  assert.equal(TOWN_GRID_SIZE * TOWN_TILE_WORLD_SIZE, 100, 'Town exterior must span 100x100 world units');

  const districtIds = Object.keys(GLOAMREST_DISTRICTS);
  assert.equal(districtIds.length, 9, 'Must define all 9 mandatory Gloamrest districts');

  const grid = generateGloamrestExteriorGrid();
  assert.equal(grid.length, 50);
  assert.equal(grid[0].length, 50);

  // Verify South Pilgrim Entrance (24, 43) is walkable and reaches Hearth Square + every building doorstep + Whispering Gate exit
  assert.equal(grid[24][43].walkable, true, 'South Pilgrim Entrance must be walkable');

  const hearthPath = findTownPath(grid, 24, 43, 24, 28);
  assert.ok(hearthPath.length > 5, 'Main street from South Entrance to Hearth Square must be clear');

  for (const bldg of BUILDING_EXTERIORS) {
    if (!bldg.doorTile) continue;
    assert.equal(
      grid[bldg.doorTile.x][bldg.doorTile.z].walkable,
      true,
      `Doorstep of ${bldg.name} at (${bldg.doorTile.x}, ${bldg.doorTile.z}) must be walkable`
    );
    const pathToDoor = findTownPath(grid, 24, 43, bldg.doorTile.x, bldg.doorTile.z);
    assert.ok(
      pathToDoor.length > 0,
      `Player must be able to walk smoothly from South Entrance to ${bldg.name} (${bldg.doorTile.x}, ${bldg.doorTile.z})`
    );
  }

  // Verify Whispering Gate wilderness road & roadside ravine cache are reachable across stone bridges
  const gatePath = findTownPath(grid, 24, 28, 38, 1);
  assert.ok(gatePath.length > 10, 'Road from Hearth Square through Whispering Gate exit must be unblocked');
  const ravinePath = findTownPath(grid, 38, 7, 41, 3);
  assert.ok(ravinePath.length > 0, 'Roadside ravine near Whispering Gate must be reachable for MQ02');
});

test('Gloamrest Building Interiors, Locked Manor Entrance & Hidden Secret Basement (Acceptance #4, #5, #13)', () => {
  const build = createDefaultCharacterBuild();
  const world = createInitialWorldState();
  const units = createEncounterUnits(0, world);
  const rels = createInitialRelationships();
  let state = createInitialGloamrestState(build);

  // 1. All 6 open settlement buildings enter real walkable interiors and exit cleanly back to town
  const openDoors: { doorId: string; expectedScene: keyof typeof GLOAMREST_INTERIORS }[] = [
    { doorId: 'door_tavern_enter', expectedScene: 'tavern' },
    { doorId: 'door_forge_enter', expectedScene: 'forge' },
    { doorId: 'door_herbalist_enter', expectedScene: 'herbalist' },
    { doorId: 'door_chapel_enter', expectedScene: 'chapel' },
    { doorId: 'door_barracks_enter', expectedScene: 'barracks' },
    { doorId: 'door_carpenter_enter', expectedScene: 'carpenter' },
  ];

  for (const { doorId, expectedScene } of openDoors) {
    const enterRes = interactWithGloamrestObject(state, doorId, units, rels);
    assert.equal(enterRes.nextState.currentSceneId, expectedScene);
    assert.ok(enterRes.nextState.discoveredInteriors.includes(expectedScene));

    const intGrid = generateInteriorGrid(expectedScene);
    const sp = enterRes.nextState.playerPos;
    assert.equal(
      intGrid[Math.round(sp.x)][Math.round(sp.z)].walkable,
      true,
      `Interior spawn in ${expectedScene} must be walkable`
    );

    const exitDoor = getSceneInteractiveObjects(enterRes.nextState).find((o) => o.kind === 'door_exit');
    assert.ok(exitDoor, `Interior ${expectedScene} must have a functional exit door`);
    const exitRes = interactWithGloamrestObject(enterRes.nextState, exitDoor!.id, units, rels);
    assert.equal(exitRes.nextState.currentSceneId, 'exterior');
  }

  // 2. Abandoned Manor starts locked; secret basement is unrevealed
  assert.equal(GLOAMREST_INTERIORS.manor_basement.isSecretRoom, true);
  assert.equal(state.discoveredInteriors.includes('manor_basement'), false);

  const lockedAttempt = interactWithGloamrestObject(state, 'door_manor_enter', units, rels);
  assert.equal(lockedAttempt.nextState.currentSceneId, 'exterior', 'Manor entrance must reject entry while locked');
  state = lockedAttempt.nextState;

  // 3. Discover rusted key in overgrown Manor Garden sundial, then unlock Manor
  const keySearch = interactWithGloamrestObject(state, 'obj_manor_garden_crypt', units, rels);
  state = keySearch.nextState;
  assert.ok(
    state.inventory.items.some((i) => i.itemId === 'manor_rusted_key'),
    'Searching garden sundial must grant Tarnished Veyne Manor Key'
  );

  const manorEnter = interactWithGloamrestObject(state, 'door_manor_enter', units, rels);
  state = manorEnter.nextState;
  assert.equal(state.currentSceneId, 'manor', 'Key must unlock Abandoned Manor and transition inside');

  // 4. Secret basement stairs remain hidden inside Manor until hearth crest latch is triggered
  assert.equal(
    getSceneInteractiveObjects(state).some((o) => o.id === 'door_manor_basement_enter'),
    false,
    'Hidden basement stairs must stay unrevealed prior to solving hearth mechanism'
  );

  const latchRes = interactWithGloamrestObject(state, 'int_manor_secret_latch', units, rels);
  state = latchRes.nextState;
  assert.ok(state.storyFlags.includes('manor_basement_revealed'));
  assert.equal(
    getSceneInteractiveObjects(state).some((o) => o.id === 'door_manor_basement_enter'),
    true,
    'Solving hearth latch must reveal secret basement stairs'
  );

  const basementEnter = interactWithGloamrestObject(state, 'door_manor_basement_enter', units, rels);
  state = basementEnter.nextState;
  assert.equal(state.currentSceneId, 'manor_basement');
  assert.ok(state.discoveredInteriors.includes('manor_basement'));

  const relicLoot = interactWithGloamrestObject(state, 'int_basement_reliquary_chest', units, rels);
  state = relicLoot.nextState;
  assert.equal(state.quests.opt01_manor_of_shattered_vows.status, 'completed');
  assert.ok(state.inventory.items.some((i) => i.itemId === 'manor_first_vigil_blade'));
  assert.ok(state.inventory.items.some((i) => i.itemId === 'veyne_family_signet'));
});

test('Gloamrest 12 Named NPCs, 4-Phase Daily Schedules, Contextual D20 Checks & Companion Interjections (Acceptance #6, #7, #8, #11, #12)', () => {
  const mandatoryNpcIds = [
    'aldric_veyne',
    'mara_fenwick',
    'garron_holt',
    'elowen_mire',
    'brother_cael',
    'captain_roderic',
    'tessa_reed',
    'bram_alder',
    'sera_wren',
    'old_nym',
    'edrin_vale',
    'lysa_thorn',
  ];

  for (const id of mandatoryNpcIds) {
    const npc = GLOAMREST_NPCS.find((n) => n.id === id);
    assert.ok(npc, `Mandatory NPC ${id} must exist in GLOAMREST_NPCS`);
    // Verify distinct schedules across day phases
    const morning = getNpcActiveSchedule(npc!, 'morning', 'peaceful');
    const evening = getNpcActiveSchedule(npc!, 'evening', 'peaceful');
    const night = getNpcActiveSchedule(npc!, 'night', 'peaceful');
    assert.ok(morning.waypoints.length > 0 && evening.waypoints.length > 0 && night.waypoints.length > 0);
  }

  // Verify NPCs shift between exterior and tavern/interiors across watches
  const baseBuild = {
    ...createDefaultCharacterBuild(),
    classId: 'paladin' as const,
    backgroundId: 'sanctum_acolyte',
  };
  const world = createInitialWorldState();
  const units = createEncounterUnits(0, world);
  const rels = createInitialRelationships();
  const morningState = createInitialGloamrestState(baseBuild);
  const eveningTavernState = {
    ...morningState,
    currentSceneId: 'tavern' as const,
    timeOfDay: 'evening' as const,
  };

  const eveningTavernNpcs = getActiveSceneNpcs(eveningTavernState);
  assert.ok(
    eveningTavernNpcs.length >= 4,
    'Multiple townsfolk & companions must gather inside the Wandering Stag Tavern in the evening'
  );

  // Verify contextual dialogue tags, companion interjections, and live D20 skill check execution
  const aldricDialogue = buildGloamrestNpcDialogue('aldric_veyne', morningState, baseBuild, world);
  assert.ok(aldricDialogue);
  assert.ok(
    aldricDialogue!.companionInterjections.length > 0,
    'Companions must interject contextually during Gloamrest conversations'
  );
  assert.ok(
    aldricDialogue!.choices.some((c) => Boolean(c.contextTag)),
    'Player class/background must surface contextual dialogue options'
  );

  const skillChoice = aldricDialogue!.choices.find((c) => Boolean(c.skillCheck))!;
  assert.ok(skillChoice, 'Elder Aldric dialogue must offer a D20 skill check branch');
  const checkRes = resolveTownDialogueChoice(morningState, 'aldric_veyne', skillChoice, units, rels);
  assert.ok(checkRes.skillCheckResult, 'Dialogue skill check must roll through existing D20 rules engine');
  assert.ok(checkRes.skillCheckResult!.d20Roll >= 1 && checkRes.skillCheckResult!.d20Roll <= 20);
});

test('Gloamrest Merchants, Equipment Stats, Herb Gathering & Complete Opening Questline MQ01-MQ04 + SQ01-SQ02 (Acceptance #9, #10, #14, #15, #17, #19)', () => {
  const build = createDefaultCharacterBuild();
  const world = createInitialWorldState();
  const baseUnits = createEncounterUnits(0, world);
  const rels = createInitialRelationships();
  const extGrid = generateGloamrestExteriorGrid();
  let state = createInitialGloamrestState(build);

  // Verify all 5 town merchants exist
  assert.equal(Object.keys(GLOAMREST_MERCHANTS).length, 5);

  // 1. MQ01: A Stranger at Gloamrest (Enter Hearth Square -> Speak Aldric -> Enter Tavern -> Speak Mara)
  state = movePlayerInGloamrest(state, 24, 26, 0, extGrid).nextState;
  assert.ok(state.discoveredDistricts.includes('hearth_square'));
  assert.ok(state.quests.mq01_stranger_at_gloamrest.completedStepIds.includes('explore_square'));

  const aldricDlg = buildGloamrestNpcDialogue('aldric_veyne', state, build, world)!;
  const reportChoice = aldricDlg.choices.find((c) => c.id === 'aldric_mq01_intro')!;
  state = resolveTownDialogueChoice(state, 'aldric_veyne', reportChoice, baseUnits, rels).nextState;

  state = interactWithGloamrestObject(state, 'door_tavern_enter', baseUnits, rels).nextState;
  const maraDlg = buildGloamrestNpcDialogue('mara_fenwick', state, build, world)!;
  const maraChoice = maraDlg.choices.find((c) => c.id === 'mara_missing_rumors')!;
  state = resolveTownDialogueChoice(state, 'mara_fenwick', maraChoice, baseUnits, rels).nextState;

  assert.equal(state.quests.mq01_stranger_at_gloamrest.status, 'completed', 'MQ01 must complete cleanly');
  assert.equal(state.quests.mq02_trouble_at_ironroot.status, 'active');
  assert.equal(state.quests.mq03_shadows_beyond_gate.status, 'active');

  // 2. MQ02: The Trouble at Ironroot -> unlocks rare blacksmith stock!
  state = { ...state, currentSceneId: 'exterior' };
  const initialForgeStock = getAvailableMerchantStock(state, 'forge_garron');
  assert.equal(
    initialForgeStock.some((s) => s.item.id === 'sunsteel_covenant_blade'),
    false,
    'Rare Forge stock must be locked before recovering Garron’s ore shipment'
  );

  state = interactWithGloamrestObject(state, 'obj_damaged_supply_cart', baseUnits, rels).nextState;
  state = interactWithGloamrestObject(state, 'obj_roadside_ravine_cache', baseUnits, rels).nextState;
  assert.ok(state.inventory.items.some((i) => i.itemId === 'meteoric_ironroot_ingots'));

  const garronDlg = buildGloamrestNpcDialogue('garron_holt', state, build, world)!;
  const deliverOre = garronDlg.choices.find((c) => c.id === 'garron_deliver_ingots')!;
  state = resolveTownDialogueChoice(state, 'garron_holt', deliverOre, baseUnits, rels).nextState;
  assert.equal(state.quests.mq02_trouble_at_ironroot.status, 'completed');
  assert.ok(state.storyFlags.includes('forge_shipment_restored'));

  const unlockedForgeStock = getAvailableMerchantStock(state, 'forge_garron');
  assert.equal(
    unlockedForgeStock.some((s) => s.item.id === 'sunsteel_covenant_blade'),
    true,
    'Completing MQ02 must unlock rare Sunsteel Covenant equipment at Ironroot Forge'
  );

  // 3. Merchant Buy, Sell, Repair & Combat Equipment Stat Application
  const goldBeforeBuy = state.inventory.gold;
  const buyRes = buyFromMerchant(state, 'forge_garron', 'sunsteel_covenant_blade');
  assert.equal(buyRes.ok, true);
  state = buyRes.nextState;
  assert.equal(state.inventory.gold, goldBeforeBuy - GLOAMREST_ITEMS.sunsteel_covenant_blade.value);

  const equipRes = equipItemOnPartyMember(state, 'seraphina', 'sunsteel_covenant_blade');
  assert.equal(equipRes.ok, true);
  state = equipRes.nextState;

  const gearedUnits = applyEquippedGearToPartyUnits(baseUnits, state.inventory.equippedByUnit);
  const baseSera = baseUnits.find((u) => u.id === 'seraphina')!;
  const gearedSera = gearedUnits.find((u) => u.id === 'seraphina')!;
  assert.ok(
    gearedSera.abilities[0].damageRange[1] > baseSera.abilities[0].damageRange[1],
    'Equipping Sunsteel Covenant Blade must increase party combat weapon damage'
  );
  assert.ok(
    gearedSera.armorClass > baseSera.armorClass,
    'Equipped armor & shield must increase party Armor Class'
  );

  const sellRes = sellToMerchant(state, 'forge_garron', 'ironroot_longsword');
  assert.equal(sellRes.ok, true, 'Unequipped old weapon can be sold cleanly to merchant');
  state = sellRes.nextState;

  const repairRes = repairPartyEquipment(state, 8);
  assert.equal(repairRes.ok, true);
  state = repairRes.nextState;

  // 4. SQ01: A Bitter Remedy (Gather 3 herbs + Rift-Touched Nightshade -> Deliver to Elowen)
  state = interactWithGloamrestObject(state, 'herb_garden_silverleaf', baseUnits, rels).nextState;
  state = interactWithGloamrestObject(state, 'herb_riverbank_bitterroot', baseUnits, rels).nextState;
  state = interactWithGloamrestObject(state, 'herb_timber_silverleaf', baseUnits, rels).nextState;
  state = interactWithGloamrestObject(state, 'herb_manor_blight', baseUnits, rels).nextState;
  assert.ok(state.quests.sq01_bitter_remedy.completedStepIds.includes('gather_herbs'));
  assert.ok(state.quests.sq01_bitter_remedy.completedStepIds.includes('inspect_blight_herb'));

  const elowenDlg = buildGloamrestNpcDialogue('elowen_mire', state, build, world)!;
  const deliverHerbs = elowenDlg.choices.find((c) => c.id === 'elowen_deliver_herbs')!;
  state = resolveTownDialogueChoice(state, 'elowen_mire', deliverHerbs, baseUnits, rels).nextState;
  assert.equal(state.quests.sq01_bitter_remedy.status, 'completed');

  // 5. MQ03: Shadows Beyond the Gate -> shifts townThreatPhase & activates MQ04 WITHOUT requiring SQ02!
  assert.equal(state.townThreatPhase, 'peaceful');
  assert.equal(state.quests.sq02_echoes_beneath_well.status, 'not_started');

  const mq03Victory = completeOutskirtsWildernessEncounter(state);
  state = mq03Victory.nextState;
  assert.equal(state.quests.mq03_shadows_beyond_gate.status, 'completed');
  assert.equal(state.townThreatPhase, 'uneasy', 'Winning Outskirts combat must shift town to heightened watch');
  assert.equal(
    state.quests.mq04_road_to_whispering_vale.status,
    'active',
    'MQ04 (Whispering Vale / Sanctum route) must unlock without forcing completion of SQ02'
  );

  // 6. SQ02: Echoes Beneath the Well -> reveals subterranean Sanctum conduit & shifts townThreatPhase to fortified
  state = interactWithGloamrestObject(state, 'obj_ancient_well', baseUnits, rels).nextState;
  assert.equal(state.quests.sq02_echoes_beneath_well.status, 'active');

  const caelDlg1 = buildGloamrestNpcDialogue('brother_cael', state, build, world)!;
  const askWell = caelDlg1.choices.find((c) => c.id === 'cael_sq02_well')!;
  state = resolveTownDialogueChoice(state, 'brother_cael', askWell, baseUnits, rels).nextState;

  const edrinDlg = buildGloamrestNpcDialogue('edrin_vale', state, build, world)!;
  const edrinDecipher = edrinDlg.choices.find((c) => c.id === 'edrin_arcana_check')!;
  state = resolveTownDialogueChoice(state, 'edrin_vale', edrinDecipher, baseUnits, rels).nextState;

  const caelDlg2 = buildGloamrestNpcDialogue('brother_cael', state, build, world)!;
  const reportConduit = caelDlg2.choices.find((c) => c.id === 'cael_complete_sq02')!;
  state = resolveTownDialogueChoice(state, 'brother_cael', reportConduit, baseUnits, rels).nextState;
  assert.equal(state.quests.sq02_echoes_beneath_well.status, 'completed');
  assert.equal(state.townThreatPhase, 'astral_resonance', 'Solving well sigil must awaken Astral Resonance phase');

  // 7. MQ04: Report findings to Elder Aldric -> issues Sealed Sanctum Writ & shifts townThreatPhase to 'fortified'!
  const aldricMq04Dlg = buildGloamrestNpcDialogue('aldric_veyne', state, build, world)!;
  const aldricWritChoice = aldricMq04Dlg.choices.find((c) => c.id === 'aldric_mq04_report')!;
  state = resolveTownDialogueChoice(state, 'aldric_veyne', aldricWritChoice, baseUnits, rels).nextState;
  assert.equal(state.townThreatPhase, 'fortified', 'Issuing the Sanctum Writ must fortify Whispering Gate');
  assert.ok(state.inventory.items.some((i) => i.itemId === 'sanctum_gate_writ'));

  // Speak with a companion in town + depart via Scout Sera Wren to complete MQ04!
  const seraCompanionDlg = buildGloamrestNpcDialogue('comp_seraphina', state, build, world)!;
  state = resolveTownDialogueChoice(state, 'comp_seraphina', seraCompanionDlg.choices[0], baseUnits, rels).nextState;

  const seraGateDlg = buildGloamrestNpcDialogue('sera_wren', state, build, world)!;
  const departChoice = seraGateDlg.choices.find((c) => c.id === 'sera_depart_sanctum')!;
  const departRes = resolveTownDialogueChoice(state, 'sera_wren', departChoice, baseUnits, rels);
  state = departRes.nextState;
  assert.equal(departRes.triggerAction, 'depart_act1_sanctum');
  assert.equal(state.quests.mq04_road_to_whispering_vale.status, 'completed');
});

test('Gloamrest Save/Load Persistence & Zero Regression on Existing Tactical Combat (Acceptance #16, #20)', () => {
  const build = createDefaultCharacterBuild();
  const world = createInitialWorldState();
  const units = createEncounterUnits(0, world);
  const rels = createInitialRelationships();
  const extGrid = generateGloamrestExteriorGrid();

  let state = createInitialGloamrestState(build);
  state = movePlayerInGloamrest(state, 12, 34, 1.25, extGrid).nextState;
  state = interactWithGloamrestObject(state, 'obj_timber_movable_barrel', units, rels, extGrid).nextState;
  state = buyFromMerchant(state, 'general_tessa', 'iron_lockpicks').nextState;

  // Round-trip JSON serialization (identical to localStorage & SavedAdventureSlot persistence)
  const serialized = JSON.stringify(state);
  const restored = JSON.parse(serialized) as typeof state;

  assert.equal(restored.version, 1);
  assert.deepEqual(restored.playerPos, { x: 12, z: 34 });
  assert.ok(restored.discoveredDistricts.includes('timber_yard'));
  assert.ok(restored.movedObjectPositions.obj_timber_movable_barrel);
  assert.ok(restored.inventory.items.some((i) => i.itemId === 'iron_lockpicks'));
  assert.deepEqual(restored.quests, state.quests);
  assert.deepEqual(restored.merchantStocks.general_tessa, state.merchantStocks.general_tessa);

  // Confirm existing tactical combat engine resolves strikes cleanly with Gloamrest-geared party units
  const gearedUnits = applyEquippedGearToPartyUnits(units, restored.inventory.equippedByUnit);
  const seraphina = gearedUnits.find((u) => u.id === 'seraphina')!;
  const enemy = gearedUnits.find((u) => u.faction === 'enemy')!;
  enemy.gridX = seraphina.gridX + 1;
  enemy.gridZ = seraphina.gridZ;
  const combatRes = resolveAbilityUse(
    seraphina,
    enemy,
    seraphina.abilities[0],
    gearedUnits,
    rels,
    world
  );
  assert.ok(combatRes.d20Roll >= 1 && combatRes.d20Roll <= 20);
  assert.equal(Object.keys(GLOAMREST_QUESTS).length, 7);
});

/* ========================================================================= */
/* CLASS SKILLS, SKILL TREES & LEVEL PROGRESSION SUITE (Sections 1–16)       */
/* ========================================================================= */

test('Level 1–20 Progression: exact cumulative XP thresholds, level cap at 20, and repeat-XP prevention (Section 1, 8, 16)', () => {
  // 1. Verify exact cumulative XP thresholds from prompt specification
  const expectedThresholds: Record<number, number> = {
    1: 0,
    2: 300,
    3: 750,
    4: 1350,
    5: 2100,
    6: 3000,
    7: 4050,
    8: 5250,
    9: 6600,
    10: 8100,
    11: 9750,
    12: 11550,
    13: 13500,
    14: 15600,
    15: 17850,
    16: 20250,
    17: 22800,
    18: 25500,
    19: 28350,
    20: 31350,
  };

  for (let lvl = 1; lvl <= 20; lvl++) {
    assert.equal(
      CUMULATIVE_XP_TABLE[lvl],
      expectedThresholds[lvl],
      `Level ${lvl} must require exactly ${expectedThresholds[lvl]} cumulative XP`
    );
    assert.equal(
      calculateLevelFromXp(expectedThresholds[lvl]),
      lvl,
      `calculateLevelFromXp(${expectedThresholds[lvl]}) must be level ${lvl}`
    );
    if (lvl > 1) {
      assert.equal(
        calculateLevelFromXp(expectedThresholds[lvl] - 1),
        lvl - 1,
        `One point below threshold (${expectedThresholds[lvl] - 1}) must be level ${lvl - 1}`
      );
    }
  }

  // 2. Progression state and repeat-XP prevention
  let state = createInitialProgressionState('warrior');
  assert.equal(state.level, 1);
  assert.equal(state.totalXp, 0);

  // Award unique XP source
  const firstAward = awardXp(state, 300, 'encounter_outskirts_wolf');
  assert.equal(firstAward.leveledUp, true);
  assert.equal(firstAward.newLevel, 2);
  assert.equal(firstAward.nextState.totalXp, 300);
  assert.ok(firstAward.nextState.completedXpSourceIds.includes('encounter_outskirts_wolf'));
  state = firstAward.nextState;

  // Attempt to exploit repeat XP from the exact same source ID
  const repeatAward = awardXp(state, 300, 'encounter_outskirts_wolf');
  assert.equal(repeatAward.leveledUp, false);
  assert.equal(repeatAward.xpGained, 0, 'Must not grant duplicate XP for identical source ID');
  assert.equal(repeatAward.nextState.totalXp, 300);

  // 3. Level cap verification at Level 20 (Max 31,350 XP)
  const maxAward = awardXp(state, 50000, 'cheat_cap_test');
  assert.equal(maxAward.nextState.level, 20);
  assert.equal(maxAward.nextState.totalXp, 31350, 'Total XP must cap at exactly 31,350');
  const pastCap = calculateLevelFromXp(999999);
  assert.equal(pastCap, 20, 'Character level must never exceed MAX_CHARACTER_LEVEL (20)');
});

test('Level-Up Rewards: 19 Skill Points, 5 Attribute Points (+1 at 4, 8, 12, 16, 20), and Class Mastery Milestones (Section 2, 6, 7)', () => {
  let state = createInitialProgressionState('paladin');
  assert.equal(state.unspentSkillPoints, 0);
  assert.equal(state.unspentAttributePoints, 0);

  // Level 1 -> 4
  const resL4 = awardXp(state, 1350, 'test_to_l4');
  state = resL4.nextState;
  assert.equal(state.level, 4);
  assert.equal(state.unspentSkillPoints, 3, 'Level 4 should have granted 3 Skill Points (Lv 2, 3, 4)');
  assert.equal(state.unspentAttributePoints, 1, 'Level 4 should have granted 1 Attribute Point');

  // Level 4 -> 5 (Mastery Milestone Tier 1)
  const resL5 = awardXp(state, 750, 'test_to_l5');
  state = resL5.nextState;
  assert.equal(state.level, 5);
  assert.equal(state.unspentSkillPoints, 4);
  assert.equal(resL5.masteryMilestoneReached, 5, 'Mastery milestone 5 should be reached');

  // Select Mastery Choice at Level 5
  const selRes = selectClassMastery(state, 5, 'paladin_mastery_5_protection');
  assert.equal(selRes.success, true);
  state = selRes.nextState;
  assert.equal(state.unlockedMasteries[5], 'paladin_mastery_5_protection');

  // Advance all the way to Level 20
  const resL20 = awardXp(state, 30000, 'test_to_l20');
  state = resL20.nextState;
  assert.equal(state.level, 20);
  assert.equal(state.unspentSkillPoints, 19, 'Total Skill Points granted from Lv 2 to 20 must be exactly 19');
  assert.equal(state.unspentAttributePoints, 5, 'Total Attribute Points granted (Lv 4, 8, 12, 16, 20) must be exactly 5');

  // Verify attribute spending
  const spendStr = spendAttributePoint(state, 'str');
  assert.equal(spendStr.success, true);
  state = spendStr.nextState;
  assert.equal(state.allocatedAttributes.str, 1);
  assert.equal(state.unspentAttributePoints, 4);

  // Verify class mastery choices exist for all 4 milestones (5, 10, 15, 20)
  for (const m of [5, 10, 15, 20] as const) {
    const choices = CLASS_MASTERY_CHOICES[m];
    assert.ok(choices && choices.length >= 3, `Milestone ${m} must have distinct development choices`);
  }
});

test('Mandatory Skill Uniqueness Audit: 96 distinct abilities (60 core + 36 spec) with zero duplicates across mechanics (Section 4, 5, 13)', () => {
  const audit = verifySkillUniquenessAudit();
  assert.equal(audit.totalSkills, 96, 'ALL_SKILLS_DATABASE must contain exactly 96 total abilities');
  assert.equal(audit.coreSkills, 60, 'Must have exactly 60 core class abilities (12 per class x 5 classes)');
  assert.equal(audit.specSkills, 36, 'Must have exactly 36 specialization abilities (6 per spec x 6 specs)');
  assert.deepEqual(audit.duplicatesFound, [], 'Skill Uniqueness Audit must find ZERO duplicate IDs or mechanics');

  // Verify exact 12 named core skills per class from Section 4
  const warriorExpected = [
    'sundering_strike', 'guarded_stance', 'whirlwind_assault', 'driving_assault',
    'weapon_parry', 'crippling_blow', 'unbreakable_resolve', 'earthsplitter',
    'relentless_pursuit', 'iron_reprisal', 'battlefield_commander', 'last_stand',
  ];
  for (const id of warriorExpected) {
    assert.ok(ALL_SKILLS_DATABASE[id], `Warrior core skill ${id} must exist`);
    assert.equal(ALL_SKILLS_DATABASE[id].classKey, 'warrior');
  }

  const mageExpected = [
    'infernal_orb', 'glacial_lance', 'chain_lightning', 'blink_step',
    'gravitational_collapse', 'arcane_disjunction', 'aegis_ward', 'counterspell',
    'phase_veil', 'runic_mine', 'astral_rift', 'prismatic_field',
  ];
  for (const id of mageExpected) {
    assert.ok(ALL_SKILLS_DATABASE[id], `Mage core skill ${id} must exist`);
    assert.equal(ALL_SKILLS_DATABASE[id].classKey, 'mage');
  }

  const rogueExpected = [
    'quickdraw', 'shadow_veil', 'mark_for_death', 'tripwire',
    'smoke_escape', 'pickpocket', 'false_opening', 'poisoned_edge',
    'evasive_roll', 'ambush_protocol', 'shadow_exchange', 'perfect_execution',
  ];
  for (const id of rogueExpected) {
    assert.ok(ALL_SKILLS_DATABASE[id], `Rogue core skill ${id} must exist`);
    assert.equal(ALL_SKILLS_DATABASE[id].classKey, 'rogue');
  }

  const paladinExpected = [
    'consecrated_strike', 'oathward', 'sanctuary_ring', 'judgment_mark',
    'radiant_mend', 'shield_of_conviction', 'oath_of_restraint', 'sacred_ground',
    'burden_of_sin', 'beacon_of_hope', 'divine_intercession', 'final_judgment',
  ];
  for (const id of paladinExpected) {
    assert.ok(ALL_SKILLS_DATABASE[id], `Paladin core skill ${id} must exist`);
    assert.equal(ALL_SKILLS_DATABASE[id].classKey, 'paladin');
  }

  const rangerExpected = [
    'precision_shot', 'hunters_instinct', 'pinning_arrow', 'hunting_ground',
    'ricochet_shot', 'camouflage', 'thornline', 'beast_call',
    'windrunner', 'deadfall_trap', 'marked_prey', 'natures_dominion',
  ];
  for (const id of rangerExpected) {
    assert.ok(ALL_SKILLS_DATABASE[id], `Ranger core skill ${id} must exist`);
    assert.equal(ALL_SKILLS_DATABASE[id].classKey, 'ranger');
  }
});

test('Skill Unlocking & Point Economy: level gating, unspent point preservation, and no automatic equip (Section 3, 6, 10, 16)', () => {
  let state = createInitialProgressionState('warrior');
  // At Level 1 with 0 points:
  assert.equal(state.unspentSkillPoints, 0);

  // Attempting to unlock Whirlwind Assault (Req. Lv 2) at Lv 1 with 0 points fails
  const failLevel = unlockSkill(state, 'whirlwind_assault', 1);
  assert.equal(failLevel.success, false);
  assert.ok(failLevel.error?.includes('Requires character level 2'));

  // Level up to 19 with 18 unspent skill points
  state = awardXp(state, 28350, 'level_19_grant').nextState;
  assert.equal(state.level, 19);
  assert.equal(state.unspentSkillPoints, 18);

  // Level 20 skill (Last Stand) cannot be unlocked at Level 19 even with 18 available points
  const failLv20At19 = unlockSkill(state, 'last_stand', 19);
  assert.equal(failLv20At19.success, false, 'Cannot unlock Level 20 skill at Level 19');
  assert.ok(failLv20At19.error?.includes('Requires character level 20'));

  // Player can save points and unlock multiple lower-level skills
  const unlockL12 = unlockSkill(state, 'earthsplitter', 19);
  assert.equal(unlockL12.success, true);
  state = unlockL12.nextState;
  assert.equal(state.unspentSkillPoints, 17, 'Should deduct exactly 1 skill point');
  assert.ok(state.learnedSkillIds.includes('earthsplitter'));

  // Do NOT automatically equip newly unlocked skills
  assert.ok(
    !state.equippedSkillIds.includes('earthsplitter'),
    'Unlocking a skill must not automatically equip it to the active loadout'
  );
});

test('Four-Slot Active Combat Loadout & Unit Integration: active skills, passive rules, and CombatUnit stat/ability application (Section 12, 15)', () => {
  let state = createInitialProgressionState('mage');
  // Level up and unlock an active spell
  state = awardXp(state, 2100, 'to_l5').nextState;
  state = unlockSkill(state, 'chain_lightning', 6).nextState; // assume learned for test

  // Equip active skill to Slot 2
  const equipRes = equipSkillToSlot(state, 1, 'chain_lightning');
  assert.equal(equipRes.success, true);
  state = equipRes.nextState;
  assert.equal(state.equippedSkillIds[1], 'chain_lightning');

  // Attempting to equip a passive perk (Beacon of Hope) to an active combat slot must fail
  state = unlockSkill(state, 'beacon_of_hope', 16).nextState;
  const failPassive = equipSkillToSlot(state, 2, 'beacon_of_hope');
  assert.equal(failPassive.success, false);
  assert.ok(failPassive.error?.includes('passive'));

  // Test applyProgressionToCommander on a mock CombatUnit
  const mockUnit = createEncounterUnits(0, createInitialWorldState())[0];
  state.allocatedAttributes.str = 2;
  state.unlockedMasteries[5] = 'warrior_mastery_5_bastion'; // +2 AC, +8 Max HP

  const upgraded = applyProgressionToCommander(mockUnit, state);
  assert.equal(upgraded.abilities.length, 4);
  assert.equal(upgraded.abilities[1].id, 'chain_lightning');
  assert.equal(upgraded.stats.str, mockUnit.stats.str + 2);
  assert.equal(upgraded.armorClass, mockUnit.armorClass + 2);
  assert.ok(upgraded.maxHp > mockUnit.maxHp);
});

test('Class Progression Save/Load Persistence Round-Trip: level, XP, unspent points, learned skills, loadouts, masteries, and attributes (Section 14)', () => {
  let state = createInitialProgressionState('ranger');
  state = awardXp(state, 6600, 'quest_mq02_cleared').nextState; // Level 9
  state = spendAttributePoint(state, 'dex').nextState;
  state = selectClassMastery(state, 5, 'ranger_mastery_5_deadeye').nextState;
  state = unlockSkill(state, 'thornline', 10).nextState;
  state = equipSkillToSlot(state, 3, 'thornline').nextState;

  // Serialize to JSON (simulating localStorage persistence)
  const serialized = JSON.stringify(state);
  const restored: typeof state = JSON.parse(serialized);

  assert.equal(restored.level, 9);
  assert.equal(restored.totalXp, 6600);
  assert.equal(restored.allocatedAttributes.dex, 1);
  assert.equal(restored.unlockedMasteries[5], 'ranger_mastery_5_deadeye');
  assert.ok(restored.learnedSkillIds.includes('thornline'));
  assert.equal(restored.equippedSkillIds[3], 'thornline');
  assert.ok(restored.completedXpSourceIds.includes('quest_mq02_cleared'));

  // Verify no duplicate point grants on reload
  const reAwardSameSource = awardXp(restored, 1000, 'quest_mq02_cleared');
  assert.equal(reAwardSameSource.xpGained, 0);
  assert.equal(reAwardSameSource.nextState.totalXp, 6600);
});

test('Clean Skill Tree Redesign Support: unequip, 4-slot uniqueness & 3-branch core classification', () => {
  let state = createInitialProgressionState('warrior');
  // Initial warrior loadout: ['sundering_strike', 'guarded_stance', 'sundering_strike', 'guarded_stance']
  assert.equal(state.equippedSkillIds.length, 4);

  // 1. Unequip slot 2
  const unequipRes = unequipSkillSlot(state, 2);
  assert.equal(unequipRes.success, true);
  state = unequipRes.nextState;
  assert.equal(state.equippedSkillIds[2], '');

  // 2. Unlock a new skill and equip to slot 2
  state = awardXp(state, 1350, 'battle_victory_1').nextState; // Level 4 -> 3 SP, meets minLevel 4 for driving_assault
  const unlockRes = unlockSkill(state, 'driving_assault');
  assert.equal(unlockRes.success, true);
  state = unlockRes.nextState;
  assert.ok(state.learnedSkillIds.includes('driving_assault'));

  const equipRes = equipSkillToSlot(state, 2, 'driving_assault');
  assert.equal(equipRes.success, true);
  state = equipRes.nextState;
  assert.equal(state.equippedSkillIds[2], 'driving_assault');

  // 3. Clean swap: equipping 'driving_assault' (currently in slot 2) to slot 0 should cleanly swap with slot 0's 'sundering_strike'
  const moveRes = equipSkillToSlot(state, 0, 'driving_assault');
  assert.equal(moveRes.success, true);
  state = moveRes.nextState;
  assert.equal(state.equippedSkillIds[0], 'driving_assault');
  assert.equal(state.equippedSkillIds[2], 'sundering_strike'); // swapped cleanly

  // 4. Verify 3-Branch Core Partitioning across all 5 classes
  const classes = ['warrior', 'paladin', 'mage', 'rogue', 'ranger'] as const;
  for (const cls of classes) {
    const coreSkills = Object.values(ALL_SKILLS_DATABASE).filter(
      (s) => s.classKey === cls && !s.specializationKey
    );
    assert.equal(coreSkills.length, 12, `${cls} must have exactly 12 core skills`);

    // Verify all core skills have unique IDs and minLevel between 1 and 20
    const ids = new Set(coreSkills.map((s) => s.id));
    assert.equal(ids.size, 12);
    for (const s of coreSkills) {
      assert.ok(s.minLevel >= 1 && s.minLevel <= 20, `minLevel ${s.minLevel} out of range for ${s.id}`);
      assert.ok(s.skillPointCost >= 1, `SP cost must be >= 1 for ${s.id}`);
      assert.ok(s.tacticalExplanation.length > 0, `tacticalExplanation missing for ${s.id}`);
      assert.ok(s.damageFormula.length > 0, `damageFormula missing for ${s.id}`);
    }
  }
});

test('Warrior Skill Tree State Verification: Learned, Available, Locked, and Equipped States across 4 Slots', () => {
  // 1. Initial Level 1 Warrior
  let state = createInitialProgressionState('warrior');
  assert.equal(state.level, 1);
  assert.equal(state.unspentSkillPoints, 0);

  // Both starting skills are learned
  assert.ok(state.learnedSkillIds.includes('sundering_strike'));
  assert.ok(state.learnedSkillIds.includes('guarded_stance'));

  // Higher level skills are locked
  assert.ok(!state.learnedSkillIds.includes('whirlwind_assault'));
  assert.ok(!state.learnedSkillIds.includes('driving_assault'));
  assert.ok(!state.learnedSkillIds.includes('last_stand'));

  // Attempting to unlock without SP or level requirement fails
  const failedUnlockLv = unlockSkill(state, 'driving_assault');
  assert.equal(failedUnlockLv.success, false);
  assert.ok(failedUnlockLv.error?.includes('Requires character level 4'));

  // 2. Level up to Level 2 (300 XP) -> Grants 1 SP, unlocks eligibility for Whirlwind Assault (minLevel 2)
  state = awardXp(state, 300, 'goblin_cleared').nextState;
  assert.equal(state.level, 2);
  assert.equal(state.unspentSkillPoints, 1);

  // Whirlwind Assault is now available to unlock
  const unlockWhirlwind = unlockSkill(state, 'whirlwind_assault');
  assert.equal(unlockWhirlwind.success, true);
  state = unlockWhirlwind.nextState;
  assert.equal(state.unspentSkillPoints, 0);
  assert.ok(state.learnedSkillIds.includes('whirlwind_assault'));

  // Equip Whirlwind Assault to slot 2
  state = equipSkillToSlot(state, 2, 'whirlwind_assault').nextState;
  assert.equal(state.equippedSkillIds[2], 'whirlwind_assault');

  // 3. Level up to Level 4 (1350 cumulative XP) -> minLevel 4 met for Driving Assault
  state = awardXp(state, 1050, 'tower_floor_1').nextState;
  assert.equal(state.level, 4);
  assert.equal(state.unspentSkillPoints, 2); // 1 from lv 3, 1 from lv 4

  const unlockDriving = unlockSkill(state, 'driving_assault');
  assert.equal(unlockDriving.success, true);
  state = unlockDriving.nextState;
  assert.equal(state.unspentSkillPoints, 1);
  assert.ok(state.learnedSkillIds.includes('driving_assault'));

  // Equip Driving Assault to slot 3
  state = equipSkillToSlot(state, 3, 'driving_assault').nextState;
  assert.equal(state.equippedSkillIds[3], 'driving_assault');

  // All 4 slots are now equipped with distinct tactical abilities
  assert.deepEqual(state.equippedSkillIds, [
    'sundering_strike',
    'guarded_stance',
    'whirlwind_assault',
    'driving_assault',
  ]);

  // Last Stand (minLevel 20) is still strictly locked
  const failedLastStand = unlockSkill(state, 'last_stand');
  assert.equal(failedLastStand.success, false);
  assert.ok(failedLastStand.error?.includes('Requires character level 20'));

  // Unequip slot 1 and verify it is empty
  state = unequipSkillSlot(state, 1).nextState;
  assert.equal(state.equippedSkillIds[1], '');
  assert.equal(state.equippedSkillIds[0], 'sundering_strike');
  assert.equal(state.equippedSkillIds[2], 'whirlwind_assault');
  assert.equal(state.equippedSkillIds[3], 'driving_assault');
});

test('In-Arena Character and Enemy Overhead Health Bars: Faction colors, HP percentages, ghost lag, and accessible DOM representation', () => {
  const partyUnit: CombatUnit = {
    id: 'seraphina',
    name: 'Seraphina',
    title: 'Sun-Sworn Paladin',
    faction: 'party',
    gridX: 2,
    gridZ: 2,
    elevation: 0,
    hp: 24,
    maxHp: 30,
    tempHp: 0,
    armorClass: 16,
    ap: 3,
    maxAp: 3,
    moveRange: 4,
    movedThisTurn: false,
    initiative: 14,
    stats: { str: 16, dex: 10, int: 10, cha: 16 },
    statuses: [{ type: 'blessed', turnsLeft: 2 }],
    abilities: [],
    cooldowns: {},
    isKO: false,
    koTimer: 0,
  };

  const enemyUnit: CombatUnit = {
    id: 'inquisitor_0',
    name: 'Iron Inquisitor',
    title: 'Heresy Executioner',
    faction: 'enemy',
    archetype: 'inquisitor',
    gridX: 4,
    gridZ: 4,
    elevation: 0,
    hp: 12,
    maxHp: 28,
    tempHp: 0,
    armorClass: 15,
    ap: 3,
    maxAp: 3,
    moveRange: 4,
    movedThisTurn: false,
    initiative: 10,
    stats: { str: 14, dex: 12, int: 10, cha: 10 },
    statuses: [{ type: 'sundered', turnsLeft: 1 }],
    abilities: [],
    cooldowns: {},
    isKO: false,
    koTimer: 0,
  };

  // 1. Party Health Evaluation
  const partyHpPct = partyUnit.hp / partyUnit.maxHp;
  assert.equal(partyHpPct, 0.8);
  assert.equal(partyUnit.faction, 'party');
  assert.ok(partyHpPct > 0.3, 'Party member is healthy (>30% HP)');

  // 2. Enemy Health Evaluation
  const enemyHpPct = enemyUnit.hp / enemyUnit.maxHp;
  assert.ok(Math.abs(enemyHpPct - 0.4285) < 0.01);
  assert.equal(enemyUnit.faction, 'enemy');

  // 3. Ghost damage lag evaluation
  let ghostHp = 28; // Enemy was originally at full HP 28, took 16 damage -> now at 12
  assert.ok(ghostHp > enemyUnit.hp, 'Ghost bar reflects delayed damage catch-up');

  // 4. Critical damage shift evaluation
  const criticalEnemy: CombatUnit = { ...enemyUnit, hp: 5 };
  const criticalPct = criticalEnemy.hp / criticalEnemy.maxHp;
  assert.ok(criticalPct <= 0.3, 'Enemy enters critical low health state (<=30% HP)');
});

test('One Skill Can Only Equip 1 Slot: strict uniqueness across all classes, cross-slot swapping, duplicate sanitization, and clean loadout state', () => {
  // 1. All five starting classes must have strictly unique equipped skills in their default loadout
  const classes = ['warrior', 'mage', 'rogue', 'paladin', 'ranger'] as const;
  for (const cls of classes) {
    const state = createInitialProgressionState(cls);
    const nonEmpties = state.equippedSkillIds.filter((id) => id && id.trim() !== '');
    const uniqueIds = new Set(nonEmpties);
    assert.equal(
      nonEmpties.length,
      uniqueIds.size,
      `${cls} default loadout has duplicated equipped skills: [${state.equippedSkillIds.join(', ')}]`
    );
    assert.equal(state.equippedSkillIds.length, 4, `${cls} loadout must always have exactly 4 slots`);
  }

  // 2. sanitizeEquippedSkills eliminates any duplicate skills, keeping only the first occurrence
  const dirtyLoadout = ['sundering_strike', 'guarded_stance', 'sundering_strike', 'guarded_stance'];
  const cleaned = sanitizeEquippedSkills(dirtyLoadout);
  assert.deepEqual(cleaned, ['sundering_strike', 'guarded_stance', '', '']);

  const quadrupleMage = ['infernal_orb', 'infernal_orb', 'infernal_orb', 'infernal_orb'];
  assert.deepEqual(sanitizeEquippedSkills(quadrupleMage), ['infernal_orb', '', '', '']);

  // 3. Moving an equipped skill to an empty slot frees up the previous slot (0 duplicates)
  let warriorState = createInitialProgressionState('warrior');
  // warrior starts with ['sundering_strike', 'guarded_stance', '', '']
  assert.equal(warriorState.equippedSkillIds[0], 'sundering_strike');
  assert.equal(warriorState.equippedSkillIds[2], '');

  // Move sundering_strike to slot 2 (0-indexed)
  const moveRes = equipSkillToSlot(warriorState, 2, 'sundering_strike');
  assert.equal(moveRes.success, true);
  warriorState = moveRes.nextState;

  // sundering_strike must ONLY be in slot 2, slot 0 must now be empty
  assert.equal(warriorState.equippedSkillIds[2], 'sundering_strike');
  assert.equal(warriorState.equippedSkillIds[0], '');
  assert.equal(warriorState.equippedSkillIds[1], 'guarded_stance');
  assert.equal(warriorState.equippedSkillIds[3], '');

  // Count occurrences of sundering_strike
  const occurrences = warriorState.equippedSkillIds.filter((id) => id === 'sundering_strike').length;
  assert.equal(occurrences, 1, 'sundering_strike must be equipped in at most 1 slot');

  // 4. Clean swap between two occupied slots
  // Currently: ['', 'guarded_stance', 'sundering_strike', '']
  // Move sundering_strike from slot 2 to slot 1 (which holds guarded_stance)
  const swapRes = equipSkillToSlot(warriorState, 1, 'sundering_strike');
  assert.equal(swapRes.success, true);
  warriorState = swapRes.nextState;

  // Now slot 1 holds sundering_strike, and slot 2 holds guarded_stance
  assert.equal(warriorState.equippedSkillIds[1], 'sundering_strike');
  assert.equal(warriorState.equippedSkillIds[2], 'guarded_stance');
  assert.equal(warriorState.equippedSkillIds[0], '');
  assert.equal(warriorState.equippedSkillIds[3], '');

  // 5. Equipping an unequipped learned skill into an occupied slot replaces that slot cleanly
  warriorState = awardXp(warriorState, 300, 'victory_l2').nextState; // Level 2 -> 1 SP
  warriorState = unlockSkill(warriorState, 'whirlwind_assault').nextState; // Learned
  assert.ok(warriorState.learnedSkillIds.includes('whirlwind_assault'));
  assert.ok(!warriorState.equippedSkillIds.includes('whirlwind_assault'));

  // Equip whirlwind_assault to slot 1 (replacing sundering_strike)
  const replaceRes = equipSkillToSlot(warriorState, 1, 'whirlwind_assault');
  assert.equal(replaceRes.success, true);
  warriorState = replaceRes.nextState;

  assert.equal(warriorState.equippedSkillIds[1], 'whirlwind_assault');
  assert.ok(!warriorState.equippedSkillIds.includes('sundering_strike'), 'sundering_strike was replaced');
  assert.equal(warriorState.equippedSkillIds[2], 'guarded_stance');

  // 6. Passives cannot be equipped to any slot
  let mageState = createInitialProgressionState('mage');
  mageState = {
    ...mageState,
    learnedSkillIds: [...mageState.learnedSkillIds, 'beacon_of_hope'],
  };
  const failPassive = equipSkillToSlot(mageState, 2, 'beacon_of_hope');
  assert.equal(failPassive.success, false);
  assert.ok(failPassive.error?.includes('passive'));
  assert.equal(mageState.equippedSkillIds[2], '');
});

test('Warrior Core Skill Family (12 Skills) Mechanics, Reactions, Immunities, and Trial Grounds Verification', () => {
  const world = createInitialWorldState();
  const rels = createInitialRelationships();
  const grid = generateTacticalGrid(0, world);

  const getWarriorAbility = (skillId: string, key: '1' | '2' | '3' | '4' = '1') => {
    const def = ALL_SKILLS_DATABASE[skillId];
    assert.ok(def, `Missing Warrior skill ${skillId} in ALL_SKILLS_DATABASE`);
    assert.equal(def.classKey, 'warrior');
    return toCombatAbility(def, key);
  };

  const makeUnit = (overrides: Partial<CombatUnit>): CombatUnit => ({
    id: 'unit_default',
    name: 'Test Unit',
    title: 'Combatant',
    faction: 'party',
    gridX: 2,
    gridZ: 2,
    elevation: 0,
    hp: 40,
    maxHp: 40,
    tempHp: 0,
    ap: 4,
    maxAp: 4,
    moveRange: 4,
    movedThisTurn: false,
    armorClass: 14,
    initiative: 15,
    stats: { str: 16, dex: 12, int: 10, cha: 12 },
    cooldowns: {},
    statuses: [],
    isKO: false,
    koTimer: 0,
    abilities: [],
    ...overrides,
  });

  // 1. Sundering Strike: applies Sundered (-2 AC) on hit, +3 bonus damage if already Sundered, respects immunity
  {
    const ability = getWarriorAbility('sundering_strike');
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 2, gridZ: 2 });
    const target = makeUnit({ id: 'enemy_1', name: 'Shieldbearer', faction: 'enemy', armorClass: 10, hp: 35, maxHp: 35, gridX: 2, gridZ: 3 });
    const res1 = resolveAbilityUse(warrior, target, ability, [warrior, target], rels, world, 15);
    assert.equal(res1.hit, true);
    assert.equal(res1.statusApplied, 'sundered', 'First hit should apply sundered');

    // Second strike on already sundered target deals +3 bonus damage
    const sunderedTarget: CombatUnit = {
      ...target,
      statuses: [{ type: 'sundered', turnsLeft: 2 }],
    };
    const res2 = resolveAbilityUse(warrior, sunderedTarget, ability, [warrior, sunderedTarget], rels, world, 15);
    assert.equal(res2.hit, true);
    assert.equal(res2.damage, res1.damage + 3, 'Should deal +3 bonus damage to already sundered target');

    // Target immune to sundered takes damage but resists status
    const immuneTarget = makeUnit({
      id: 'enemy_immune',
      name: 'Golem',
      faction: 'enemy',
      armorClass: 10,
      hp: 40,
      maxHp: 40,
      gridX: 2,
      gridZ: 3,
      immunities: ['sundered'],
    });
    const resImmune = resolveAbilityUse(warrior, immuneTarget, ability, [warrior, immuneTarget], rels, world, 15);
    assert.equal(resImmune.hit, true);
    assert.equal(resImmune.statusApplied, undefined, 'Immune target should resist sundered');
  }

  // 2. Guarded Stance: +2 AC Warded, +6 Temp HP, displacement immunity, -1 moveRange trade-off, 25% physical mitigation
  {
    const ability = getWarriorAbility('guarded_stance');
    const openGrid = generateTacticalGrid(0, world).map((row) =>
      row.map((tile) => ({ ...tile, walkable: true, surface: 'none' as const }))
    );
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', moveRange: 4, gridX: 4, gridZ: 4 });
    const envRes = resolveEnvironmentalInteraction(warrior, ability, 4, 4, openGrid, [], [warrior]);
    const bracedWarrior = envRes.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(bracedWarrior.tempHp, 6);
    assert.equal(bracedWarrior.guardedStanceTurns, 2);
    assert.ok(bracedWarrior.statuses.some((e) => e.type === 'warded'));

    // Check -1 moveRange trade-off in getValidMoveTiles
    const normalTiles = getValidMoveTiles(warrior, openGrid, [warrior]);
    const bracedTiles = getValidMoveTiles(bracedWarrior, openGrid, [bracedWarrior]);
    const maxNormalDist = Math.max(...normalTiles.map((t) => chebyshevDistance(warrior.gridX, warrior.gridZ, t.x, t.z)));
    const maxBracedDist = Math.max(...bracedTiles.map((t) => chebyshevDistance(bracedWarrior.gridX, bracedWarrior.gridZ, t.x, t.z)));
    assert.equal(maxNormalDist, 4);
    assert.equal(maxBracedDist, 3, 'Guarded Stance should reduce move range by 1 while active');

    // Check 25% physical damage reduction via resolveWarriorDefensiveReactions
    const attacker = makeUnit({ id: 'enemy_atk', faction: 'enemy', gridX: 4, gridZ: 5 });
    const meleeAb = getWarriorAbility('sundering_strike');
    const reaction = resolveWarriorDefensiveReactions(attacker, bracedWarrior, meleeAb, 12);
    assert.equal(reaction.finalDamage, 9, 'Guarded Stance should mitigate 25% of incoming physical damage (12 -> 9)');

    // Check displacement immunity while Guarded Stance is active
    const pushAbility = getWarriorAbility('driving_assault');
    const enemyCharger = makeUnit({ id: 'enemy_charger', faction: 'enemy', gridX: 4, gridZ: 2 });
    const pushEnv = resolveEnvironmentalInteraction(enemyCharger, pushAbility, 4, 4, openGrid, [], [enemyCharger, bracedWarrior], 'commander');
    const afterPushWarrior = pushEnv.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(afterPushWarrior.gridX, 4);
    assert.equal(afterPushWarrior.gridZ, 4, 'Guarded Stance must prevent forced knockback/displacement');
  }

  // 3. Whirlwind Assault: hits all adjacent enemies within Chebyshev distance 1, ignores allies, holds tile
  {
    const ability = getWarriorAbility('whirlwind_assault');
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 3, gridZ: 3 });
    const enemyA = makeUnit({ id: 'e1', name: 'Raider A', faction: 'enemy', hp: 20, maxHp: 20, gridX: 3, gridZ: 2 });
    const enemyB = makeUnit({ id: 'e2', name: 'Raider B', faction: 'enemy', hp: 20, maxHp: 20, gridX: 4, gridZ: 4 }); // diagonal Chebyshev 1
    const ally = makeUnit({ id: 'ally_1', name: 'Lyra', faction: 'party', hp: 20, maxHp: 20, gridX: 2, gridZ: 3 });
    const distantEnemy = makeUnit({ id: 'e3', name: 'Archer', faction: 'enemy', hp: 20, maxHp: 20, gridX: 3, gridZ: 5 });

    const envRes = resolveEnvironmentalInteraction(
      warrior,
      ability,
      3,
      2,
      grid,
      [],
      [warrior, enemyA, enemyB, ally, distantEnemy],
      'e1'
    );
    const updated = envRes.updatedUnits;
    assert.ok(updated.find((u) => u.id === 'e2')!.hp < 20, 'Adjacent diagonal enemy hit by Whirlwind');
    assert.equal(updated.find((u) => u.id === 'ally_1')!.hp, 20, 'Adjacent ally must take zero friendly fire');
    assert.equal(updated.find((u) => u.id === 'e3')!.hp, 20, 'Out-of-range enemy untouched');
    assert.equal(updated.find((u) => u.id === 'commander')!.gridX, 3);
    assert.equal(updated.find((u) => u.id === 'commander')!.gridZ, 3, 'Warrior remains on current tile');
  }

  // 4. Driving Assault: charges adjacent to target, pushes 2 tiles back, deals +4 collision damage on wall/obstacle
  {
    const ability = getWarriorAbility('driving_assault');
    const openGrid = generateTacticalGrid(0, world).map((row) =>
      row.map((tile) => ({ ...tile, walkable: true, surface: 'none' as const, terrain: 'stone' as const }))
    );
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 1, gridZ: 2 });
    const enemyOpen = makeUnit({ id: 'e_open', name: 'Cultist', faction: 'enemy', armorClass: 10, hp: 30, maxHp: 30, gridX: 3, gridZ: 2 });
    const envOpen = resolveEnvironmentalInteraction(warrior, ability, 3, 2, openGrid, [], [warrior, enemyOpen], 'e_open');
    const movedWarrior = envOpen.updatedUnits.find((u) => u.id === 'commander')!;
    const pushedEnemy = envOpen.updatedUnits.find((u) => u.id === 'e_open')!;
    assert.equal(chebyshevDistance(movedWarrior.gridX, movedWarrior.gridZ, 3, 2), 1, 'Warrior charges adjacent to target original tile');
    assert.equal(pushedEnemy.gridX, 5, 'Target pushed 2 tiles back along charge vector');
    assert.equal(pushedEnemy.gridZ, 2);

    // Target at arena edge (x=9) collides with boundary for +4 impact damage
    const warriorEdge = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 7, gridZ: 2 });
    const enemyEdge = makeUnit({ id: 'e_edge', name: 'Cornered', faction: 'enemy', armorClass: 10, hp: 30, maxHp: 30, gridX: 9, gridZ: 2 });
    const envEdge = resolveEnvironmentalInteraction(warriorEdge, ability, 9, 2, openGrid, [], [warriorEdge, enemyEdge], 'e_edge');
    const slammedEnemy = envEdge.updatedUnits.find((u) => u.id === 'e_edge')!;
    assert.equal(slammedEnemy.hp, 26, 'Wall collision on Driving Assault push deals +4 impact damage (30 -> 26)');
  }

  // 5. Weapon Parry: grants +8 Temp HP + Warded, deflects next melee attack & counters for 8 DMG, ignores ranged/AoE
  {
    const ability = getWarriorAbility('weapon_parry');
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 2, gridZ: 2 });
    const envRes = resolveEnvironmentalInteraction(warrior, ability, 2, 2, grid, [], [warrior]);
    const parryingWarrior = envRes.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(parryingWarrior.weaponParryActive, true);
    assert.equal(parryingWarrior.tempHp, 8);

    // Ranged attack does NOT trigger Weapon Parry
    const rangedEnemy = makeUnit({ id: 'e_ranged', name: 'Weaver', faction: 'enemy', hp: 25, maxHp: 25, gridX: 2, gridZ: 6 });
    const rangedAb = { ...getWarriorAbility('sundering_strike'), range: 5 };
    const rangedReaction = resolveWarriorDefensiveReactions(rangedEnemy, parryingWarrior, rangedAb, 10);
    assert.equal(rangedReaction.parryTriggered, false, 'Ranged attack should not be parried');
    assert.equal(rangedReaction.finalDamage, 10);

    // Melee attack DOES trigger Weapon Parry: 0 damage taken, 8 counter damage to attacker
    const meleeEnemy = makeUnit({ id: 'e_melee', name: 'Brute', faction: 'enemy', hp: 25, maxHp: 25, gridX: 2, gridZ: 3 });
    const meleeAb = getWarriorAbility('sundering_strike');
    const meleeReaction = resolveWarriorDefensiveReactions(meleeEnemy, parryingWarrior, meleeAb, 14);
    assert.equal(meleeReaction.parryTriggered, true);
    assert.equal(meleeReaction.finalDamage, 0);
    assert.equal(meleeReaction.counterDamageToAttacker, 8);
  }

  // 6. Crippling Blow: applies Rooted (2 turns), respects rooted immunity
  {
    const ability = getWarriorAbility('crippling_blow');
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 2, gridZ: 2 });
    const runner = makeUnit({ id: 'e_runner', name: 'Skirmisher', faction: 'enemy', armorClass: 10, hp: 28, maxHp: 28, gridX: 2, gridZ: 3 });
    const res = resolveAbilityUse(warrior, runner, ability, [warrior, runner], rels, world, 15);
    assert.equal(res.statusApplied, 'rooted');

    // Immune enemy resists Rooted
    const unstoppable = makeUnit({
      id: 'e_golem',
      name: 'Golem',
      faction: 'enemy',
      armorClass: 10,
      hp: 40,
      maxHp: 40,
      gridX: 2,
      gridZ: 3,
      immunities: ['rooted'],
    });
    const resImmune = resolveAbilityUse(warrior, unstoppable, ability, [warrior, unstoppable], rels, world, 15);
    assert.equal(resImmune.statusApplied, undefined, 'Immune enemy resists Rooted');
  }

  // 7. Unbreakable Resolve: purges burning, rooted, sundered and refreshes +12 Temp HP without infinite stacking
  {
    const ability = getWarriorAbility('unbreakable_resolve');
    const debuffedWarrior = makeUnit({
      id: 'commander',
      name: 'Aurelia',
      tempHp: 5,
      statuses: [
        { type: 'burning', turnsLeft: 2 },
        { type: 'rooted', turnsLeft: 2 },
        { type: 'sundered', turnsLeft: 2 },
        { type: 'blessed', turnsLeft: 2 },
      ],
    });
    const envRes = resolveEnvironmentalInteraction(debuffedWarrior, ability, 2, 2, grid, [], [debuffedWarrior]);
    const cleansed = envRes.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(cleansed.statuses.some((e) => e.type === 'burning'), false);
    assert.equal(cleansed.statuses.some((e) => e.type === 'rooted'), false);
    assert.equal(cleansed.statuses.some((e) => e.type === 'sundered'), false);
    assert.equal(cleansed.statuses.some((e) => e.type === 'blessed'), true, 'Positive buffs must remain intact');
    assert.equal(cleansed.tempHp, 12, 'Refreshes Temp HP to 12 rather than stacking infinitely (5 -> 12)');
  }

  // 8. Earthsplitter: 3-tile directional line fracture, hits multiple lined-up enemies, stops early at impassable pillar
  {
    const ability = getWarriorAbility('earthsplitter');
    const openGrid = generateTacticalGrid(0, world).map((row) =>
      row.map((tile) => ({ ...tile, walkable: true, terrain: 'stone' as typeof tile.terrain }))
    );
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 2, gridZ: 1 });
    const frontEnemy = makeUnit({ id: 'e_front', name: 'Front', faction: 'enemy', armorClass: 10, hp: 30, maxHp: 30, gridX: 2, gridZ: 2 });
    const backEnemy = makeUnit({ id: 'e_back', name: 'Back', faction: 'enemy', armorClass: 10, hp: 30, maxHp: 30, gridX: 2, gridZ: 4 });

    // Open line hits backEnemy at z=4 along the 3-tile fracture
    const envOpen = resolveEnvironmentalInteraction(warrior, ability, 2, 2, openGrid, [], [warrior, frontEnemy, backEnemy], 'e_front');
    assert.ok(envOpen.updatedUnits.find((u) => u.id === 'e_back')!.hp < 30, 'Back enemy on open 3-tile line is struck');

    // Place an impassable stone pillar tile at (x=2, z=3) — fracture must stop at pillar and NOT hit backEnemy at z=4
    const pillarGrid = openGrid.map((row) => row.map((tile) => ({ ...tile })));
    pillarGrid[2][3].terrain = 'pillar';
    pillarGrid[2][3].walkable = false;
    const envBlocked = resolveEnvironmentalInteraction(warrior, ability, 2, 2, pillarGrid, [], [warrior, frontEnemy, backEnemy], 'e_front');
    assert.equal(envBlocked.updatedUnits.find((u) => u.id === 'e_back')!.hp, 30, 'Enemy behind impassable pillar is protected');
  }

  // 9. Relentless Pursuit: moves Warrior adjacent to target within 4 tiles, does not displace enemy, refunds +1 AP vs <=40% HP
  {
    const ability = getWarriorAbility('relentless_pursuit');
    const openGrid = generateTacticalGrid(0, world).map((row) =>
      row.map((tile) => ({ ...tile, walkable: true }))
    );
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', ap: 2, maxAp: 4, gridX: 1, gridZ: 1 });
    const woundedPrey = makeUnit({ id: 'e_prey', name: 'Fleeing Weaver', faction: 'enemy', armorClass: 10, hp: 10, maxHp: 30, gridX: 4, gridZ: 1 });
    const res = resolveAbilityUse(warrior, woundedPrey, ability, [warrior, woundedPrey], rels, world, 15);
    const envRes = resolveEnvironmentalInteraction(warrior, ability, 4, 1, openGrid, [], [warrior, woundedPrey], 'e_prey');
    const pursuedWarrior = envRes.updatedUnits.find((u) => u.id === 'commander')!;
    const struckPrey = envRes.updatedUnits.find((u) => u.id === 'e_prey')!;
    assert.equal(manhattanDistance(pursuedWarrior.gridX, pursuedWarrior.gridZ, 4, 1), 1, 'Warrior closes gap to adjacent tile');
    assert.equal(struckPrey.gridX, 4);
    assert.equal(struckPrey.gridZ, 1, 'Relentless Pursuit does not displace target');
    assert.equal(res.apRefunded, 1, 'Refunds +1 AP when striking enemy at or below 40% HP');
  }

  // 10. Iron Reprisal: deals +6 bonus damage when wounded or after taking damage, arms 1 non-recursive melee counter
  {
    const ability = getWarriorAbility('iron_reprisal');
    const healthyWarrior = makeUnit({ id: 'commander', name: 'Aurelia', hp: 40, maxHp: 40, damageTakenSinceLastTurn: 0, gridX: 2, gridZ: 2 });
    const woundedWarrior = makeUnit({ id: 'commander', name: 'Aurelia', hp: 25, maxHp: 40, damageTakenSinceLastTurn: 8, gridX: 2, gridZ: 2 });
    const target = makeUnit({ id: 'e_target', name: 'Executioner', faction: 'enemy', armorClass: 10, hp: 40, maxHp: 40, gridX: 2, gridZ: 3 });

    const resHealthy = resolveAbilityUse(healthyWarrior, target, ability, [healthyWarrior, target], rels, world, 15);
    const resWounded = resolveAbilityUse(woundedWarrior, target, ability, [woundedWarrior, target], rels, world, 15);
    assert.equal(resWounded.damage, resHealthy.damage + 6, 'Iron Reprisal deals +6 bonus damage when wounded');

    const envRes = resolveEnvironmentalInteraction(woundedWarrior, ability, 2, 3, grid, [], [woundedWarrior, target], 'e_target');
    const armedWarrior = envRes.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(armedWarrior.ironReprisalActive, true);

    // Trigger melee attack against armed Warrior -> 9 counter damage
    const meleeAb = getWarriorAbility('sundering_strike');
    const reaction1 = resolveWarriorDefensiveReactions(target, armedWarrior, meleeAb, 6);
    assert.equal(reaction1.reprisalTriggered, true);
    assert.equal(reaction1.counterDamageToAttacker, 9);
  }

  // 11. Battlefield Commander: grants Warrior and conscious allies within 4 tiles +10 Temp HP and Blessed (+2 Hit)
  {
    const ability = getWarriorAbility('battlefield_commander');
    const warrior = makeUnit({ id: 'commander', name: 'Aurelia', gridX: 3, gridZ: 3 });
    const nearAlly = makeUnit({ id: 'ally_near', name: 'Seraphina', faction: 'party', gridX: 5, gridZ: 4 });
    const farAlly = makeUnit({ id: 'ally_far', name: 'Kaelen', faction: 'party', gridX: 8, gridZ: 8 });
    const enemy = makeUnit({ id: 'e_near', name: 'Cultist', faction: 'enemy', gridX: 3, gridZ: 4 });

    const envRes = resolveEnvironmentalInteraction(warrior, ability, 3, 3, grid, [], [warrior, nearAlly, farAlly, enemy]);
    const updated = envRes.updatedUnits;
    const uWarrior = updated.find((u) => u.id === 'commander')!;
    const uNearAlly = updated.find((u) => u.id === 'ally_near')!;
    const uFarAlly = updated.find((u) => u.id === 'ally_far')!;
    const uEnemy = updated.find((u) => u.id === 'e_near')!;

    assert.equal(uWarrior.tempHp, 10);
    assert.ok(uWarrior.statuses.some((e) => e.type === 'blessed'));
    assert.equal(uNearAlly.tempHp, 10);
    assert.ok(uNearAlly.statuses.some((e) => e.type === 'blessed'));
    assert.equal(uFarAlly.tempHp, 0, 'Ally outside radius 4 is not buffed');
    assert.equal(uEnemy.tempHp, 0, 'Enemies are never buffed by Battlefield Commander');
  }

  // 12. Last Stand: gated by critical condition, usable once per combat, grants +20 Temp HP, Warded, and 1 HP floor
  {
    const ability = getWarriorAbility('last_stand');
    const healthyAlone = makeUnit({ id: 'commander', name: 'Aurelia', hp: 40, maxHp: 40, gridX: 2, gridZ: 2 });
    const allyAlive = makeUnit({ id: 'ally_1', name: 'Lyra', faction: 'party', hp: 25, maxHp: 25, gridX: 1, gridZ: 1 });
    assert.equal(isLastStandConditionMet(healthyAlone, [healthyAlone, allyAlive]).allowed, false, 'Cannot use Last Stand when healthy and not surrounded');

    // Slot state evaluator disables Last Stand when condition is not met
    const gatedState = evaluateSkillSlotState(healthyAlone, ability, [healthyAlone, allyAlive], grid, []);
    assert.equal(gatedState.state, 'disabled');

    // Critical HP (<= 45%) unlocks Last Stand
    const criticalWarrior = makeUnit({ id: 'commander', name: 'Aurelia', hp: 15, maxHp: 40, gridX: 2, gridZ: 2 });
    assert.equal(isLastStandConditionMet(criticalWarrior, [criticalWarrior, allyAlive]).allowed, true);

    const envRes = resolveEnvironmentalInteraction(criticalWarrior, ability, 2, 2, grid, [], [criticalWarrior, allyAlive]);
    const undyingWarrior = envRes.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(undyingWarrior.tempHp, 20);
    assert.equal(undyingWarrior.lastStandTurns, 2);
    assert.equal(undyingWarrior.usedLastStand, true);

    // Cannot trigger Last Stand a second time in the same encounter
    assert.equal(isLastStandConditionMet(undyingWarrior, [undyingWarrior, allyAlive]).allowed, false, 'Once-per-combat restriction enforced');

    // Lethal blow of 60 damage is clamped so Warrior survives at 1 HP
    const boss = makeUnit({ id: 'boss', faction: 'enemy', gridX: 2, gridZ: 3 });
    const meleeAb = getWarriorAbility('sundering_strike');
    const lethalReaction = resolveWarriorDefensiveReactions(boss, undyingWarrior, meleeAb, 60);
    assert.equal(lethalReaction.lastStandClamped, true);
    const remainingHp = undyingWarrior.hp + undyingWarrior.tempHp - lethalReaction.finalDamage;
    assert.equal(remainingHp, 1, 'Last Stand clamps incoming damage so Warrior survives at 1 HP');

    // Environmental detonation (oil barrel) also respects the 1 HP survival floor under Last Stand
    const warriorAt1Hp: CombatUnit = { ...undyingWarrior, hp: 3, tempHp: 0, gridX: 6, gridZ: 2 };
    const barrelObj = {
      id: 'barrel_test',
      name: 'Oil Cask',
      kind: 'oil_barrel' as const,
      gridX: 6,
      gridZ: 3,
      elevation: 0,
      hp: 10,
      maxHp: 10,
      pushable: true,
      destroyed: false,
    };
    const fireAb = { ...meleeAb, element: 'fire' as const };
    const barrelEnv = resolveEnvironmentalInteraction(boss, fireAb, 6, 3, grid, [barrelObj], [warriorAt1Hp, boss]);
    const afterBlastWarrior = barrelEnv.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(afterBlastWarrior.hp, 1, 'Last Stand 1 HP floor prevents environmental explosion from killing Warrior');
    assert.equal(afterBlastWarrior.isKO, false);
  }

  // 13. Task 6 Warrior Trial Grounds Controlled Encounter verification
  {
    const trial = createWarriorTrialGroundsEncounter(world);
    const commander = trial.units.find((u) => u.id === 'seraphina')!;
    assert.ok(commander, 'Trial Grounds includes Vanguard Commander unit');
    assert.equal(commander.abilities.length, 4, 'Trial Grounds equips 4 active Warrior skills in the 4-slot loadout');
    assert.ok(trial.units.some((u) => u.id === 'trial_high_defense' && u.armorClass >= 18), 'Includes High-AC target');
    assert.ok(trial.units.some((u) => u.id === 'trial_low_defense' && u.armorClass <= 12), 'Includes Low-AC bloodied target');
    assert.ok(trial.units.some((u) => u.id === 'trial_high_mobility' && u.moveRange >= 6), 'Includes High-Mobility target');
    assert.ok(trial.units.some((u) => u.id === 'trial_melee_boss' && u.hp >= 60), 'Includes Melee Boss target');
    assert.ok(trial.units.some((u) => u.id === 'trial_unstoppable' && u.immunities?.includes('rooted')), 'Includes Root-immune target');
    assert.ok(trial.units.some((u) => u.id === 'trial_displacement_immune' && u.immunities?.includes('displacement')), 'Includes Displacement-resistant target');
    assert.ok(trial.units.some((u) => u.id === 'trial_pillar_behind'), 'Includes enemy positioned behind stone pillar');
    assert.ok(trial.units.some((u) => u.id === 'trial_ranged_weaver'), 'Includes Ranged Caster target');
    assert.ok(trial.grid.some((row) => row.some((tile) => tile.terrain === 'pillar')), 'Includes impassable stone pillar terrain');
    assert.ok(trial.grid.some((row) => row.some((tile) => tile.terrain === 'hazard_rift' || tile.surface === 'fire_pool')), 'Includes environmental hazards');
  }
});

test('Warrior Core Skill Multi-Skill Combat Combinations (Synergy Chains & Defensive Layering)', () => {
  const world = createInitialWorldState();
  const rels = createInitialRelationships();
  const openGrid = generateTacticalGrid(0, world).map((row) =>
    row.map((tile) => ({ ...tile, walkable: true, terrain: 'stone' as typeof tile.terrain, surface: 'normal' as typeof tile.surface }))
  );

  const getWarriorAbility = (skillId: string, key: '1' | '2' | '3' | '4' = '1') => {
    const def = ALL_SKILLS_DATABASE[skillId];
    assert.ok(def, `Missing Warrior skill ${skillId} in ALL_SKILLS_DATABASE`);
    assert.equal(def.classKey, 'warrior');
    return toCombatAbility(def, key);
  };

  const makeUnit = (overrides: Partial<CombatUnit>): CombatUnit => ({
    id: 'unit_default',
    name: 'Test Unit',
    title: 'Combatant',
    faction: 'party',
    gridX: 2,
    gridZ: 2,
    elevation: 0,
    hp: 40,
    maxHp: 40,
    tempHp: 0,
    ap: 4,
    maxAp: 4,
    moveRange: 4,
    movedThisTurn: false,
    armorClass: 14,
    initiative: 15,
    stats: { str: 16, dex: 12, int: 10, cha: 12 },
    cooldowns: {},
    statuses: [],
    isKO: false,
    koTimer: 0,
    abilities: [],
    ...overrides,
  });

  // COMBO 1: Relentless Pursuit (Range 4 gap-close + +1 AP refund vs <=40% HP target) -> Sundering Strike -> 2nd Sundering Strike (+3 Exploit DMG)
  {
    const pursuit = getWarriorAbility('relentless_pursuit');
    const sunder = getWarriorAbility('sundering_strike');
    let warrior = makeUnit({ id: 'commander', name: 'Aurelia', ap: 2, maxAp: 4, gridX: 1, gridZ: 2 });
    let enemy = makeUnit({ id: 'e_combo1', name: 'Wounded Zealot', faction: 'enemy', armorClass: 14, hp: 16, maxHp: 40, gridX: 5, gridZ: 2 });

    // Step 1: Relentless Pursuit from 4 tiles away (costs 1 AP, refunds +1 AP because enemy HP 16/40 = 40%)
    const rPursuit = resolveAbilityUse(warrior, enemy, pursuit, [warrior, enemy], rels, world, 16);
    assert.equal(rPursuit.hit, true);
    assert.equal(rPursuit.apRefunded, 1, 'Relentless Pursuit refunds +1 AP against 40% HP target');
    const envPursuit = resolveEnvironmentalInteraction(warrior, pursuit, 5, 2, openGrid, [], [warrior, enemy], 'e_combo1');
    warrior = {
      ...envPursuit.updatedUnits.find((u) => u.id === 'commander')!,
      ap: Math.min(warrior.maxAp, warrior.ap - pursuit.apCost + (rPursuit.apRefunded ?? 0)),
    };
    enemy = {
      ...envPursuit.updatedUnits.find((u) => u.id === 'e_combo1')!,
      hp: 18, // Set HP to 18 so follow-up Sundering combo can be tested
    };
    assert.equal(warrior.ap, 2, 'Warrior retains 2 AP after Relentless Pursuit refund');
    assert.equal(manhattanDistance(warrior.gridX, warrior.gridZ, enemy.gridX, enemy.gridZ), 1, 'Warrior is now adjacent to target');

    // Step 2: First Sundering Strike (1 AP) applies Sundered (-2 AC)
    const rSunder1 = resolveAbilityUse(warrior, enemy, sunder, [warrior, enemy], rels, world, 16);
    assert.equal(rSunder1.hit, true);
    warrior = { ...warrior, ap: warrior.ap - sunder.apCost };
    enemy = {
      ...enemy,
      hp: Math.max(1, enemy.hp - rSunder1.damage),
      statuses: [{ type: 'sundered', turnsLeft: 2 }],
    };

    // Step 3: Second Sundering Strike (1 AP) exploits Sundered for +3 bonus damage
    const rSunder2 = resolveAbilityUse(warrior, enemy, sunder, [warrior, enemy], rels, world, 16);
    assert.equal(rSunder2.damage, rSunder1.damage + 3, 'Follow-up Sundering Strike deals +3 exploit damage after gap-close');
  }

  // COMBO 2: Driving Assault (Charge + Push 2 into Wall + Sundered) -> Crippling Blow (Rooted lockdown) -> Unbreakable Resolve (Debuff purge + 12 Temp HP)
  {
    const driving = getWarriorAbility('driving_assault');
    const crippling = getWarriorAbility('crippling_blow');
    const resolve = getWarriorAbility('unbreakable_resolve');

    let warrior = makeUnit({
      id: 'commander',
      name: 'Aurelia',
      ap: 4,
      gridX: 6,
      gridZ: 2,
      statuses: [
        { type: 'burning', turnsLeft: 2 },
        { type: 'sundered', turnsLeft: 2 },
      ],
    });
    let enemy = makeUnit({ id: 'e_combo2', name: 'Vanguard Raider', faction: 'enemy', armorClass: 12, hp: 40, maxHp: 40, moveRange: 5, gridX: 8, gridZ: 2 });

    // Driving Assault from (6,2) to (8,2): pushes enemy toward x=10, hits wall at x=9 for +4 collision damage
    const rDrive = resolveAbilityUse(warrior, enemy, driving, [warrior, enemy], rels, world, 16);
    assert.equal(rDrive.hit, true);
    const envDrive = resolveEnvironmentalInteraction(warrior, driving, 8, 2, openGrid, [], [warrior, enemy], 'e_combo2');
    warrior = envDrive.updatedUnits.find((u) => u.id === 'commander')!;
    enemy = envDrive.updatedUnits.find((u) => u.id === 'e_combo2')!;
    assert.equal(enemy.gridX, 9, 'Enemy slammed into arena boundary at x=9');
    assert.equal(enemy.hp, 36, 'Enemy took +4 wall collision damage');

    // Follow up with Crippling Blow from adjacent tile (8,2) -> (9,2)
    const rCripple = resolveAbilityUse(warrior, enemy, crippling, [warrior, enemy], rels, world, 16);
    assert.equal(rCripple.hit, true);
    assert.equal(rCripple.statusApplied, 'rooted');
    enemy = { ...enemy, statuses: [...enemy.statuses, { type: 'rooted', turnsLeft: 2 }] };
    const rootedTiles = getValidMoveTiles(enemy, openGrid, [warrior, enemy], []);
    assert.equal(rootedTiles.length, 0, 'Pinned raider has 0 movement tiles after Driving Assault + Crippling Blow');

    // Warrior uses Unbreakable Resolve to purge Burning + Sundered and refresh +12 Temp HP
    const envResolve = resolveEnvironmentalInteraction(warrior, resolve, warrior.gridX, warrior.gridZ, openGrid, [], [warrior, enemy]);
    warrior = envResolve.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(warrior.statuses.length, 0, 'Unbreakable Resolve cleanses Burning and Sundered');
    assert.equal(warrior.tempHp, 12, 'Unbreakable Resolve sets +12 Temp HP buffer');
  }

  // COMBO 3: Guarded Stance + Iron Reprisal + Last Stand survival against simultaneous multi-attacker assault
  {
    const stance = getWarriorAbility('guarded_stance');
    const reprisal = getWarriorAbility('iron_reprisal');
    const lastStand = getWarriorAbility('last_stand');
    const enemyStrike = getWarriorAbility('sundering_strike');

    let warrior = makeUnit({ id: 'commander', name: 'Aurelia', hp: 14, maxHp: 40, damageTakenSinceLastTurn: 10, gridX: 3, gridZ: 3 });
    const boss1 = makeUnit({ id: 'boss_1', name: 'Dread Executioner', faction: 'enemy', hp: 45, maxHp: 45, gridX: 3, gridZ: 4 });
    const boss2 = makeUnit({ id: 'boss_2', name: 'Ash Stalker', faction: 'enemy', hp: 35, maxHp: 35, gridX: 4, gridZ: 3 });

    // Activate Guarded Stance (+6 Temp HP, 25% phys reduction, displacement immunity)
    let env = resolveEnvironmentalInteraction(warrior, stance, 3, 3, openGrid, [], [warrior, boss1, boss2]);
    warrior = env.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(warrior.guardedStanceTurns, 2);

    // Strike Boss 1 with Iron Reprisal (+6 wounded bonus damage + arms 9 DMG melee counter)
    const rReprisal = resolveAbilityUse(warrior, boss1, reprisal, [warrior, boss1, boss2], rels, world, 16);
    assert.equal(rReprisal.hit, true);
    env = resolveEnvironmentalInteraction(warrior, reprisal, 3, 4, openGrid, [], [warrior, boss1, boss2], 'boss_1');
    warrior = env.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(warrior.ironReprisalActive, true);

    // Activate Last Stand (+20 Temp HP, 1 HP survival floor for 2 turns)
    env = resolveEnvironmentalInteraction(warrior, lastStand, 3, 3, openGrid, [], [warrior, boss1, boss2]);
    warrior = env.updatedUnits.find((u) => u.id === 'commander')!;
    assert.equal(warrior.lastStandTurns, 2);
    assert.equal(warrior.tempHp, 20);

    // Simultaneous Attack 1: Boss 1 swings for 20 physical damage -> reduced 25% to 15, triggers 9 DMG Iron Reprisal counter
    const hit1 = resolveWarriorDefensiveReactions(boss1, warrior, enemyStrike, 20);
    assert.equal(hit1.finalDamage, 15, 'Guarded Stance reduces 20 physical damage by 25% to 15');
    assert.equal(hit1.reprisalTriggered, true);
    assert.equal(hit1.counterDamageToAttacker, 9, 'Iron Reprisal counters Boss 1 for 9 damage');
    warrior = {
      ...warrior,
      ironReprisalActive: false,
      tempHp: Math.max(0, warrior.tempHp - hit1.finalDamage),
      hp: warrior.hp - Math.max(0, hit1.finalDamage - warrior.tempHp),
    };
    assert.equal(warrior.tempHp, 5);
    assert.equal(warrior.hp, 14);

    // Simultaneous Attack 2: Boss 2 swings for 40 physical damage -> reduced 25% to 30, clamped to 18 so Warrior survives at 1 HP!
    const hit2 = resolveWarriorDefensiveReactions(boss2, warrior, enemyStrike, 40);
    assert.equal(hit2.reprisalTriggered, false, 'Iron Reprisal already discharged on Attack 1');
    assert.equal(hit2.lastStandClamped, true, 'Last Stand clamps lethal second attack');
    const postHit2Hp = warrior.hp + warrior.tempHp - hit2.finalDamage;
    assert.equal(postHit2Hp, 1, 'Warrior survives simultaneous multi-boss assault at 1 HP');
  }
});















