import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  ALL_SKILLS_DATABASE,
  PlayableClassKey,
} from './progressionData';
import { CharacterSubclassId } from './rules';
import {
  MASTER_SKILL_REGISTRY,
  getAllMasterSkills,
  getMasterSkill,
  getMasterSkillsByClass,
  getMasterSkillsBySpecialization,
  validateMasterSkillSystem,
} from './skills/skillRegistry';
import {
  MASTER_ANIMATION_REGISTRY,
  getMasterAnimationConfig,
  getMasterAnimationPhase,
  isMasterAnimationFinished,
  sampleMasterRigTransform,
} from './skills/masterAnimationRegistry';
import { soundEngine } from './audio';

test('1. Total Count & Category Breakdown: Exactly 96 skills across 5 classes & 6 specializations', () => {
  const allSkills = getAllMasterSkills();
  assert.equal(allSkills.length, 96, 'Master registry must contain exactly 96 skills');

  // Verify class breakdown (60 core skills)
  const classes: PlayableClassKey[] = ['warrior', 'mage', 'rogue', 'paladin', 'ranger'];
  classes.forEach((c) => {
    const classSkills = getMasterSkillsByClass(c);
    assert.equal(classSkills.length, 12, `Class ${c} must have exactly 12 core skills`);
  });

  // Verify specialization breakdown (36 specialization skills)
  const specs: CharacterSubclassId[] = [
    'dawn_warden',
    'vengeance_knight',
    'crimson_savant',
    'rift_chronomancer',
    'briar_stalker',
    'ironbough_sentinel',
  ];
  specs.forEach((sp) => {
    const specSkills = getMasterSkillsBySpecialization(sp);
    assert.equal(specSkills.length, 6, `Specialization ${sp} must have exactly 6 skills`);
  });
});

test('2. Rule 1: No Repeated Skill Mechanics — strictly unique IDs, names, and mechanics', () => {
  const allSkills = getAllMasterSkills();
  const seenIds = new Set<string>();
  const seenNames = new Set<string>();
  const seenMechanics = new Set<string>();

  allSkills.forEach((s) => {
    // ID uniqueness
    assert.ok(!seenIds.has(s.id), `Duplicate skill ID found: ${s.id}`);
    seenIds.add(s.id);

    // Name uniqueness
    assert.ok(!seenNames.has(s.name.toLowerCase()), `Duplicate skill name found: ${s.name}`);
    seenNames.add(s.name.toLowerCase());

    // Central mechanic uniqueness
    const normalizedMechanic = s.centralMechanic.trim().toLowerCase();
    assert.ok(
      normalizedMechanic.length > 20,
      `Central mechanic for ${s.id} is too brief or missing`
    );
    assert.ok(
      !seenMechanics.has(normalizedMechanic),
      `Duplicate skill central mechanic found on ${s.id}: "${s.centralMechanic}"`
    );
    seenMechanics.add(normalizedMechanic);
  });

  assert.equal(seenIds.size, 96);
  assert.equal(seenNames.size, 96);
  assert.equal(seenMechanics.size, 96);
});

test('3. Rule 2: No Repeated Icon Artwork — strictly unique icon references and distinct disk SVG files', () => {
  const allSkills = getAllMasterSkills();
  const seenIconRefs = new Set<string>();
  const seenIconPaths = new Set<string>();
  const seenSvgContents = new Set<string>();

  const publicDir = path.resolve(process.cwd(), 'public');

  allSkills.forEach((s) => {
    // Unique iconReference string
    assert.ok(
      !seenIconRefs.has(s.iconReference),
      `Duplicate icon reference: ${s.iconReference} on skill ${s.id}`
    );
    seenIconRefs.add(s.iconReference);

    // Unique icon asset path
    assert.ok(
      !seenIconPaths.has(s.iconAssetPath),
      `Duplicate icon asset path: ${s.iconAssetPath} on skill ${s.id}`
    );
    seenIconPaths.add(s.iconAssetPath);

    // Verify SVG file exists on disk
    const diskPath = path.join(publicDir, s.iconAssetPath.replace(/^\//, ''));
    assert.ok(
      fs.existsSync(diskPath),
      `Icon file does not exist on disk for skill ${s.id}: ${diskPath}`
    );

    const svgContent = fs.readFileSync(diskPath, 'utf8').trim();
    assert.ok(svgContent.startsWith('<svg'), `File at ${diskPath} is not an SVG`);
    assert.ok(svgContent.includes('viewBox="0 0 128 128"'), `File at ${diskPath} lacks standard 128x128 viewBox`);

    // Verify distinct SVG artwork content (no two skills share the exact same SVG drawing)
    assert.ok(
      !seenSvgContents.has(svgContent),
      `Duplicate SVG artwork content detected between skills. File: ${diskPath}`
    );
    seenSvgContents.add(svgContent);
  });

  assert.equal(seenIconRefs.size, 96);
  assert.equal(seenIconPaths.size, 96);
  assert.equal(seenSvgContents.size, 96);
});

test('4. Rule 3: No Repeated Skill Animations — strictly unique animation IDs, durations, and rig transforms', () => {
  const allSkills = getAllMasterSkills();
  const seenAnimIds = new Set<string>();
  const impactPoseSignatures = new Set<string>();

  allSkills.forEach((s) => {
    const anim = s.animationConfig;
    assert.ok(anim, `Missing animationConfig for skill ${s.id}`);

    // Unique animation ID
    assert.ok(
      !seenAnimIds.has(anim.animationId),
      `Duplicate animationId: ${anim.animationId} on skill ${s.id}`
    );
    seenAnimIds.add(anim.animationId);

    // Valid timings
    assert.ok(anim.anticipationDuration > 0, `${s.id} anticipationDuration must be > 0`);
    assert.ok(anim.executionDuration > 0, `${s.id} executionDuration must be > 0`);
    assert.ok(anim.impactTiming > 0, `${s.id} impactTiming must be > 0`);
    assert.ok(anim.recoveryDuration > 0, `${s.id} recoveryDuration must be > 0`);
    assert.ok(anim.totalDuration > anim.impactTiming, `${s.id} totalDuration must be > impactTiming`);

    // Sample impact pose
    const { transform, phase } = sampleMasterRigTransform(s.id, anim.impactTiming);
    assert.equal(phase, 'impact', `Sampled pose at impactTiming for ${s.id} must be 'impact' phase`);
    assert.ok(transform.bodyPos && transform.bodyRot && transform.weaponPos && transform.weaponRot);

    // Pose signature uniqueness test (verifying distinct physical poses across skills)
    const poseSig = [
      transform.weaponPos.map((n) => n.toFixed(2)).join(','),
      transform.weaponRot.map((n) => n.toFixed(2)).join(','),
      transform.bodyPos.map((n) => n.toFixed(2)).join(','),
      transform.bodyRot.map((n) => n.toFixed(2)).join(','),
    ].join('|');

    assert.ok(
      !impactPoseSignatures.has(poseSig),
      `Duplicate impact pose signature between skills! ${s.id} shares pose ${poseSig}`
    );
    impactPoseSignatures.add(poseSig);
  });

  assert.equal(seenAnimIds.size, 96);
  assert.equal(impactPoseSignatures.size, 96);
});

test('5. Audio System Integration: Every skill triggers a verified method on soundEngine', () => {
  const allSkills = getAllMasterSkills();
  const soundEngineAny = soundEngine as unknown as Record<string, unknown>;

  allSkills.forEach((s) => {
    const soundMethod = s.audioMethod;
    assert.ok(soundMethod, `Skill ${s.id} is missing audioMethod`);

    const fn = soundEngineAny[soundMethod];
    assert.equal(
      typeof fn,
      'function',
      `Method ${soundMethod} referenced by skill ${s.id} does not exist on soundEngine`
    );

    // Verify calling method in headless environment does not throw
    assert.doesNotThrow(() => {
      (fn as () => void).call(soundEngine);
    }, `Calling soundEngine.${soundMethod}() threw an unexpected error`);
  });
});

test('6. Complete Validation Engine: validateMasterSkillSystem() reports 100% compliance', () => {
  const result = validateMasterSkillSystem();
  assert.equal(result.isValid, true, 'Validation system must pass');
  assert.equal(result.totalSkills, 96);
  assert.equal(result.duplicateIds.length, 0);
  assert.equal(result.duplicateAnimationIds.length, 0);
  assert.equal(result.duplicateIconReferences.length, 0);
  assert.equal(result.duplicateMechanics.length, 0);
  assert.equal(result.missingAnimationConfigs.length, 0);
});

test('7. Combat Progression Integration: All skills conform to AP, cooldown, range, and progression constraints', () => {
  const allSkills = getAllMasterSkills();

  allSkills.forEach((s) => {
    const def = s.definition;
    assert.ok(def.apCost >= 0 && def.apCost <= 4, `${s.id} invalid AP cost: ${def.apCost}`);
    assert.ok(def.cooldown >= 0 && def.cooldown <= 6, `${s.id} invalid cooldown: ${def.cooldown}`);
    assert.ok(def.minLevel >= 1 && def.minLevel <= 20, `${s.id} invalid minLevel: ${def.minLevel}`);
    assert.ok(def.range >= 0 && def.range <= 8, `${s.id} invalid range: ${def.range}`);
    assert.ok(['enemy', 'ally', 'self', 'ground'].includes(def.targetType), `${s.id} invalid targetType: ${def.targetType}`);
    assert.ok(def.skillPointCost === 1, `${s.id} skillPointCost must be 1`);
  });
});
