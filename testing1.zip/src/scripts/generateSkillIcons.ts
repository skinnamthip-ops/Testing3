import fs from 'fs';
import path from 'path';
import { ALL_SKILLS_DATABASE, SkillProgressionDefinition } from '../game/progressionData';

const iconDir = path.resolve('public/assets/icons/skills');
if (!fs.existsSync(iconDir)) {
  fs.mkdirSync(iconDir, { recursive: true });
}

function getThemeColors(skill: SkillProgressionDefinition): {
  bgStart: string;
  bgEnd: string;
  primary: string;
  secondary: string;
  accent: string;
} {
  const spec = skill.specializationKey;
  if (spec === 'dawn_warden') {
    return { bgStart: '#2A2314', bgEnd: '#141410', primary: '#E2B05A', secondary: '#F7E3A6', accent: '#D97724' };
  }
  if (spec === 'vengeance_knight') {
    return { bgStart: '#2A1616', bgEnd: '#140D0D', primary: '#C43D36', secondary: '#962B2B', accent: '#E0726B' };
  }
  if (spec === 'crimson_savant') {
    return { bgStart: '#291219', bgEnd: '#130A0E', primary: '#D13854', secondary: '#911C34', accent: '#F06782' };
  }
  if (spec === 'rift_chronomancer') {
    return { bgStart: '#142130', bgEnd: '#0C121C', primary: '#4A92D9', secondary: '#24598F', accent: '#82BEF5' };
  }
  if (spec === 'briar_stalker') {
    return { bgStart: '#152419', bgEnd: '#0C140E', primary: '#4CAF68', secondary: '#276E3C', accent: '#78D692' };
  }
  if (spec === 'ironbough_sentinel') {
    return { bgStart: '#261F16', bgEnd: '#14110C', primary: '#8F6E45', secondary: '#574125', accent: '#BDA277' };
  }

  // Core classes
  switch (skill.classKey) {
    case 'warrior':
      return { bgStart: '#261E16', bgEnd: '#13110E', primary: '#C27438', secondary: '#7A451D', accent: '#E8A366' };
    case 'mage':
      return { bgStart: '#1E192E', bgEnd: '#0F0D17', primary: '#8752DE', secondary: '#522A96', accent: '#B78FF5' };
    case 'rogue':
      return { bgStart: '#16211C', bgEnd: '#0E1411', primary: '#429668', secondary: '#23593D', accent: '#72C799' };
    case 'paladin':
      return { bgStart: '#262215', bgEnd: '#14120B', primary: '#D9A943', secondary: '#8A661D', accent: '#F2D37E' };
    case 'ranger':
      return { bgStart: '#17241A', bgEnd: '#0D140E', primary: '#4F9E56', secondary: '#27632D', accent: '#85D48D' };
    default:
      return { bgStart: '#242424', bgEnd: '#121212', primary: '#E2B05A', secondary: '#888888', accent: '#F2ECE1' };
  }
}

function generateEmblemSvg(skill: SkillProgressionDefinition, colors: ReturnType<typeof getThemeColors>): string {
  const p = colors.primary;
  const s = colors.secondary;
  const a = colors.accent;
  const cat = skill.category;

  if (cat === 'martial_cleave' || cat === 'execution_gapcloser' || skill.name.toLowerCase().includes('strike') || skill.name.toLowerCase().includes('assault')) {
    return `
      <!-- Crossed Blades / Heavy Cleave -->
      <path d="M24 104L104 24M28 20L100 92" stroke="${p}" stroke-width="4.5" stroke-linecap="round"/>
      <polygon points="100,20 108,28 92,44 84,36" fill="${a}" stroke="${s}" stroke-width="2"/>
      <polygon points="20,100 28,108 44,92 36,84" fill="${s}" stroke="${p}" stroke-width="2"/>
      <circle cx="64" cy="64" r="18" fill="none" stroke="${a}" stroke-width="2" stroke-dasharray="4 3"/>
      <path d="M42 42C56 30 72 30 86 42" stroke="${a}" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M42 86C56 98 72 98 86 86" stroke="${p}" stroke-width="3" fill="none" stroke-linecap="round"/>
    `;
  }

  if (cat === 'bastion_aura' || skill.name.toLowerCase().includes('shield') || skill.name.toLowerCase().includes('stance') || skill.name.toLowerCase().includes('ward')) {
    return `
      <!-- Crested Tower Shield & Bulwark -->
      <polygon points="64,22 96,36 88,86 64,106 40,86 32,36" fill="${s}" fill-opacity="0.4" stroke="${p}" stroke-width="4" stroke-linejoin="round"/>
      <polygon points="64,32 86,42 80,78 64,94 48,78 42,42" fill="none" stroke="${a}" stroke-width="2.2" stroke-linejoin="round"/>
      <line x1="64" y1="36" x2="64" y2="88" stroke="${a}" stroke-width="2.5"/>
      <line x1="46" y1="56" x2="82" y2="56" stroke="${a}" stroke-width="2.5"/>
      <circle cx="64" cy="56" r="5" fill="${a}"/>
    `;
  }

  if (cat === 'consecration_judgment' || cat === 'cleansing_mend' || skill.element === 'radiant') {
    return `
      <!-- Radiant Solar Cross & Halo -->
      <circle cx="64" cy="64" r="34" fill="none" stroke="${p}" stroke-width="2" stroke-dasharray="6 4"/>
      <path d="M64 16L64 112M16 64L112 64" stroke="${p}" stroke-width="4.5" stroke-linecap="round"/>
      <polygon points="64,26 72,48 94,40 82,60 102,64 82,68 94,88 72,80 64,102 56,80 34,88 46,68 26,64 46,60 34,40 56,48" fill="${a}" fill-opacity="0.6"/>
      <circle cx="64" cy="64" r="9" fill="${a}" stroke="#171B19" stroke-width="2"/>
    `;
  }

  if (cat === 'spacetime_implosion' || cat === 'phase_transfusion' || cat === 'piercing_ray' || skill.element === 'arcane') {
    return `
      <!-- Astral Singularity & Dimensional Rift -->
      <circle cx="64" cy="64" r="28" fill="none" stroke="${p}" stroke-width="3"/>
      <ellipse cx="64" cy="64" rx="42" ry="16" fill="none" stroke="${a}" stroke-width="2.4" transform="rotate(-30 64 64)"/>
      <ellipse cx="64" cy="64" rx="42" ry="16" fill="none" stroke="${s}" stroke-width="2.4" transform="rotate(30 64 64)"/>
      <circle cx="64" cy="64" r="8" fill="${a}"/>
      <polygon points="64,18 70,36 88,42 74,54 78,72 64,62 50,72 54,54 40,42 58,36" fill="${p}" fill-opacity="0.5"/>
    `;
  }

  if (cat === 'pyromantic_detonation' || skill.element === 'fire') {
    return `
      <!-- Pyromantic Firestorm -->
      <path d="M64 18C74 38 94 48 94 72C94 92 78 108 64 108C50 108 34 92 34 72C34 52 50 38 64 18Z" fill="${s}" fill-opacity="0.4" stroke="${p}" stroke-width="3.5"/>
      <path d="M64 42C70 54 82 62 82 76C82 86 74 96 64 96C54 96 46 86 46 76C46 64 56 54 64 42Z" fill="${a}" stroke="${p}" stroke-width="2"/>
      <circle cx="64" cy="76" r="6" fill="#F2ECE1"/>
    `;
  }

  if (cat === 'deadeye_snipe' || skill.classKey === 'ranger') {
    return `
      <!-- Recurve Bow & Piercing Arrowhead -->
      <path d="M30 26C54 44 54 84 30 102" stroke="${p}" stroke-width="4.5" fill="none" stroke-linecap="round"/>
      <line x1="30" y1="26" x2="30" y2="102" stroke="${s}" stroke-width="1.8"/>
      <line x1="22" y1="64" x2="106" y2="64" stroke="${a}" stroke-width="3.2"/>
      <polygon points="106,64 92,54 96,64 92,74" fill="${a}" stroke="${p}" stroke-width="1.8"/>
      <circle cx="64" cy="64" r="16" fill="none" stroke="${a}" stroke-width="1.5" stroke-dasharray="3 3"/>
    `;
  }

  if (cat === 'trap_snare' || cat === 'briar_barricade' || skill.element === 'nature') {
    return `
      <!-- Entangling Bramble Thorns -->
      <path d="M22 64C42 42 52 86 74 54C88 34 96 68 106 64" stroke="${p}" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M36 50L46 44M60 74L70 82M82 46L92 38" stroke="${a}" stroke-width="3" stroke-linecap="round"/>
      <circle cx="64" cy="64" r="24" fill="none" stroke="${s}" stroke-width="2.5" stroke-dasharray="4 4"/>
      <polygon points="64,28 72,40 64,52 56,40" fill="${a}"/>
      <polygon points="64,76 72,88 64,100 56,88" fill="${a}"/>
    `;
  }

  // Default rogue / precise emblem
  return `
    <!-- Precision Crosshair & Shadow Blades -->
    <circle cx="64" cy="64" r="30" fill="none" stroke="${p}" stroke-width="3"/>
    <circle cx="64" cy="64" r="14" fill="none" stroke="${a}" stroke-width="2"/>
    <line x1="64" y1="20" x2="64" y2="44" stroke="${a}" stroke-width="2.5"/>
    <line x1="64" y1="84" x2="64" y2="108" stroke="${a}" stroke-width="2.5"/>
    <line x1="20" y1="64" x2="44" y2="64" stroke="${a}" stroke-width="2.5"/>
    <line x1="84" y1="64" x2="108" y2="64" stroke="${a}" stroke-width="2.5"/>
    <circle cx="64" cy="64" r="4" fill="${a}"/>
  `;
}

function generateSvgContent(skill: SkillProgressionDefinition): string {
  const colors = getThemeColors(skill);
  const emblem = generateEmblemSvg(skill, colors);

  return `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128" fill="none">
  <defs>
    <radialGradient id="bg_${skill.id}" cx="50%" cy="46%" r="62%">
      <stop offset="0%" stop-color="${colors.bgStart}"/>
      <stop offset="100%" stop-color="${colors.bgEnd}"/>
    </radialGradient>
    <radialGradient id="aura_${skill.id}" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="${colors.primary}" stop-opacity="0.22"/>
      <stop offset="100%" stop-color="${colors.primary}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="128" height="128" fill="url(#bg_${skill.id})"/>
  <rect x="2" y="2" width="124" height="124" rx="4" fill="none" stroke="#5A4B38" stroke-width="1.8" opacity="0.6"/>
  <!-- Fantasy Border Insets -->
  <g opacity="0.38" stroke="${colors.primary}" stroke-width="1.2">
    <path d="M6 16L16 6M122 16L112 6M6 112L16 122M122 112L112 122"/>
    <circle cx="16" cy="16" r="2" fill="${colors.accent}"/>
    <circle cx="112" cy="16" r="2" fill="${colors.accent}"/>
    <circle cx="16" cy="112" r="2" fill="${colors.accent}"/>
    <circle cx="112" cy="112" r="2" fill="${colors.accent}"/>
  </g>
  <circle cx="64" cy="64" r="50" fill="url(#aura_${skill.id})"/>
  ${emblem}
</svg>`;
}

let generatedCount = 0;
for (const [skillId, skill] of Object.entries(ALL_SKILLS_DATABASE)) {
  const filePath = path.join(iconDir, `${skillId}.svg`);
  if (!fs.existsSync(filePath)) {
    const svg = generateSvgContent(skill);
    fs.writeFileSync(filePath, svg, 'utf8');
    generatedCount++;
  }
}

console.log(`Successfully generated ${generatedCount} missing skill SVG icons in public/assets/icons/skills!`);
