import React, { useState, useMemo, useRef, useCallback } from 'react';
import {
  DistrictId,
  InteriorId,
  TOWN_GRID_SIZE,
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  generateGloamrestExteriorGrid,
} from '../game/gloamrestMapAndInteriors';
import { GloamrestSaveState } from '../game/gloamrestEngineTypes';
import { GLOAMREST_QUESTS } from '../game/gloamrestItemsAndQuests';
import {
  MAP_DISTRICT_METADATA,
  MAP_BUILDINGS,
  MapDistrictMetadata,
  MapBuildingMetadata,
  MapFilterCategory,
  MapDiscoveryState,
  getDistrictDiscoveryState,
  getDiscoveredDistrictsCount,
  getExploredInteriorsCount,
  getActiveQuestMapMarkers,
  getNpcMapMarkers,
  getServiceMapMarkers,
} from '../game/gloamrestMapData';

export interface GloamrestSettlementMapModalProps {
  gloamrestState: GloamrestSaveState;
  onClose: () => void;
  onTrackQuest?: (questId: any) => void;
}

export const GloamrestSettlementMapModal: React.FC<GloamrestSettlementMapModalProps> = ({
  gloamrestState,
  onClose,
  onTrackQuest,
}) => {
  const exteriorGrid = useMemo(() => generateGloamrestExteriorGrid(), []);

  // Selected District & Building
  const [selectedDistrictId, setSelectedDistrictId] = useState<DistrictId>('hearth_square');
  const [selectedBuildingId, setSelectedBuildingId] = useState<string | null>(null);

  // Map Filter & Search
  const [activeFilter, setActiveFilter] = useState<MapFilterCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Interactive Zoom & Pan State
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const panStartRef = useRef<{ mouseX: number; mouseY: number; startPanX: number; startPanY: number }>({
    mouseX: 0,
    mouseY: 0,
    startPanX: 0,
    startPanY: 0,
  });

  const svgRef = useRef<SVGSVGElement | null>(null);

  // Player position mapped to exterior coordinate (if inside building, map to its doorway)
  const playerMapCoords = useMemo(() => {
    if (gloamrestState.currentSceneId === 'exterior') {
      return gloamrestState.playerPos;
    }
    const interior = GLOAMREST_INTERIORS[gloamrestState.currentSceneId as InteriorId];
    if (interior && interior.returnSceneId === 'exterior') {
      return interior.returnSpawn;
    }
    return MAP_DISTRICT_METADATA.abandoned_manor.center;
  }, [gloamrestState.currentSceneId, gloamrestState.playerPos]);

  // Active markers
  const questMarkers = useMemo(() => getActiveQuestMapMarkers(gloamrestState), [gloamrestState]);
  const npcMarkers = useMemo(() => getNpcMapMarkers(gloamrestState), [gloamrestState]);
  const serviceMarkers = useMemo(() => getServiceMapMarkers(), []);

  const selectedDistrictMeta: MapDistrictMetadata =
    MAP_DISTRICT_METADATA[selectedDistrictId] ?? MAP_DISTRICT_METADATA.hearth_square;
  const selectedBuildingMeta: MapBuildingMetadata | undefined = selectedBuildingId
    ? MAP_BUILDINGS.find((b) => b.id === selectedBuildingId)
    : undefined;

  const districtDiscoveryState = getDistrictDiscoveryState(gloamrestState, selectedDistrictId);

  // Discovery statistics
  const discoveredCount = getDiscoveredDistrictsCount(gloamrestState);
  const exploredInteriorsCount = getExploredInteriorsCount(gloamrestState);

  // Zoom handlers
  const handleZoomIn = () => setZoomLevel((z) => Math.min(2.5, +(z + 0.25).toFixed(2)));
  const handleZoomOut = () => setZoomLevel((z) => Math.max(0.75, +(z - 0.25).toFixed(2)));
  const handleResetZoom = () => {
    setZoomLevel(1.0);
    setPanOffset({ x: 0, y: 0 });
  };

  // Center on player
  const handleCenterOnPlayer = () => {
    // Player coords in 0..50 grid -> 0..500 SVG space
    const targetSvgX = playerMapCoords.x * 10;
    const targetSvgY = playerMapCoords.z * 10;
    const offsetX = 250 - targetSvgX;
    const offsetY = 250 - targetSvgY;
    setPanOffset({
      x: Math.max(-140, Math.min(140, offsetX)),
      y: Math.max(-140, Math.min(140, offsetY)),
    });
  };

  // Wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      setZoomLevel((z) => Math.min(2.5, +(z + 0.15).toFixed(2)));
    } else {
      setZoomLevel((z) => Math.max(0.75, +(z - 0.15).toFixed(2)));
    }
  };

  // Pan drag events
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0 && e.button !== 1) return; // Left or middle click
    setIsPanning(true);
    panStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startPanX: panOffset.x,
      startPanY: panOffset.y,
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning) return;
    const deltaX = (e.clientX - panStartRef.current.mouseX) / zoomLevel;
    const deltaY = (e.clientY - panStartRef.current.mouseY) / zoomLevel;
    setPanOffset({
      x: Math.max(-180, Math.min(180, panStartRef.current.startPanX + deltaX)),
      y: Math.max(-180, Math.min(180, panStartRef.current.startPanY + deltaY)),
    });
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // District selection helper
  const handleSelectDistrict = (distId: DistrictId) => {
    setSelectedDistrictId(distId);
    setSelectedBuildingId(null);
  };

  // Building selection helper
  const handleSelectBuilding = (bldgId: string, distId: DistrictId) => {
    setSelectedBuildingId(bldgId);
    setSelectedDistrictId(distId);
  };

  // Filtered buildings based on search query
  const searchedBuildings = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return MAP_BUILDINGS.filter(
      (b) =>
        gloamrestState.discoveredDistricts.includes(b.districtId) &&
        (b.name.toLowerCase().includes(query) ||
          b.category.toLowerCase().includes(query) ||
          b.services.some((s) => s.toLowerCase().includes(query)))
    );
  }, [searchQuery, gloamrestState.discoveredDistricts]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-testid="gloamrest-settlement-map-modal"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9000,
        backgroundColor: 'rgba(10, 14, 12, 0.90)',
        backdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        color: '#F2ECE1',
        fontFamily: 'Cinzel, Georgia, serif',
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        style={{
          width: '80vw',
          maxWidth: '1440px',
          height: '82vh',
          maxHeight: '940px',
          backgroundColor: '#161C18',
          border: '2px solid #5A4B38',
          borderRadius: '8px',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 25px 60px rgba(0, 0, 0, 0.9), inset 0 0 120px rgba(226, 176, 90, 0.04)',
          overflow: 'hidden',
        }}
      >
        {/* A. HEADER */}
        <div
          style={{
            padding: '14px 24px',
            backgroundColor: '#111613',
            borderBottom: '2px solid #5A4B38',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexShrink: 0,
          }}
        >
          <div>
            <div
              style={{
                fontSize: '11px',
                letterSpacing: '2px',
                color: '#E2B05A',
                fontWeight: 700,
                fontFamily: 'JetBrains Mono, monospace',
                textTransform: 'uppercase',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <span>🧭</span> CARTOGRAPHER’S SURVEY · WHISPERING VALE
            </div>
            <h2
              style={{
                margin: '2px 0 0 0',
                fontSize: '22px',
                color: '#F2ECE1',
                letterSpacing: '1.5px',
                fontWeight: 700,
              }}
            >
              SETTLEMENT CHARTER OF GLOAMREST
            </h2>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div
              style={{
                padding: '6px 14px',
                backgroundColor: '#1E2420',
                border: '1px solid #5A4B38',
                borderRadius: '4px',
                fontSize: '12px',
                color: '#B5AC9A',
                fontFamily: 'JetBrains Mono, monospace',
                letterSpacing: '1px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <span style={{ color: '#E2B05A' }}>
                {gloamrestState.timeOfDay === 'night' ? '🌙' : '☀️'}
              </span>
              <span>
                DAY {gloamrestState.dayCount} · {gloamrestState.timeOfDay.toUpperCase()}
              </span>
            </div>

            <button
              onClick={onClose}
              style={{
                backgroundColor: '#222722',
                border: '1px solid #5A4B38',
                color: '#F2ECE1',
                padding: '8px 16px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontFamily: 'Cinzel, Georgia, serif',
                fontSize: '12px',
                letterSpacing: '1px',
                transition: 'all 0.15s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#B85349';
                e.currentTarget.style.borderColor = '#E74C3C';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#222722';
                e.currentTarget.style.borderColor = '#5A4B38';
              }}
            >
              CLOSE MAP [M / ESC]
            </button>
          </div>
        </div>

        {/* BODY CONTAINER: FULL WIDTH CARTOGRAPHIC MAP */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {/* MAIN CARTOGRAPHIC MAP AREA */}
          <div
            style={{
              flex: 1,
              backgroundColor: '#111513',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
              position: 'relative',
            }}
          >
            {/* Top Toolbar: Zoom, Center, Filters & Search */}
            <div
              style={{
                padding: '10px 16px',
                backgroundColor: '#171B19',
                borderBottom: '1px solid #3A3324',
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '10px',
                zIndex: 10,
              }}
            >
              {/* Zoom Controls */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <button
                  onClick={handleZoomIn}
                  title="Zoom In"
                  style={{
                    width: '28px',
                    height: '28px',
                    backgroundColor: '#222722',
                    border: '1px solid #5A4B38',
                    color: '#F2ECE1',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 700,
                  }}
                >
                  +
                </button>
                <button
                  onClick={handleZoomOut}
                  title="Zoom Out"
                  style={{
                    width: '28px',
                    height: '28px',
                    backgroundColor: '#222722',
                    border: '1px solid #5A4B38',
                    color: '#F2ECE1',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 700,
                  }}
                >
                  −
                </button>
                <button
                  onClick={handleResetZoom}
                  title="Reset Zoom & Pan"
                  style={{
                    padding: '4px 8px',
                    backgroundColor: '#222722',
                    border: '1px solid #5A4B38',
                    color: '#B5AC9A',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                >
                  {Math.round(zoomLevel * 100)}% ⟲
                </button>
                <button
                  onClick={handleCenterOnPlayer}
                  title="Center On Player"
                  style={{
                    padding: '4px 10px',
                    backgroundColor: '#1E2B25',
                    border: '1px solid #38BDF8',
                    color: '#38BDF8',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono, monospace',
                    fontWeight: 700,
                  }}
                >
                  ⌖ YOU
                </button>
              </div>

              {/* Category Filter Buttons */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                {(['all', 'services', 'quests', 'npcs', 'exits'] as MapFilterCategory[]).map(
                  (cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveFilter(cat)}
                      style={{
                        padding: '3px 8px',
                        backgroundColor: activeFilter === cat ? '#E2B05A' : '#1C211E',
                        border: `1px solid ${activeFilter === cat ? '#F59E0B' : '#3A3324'}`,
                        borderRadius: '3px',
                        color: activeFilter === cat ? '#171B19' : '#B5AC9A',
                        fontSize: '10px',
                        fontWeight: 700,
                        fontFamily: 'JetBrains Mono, monospace',
                        textTransform: 'uppercase',
                        cursor: 'pointer',
                      }}
                    >
                      {cat}
                    </button>
                  )
                )}
              </div>

              {/* Search Box */}
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  placeholder="Search discovered..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  style={{
                    width: '150px',
                    padding: '4px 8px 4px 22px',
                    backgroundColor: '#111513',
                    border: '1px solid #5A4B38',
                    borderRadius: '4px',
                    color: '#F2ECE1',
                    fontSize: '11px',
                    fontFamily: 'sans-serif',
                    outline: 'none',
                  }}
                />
                <span
                  style={{
                    position: 'absolute',
                    left: '6px',
                    top: '4px',
                    fontSize: '11px',
                    color: '#77796F',
                  }}
                >
                  🔍
                </span>
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    style={{
                      position: 'absolute',
                      right: '6px',
                      top: '4px',
                      background: 'none',
                      border: 'none',
                      color: '#B5AC9A',
                      cursor: 'pointer',
                      fontSize: '10px',
                    }}
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Interactive SVG Viewport with Drag & Wheel */}
            <div
              style={{
                flex: 1,
                position: 'relative',
                overflow: 'hidden',
                cursor: isPanning ? 'grabbing' : 'grab',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: '#0F1311',
              }}
              onWheel={handleWheel}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              <svg
                ref={svgRef}
                viewBox={`0 0 ${TOWN_GRID_SIZE * 10} ${TOWN_GRID_SIZE * 10}`}
                style={{
                  width: '100%',
                  height: '100%',
                  transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoomLevel})`,
                  transformOrigin: 'center center',
                  transition: isPanning ? 'none' : 'transform 0.1s ease-out',
                }}
              >
                <defs>
                  {/* Hatched Pattern for Undiscovered Fog-of-War */}
                  <pattern
                    id="mapHatch"
                    width="12"
                    height="12"
                    patternTransform="rotate(45 0 0)"
                    patternUnits="userSpaceOnUse"
                  >
                    <line x1="0" y1="0" x2="0" y2="12" stroke="#1F2821" strokeWidth="2.5" />
                  </pattern>

                  {/* Radial River Gradient */}
                  <linearGradient id="riverGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#14313B" />
                    <stop offset="50%" stopColor="#1B4250" />
                    <stop offset="100%" stopColor="#14313B" />
                  </linearGradient>

                  {/* Cobblestone Pattern */}
                  <pattern id="cobblePattern" width="10" height="10" patternUnits="userSpaceOnUse">
                    <rect width="10" height="10" fill="#433B32" />
                    <circle cx="5" cy="5" r="4.2" fill="#4D4339" stroke="#362E26" strokeWidth="0.8" />
                  </pattern>
                </defs>

                {/* Layer 1: Base Terrain Grid */}
                {exteriorGrid.map((col, x) =>
                  col.map((tile, z) => {
                    let fill = '#1A231C';
                    if (tile.terrain === 'river_water') fill = 'url(#riverGradient)';
                    else if (tile.terrain === 'cobble_plaza') fill = '#4D4439';
                    else if (tile.terrain === 'main_road') fill = '#453C32';
                    else if (tile.terrain === 'dirt_path' || tile.terrain === 'alley')
                      fill = '#382F24';
                    else if (tile.terrain === 'stone_bridge') fill = '#786C5A';
                    else if (tile.terrain === 'wooden_bridge') fill = '#6B5034';
                    else if (tile.terrain === 'wall_stone') fill = '#2E302D';
                    else if (tile.terrain === 'rocky_hill') fill = '#141615';
                    else if (tile.terrain === 'forest_floor') fill = '#141B16';

                    return (
                      <rect
                        key={`${x}-${z}`}
                        x={x * 10}
                        y={z * 10}
                        width={10.2}
                        height={10.2}
                        fill={fill}
                      />
                    );
                  })
                )}

                {/* Layer 2: River Bank Outlines */}
                <path
                  d="M 310 20 L 310 470"
                  stroke="#234E5E"
                  strokeWidth="2"
                  fill="none"
                />
                <path
                  d="M 330 20 L 330 470"
                  stroke="#234E5E"
                  strokeWidth="2"
                  fill="none"
                />

                {/* Layer 3: Bridges Over Silverbrook */}
                {/* 1) Gatehouse Stone Bridge */}
                <rect x={300} y={70} width={30} height={20} fill="#786C5A" stroke="#E2B05A" strokeWidth="1" />
                <line x1={300} y1={80} x2={330} y2={80} stroke="#4A3D2E" strokeWidth="1.5" />
                {/* 2) Central Market Stone Bridge */}
                <rect x={300} y={240} width={30} height={20} fill="#786C5A" stroke="#E2B05A" strokeWidth="1" />
                <line x1={300} y1={250} x2={330} y2={250} stroke="#4A3D2E" strokeWidth="1.5" />
                {/* 3) Southern Mill Wooden Bridge */}
                <rect x={300} y={355} width={30} height={15} fill="#5E4329" stroke="#8C633E" strokeWidth="1" />

                {/* Layer 4: Hearth Square Plaza Center Rim */}
                <circle cx={245} cy={255} r={46} fill="none" stroke="#635748" strokeWidth="2" strokeDasharray="6 4" />
                <circle cx={245} cy={255} r={8} fill="#243428" stroke="#E2B05A" strokeWidth="1.5" />

                {/* Layer 5: Building Footprints */}
                {MAP_BUILDINGS.map((bldg) => {
                  const isSelected = selectedBuildingId === bldg.id;
                  const isDistrictDiscovered = gloamrestState.discoveredDistricts.includes(bldg.districtId);
                  const isMatch = searchedBuildings.some((sb) => sb.id === bldg.id);

                  const bx = bldg.footprint.minX * 10;
                  const bz = bldg.footprint.minZ * 10;
                  const bw = (bldg.footprint.maxX - bldg.footprint.minX + 1) * 10;
                  const bh = (bldg.footprint.maxZ - bldg.footprint.minZ + 1) * 10;

                  return (
                    <g
                      key={bldg.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectBuilding(bldg.id, bldg.districtId);
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <title>{`${bldg.name} (${bldg.category}) · Services: ${bldg.services.join(', ')}`}</title>
                      {/* Drop shadow */}
                      <rect
                        x={bx + 2}
                        y={bz + 2}
                        width={bw}
                        height={bh}
                        fill="rgba(0, 0, 0, 0.6)"
                        rx="1"
                      />
                      {/* Main Building Roof */}
                      <rect
                        x={bx}
                        y={bz}
                        width={bw}
                        height={bh}
                        fill={isSelected ? '#4A3D28' : isMatch ? '#544626' : '#5E4A34'}
                        stroke={isSelected ? '#F59E0B' : isMatch ? '#E2B05A' : '#7D6448'}
                        strokeWidth={isSelected ? '2.5' : '1.2'}
                        rx="1"
                      />
                      {/* Roof Gable Ridge Line */}
                      <line
                        x1={bx + 3}
                        y1={bz + bh / 2}
                        x2={bx + bw - 3}
                        y2={bz + bh / 2}
                        stroke="#7D6448"
                        strokeWidth="1"
                      />
                      {/* Doorstep Marker */}
                      {bldg.doorTile && (
                        <circle
                          cx={bldg.doorTile.x * 10 + 5}
                          cy={bldg.doorTile.z * 10 + 5}
                          r="2.5"
                          fill="#E2B05A"
                        />
                      )}
                    </g>
                  );
                })}

                {/* Layer 6: District Boundaries & Interaction Zones */}
                {(
                  Object.values(GLOAMREST_DISTRICTS) as (typeof GLOAMREST_DISTRICTS)[DistrictId][]
                ).map((dist) => {
                  const isDiscovered = gloamrestState.discoveredDistricts.includes(dist.id);
                  const isSelected = selectedDistrictId === dist.id;
                  const discoveryState = getDistrictDiscoveryState(gloamrestState, dist.id);

                  const bx = dist.bounds.minX * 10;
                  const bz = dist.bounds.minZ * 10;
                  const bw = (dist.bounds.maxX - dist.bounds.minX + 1) * 10;
                  const bh = (dist.bounds.maxZ - dist.bounds.minZ + 1) * 10;

                  return (
                    <g
                      key={dist.id}
                      onClick={() => handleSelectDistrict(dist.id)}
                      style={{ cursor: 'pointer' }}
                    >
                      <title>{isDiscovered ? `${dist.name} (${dist.subtitle})` : 'Unknown Quarter (Unexplored)'}</title>
                      {/* District Boundary Box */}
                      <rect
                        x={bx}
                        y={bz}
                        width={bw}
                        height={bh}
                        fill={
                          !isDiscovered
                            ? 'url(#mapHatch)'
                            : isSelected
                            ? 'rgba(226, 176, 90, 0.08)'
                            : 'transparent'
                        }
                        stroke={
                          isSelected
                            ? '#E2B05A'
                            : isDiscovered
                            ? '#5A4B38'
                            : '#2A302B'
                        }
                        strokeWidth={isSelected ? '2.5' : '1.2'}
                        strokeDasharray={isSelected ? undefined : '5 4'}
                      />

                      {/* Fog of War Overlay for Undiscovered Districts */}
                      {!isDiscovered && (
                        <rect
                          x={bx}
                          y={bz}
                          width={bw}
                          height={bh}
                          fill="rgba(11, 15, 12, 0.72)"
                        />
                      )}

                      {/* District Name Label */}
                      <text
                        x={dist.center.x * 10}
                        y={dist.center.z * 10}
                        textAnchor="middle"
                        fontSize="11"
                        fontFamily="Cinzel, serif"
                        fontWeight="700"
                        letterSpacing="1px"
                        fill={
                          isSelected
                            ? '#F59E0B'
                            : isDiscovered
                            ? discoveryState === 'fully_explored'
                              ? '#7E9C82'
                              : '#F2ECE1'
                            : '#6B7068'
                        }
                        stroke="#0D100E"
                        strokeWidth="3"
                        style={{ paintOrder: 'stroke fill', userSelect: 'none' }}
                      >
                        {isDiscovered ? dist.name.toUpperCase() : 'UNKNOWN QUARTER'}
                      </text>

                      {/* Fully Explored Indicator */}
                      {isDiscovered && discoveryState === 'fully_explored' && (
                        <text
                          x={dist.center.x * 10}
                          y={dist.center.z * 10 + 13}
                          textAnchor="middle"
                          fontSize="9"
                          fontFamily="JetBrains Mono, monospace"
                          fill="#7E9C82"
                          stroke="#0D100E"
                          strokeWidth="2"
                          style={{ paintOrder: 'stroke fill', userSelect: 'none' }}
                        >
                          ★★ FULLY EXPLORED
                        </text>
                      )}
                    </g>
                  );
                })}

                {/* Layer 7: Service Markers */}
                {(activeFilter === 'all' || activeFilter === 'services') &&
                  serviceMarkers.map((srv) => (
                    <g
                      key={srv.id}
                      transform={`translate(${srv.gridX * 10 + 5}, ${srv.gridZ * 10 + 5})`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectDistrict(srv.districtId);
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <title>{srv.subtitle ? `${srv.title} (${srv.subtitle})` : srv.title}</title>
                      <circle r="7.5" fill="#171B19" stroke={srv.color} strokeWidth="1.5" />
                      <text
                        textAnchor="middle"
                        dominantBaseline="central"
                        fontSize="9"
                      >
                        {srv.icon}
                      </text>
                    </g>
                  ))}

                {/* Layer 8: NPC Markers */}
                {(activeFilter === 'all' || activeFilter === 'npcs') &&
                  npcMarkers.map((npc) => (
                    <g
                      key={npc.id}
                      transform={`translate(${npc.gridX * 10 + 5}, ${npc.gridZ * 10 + 5})`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectDistrict(npc.districtId);
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <title>{npc.subtitle ? `${npc.title} (${npc.subtitle})` : npc.title}</title>
                      <circle r="6" fill="#222722" stroke="#B5AC9A" strokeWidth="1" />
                      <text
                        textAnchor="middle"
                        dominantBaseline="central"
                        fontSize="8"
                      >
                        👤
                      </text>
                    </g>
                  ))}

                {/* Layer 9: Active Quest Objectives */}
                {(activeFilter === 'all' || activeFilter === 'quests') &&
                  questMarkers.map((qm) => (
                    <g
                      key={qm.id}
                      transform={`translate(${qm.gridX * 10}, ${qm.gridZ * 10})`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectDistrict(qm.districtId);
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <title>{`[${qm.questCode ?? 'QUEST'}] ${qm.title}${qm.subtitle ? ` · ${qm.subtitle}` : ''}`}</title>
                      {/* Pulsing Beacon Ring */}
                      <circle r="16" fill="rgba(226, 176, 90, 0.2)" stroke="#E2B05A" strokeWidth="1">
                        <animate
                          attributeName="r"
                          values="10;22;10"
                          dur="2.5s"
                          repeatCount="indefinite"
                        />
                        <animate
                          attributeName="opacity"
                          values="0.8;0.1;0.8"
                          dur="2.5s"
                          repeatCount="indefinite"
                        />
                      </circle>
                      {/* Golden Diamond Core */}
                      <polygon
                        points="0,-10 9,0 0,10 -9,0"
                        fill="#E2B05A"
                        stroke="#171B19"
                        strokeWidth="1.8"
                      />
                      <text
                        y="-14"
                        textAnchor="middle"
                        fontSize="8"
                        fontFamily="JetBrains Mono, monospace"
                        fontWeight="700"
                        fill="#E2B05A"
                        stroke="#111613"
                        strokeWidth="2"
                        style={{ paintOrder: 'stroke fill' }}
                      >
                        {qm.questCode ?? 'QUEST'}
                      </text>
                    </g>
                  ))}

                {/* Layer 10: Player Position Marker */}
                <g transform={`translate(${playerMapCoords.x * 10}, ${playerMapCoords.z * 10})`}>
                  <title>{`Commander Position: [${playerMapCoords.x}, ${playerMapCoords.z}]`}</title>
                  {/* Outer pulsating sonar ring */}
                  <circle r="14" fill="rgba(56, 189, 248, 0.25)" stroke="#38BDF8" strokeWidth="1.2">
                    <animate
                      attributeName="r"
                      values="10;18;10"
                      dur="2s"
                      repeatCount="indefinite"
                    />
                  </circle>
                  {/* Cyan Core */}
                  <circle r="6" fill="#38BDF8" stroke="#FFFFFF" strokeWidth="2" />
                  {/* Heading dot */}
                  <circle cx="0" cy="-7" r="1.8" fill="#F8FAFC" />
                </g>
              </svg>
            </div>

            {/* Bottom Map Legend & Summary Bar */}
            <div
              style={{
                padding: '8px 16px',
                backgroundColor: '#171B19',
                borderTop: '1px solid #3A3324',
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                fontSize: '11px',
                color: '#B5AC9A',
                fontFamily: 'JetBrains Mono, monospace',
                gap: '8px',
                zIndex: 10,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <span
                    style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      backgroundColor: '#38BDF8',
                      display: 'inline-block',
                    }}
                  />
                  Commander
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <span
                    style={{
                      width: '8px',
                      height: '8px',
                      transform: 'rotate(45deg)',
                      backgroundColor: '#E2B05A',
                      display: 'inline-block',
                    }}
                  />
                  Quest Objective
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <span style={{ color: '#7E9C82' }}>◆</span> Discovered
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <span style={{ color: '#6B7068' }}>·</span> Undiscovered
                </span>
              </div>

              {/* Active Selection Badge (minimal and clean) */}
              {selectedBuildingMeta ? (
                <div style={{ color: '#F2ECE1', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ color: '#E2B05A', fontWeight: 700 }}>SELECTED:</span>
                  <span>{selectedBuildingMeta.name}</span>
                  <span style={{ color: '#77796F' }}>({selectedDistrictMeta.name})</span>
                </div>
              ) : selectedDistrictId ? (
                <div style={{ color: '#F2ECE1', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ color: '#E2B05A', fontWeight: 700 }}>SELECTED:</span>
                  <span>{selectedDistrictMeta.name}</span>
                  <span
                    style={{
                      color:
                        districtDiscoveryState === 'fully_explored'
                          ? '#7E9C82'
                          : districtDiscoveryState === 'discovered'
                          ? '#A3C4A8'
                          : '#77796F',
                    }}
                  >
                    ({districtDiscoveryState === 'fully_explored'
                      ? 'Fully Explored'
                      : districtDiscoveryState === 'discovered'
                      ? 'Discovered'
                      : 'Undiscovered'})
                  </span>
                </div>
              ) : null}

              <div style={{ color: '#E2B05A', fontWeight: 700 }}>
                DISCOVERED DISTRICTS: {discoveredCount} / 9 · INTERIORS: {exploredInteriorsCount} / 8
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
