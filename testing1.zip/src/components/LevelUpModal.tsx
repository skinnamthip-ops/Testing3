import React from 'react';
import { LevelUpResult, SkillProgressionDefinition } from '../game/progressionData';
import { SkillIconSvg } from './SkillIcons';

interface LevelUpModalProps {
  result: LevelUpResult;
  onOpenSkillTree: () => void;
  onClose: () => void;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({
  result,
  onOpenSkillTree,
  onClose,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="levelup-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fade-in select-none text-[#F2ECE1]"
    >
      <div className="relative flex flex-col w-full max-w-xl bg-[#171B19] border-2 border-[#E2B05A] rounded-2xl shadow-2xl overflow-hidden p-6 text-center space-y-6">
        {/* Glow Halo */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-32 bg-radial from-[#E2B05A]/25 via-transparent to-transparent pointer-events-none" />

        {/* Level Up Banner */}
        <div className="relative">
          <div className="text-xs font-mono font-bold tracking-widest uppercase text-[#E2B05A] mb-1">
            Character Advancement
          </div>
          <h2 id="levelup-title" className="font-serif text-3xl sm:text-4xl font-extrabold text-[#F2ECE1] tracking-wide">
            LEVEL UP!
          </h2>
          <div className="flex items-center justify-center gap-3 mt-2 text-lg font-serif">
            <span className="text-[#B5AC9A]">Level {result.previousLevel}</span>
            <span className="text-[#E2B05A] text-xl font-bold">➔</span>
            <span className="text-[#E2B05A] font-bold text-2xl px-3 py-0.5 rounded-lg bg-[#3A3324] border border-[#E2B05A]">
              Level {result.newLevel}
            </span>
          </div>
        </div>

        {/* Rewards Summary Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-left">
          <div className="p-3 bg-[#222722] rounded-xl border border-[#5A4B38]">
            <span className="text-[10px] text-[#77796F] uppercase block">Skill Points</span>
            <div className="text-lg font-bold font-mono text-[#E2B05A] mt-0.5">
              +{result.skillPointsGained} Point
            </div>
            <span className="text-[11px] text-[#B5AC9A]">For skill tree unlocks</span>
          </div>

          <div className="p-3 bg-[#222722] rounded-xl border border-[#5A4B38]">
            <span className="text-[10px] text-[#77796F] uppercase block">Attribute Points</span>
            <div className="text-lg font-bold font-mono text-[#7E9C82] mt-0.5">
              +{result.attributePointsGained} Point
            </div>
            <span className="text-[11px] text-[#B5AC9A]">
              {result.attributePointsGained > 0 ? 'STR / DEX / INT / CHA' : 'Next at Lv 4, 8, 12, 16, 20'}
            </span>
          </div>

          <div className="p-3 bg-[#222722] rounded-xl border border-[#5A4B38] col-span-2 sm:col-span-1">
            <span className="text-[10px] text-[#77796F] uppercase block">Class Mastery</span>
            <div className={`text-sm font-bold font-serif mt-1 ${result.masteryMilestoneReached ? 'text-[#E2B05A]' : 'text-[#77796F]'}`}>
              {result.masteryMilestoneReached ? `Milestone Lv ${result.masteryMilestoneReached} Ready!` : 'Standard Rank'}
            </div>
            <span className="text-[11px] text-[#B5AC9A]">
              {result.masteryMilestoneReached ? 'Select your path in Skill Tree' : 'Milestones at Lv 5, 10, 15, 20'}
            </span>
          </div>
        </div>

        {/* Newly Available Skills Section */}
        {result.newlyAvailableSkills.length > 0 && (
          <div className="text-left space-y-2">
            <div className="text-xs font-serif font-bold uppercase tracking-wider text-[#E2B05A]">
              Newly Unlocked Abilities (Ready to Learn):
            </div>
            <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1">
              {result.newlyAvailableSkills.map((sk: SkillProgressionDefinition) => (
                <div
                  key={sk.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-[#222722] border border-[#5A4B38]/60"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 shrink-0 rounded overflow-hidden border border-[#5A4B38] bg-[#111613]">
                      <SkillIconSvg skillId={sk.id} skillName={sk.name} className="w-8 h-8" />
                    </div>
                    <div>
                      <div className="text-xs font-serif font-bold text-[#F2ECE1]">{sk.name}</div>
                      <div className="text-[10px] text-[#77796F] line-clamp-1">{sk.centralMechanic}</div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A]/40 shrink-0">
                    Req. Lv {sk.minLevel}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#5A4B38]/60">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-[#222722] hover:bg-[#292E29] text-[#B5AC9A] hover:text-[#F2ECE1] text-xs font-bold border border-[#5A4B38] transition-colors"
          >
            Continue Adventure
          </button>
          <button
            type="button"
            data-testid="inspect-new-abilities-button"
            onClick={() => {
              onClose();
              onOpenSkillTree();
            }}
            className="px-5 py-2 rounded-lg bg-[#E2B05A] hover:bg-[#F7E3A6] text-[#171B19] text-xs font-bold shadow-lg transition-colors"
          >
            Open Skill Tree & Learn
          </button>
        </div>
      </div>
    </div>
  );
};
