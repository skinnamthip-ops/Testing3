import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  CharacterRaceId,
  CharacterClassId,
  CharacterSubclassId,
  CharacterCreationBuild,
  CHARACTER_CLASSES,
  CHARACTER_SUBCLASSES,
  CHARACTER_RACES,
  computeCharacterBuildPreview,
} from '../game/rules';
import {
  ArchetypeClassId,
  CharacterAppearanceConfig,
} from '../components/CharacterPixelPreviewCanvas';
import {
  BODY_PRESETS,
  FACE_PRESETS_BY_RACE,
  HAIRSTYLE_LIBRARY,
  HAIR_COLORS,
  SECONDARY_HAIR_HIGHLIGHTS,
  FACIAL_HAIR_OPTIONS,
  EYE_COLORS,
  SCARS_LIBRARY,
  TATTOOS_LIBRARY,
  MARKINGS_LIBRARY,
  TIEFLING_HORNS,
  HORN_COLORS,
  NARRATIVE_BACKGROUNDS,
  PERSONALITY_OPTIONS,
  VOICE_OPTIONS,
  PLAYABLE_CLASS_PROFILES,
  PlayableClassProfile,
  ATTRIBUTE_METADATA,
  ATTRIBUTE_POINT_BUDGET,
  MAX_ALLOC_PER_STAT,
  SPECIALIZATION_ROADMAP,
  SPECIALIZATION_PROFILES,
  getCompatibleSpecializations,
  SpecializationDetailedProfile,
  RACE_EXTENDED_DETAILS,
  RACE_RANDOM_NAMES,
  CharacterDetailedAppearance,
  createDefaultDetailedAppearance,
  randomizeDetailedAppearance,
  getD20Modifier,
  formatD20Modifier,
  PersistentCharacterConfiguration,
  CREATION_GAMEPLAY_TIPS,
  APPEARANCE_CATEGORY_LIST,
  AppearanceCategoryId,
  CREATION_PROGRESS_STEPS,
  CreationStepId,
} from '../game/characterCreationData';
import {
  SavedAdventureSlot,
  loadSavedSlots,
  persistSavedSlots,
} from '../game/saveAdventureSlots';
import { createInitialGloamrestState } from '../game/gloamrestEngine';
import { soundEngine } from '../game/audio';
import { CharacterCreator3DPreview } from './CharacterCreator3DPreview';

export type MenuScreen =
  | 'main_menu'
  | 'begin'
  | 'ancestry'
  | 'body'
  | 'face'
  | 'appearance'
  | 'identity'
  | 'class'
  | 'subclass'
  | 'attributes'
  | 'combat_identity'
  | 'review'
  | 'loading_intro'
  | 'load_game'
  | 'settings'
  | 'credits';

interface GameSettingsState {
  graphics: {
    resolutionScale: '100%' | '125%' | '150%';
    windowMode: 'Fullscreen' | 'Borderless' | 'Windowed';
    pixelScaling: 'Integer Crisp' | 'Balanced';
    ambientParticles: boolean;
    showFpsCounter: boolean;
  };
  audio: {
    masterVolume: number;
    musicVolume: number;
    sfxVolume: number;
    muted: boolean;
  };
  controls: {
    controllerVibration: boolean;
    mouseSensitivity: number;
    invertCameraPan: boolean;
  };
  gameplay: {
    confirmEndTurn: boolean;
    showTacticalGrid: boolean;
    defaultOath: 'Mercy' | 'Dominion' | 'Balance';
    startingStageId: number;
  };
  accessibility: {
    textSize: 'Standard' | 'Large';
    highContrastText: boolean;
    reducedMotion: boolean;
  };
  language: 'English' | 'Français' | 'Deutsch' | 'Español' | '日本語';
}

const DEFAULT_SETTINGS: GameSettingsState = {
  graphics: {
    resolutionScale: '100%',
    windowMode: 'Borderless',
    pixelScaling: 'Integer Crisp',
    ambientParticles: true,
    showFpsCounter: false,
  },
  audio: {
    masterVolume: 85,
    musicVolume: 75,
    sfxVolume: 80,
    muted: false,
  },
  controls: {
    controllerVibration: true,
    mouseSensitivity: 50,
    invertCameraPan: false,
  },
  gameplay: {
    confirmEndTurn: false,
    showTacticalGrid: true,
    defaultOath: 'Mercy',
    startingStageId: 0,
  },
  accessibility: {
    textSize: 'Standard',
    highContrastText: false,
    reducedMotion: false,
  },
  language: 'English',
};

const SETTINGS_STORAGE_KEY = 'fantasy_rpg_settings_v1';
const LAST_FINALIZED_CHAR_KEY = 'fantasy_rpg_finalized_character_v1';

function loadStoredSettings(): GameSettingsState {
  try {
    const raw = window.localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

interface StartupMenuOverlayProps {
  characterBuild: CharacterCreationBuild;
  onChangeCharacterBuild: (next: CharacterCreationBuild) => void;
  originChoice: 'Mercy' | 'Dominion' | 'Balance';
  onChangeOriginChoice: (next: 'Mercy' | 'Dominion' | 'Balance') => void;
  selectedStageId: number;
  onChangeStageId: (stageId: number) => void;
  onStartExpedition: () => void;
  onStartWithParley: () => void;
  onLoadSavedSlot?: (slot: SavedAdventureSlot) => void;
}

const MAIN_MENU_ITEMS = [
  { id: 'continue', label: 'Continue', testId: 'menu-btn-continue' },
  { id: 'new_adventure', label: 'New Adventure', testId: 'forge-commander-btn' },
  { id: 'load_game', label: 'Load Game', testId: 'menu-btn-load-game' },
  { id: 'settings', label: 'Settings', testId: 'menu-btn-settings' },
  { id: 'credits', label: 'Credits', testId: 'menu-btn-credits' },
  { id: 'exit', label: 'Exit Game', testId: 'menu-btn-exit' },
] as const;

type SettingsTabId =
  | 'Graphics'
  | 'Audio'
  | 'Controls'
  | 'Gameplay'
  | 'Accessibility'
  | 'Language';

export const StartupMenuOverlay: React.FC<StartupMenuOverlayProps> = ({
  characterBuild,
  onChangeCharacterBuild,
  originChoice,
  onChangeOriginChoice,
  selectedStageId,
  onChangeStageId,
  onStartExpedition,
  onStartWithParley,
  onLoadSavedSlot,
}) => {
  const [currentScreen, setCurrentScreen] = useState<MenuScreen>('main_menu');
  const [highestStepReached, setHighestStepReached] = useState<number>(0);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [selectedMenuIndex, setSelectedMenuIndex] = useState<number>(1);
  const [hoveredMenuIndex, setHoveredMenuIndex] = useState<number | null>(null);

  // Centralized Detailed Appearance State
  const [detailedAppearance, setDetailedAppearance] = useState<CharacterDetailedAppearance>(
    () => createDefaultDetailedAppearance(characterBuild.raceId)
  );

  // Character Identity State
  const [commanderName, setCommanderName] = useState<string>(
    characterBuild.commanderName || 'Seraphina Vane'
  );
  const [archetypeClass, setArchetypeClass] = useState<ArchetypeClassId>('paladin');
  const [selectedBackgroundId, setSelectedBackgroundId] = useState<string>('the_devout');
  const [selectedPersonalityId, setSelectedPersonalityId] = useState<string>('compassionate');
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>('heroic_noble');

  // Attribute Point Allocation (Budget: 4 Points)
  const [allocatedPoints, setAllocatedPoints] = useState<{
    str: number;
    dex: number;
    int: number;
    cha: number;
  }>(() => characterBuild.allocatedStats ?? { str: 2, dex: 0, int: 0, cha: 2 });

  // Appearance Active Sub-tab (Screen 05)
  const [activeAppearanceTab, setActiveAppearanceTab] = useState<
    'hair' | 'color' | 'facial_hair' | 'skin' | 'eyes' | 'scars' | 'horns'
  >('hair');

  // Subclass View Tab (Screen 08: Details vs Compare)
  const [subclassViewTab, setSubclassViewTab] = useState<'details' | 'compare'>('details');

  // Advanced Face Mode Accordion / Section (Screen 04)
  const [activeFaceSection, setActiveFaceSection] = useState<'head' | 'eyes' | 'nose' | 'mouth' | 'brows' | 'ears'>('head');

  // Loading Screen & Finalization State
  const [isFinalizing, setIsFinalizing] = useState<boolean>(false);
  const [loadingProgress, setLoadingProgress] = useState<number>(0);
  const [loadingTipIndex, setLoadingTipIndex] = useState<number>(0);
  const [validationMessage, setValidationMessage] = useState<string | null>(null);

  // Saved Adventures
  const [saveSlots, setSaveSlots] = useState<SavedAdventureSlot[]>(() => loadSavedSlots());
  const [selectedSaveId, setSelectedSaveId] = useState<string | null>(
    () => loadSavedSlots()[0]?.id ?? null
  );
  const [slotPendingDelete, setSlotPendingDelete] = useState<SavedAdventureSlot | null>(null);

  // Settings
  const [settings, setSettings] = useState<GameSettingsState>(() => loadStoredSettings());
  const [activeSettingsTab, setActiveSettingsTab] = useState<SettingsTabId>('Graphics');
  const [settingsSavedNotice, setSettingsSavedNotice] = useState<string | null>(null);

  // Exit Modal
  const [showExitConfirm, setShowExitConfirm] = useState<boolean>(false);

  const mostRecentSave = useMemo(() => {
    if (saveSlots.length === 0) return null;
    return [...saveSlots].sort((a, b) => b.timestamp - a.timestamp)[0];
  }, [saveSlots]);

  useEffect(() => {
    setSelectedMenuIndex(mostRecentSave ? 0 : 1);
  }, [mostRecentSave !== null]);

  // Track highest step reached
  useEffect(() => {
    const idx = CREATION_PROGRESS_STEPS.findIndex((s) => s.id === currentScreen);
    if (idx >= 0) {
      setHighestStepReached((prev) => Math.max(prev, idx));
    }
  }, [currentScreen]);

  const navigateToScreen = useCallback((next: MenuScreen) => {
    setValidationMessage(null);
    setIsTransitioning(true);
    window.setTimeout(() => {
      setCurrentScreen(next);
      setIsTransitioning(false);
    }, 100);
  }, []);

  // Synchronized Preview Calculations
  const preview = useMemo(
    () =>
      computeCharacterBuildPreview({
        ...characterBuild,
        commanderName,
        allocatedStats: allocatedPoints,
        backgroundId: selectedBackgroundId,
      }),
    [characterBuild, commanderName, allocatedPoints, selectedBackgroundId]
  );

  const activeClassProfile = useMemo(
    () =>
      PLAYABLE_CLASS_PROFILES.find((c) => c.archetypeId === archetypeClass) ??
      PLAYABLE_CLASS_PROFILES[3],
    [archetypeClass]
  );

  const compatibleSpecializations = useMemo(
    () => getCompatibleSpecializations(archetypeClass),
    [archetypeClass]
  );

  const activeSpecializationProfile = useMemo(() => {
    return (
      compatibleSpecializations.find((s) => s.id === characterBuild.subclassId) ??
      compatibleSpecializations[0] ??
      SPECIALIZATION_PROFILES.dawn_warden
    );
  }, [compatibleSpecializations, characterBuild.subclassId]);

  const activeBackground = useMemo(
    () =>
      NARRATIVE_BACKGROUNDS.find((b) => b.id === selectedBackgroundId) ??
      NARRATIVE_BACKGROUNDS[5],
    [selectedBackgroundId]
  );

  const activePersonality = useMemo(
    () =>
      PERSONALITY_OPTIONS.find((p) => p.id === selectedPersonalityId) ??
      PERSONALITY_OPTIONS[0],
    [selectedPersonalityId]
  );

  const pointsSpent = useMemo(
    () => allocatedPoints.str + allocatedPoints.dex + allocatedPoints.int + allocatedPoints.cha,
    [allocatedPoints]
  );
  const remainingPoints = ATTRIBUTE_POINT_BUDGET - pointsSpent;

  // Persistent Character Configuration Round-trip
  const persistentCharacterData: PersistentCharacterConfiguration = useMemo(
    () => ({
      character_name: commanderName.trim() || 'Seraphina Vane',
      race: characterBuild.raceId,
      appearance: detailedAppearance,
      detailedAppearance,
      class: archetypeClass,
      background: selectedBackgroundId,
      personality: selectedPersonalityId,
      voice: selectedVoiceId,
      attributes: preview.stats,
      starting_equipment: activeClassProfile.startingEquipment,
      starting_abilities: activeClassProfile.startingAbilities,
    }),
    [
      commanderName,
      characterBuild.raceId,
      detailedAppearance,
      archetypeClass,
      selectedBackgroundId,
      selectedPersonalityId,
      selectedVoiceId,
      preview.stats,
      activeClassProfile,
    ]
  );

  // =========================================================================
  // HANDLERS FOR CREATION STEPS
  // =========================================================================

  const handleSelectRace = (raceId: CharacterRaceId) => {
    soundEngine.playMeleeHit(false);
    const nextAppearance = createDefaultDetailedAppearance(raceId);
    setDetailedAppearance(nextAppearance);
    onChangeCharacterBuild({
      ...characterBuild,
      raceId,
      commanderName,
      allocatedStats: allocatedPoints,
      backgroundId: selectedBackgroundId,
    });
  };

  const handleRandomizeAppearance = () => {
    soundEngine.playHealBless();
    const randomized = randomizeDetailedAppearance(characterBuild.raceId);
    setDetailedAppearance(randomized);
  };

  const handleResetAppearance = () => {
    soundEngine.playDiceRoll(true);
    setDetailedAppearance(createDefaultDetailedAppearance(characterBuild.raceId));
  };

  const handleSelectBodyPreset = (presetId: string) => {
    soundEngine.playMeleeHit(false);
    const preset = BODY_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    setDetailedAppearance((prev) => ({
      ...prev,
      bodyPreset: preset.id,
      ...preset.proportions,
    }));
  };

  const handleSelectFacePreset = (presetId: number) => {
    soundEngine.playMeleeHit(false);
    const presets = FACE_PRESETS_BY_RACE[characterBuild.raceId];
    const match = presets.find((p) => p.id === presetId);
    if (!match) return;
    setDetailedAppearance((prev) => ({
      ...prev,
      facePresetId: match.id,
      ...match.proportions,
    }));
  };

  const handleSelectArchetypeClass = (profile: PlayableClassProfile) => {
    soundEngine.playMeleeHit(false);
    setArchetypeClass(profile.archetypeId);
    // Auto-align recommended attribute allocation if player hasn't custom allocated
    setAllocatedPoints(profile.recommendedAllocation);
    // Keep current subclass if compatible, otherwise use default for new class
    const isCurrentSubclassCompatible = profile.compatibleSubclassIds.includes(
      characterBuild.subclassId
    );
    const nextSubclassId = isCurrentSubclassCompatible
      ? characterBuild.subclassId
      : profile.defaultSubclassId;

    onChangeCharacterBuild({
      ...characterBuild,
      classId: profile.mappedClassId,
      subclassId: nextSubclassId,
      commanderName,
      allocatedStats: profile.recommendedAllocation,
      backgroundId: selectedBackgroundId,
    });
  };

  const handleSelectSubclass = (subclassId: CharacterSubclassId) => {
    soundEngine.playHealBless();
    onChangeCharacterBuild({
      ...characterBuild,
      subclassId,
    });
  };

  const handleGenerateRandomName = () => {
    soundEngine.playDiceRoll(true);
    const names = RACE_RANDOM_NAMES[characterBuild.raceId] ?? RACE_RANDOM_NAMES.half_elf;
    const randomName = names[Math.floor(Math.random() * names.length)];
    setCommanderName(randomName);
    onChangeCharacterBuild({ ...characterBuild, commanderName: randomName });
  };

  const handleStatChange = (key: 'str' | 'dex' | 'int' | 'cha', delta: number) => {
    soundEngine.playMeleeHit(false);
    setAllocatedPoints((prev) => {
      const cur = prev[key];
      const next = cur + delta;
      if (delta > 0 && remainingPoints <= 0) return prev;
      if (next < 0 || next > MAX_ALLOC_PER_STAT) return prev;
      const nextAlloc = { ...prev, [key]: next };
      onChangeCharacterBuild({
        ...characterBuild,
        allocatedStats: nextAlloc,
      });
      return nextAlloc;
    });
  };

  // Step Navigation Helpers
  const currentStepIndex = CREATION_PROGRESS_STEPS.findIndex((s) => s.id === currentScreen);
  const isCreationScreen = currentStepIndex >= 0;

  const handleContinue = () => {
    soundEngine.playHealBless();
    if (currentScreen === 'identity') {
      if (!commanderName.trim()) {
        setValidationMessage('Please provide a character name before proceeding.');
        return;
      }
    }
    if (currentStepIndex >= 0 && currentStepIndex < CREATION_PROGRESS_STEPS.length - 1) {
      navigateToScreen(CREATION_PROGRESS_STEPS[currentStepIndex + 1].id);
    }
  };

  const handleBack = () => {
    soundEngine.playMeleeHit(false);
    if (currentStepIndex > 0) {
      navigateToScreen(CREATION_PROGRESS_STEPS[currentStepIndex - 1].id);
    } else if (currentScreen === 'begin') {
      navigateToScreen('main_menu');
    }
  };

  // Final Confirmation & World Entry
  const handleFinalizeAndBeginAdventure = useCallback(() => {
    if (isFinalizing) return;
    const trimmed = commanderName.trim();
    if (!trimmed) {
      setValidationMessage('Please provide a character name before swearing the oath.');
      navigateToScreen('identity');
      return;
    }

    setIsFinalizing(true);
    soundEngine.playVictoryFanfare();

    const finalizedBuild: CharacterCreationBuild = {
      commanderName: trimmed,
      raceId: characterBuild.raceId,
      classId: characterBuild.classId,
      subclassId: characterBuild.subclassId,
      allocatedStats: allocatedPoints,
      backgroundId: selectedBackgroundId,
      personalityId: selectedPersonalityId,
      voiceId: selectedVoiceId,
      detailedAppearance,
      appearance: detailedAppearance,
    };
    onChangeCharacterBuild(finalizedBuild);

    // Save persistent character configuration to storage
    try {
      window.localStorage.setItem(LAST_FINALIZED_CHAR_KEY, JSON.stringify(persistentCharacterData));
    } catch {
      // Ignore storage errors
    }

    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
      now.getDate()
    ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;

    const newSlot: SavedAdventureSlot = {
      id: `slot-${Date.now()}`,
      commanderName: trimmed,
      level: 1,
      raceId: characterBuild.raceId,
      classId: characterBuild.classId,
      subclassId: characterBuild.subclassId,
      archetypeClass,
      backgroundId: selectedBackgroundId,
      allocatedStats: allocatedPoints,
      originChoice,
      stageId: selectedStageId,
      playtime: '00h 01m',
      saveDate: formattedDate,
      timestamp: Date.now(),
      fullConfig: persistentCharacterData,
      inGloamrest: true,
      locationLabel: 'Gloamrest · Hearth Square',
      gloamrestState: createInitialGloamrestState(finalizedBuild),
    };

    const nextSlots = [newSlot, ...saveSlots].slice(0, 6);
    setSaveSlots(nextSlots);
    persistSavedSlots(nextSlots);

    // Transition to Loading Intro Screen
    setLoadingProgress(0);
    setLoadingTipIndex(0);
    setCurrentScreen('loading_intro');
  }, [
    isFinalizing,
    commanderName,
    characterBuild,
    allocatedPoints,
    selectedBackgroundId,
    selectedPersonalityId,
    selectedVoiceId,
    detailedAppearance,
    persistentCharacterData,
    archetypeClass,
    originChoice,
    selectedStageId,
    saveSlots,
    onChangeCharacterBuild,
    navigateToScreen,
  ]);

  // Loading Screen Timer
  useEffect(() => {
    if (currentScreen !== 'loading_intro') return;
    const interval = window.setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          window.clearInterval(interval);
          onStartExpedition();
          return 100;
        }
        return prev + 20;
      });
    }, 280);

    const tipInterval = window.setInterval(() => {
      setLoadingTipIndex((prev) => (prev + 1) % CREATION_GAMEPLAY_TIPS.length);
    }, 2400);

    return () => {
      window.clearInterval(interval);
      window.clearInterval(tipInterval);
    };
  }, [currentScreen, onStartExpedition]);

  // Main Menu Navigation Handler
  const triggerMenuAction = useCallback(
    (idx: number) => {
      const item = MAIN_MENU_ITEMS[idx];
      if (!item) return;
      soundEngine.playMeleeHit(false);
      switch (item.id) {
        case 'continue':
          if (mostRecentSave && onLoadSavedSlot) onLoadSavedSlot(mostRecentSave);
          else onStartExpedition();
          break;
        case 'new_adventure':
          navigateToScreen('begin');
          break;
        case 'load_game':
          navigateToScreen('load_game');
          break;
        case 'settings':
          navigateToScreen('settings');
          break;
        case 'credits':
          navigateToScreen('credits');
          break;
        case 'exit':
          setShowExitConfirm(true);
          break;
      }
    },
    [mostRecentSave, onLoadSavedSlot, onStartExpedition, navigateToScreen]
  );

  return (
    <section
      aria-label="Character Creation & Main Menu"
      data-testid="startup-menu-overlay"
      className="fixed inset-0 z-30 flex flex-col justify-between overflow-hidden select-none bg-[#111613] text-[#F2ECE1] font-sans"
    >
      {/* ========================================================================= */}
      {/* 1. MAIN MENU SCREEN                                                       */}
      {/* ========================================================================= */}
      {currentScreen === 'main_menu' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center p-8 bg-[radial-gradient(ellipse_at_center,rgba(22,28,24,0.92)_0%,#111613_100%)]">
          <div className="text-center space-y-4 mb-10 max-w-xl">
            <h1 className="text-4xl md:text-5xl font-serif tracking-widest text-[#F2ECE1] uppercase drop-shadow-lg">
              DIMRAETH
            </h1>
            <p className="text-xs md:text-sm font-mono tracking-widest text-[#E2B05A] uppercase">
              The Shattered Oath
            </p>
            <div className="w-24 h-px bg-[#5A4B38] mx-auto mt-2" />
          </div>

          {/* Menu Items */}
          <nav aria-label="Main Menu Navigation" className="flex flex-col space-y-3 w-64">
            {MAIN_MENU_ITEMS.map((item, idx) => {
              const isContinueDisabled = item.id === 'continue' && !mostRecentSave;
              const isSelected = selectedMenuIndex === idx;

              return (
                <button
                  key={item.id}
                  type="button"
                  data-testid={item.testId}
                  disabled={isContinueDisabled}
                  onClick={() => triggerMenuAction(idx)}
                  onMouseEnter={() => setSelectedMenuIndex(idx)}
                  className={`px-5 py-3 text-sm font-mono tracking-wider uppercase text-center rounded border transition-all duration-150 ${
                    isContinueDisabled
                      ? 'border-transparent text-[#5A4B38] cursor-not-allowed opacity-50'
                      : isSelected
                      ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.12)] text-[#E2B05A] shadow-[0_0_15px_rgba(226,176,90,0.2)]'
                      : 'border-[#5A4B38]/60 bg-[rgba(22,28,24,0.6)] text-[#B5AC9A] hover:border-[#E2B05A]/70 hover:text-[#F2ECE1]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. THE 10-SCREEN 3-PANEL CHARACTER CREATOR ARCHITECTURE                   */}
      {/* ========================================================================= */}
      {isCreationScreen && (
        <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
          {/* Top Bar Header */}
          <header className="h-14 border-b border-[#5A4B38] bg-[rgba(17,22,19,0.95)] px-6 flex items-center justify-between z-20 backdrop-blur-sm">
            <div className="flex items-center space-x-4">
              <span className="text-xs font-serif tracking-widest text-[#E2B05A] uppercase">
                Dimraeth: The Shattered Oath
              </span>
              <span className="text-xs text-[#5A4B38]">·</span>
              <span className="text-xs font-mono text-[#B5AC9A]">
                {CREATION_PROGRESS_STEPS[currentStepIndex].stepNum}. {CREATION_PROGRESS_STEPS[currentStepIndex].subtitle}
              </span>
            </div>

            <button
              type="button"
              onClick={() => navigateToScreen('main_menu')}
              className="px-3 py-1 text-xs font-mono text-[#B5AC9A] hover:text-[#B85349] transition"
            >
              Exit to Menu
            </button>
          </header>

          {/* MAIN 3-PANEL LAYOUT */}
          <div className="flex-1 flex overflow-hidden relative">
            {/* ------------------------------------------------------------------- */}
            {/* LEFT PANEL: 18% Width — Progression Navigation Steps               */}
            {/* ------------------------------------------------------------------- */}
            <aside className="w-[18%] min-w-[210px] max-w-[260px] border-r border-[#5A4B38] bg-[rgba(22,28,24,0.95)] p-4 flex flex-col justify-between overflow-y-auto z-10">
              <div>
                <h2 className="text-[11px] font-mono tracking-widest text-[#B5AC9A] uppercase mb-4 px-2">
                  Oath Progression
                </h2>
                <nav className="space-y-1">
                  {CREATION_PROGRESS_STEPS.map((step, idx) => {
                    const isActive = step.id === currentScreen;
                    const isCompleted = idx < highestStepReached;
                    const isAccessible = idx <= highestStepReached;

                    return (
                      <button
                        key={step.id}
                        type="button"
                        disabled={!isAccessible}
                        onClick={() => navigateToScreen(step.id)}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded text-left transition-all ${
                          isActive
                            ? 'bg-[rgba(226,176,90,0.15)] border-l-2 border-[#E2B05A] text-[#E2B05A]'
                            : isCompleted
                            ? 'text-[#F2ECE1] hover:bg-[#202922]'
                            : 'text-[#5A4B38] cursor-not-allowed opacity-60'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <span
                            className={`text-[11px] font-mono ${
                              isActive ? 'text-[#E2B05A]' : isCompleted ? 'text-[#7E9C82]' : 'text-[#5A4B38]'
                            }`}
                          >
                            {step.stepNum}
                          </span>
                          <span className="text-xs font-medium tracking-wide">
                            {step.label}
                          </span>
                        </div>
                        {isCompleted && !isActive && (
                          <span className="text-[#7E9C82] text-xs">✓</span>
                        )}
                        {isActive && (
                          <span className="w-1.5 h-1.5 rounded-full bg-[#E2B05A] animate-pulse" />
                        )}
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Character Summary Pip */}
              <div className="p-3 bg-[rgba(17,22,19,0.8)] border border-[#5A4B38]/50 rounded mt-4">
                <div className="text-[10px] font-mono text-[#B5AC9A] uppercase tracking-wider mb-1">
                  Commander
                </div>
                <div className="text-xs font-serif text-[#F2ECE1] truncate">
                  {commanderName || 'Unnamed Oathbearer'}
                </div>
                <div className="text-[11px] text-[#E2B05A] truncate mt-0.5">
                  {RACE_EXTENDED_DETAILS[characterBuild.raceId]?.name} · {activeClassProfile.name}
                </div>
              </div>
            </aside>

            {/* ------------------------------------------------------------------- */}
            {/* CENTER PANEL: 48–52% Width — Live 3D Character Preview             */}
            {/* ------------------------------------------------------------------- */}
            <main className="flex-1 h-full relative overflow-hidden bg-[#0d120f]">
              <CharacterCreator3DPreview
                raceId={characterBuild.raceId}
                archetypeClass={archetypeClass}
                subclassId={characterBuild.subclassId}
                appearance={detailedAppearance}
                framingMode={currentScreen === 'face' || currentScreen === 'appearance' ? 'face' : 'full_body'}
              />
            </main>

            {/* ------------------------------------------------------------------- */}
            {/* RIGHT PANEL: 30–34% Width — Contextual Customization Step Content    */}
            {/* ------------------------------------------------------------------- */}
            <aside className="w-[32%] min-w-[340px] max-w-[450px] border-l border-[#5A4B38] bg-[rgba(22,28,24,0.96)] p-6 flex flex-col justify-between overflow-y-auto z-10 shadow-2xl">
              <div className="space-y-6">
                {/* Header of Active Step */}
                <div className="border-b border-[#5A4B38]/60 pb-3">
                  <h3 className="text-lg font-serif text-[#F2ECE1] uppercase tracking-wider">
                    {CREATION_PROGRESS_STEPS[currentStepIndex].subtitle}
                  </h3>
                  <p className="text-xs text-[#B5AC9A] mt-1 font-sans">
                    {currentScreen === 'begin' && 'Every oath begins with a choice. Define the one who will carry yours.'}
                    {currentScreen === 'ancestry' && 'Your blood remembers what the world has forgotten.'}
                    {currentScreen === 'body' && 'Shape the body that will carry you through the world.'}
                    {currentScreen === 'face' && 'A face carries the history of a life not yet lived.'}
                    {currentScreen === 'appearance' && 'Choose the details by which the world will remember you.'}
                    {currentScreen === 'identity' && 'The road ahead begins with the life you leave behind.'}
                    {currentScreen === 'class' && 'Power is not inherited. It is mastered.'}
                    {currentScreen === 'subclass' && 'Every vow carves a specialized destiny across the tactical field.'}
                    {currentScreen === 'attributes' && 'Your strengths will determine how you face the challenges ahead.'}
                    {currentScreen === 'combat_identity' && 'Choose how you will face the dangers ahead.'}
                    {currentScreen === 'review' && 'This is the character who will shape the fate of Dimraeth.'}
                  </p>
                </div>

                {/* Validation Notice */}
                {validationMessage && (
                  <div className="p-3 bg-[rgba(184,83,73,0.15)] border border-[#B85349] text-[#B85349] text-xs rounded">
                    {validationMessage}
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 01: BEGIN YOUR OATH                                      */}
                {/* =============================================================== */}
                {currentScreen === 'begin' && (
                  <div className="space-y-6 text-sm text-[#B5AC9A] leading-relaxed">
                    <p>
                      Before the high stone bastions of Gloamrest were raised, and before the astral rift tore the firmament asunder, champions were forged by the sacred vows they swore.
                    </p>
                    <p>
                      Inspect your standing silhouette upon the sanctum pedestal. Tailor their ancestry, physique, facial structure, gear, and combat identity before stepping into the shattered realm.
                    </p>
                    <div className="pt-4 flex flex-col space-y-3">
                      <button
                        type="button"
                        onClick={() => navigateToScreen('ancestry')}
                        className="w-full py-3 bg-[#E2B05A] text-[#111613] font-mono text-xs uppercase tracking-wider font-semibold rounded hover:bg-[#c99a4a] transition shadow-lg"
                      >
                        Create Character
                      </button>
                      <button
                        type="button"
                        onClick={() => navigateToScreen('main_menu')}
                        className="w-full py-2.5 border border-[#5A4B38] text-[#B5AC9A] font-mono text-xs uppercase tracking-wider rounded hover:text-[#F2ECE1] transition"
                      >
                        Return to Main Menu
                      </button>
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 02: CHOOSE YOUR ANCESTRY                                 */}
                {/* =============================================================== */}
                {currentScreen === 'ancestry' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-2.5">
                      {(['half_elf', 'tiefling', 'wood_kin', 'astral_human'] as CharacterRaceId[]).map((rId) => {
                        const raceMeta = RACE_EXTENDED_DETAILS[rId];
                        const isSelected = characterBuild.raceId === rId;

                        return (
                          <button
                            key={rId}
                            type="button"
                            onClick={() => handleSelectRace(rId)}
                            className={`p-3.5 rounded border text-left transition-all ${
                              isSelected
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.12)] shadow-[0_0_12px_rgba(226,176,90,0.15)]'
                                : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] hover:border-[#E2B05A]/60'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-serif text-sm font-medium text-[#F2ECE1]">
                                {raceMeta.name}
                              </span>
                              <span className="text-[10px] font-mono text-[#E2B05A]">
                                {raceMeta.tagline}
                              </span>
                            </div>
                            <p className="text-xs text-[#B5AC9A] mt-1.5 line-clamp-2">
                              {raceMeta.identityDescription}
                            </p>
                          </button>
                        );
                      })}
                    </div>

                    {/* Detailed Ancestry Info Card */}
                    <div className="p-4 bg-[rgba(17,22,19,0.85)] border border-[#5A4B38] rounded space-y-2 mt-4">
                      <div className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider">
                        Physical & Racial Traits
                      </div>
                      <ul className="space-y-1.5 text-xs text-[#B5AC9A]">
                        {RACE_EXTENDED_DETAILS[characterBuild.raceId]?.physicalCharacteristics.map(
                          (char, idx) => (
                            <li key={idx} className="flex items-start space-x-2">
                              <span className="text-[#E2B05A]">•</span>
                              <span>{char}</span>
                            </li>
                          )
                        )}
                      </ul>
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 03: DEFINE YOUR PHYSIQUE                                 */}
                {/* =============================================================== */}
                {currentScreen === 'body' && (
                  <div className="space-y-5">
                    {/* Presets */}
                    <div>
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block mb-2">
                        Base Body Presets
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {BODY_PRESETS.map((bp) => (
                          <button
                            key={bp.id}
                            type="button"
                            onClick={() => handleSelectBodyPreset(bp.id)}
                            className={`p-2.5 text-xs font-mono rounded border text-left transition ${
                              detailedAppearance.bodyPreset === bp.id
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A] hover:border-[#E2B05A]/60'
                            }`}
                          >
                            <div className="font-semibold">{bp.name}</div>
                            <div className="text-[10px] text-[#B5AC9A] truncate mt-0.5">
                              {bp.description}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Individual Sliders */}
                    <div className="space-y-3 pt-2 border-t border-[#5A4B38]/50">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Physical Proportions
                      </label>

                      {[
                        { key: 'height', label: 'Height', min: 0.85, max: 1.15, step: 0.01, unit: 'x' },
                        { key: 'shoulderWidth', label: 'Shoulder Width', min: 0.8, max: 1.25, step: 0.01, unit: 'x' },
                        { key: 'chest', label: 'Chest Proportions', min: 0.8, max: 1.25, step: 0.01, unit: 'x' },
                        { key: 'waist', label: 'Waist Taper', min: 0.8, max: 1.25, step: 0.01, unit: 'x' },
                        { key: 'armThickness', label: 'Arm Proportions', min: 0.8, max: 1.25, step: 0.01, unit: 'x' },
                        { key: 'legThickness', label: 'Leg Proportions', min: 0.8, max: 1.25, step: 0.01, unit: 'x' },
                        { key: 'muscularity', label: 'Muscular Definition', min: 0.0, max: 1.0, step: 0.05, unit: '%' },
                        { key: 'posture', label: 'Posture & Poise', min: 0.0, max: 1.0, step: 0.05, unit: '%' },
                      ].map((slider) => {
                        const val = (detailedAppearance as any)[slider.key] ?? 1.0;
                        const displayVal =
                          slider.unit === '%' ? `${Math.round(val * 100)}%` : `${val.toFixed(2)}x`;

                        return (
                          <div key={slider.key} className="space-y-1">
                            <div className="flex justify-between text-xs text-[#B5AC9A]">
                              <span>{slider.label}</span>
                              <span className="font-mono text-[#E2B05A]">{displayVal}</span>
                            </div>
                            <input
                              type="range"
                              min={slider.min}
                              max={slider.max}
                              step={slider.step}
                              value={val}
                              onChange={(e) =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  [slider.key]: parseFloat(e.target.value),
                                }))
                              }
                              className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 04: DEFINE YOUR FEATURES (FACE)                          */}
                {/* =============================================================== */}
                {currentScreen === 'face' && (
                  <div className="space-y-4">
                    {/* Mode Toggle: Presets vs Advanced */}
                    <div className="flex rounded border border-[#5A4B38] overflow-hidden">
                      <button
                        type="button"
                        onClick={() =>
                          setDetailedAppearance((prev) => ({ ...prev, faceMode: 'presets' }))
                        }
                        className={`flex-1 py-1.5 text-xs font-mono uppercase tracking-wider transition ${
                          detailedAppearance.faceMode === 'presets'
                            ? 'bg-[#E2B05A] text-[#111613] font-semibold'
                            : 'bg-[#161c18] text-[#B5AC9A]'
                        }`}
                      >
                        Presets (12)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setDetailedAppearance((prev) => ({ ...prev, faceMode: 'advanced' }))
                        }
                        className={`flex-1 py-1.5 text-xs font-mono uppercase tracking-wider transition ${
                          detailedAppearance.faceMode === 'advanced'
                            ? 'bg-[#E2B05A] text-[#111613] font-semibold'
                            : 'bg-[#161c18] text-[#B5AC9A]'
                        }`}
                      >
                        Advanced Sliders
                      </button>
                    </div>

                    {/* Presets Mode: 12 Distinct Presets */}
                    {detailedAppearance.faceMode === 'presets' && (
                      <div className="grid grid-cols-2 gap-2 max-h-[380px] overflow-y-auto pr-1">
                        {FACE_PRESETS_BY_RACE[characterBuild.raceId]?.map((fp) => {
                          const isSelected = detailedAppearance.facePresetId === fp.id;
                          return (
                            <button
                              key={fp.id}
                              type="button"
                              onClick={() => handleSelectFacePreset(fp.id)}
                              className={`p-2.5 text-left rounded border text-xs transition ${
                                isSelected
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A] hover:border-[#E2B05A]/60'
                              }`}
                            >
                              <div className="font-serif font-medium">{fp.name}</div>
                              <div className="text-[10px] font-mono text-[#E2B05A]/80 uppercase mt-0.5">
                                {fp.archetype}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Advanced Mode: Granular Sliders */}
                    {detailedAppearance.faceMode === 'advanced' && (
                      <div className="space-y-4">
                        <div className="flex space-x-1 border-b border-[#5A4B38]/50 pb-2 overflow-x-auto text-[11px] font-mono">
                          {(['head', 'eyes', 'nose', 'mouth', 'brows', 'ears'] as const).map((sec) => (
                            <button
                              key={sec}
                              type="button"
                              onClick={() => setActiveFaceSection(sec)}
                              className={`px-2 py-1 rounded uppercase ${
                                activeFaceSection === sec
                                  ? 'bg-[#E2B05A] text-[#111613] font-semibold'
                                  : 'text-[#B5AC9A] hover:bg-[#202922]'
                              }`}
                            >
                              {sec}
                            </button>
                          ))}
                        </div>

                        <div className="space-y-3">
                          {activeFaceSection === 'head' && (
                            <>
                              {[
                                { key: 'faceWidth', label: 'Face Width' },
                                { key: 'faceLength', label: 'Face Length' },
                                { key: 'jawWidth', label: 'Jaw Width' },
                                { key: 'chinLength', label: 'Chin Length' },
                                { key: 'cheekboneHeight', label: 'Cheekbone Prominence' },
                              ].map((f) => (
                                <div key={f.key} className="space-y-1">
                                  <div className="flex justify-between text-xs text-[#B5AC9A]">
                                    <span>{f.label}</span>
                                    <span className="font-mono text-[#E2B05A]">
                                      {((detailedAppearance as any)[f.key] ?? 1.0).toFixed(2)}
                                    </span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.8"
                                    max="1.25"
                                    step="0.01"
                                    value={(detailedAppearance as any)[f.key] ?? 1.0}
                                    onChange={(e) =>
                                      setDetailedAppearance((prev) => ({
                                        ...prev,
                                        [f.key]: parseFloat(e.target.value),
                                      }))
                                    }
                                    className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                                  />
                                </div>
                              ))}
                            </>
                          )}

                          {activeFaceSection === 'eyes' && (
                            <>
                              {[
                                { key: 'eyeSize', label: 'Eye Size' },
                                { key: 'eyeSpacing', label: 'Eye Spacing' },
                                { key: 'eyeDepth', label: 'Eye Depth' },
                              ].map((f) => (
                                <div key={f.key} className="space-y-1">
                                  <div className="flex justify-between text-xs text-[#B5AC9A]">
                                    <span>{f.label}</span>
                                    <span className="font-mono text-[#E2B05A]">
                                      {((detailedAppearance as any)[f.key] ?? 1.0).toFixed(2)}
                                    </span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.8"
                                    max="1.2"
                                    step="0.01"
                                    value={(detailedAppearance as any)[f.key] ?? 1.0}
                                    onChange={(e) =>
                                      setDetailedAppearance((prev) => ({
                                        ...prev,
                                        [f.key]: parseFloat(e.target.value),
                                      }))
                                    }
                                    className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                                  />
                                </div>
                              ))}
                            </>
                          )}

                          {activeFaceSection === 'nose' && (
                            <>
                              {[
                                { key: 'noseLength', label: 'Nose Length' },
                                { key: 'noseWidth', label: 'Nose Width' },
                                { key: 'bridgeHeight', label: 'Bridge Height' },
                              ].map((f) => (
                                <div key={f.key} className="space-y-1">
                                  <div className="flex justify-between text-xs text-[#B5AC9A]">
                                    <span>{f.label}</span>
                                    <span className="font-mono text-[#E2B05A]">
                                      {((detailedAppearance as any)[f.key] ?? 1.0).toFixed(2)}
                                    </span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.8"
                                    max="1.2"
                                    step="0.01"
                                    value={(detailedAppearance as any)[f.key] ?? 1.0}
                                    onChange={(e) =>
                                      setDetailedAppearance((prev) => ({
                                        ...prev,
                                        [f.key]: parseFloat(e.target.value),
                                      }))
                                    }
                                    className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                                  />
                                </div>
                              ))}
                            </>
                          )}

                          {activeFaceSection === 'mouth' && (
                            <>
                              {[
                                { key: 'mouthWidth', label: 'Mouth Width' },
                                { key: 'lipThickness', label: 'Lip Thickness' },
                              ].map((f) => (
                                <div key={f.key} className="space-y-1">
                                  <div className="flex justify-between text-xs text-[#B5AC9A]">
                                    <span>{f.label}</span>
                                    <span className="font-mono text-[#E2B05A]">
                                      {((detailedAppearance as any)[f.key] ?? 1.0).toFixed(2)}
                                    </span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.8"
                                    max="1.2"
                                    step="0.01"
                                    value={(detailedAppearance as any)[f.key] ?? 1.0}
                                    onChange={(e) =>
                                      setDetailedAppearance((prev) => ({
                                        ...prev,
                                        [f.key]: parseFloat(e.target.value),
                                      }))
                                    }
                                    className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                                  />
                                </div>
                              ))}
                            </>
                          )}

                          {activeFaceSection === 'brows' && (
                            <>
                              {[
                                { key: 'browThickness', label: 'Brow Thickness' },
                                { key: 'browAngle', label: 'Brow Angle' },
                              ].map((f) => (
                                <div key={f.key} className="space-y-1">
                                  <div className="flex justify-between text-xs text-[#B5AC9A]">
                                    <span>{f.label}</span>
                                    <span className="font-mono text-[#E2B05A]">
                                      {((detailedAppearance as any)[f.key] ?? 1.0).toFixed(2)}
                                    </span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.8"
                                    max="1.25"
                                    step="0.01"
                                    value={(detailedAppearance as any)[f.key] ?? 1.0}
                                    onChange={(e) =>
                                      setDetailedAppearance((prev) => ({
                                        ...prev,
                                        [f.key]: parseFloat(e.target.value),
                                      }))
                                    }
                                    className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                                  />
                                </div>
                              ))}
                            </>
                          )}

                          {activeFaceSection === 'ears' && (
                            <>
                              {[
                                { key: 'earSize', label: 'Ear Size' },
                                { key: 'earAngle', label: 'Ear Angle' },
                              ].map((f) => (
                                <div key={f.key} className="space-y-1">
                                  <div className="flex justify-between text-xs text-[#B5AC9A]">
                                    <span>{f.label}</span>
                                    <span className="font-mono text-[#E2B05A]">
                                      {((detailedAppearance as any)[f.key] ?? 1.0).toFixed(2)}
                                    </span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.8"
                                    max="1.3"
                                    step="0.01"
                                    value={(detailedAppearance as any)[f.key] ?? 1.0}
                                    onChange={(e) =>
                                      setDetailedAppearance((prev) => ({
                                        ...prev,
                                        [f.key]: parseFloat(e.target.value),
                                      }))
                                    }
                                    className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                                  />
                                </div>
                              ))}
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 05: HAIR & APPEARANCE                                    */}
                {/* =============================================================== */}
                {currentScreen === 'appearance' && (
                  <div className="space-y-4">
                    {/* Sub-tab Navigation */}
                    <div className="flex space-x-1 border-b border-[#5A4B38]/50 pb-2 overflow-x-auto text-xs font-mono">
                      {[
                        { id: 'hair', label: 'Hair (20)' },
                        { id: 'color', label: 'Colors' },
                        { id: 'facial_hair', label: 'Beard' },
                        { id: 'skin', label: 'Skin' },
                        { id: 'eyes', label: 'Eyes' },
                        { id: 'scars', label: 'Scars' },
                        ...(characterBuild.raceId === 'tiefling'
                          ? [{ id: 'horns', label: 'Horns' }]
                          : []),
                      ].map((tab: any) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setActiveAppearanceTab(tab.id)}
                          className={`px-2.5 py-1 rounded uppercase tracking-wider transition ${
                            activeAppearanceTab === tab.id
                              ? 'bg-[#E2B05A] text-[#111613] font-semibold'
                              : 'text-[#B5AC9A] hover:bg-[#202922]'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {/* 1. Hairstyle Library (20 distinct styles) */}
                    {activeAppearanceTab === 'hair' && (
                      <div className="grid grid-cols-2 gap-2 max-h-[360px] overflow-y-auto pr-1">
                        {HAIRSTYLE_LIBRARY.map((hs) => {
                          const isSelected = detailedAppearance.hairStyleId === hs.id;
                          return (
                            <button
                              key={hs.id}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  hairStyleId: hs.id,
                                }))
                              }
                              className={`p-2.5 rounded border text-left text-xs transition ${
                                isSelected
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A] hover:border-[#E2B05A]/60'
                              }`}
                            >
                              <div className="font-serif font-medium truncate">{hs.name}</div>
                              <div className="text-[10px] font-mono text-[#E2B05A]/80 uppercase mt-0.5">
                                {hs.category}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* 2. Hair Colors & Secondary Highlights */}
                    {activeAppearanceTab === 'color' && (
                      <div className="space-y-4">
                        <div>
                          <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block mb-2">
                            Primary Hair Color
                          </label>
                          <div className="grid grid-cols-5 gap-2">
                            {HAIR_COLORS.map((c) => (
                              <button
                                key={c.hex}
                                type="button"
                                onClick={() =>
                                  setDetailedAppearance((prev) => ({
                                    ...prev,
                                    hairPrimaryColor: c.hex,
                                  }))
                                }
                                title={c.label}
                                className={`h-8 rounded border-2 transition ${
                                  detailedAppearance.hairPrimaryColor === c.hex
                                    ? 'border-[#E2B05A] scale-110 shadow-md'
                                    : 'border-[#5A4B38]/50 hover:border-[#E2B05A]'
                                }`}
                                style={{ backgroundColor: c.hex }}
                              />
                            ))}
                          </div>
                        </div>

                        <div>
                          <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block mb-2">
                            Secondary Highlights
                          </label>
                          <div className="grid grid-cols-6 gap-2">
                            {SECONDARY_HAIR_HIGHLIGHTS.map((c) => (
                              <button
                                key={c.hex}
                                type="button"
                                onClick={() =>
                                  setDetailedAppearance((prev) => ({
                                    ...prev,
                                    hairSecondaryColor: c.hex,
                                  }))
                                }
                                title={c.label}
                                className={`h-8 rounded border-2 transition ${
                                  detailedAppearance.hairSecondaryColor === c.hex
                                    ? 'border-[#E2B05A] scale-110'
                                    : 'border-[#5A4B38]/50 hover:border-[#E2B05A]'
                                }`}
                                style={{ backgroundColor: c.hex }}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* 3. Facial Hair */}
                    {activeAppearanceTab === 'facial_hair' && (
                      <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                        {FACIAL_HAIR_OPTIONS.map((fh) => {
                          const isSelected = detailedAppearance.facialHairStyle === fh.id;
                          return (
                            <button
                              key={fh.id}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  facialHairStyle: fh.id,
                                }))
                              }
                              className={`w-full p-2.5 rounded border text-left text-xs transition ${
                                isSelected
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A] hover:border-[#E2B05A]/60'
                              }`}
                            >
                              <div className="font-serif font-medium">{fh.label}</div>
                              <div className="text-[10px] text-[#B5AC9A] mt-0.5">{fh.description}</div>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* 4. Skin Tones & Undertones */}
                    {activeAppearanceTab === 'skin' && (
                      <div className="space-y-4">
                        <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                          Compatible Racial Skin Tones
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {RACE_EXTENDED_DETAILS[characterBuild.raceId]?.compatibleSkinTones.map((st) => (
                            <button
                              key={st.hex}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  skinToneHex: st.hex,
                                  skinUndertone: st.undertone,
                                }))
                              }
                              className={`p-2 rounded border flex items-center space-x-2 text-left text-xs transition ${
                                detailedAppearance.skinToneHex.toLowerCase() === st.hex.toLowerCase()
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.12)]'
                                  : 'border-[#5A4B38]/60 hover:border-[#E2B05A]'
                              }`}
                            >
                              <span
                                className="w-5 h-5 rounded-full border border-black/40 flex-shrink-0"
                                style={{ backgroundColor: st.hex }}
                              />
                              <div className="truncate">
                                <div className="text-[11px] text-[#F2ECE1] truncate">{st.label}</div>
                                <div className="text-[9px] font-mono text-[#B5AC9A] uppercase">
                                  {st.undertone}
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 5. Eye Colors */}
                    {activeAppearanceTab === 'eyes' && (
                      <div className="space-y-4">
                        <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                          Natural & Fantasy Irises
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {EYE_COLORS.map((ec) => (
                            <button
                              key={ec.hex}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  eyeColorHex: ec.hex,
                                }))
                              }
                              className={`p-2 rounded border flex items-center space-x-2.5 text-left text-xs transition ${
                                detailedAppearance.eyeColorHex.toLowerCase() === ec.hex.toLowerCase()
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.12)]'
                                  : 'border-[#5A4B38]/60 hover:border-[#E2B05A]'
                              }`}
                            >
                              <span
                                className="w-4 h-4 rounded-full border border-black/50 shadow flex-shrink-0"
                                style={{ backgroundColor: ec.hex }}
                              />
                              <div>
                                <div className="text-xs text-[#F2ECE1]">{ec.label}</div>
                                <div className="text-[9px] font-mono text-[#E2B05A]/80 uppercase">
                                  {ec.type}
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 6. Scars & Markings */}
                    {activeAppearanceTab === 'scars' && (
                      <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                        <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                          Battle Scars
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {SCARS_LIBRARY.map((s) => (
                            <button
                              key={s.id}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({ ...prev, scarId: s.id }))
                              }
                              className={`p-2 rounded border text-left text-xs transition ${
                                detailedAppearance.scarId === s.id
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A]'
                              }`}
                            >
                              <div className="font-medium">{s.label}</div>
                            </button>
                          ))}
                        </div>

                        <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block pt-2">
                          Tattoos & Sigils
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {TATTOOS_LIBRARY.map((t) => (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({ ...prev, tattooId: t.id }))
                              }
                              className={`p-2 rounded border text-left text-xs transition ${
                                detailedAppearance.tattooId === t.id
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A]'
                              }`}
                            >
                              <div className="font-medium">{t.label}</div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 7. Tiefling Horns */}
                    {activeAppearanceTab === 'horns' && characterBuild.raceId === 'tiefling' && (
                      <div className="space-y-4">
                        <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                          Horn Styles
                        </label>
                        <div className="space-y-1.5">
                          {TIEFLING_HORNS.map((th) => (
                            <button
                              key={th.id}
                              type="button"
                              onClick={() =>
                                setDetailedAppearance((prev) => ({ ...prev, hornStyle: th.id }))
                              }
                              className={`w-full p-2.5 rounded border text-left text-xs transition ${
                                detailedAppearance.hornStyle === th.id
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A]'
                              }`}
                            >
                              <div className="font-serif font-medium">{th.label}</div>
                              <div className="text-[10px] text-[#B5AC9A] mt-0.5">{th.description}</div>
                            </button>
                          ))}
                        </div>

                        <div className="space-y-3 pt-2">
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs text-[#B5AC9A]">
                              <span>Horn Length</span>
                              <span className="font-mono text-[#E2B05A]">
                                {(detailedAppearance.hornLength || 1.0).toFixed(2)}x
                              </span>
                            </div>
                            <input
                              type="range"
                              min="0.8"
                              max="1.3"
                              step="0.02"
                              value={detailedAppearance.hornLength || 1.0}
                              onChange={(e) =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  hornLength: parseFloat(e.target.value),
                                }))
                              }
                              className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                            />
                          </div>

                          <div className="space-y-1">
                            <div className="flex justify-between text-xs text-[#B5AC9A]">
                              <span>Horn Curvature</span>
                              <span className="font-mono text-[#E2B05A]">
                                {(detailedAppearance.hornCurvature || 1.0).toFixed(2)}x
                              </span>
                            </div>
                            <input
                              type="range"
                              min="0.8"
                              max="1.3"
                              step="0.02"
                              value={detailedAppearance.hornCurvature || 1.0}
                              onChange={(e) =>
                                setDetailedAppearance((prev) => ({
                                  ...prev,
                                  hornCurvature: parseFloat(e.target.value),
                                }))
                              }
                              className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 06: IDENTITY & ORIGINS                                   */}
                {/* =============================================================== */}
                {currentScreen === 'identity' && (
                  <div className="space-y-5">
                    {/* Character Name */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Character Name
                      </label>
                      <div className="flex space-x-2">
                        <input
                          type="text"
                          maxLength={24}
                          value={commanderName}
                          onChange={(e) => {
                            setCommanderName(e.target.value);
                            onChangeCharacterBuild({
                              ...characterBuild,
                              commanderName: e.target.value,
                            });
                          }}
                          className="flex-1 bg-[#111613] border border-[#5A4B38] rounded px-3 py-2 text-sm text-[#F2ECE1] font-serif focus:border-[#E2B05A] outline-none"
                          placeholder="Name your protagonist..."
                        />
                        <button
                          type="button"
                          onClick={handleGenerateRandomName}
                          title="Generate Racial Name"
                          className="px-3 py-2 border border-[#5A4B38] bg-[#1a221d] text-xs font-mono text-[#E2B05A] rounded hover:border-[#E2B05A] transition"
                        >
                          Randomize
                        </button>
                      </div>
                    </div>

                    {/* Narrative Backgrounds (7 options) */}
                    <div className="space-y-2">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Narrative Background (7)
                      </label>
                      <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                        {NARRATIVE_BACKGROUNDS.map((bg) => {
                          const isSelected = selectedBackgroundId === bg.id;
                          return (
                            <button
                              key={bg.id}
                              type="button"
                              onClick={() => {
                                setSelectedBackgroundId(bg.id);
                                onChangeOriginChoice(bg.mappedOriginChoice);
                              }}
                              className={`w-full p-2.5 rounded border text-left text-xs transition ${
                                isSelected
                                  ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.12)] shadow'
                                  : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] hover:border-[#E2B05A]/60'
                              }`}
                            >
                              <div className="flex items-center space-x-2">
                                <span>{bg.emblem}</span>
                                <span className="font-serif font-medium text-[#F2ECE1]">{bg.name}</span>
                              </div>
                              <p className="text-[11px] text-[#B5AC9A] mt-1 line-clamp-2">{bg.lore}</p>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Personality (6 options) */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Personality Disposition
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {PERSONALITY_OPTIONS.map((po) => (
                          <button
                            key={po.id}
                            type="button"
                            onClick={() => setSelectedPersonalityId(po.id)}
                            className={`p-2 rounded border text-left text-xs transition ${
                              selectedPersonalityId === po.id
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A]'
                            }`}
                          >
                            <div className="font-medium">{po.name}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Voice Presentation */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Voice Presentation
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {VOICE_OPTIONS.map((vo) => (
                          <button
                            key={vo.id}
                            type="button"
                            onClick={() => setSelectedVoiceId(vo.id)}
                            className={`p-2 rounded border text-left text-xs transition ${
                              selectedVoiceId === vo.id
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] text-[#E2B05A]'
                                : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] text-[#B5AC9A]'
                            }`}
                          >
                            <div className="font-medium truncate">{vo.name}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 07: CHOOSE YOUR PATH (CLASS SELECTION)                   */}
                {/* =============================================================== */}
                {currentScreen === 'class' && (
                  <div className="space-y-4">
                    {/* Compact 5-Class Cards Grid */}
                    <div className="grid grid-cols-5 gap-1.5">
                      {PLAYABLE_CLASS_PROFILES.map((prof) => {
                        const isSelected = archetypeClass === prof.archetypeId;
                        return (
                          <button
                            key={prof.archetypeId}
                            type="button"
                            onClick={() => handleSelectArchetypeClass(prof)}
                            className={`flex flex-col items-center justify-center p-2 rounded border text-center transition-all cursor-pointer ${
                              isSelected
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.18)] shadow-[0_0_12px_rgba(226,176,90,0.25)] ring-1 ring-[#E2B05A]'
                                : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] hover:border-[#E2B05A]/50 hover:bg-[rgba(22,28,24,0.9)]'
                            }`}
                          >
                            <span className="text-xl mb-1">{prof.icon}</span>
                            <span className="font-serif text-xs font-semibold text-[#F2ECE1] block truncate w-full">
                              {prof.name}
                            </span>
                            <span className="text-[9px] font-mono text-[#B5AC9A] truncate w-full block mt-0.5">
                              {prof.oneLineIdentity}
                            </span>
                            {isSelected ? (
                              <span className="mt-1 text-[8px] font-mono uppercase tracking-wider bg-[#E2B05A] text-[#111613] font-bold px-1.5 py-0.5 rounded-full">
                                Selected
                              </span>
                            ) : (
                              <span className="mt-1 text-[8px] font-mono uppercase tracking-wider text-[#5A4B38]">
                                {prof.difficulty}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Selected Class Presentation Panel */}
                    <div className="p-4 bg-[rgba(17,22,19,0.92)] border border-[#5A4B38] rounded space-y-3 text-xs">
                      {/* Class Header & Role */}
                      <div className="border-b border-[#5A4B38]/50 pb-2.5 flex items-baseline justify-between">
                        <div>
                          <h4 className="font-serif text-base font-bold text-[#F2ECE1]">
                            {activeClassProfile.name}
                          </h4>
                          <span className="text-xs font-serif italic text-[#E2B05A]">
                            {activeClassProfile.title}
                          </span>
                        </div>
                        <span className="text-[9px] font-mono text-[#7E9C82] uppercase bg-[#7E9C82]/10 px-2 py-0.5 rounded border border-[#7E9C82]/30">
                          Role: {activeClassProfile.combatRole}
                        </span>
                      </div>

                      {/* Official Class Description */}
                      <p className="text-xs text-[#F2ECE1]/90 leading-relaxed italic bg-[rgba(0,0,0,0.3)] p-2.5 rounded border-l-2 border-[#E2B05A]">
                        "{activeClassProfile.description}"
                      </p>

                      {/* Tactical Strengths */}
                      <div className="space-y-1.5">
                        <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                          Tactical Strengths
                        </div>
                        <ul className="space-y-1 text-[11px] text-[#B5AC9A]">
                          {activeClassProfile.tacticalStrengths.map((str, idx) => (
                            <li key={idx} className="flex items-start space-x-1.5">
                              <span className="text-[#E2B05A] text-[10px] mt-0.5">◆</span>
                              <span>{str}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Weapon & Armor Identity */}
                      <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#5A4B38]/40">
                        <div className="p-2 bg-[rgba(0,0,0,0.25)] rounded border border-[#5A4B38]/30">
                          <div className="text-[9px] font-mono text-[#E2B05A] uppercase">Weapon Identity</div>
                          <div className="text-[11px] text-[#F2ECE1] font-medium mt-0.5">{activeClassProfile.weaponIdentity}</div>
                        </div>
                        <div className="p-2 bg-[rgba(0,0,0,0.25)] rounded border border-[#5A4B38]/30">
                          <div className="text-[9px] font-mono text-[#E2B05A] uppercase">Armor Identity</div>
                          <div className="text-[11px] text-[#F2ECE1] font-medium mt-0.5">{activeClassProfile.armorIdentity}</div>
                        </div>
                      </div>

                      {/* Existing Class Abilities */}
                      <div className="space-y-1.5 pt-1 border-t border-[#5A4B38]/40">
                        <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                          Starting Class Abilities
                        </div>
                        <div className="space-y-1.5">
                          {activeClassProfile.startingAbilities.map((ab) => (
                            <div key={ab.id} className="p-2 bg-[rgba(0,0,0,0.25)] rounded border border-[#5A4B38]/30 space-y-0.5">
                              <div className="flex items-center justify-between">
                                <span className="font-serif font-medium text-[#F2ECE1] text-[11px]">{ab.name}</span>
                                <span className="text-[9px] font-mono text-[#7E9C82]">Active</span>
                              </div>
                              <p className="text-[10px] text-[#B5AC9A]">{ab.summary}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 08: OATH OF SPECIALIZATION (SUBCLASS SELECTION)          */}
                {/* =============================================================== */}
                {currentScreen === 'subclass' && (
                  <div className="space-y-4">
                    {/* View Mode Toggle: Details vs Compare */}
                    <div className="flex rounded border border-[#5A4B38] overflow-hidden p-0.5 bg-[rgba(17,22,19,0.8)]">
                      <button
                        type="button"
                        onClick={() => setSubclassViewTab('details')}
                        className={`flex-1 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition cursor-pointer ${
                          subclassViewTab === 'details'
                            ? 'bg-[#E2B05A] text-[#111613] font-bold shadow'
                            : 'text-[#B5AC9A] hover:text-[#F2ECE1]'
                        }`}
                      >
                        Specialization Details
                      </button>
                      <button
                        type="button"
                        onClick={() => setSubclassViewTab('compare')}
                        className={`flex-1 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition cursor-pointer ${
                          subclassViewTab === 'compare'
                            ? 'bg-[#E2B05A] text-[#111613] font-bold shadow'
                            : 'text-[#B5AC9A] hover:text-[#F2ECE1]'
                        }`}
                      >
                        Compare Specializations
                      </button>
                    </div>

                    {/* Compatible Specialization Cards */}
                    {/* Centered if exactly 1 option (e.g. Rogue), 2-column grid if multiple */}
                    <div
                      className={
                        compatibleSpecializations.length === 1
                          ? 'flex justify-center'
                          : 'grid grid-cols-2 gap-2.5'
                      }
                    >
                      {compatibleSpecializations.map((spec) => {
                        const isSelected = characterBuild.subclassId === spec.id;
                        return (
                          <button
                            key={spec.id}
                            type="button"
                            onClick={() => handleSelectSubclass(spec.id)}
                            className={`p-3 rounded border text-left transition-all cursor-pointer ${
                              compatibleSpecializations.length === 1 ? 'w-full max-w-sm' : ''
                            } ${
                              isSelected
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.15)] shadow-[0_0_12px_rgba(226,176,90,0.25)] ring-1 ring-[#E2B05A]'
                                : 'border-[#5A4B38]/60 bg-[rgba(17,22,19,0.7)] hover:border-[#E2B05A]/50 hover:bg-[rgba(22,28,24,0.9)]'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xl">{spec.icon}</span>
                              <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-[rgba(0,0,0,0.4)] border border-[#5A4B38]/50 text-[#B5AC9A]">
                                {spec.availabilityState}
                              </span>
                            </div>
                            <div className="font-serif font-bold text-xs text-[#F2ECE1] truncate">
                              {spec.name}
                            </div>
                            <div className="text-[10px] font-serif italic text-[#E2B05A] truncate mt-0.5">
                              {spec.shortIdentity}
                            </div>
                            <p className="text-[10px] text-[#B5AC9A] mt-1 line-clamp-2 leading-relaxed">
                              {spec.oneLineCombatDescription}
                            </p>
                            {isSelected ? (
                              <div className="mt-2 text-[9px] font-mono uppercase text-[#E2B05A] font-bold flex items-center space-x-1">
                                <span>✓</span>
                                <span>Active Specialization Path</span>
                              </div>
                            ) : (
                              <div className="mt-2 text-[9px] font-mono text-[#5A4B38]">
                                Click to Select Path
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* DETAILS VIEW */}
                    {subclassViewTab === 'details' && (
                      <div className="p-4 bg-[rgba(17,22,19,0.92)] border border-[#5A4B38] rounded space-y-3 text-xs">
                        {/* Header */}
                        <div className="border-b border-[#5A4B38]/50 pb-2.5 flex items-baseline justify-between">
                          <div>
                            <h4 className="font-serif text-base font-bold text-[#F2ECE1]">
                              {activeSpecializationProfile.name}
                            </h4>
                            <span className="text-xs font-serif italic text-[#E2B05A]">
                              {activeSpecializationProfile.title}
                            </span>
                          </div>
                          <span className="text-[9px] font-mono text-[#7E9C82] uppercase bg-[#7E9C82]/10 px-2 py-0.5 rounded border border-[#7E9C82]/30">
                            {activeSpecializationProfile.tacticalRole}
                          </span>
                        </div>

                        {/* Lore Description */}
                        <p className="text-xs text-[#F2ECE1]/90 leading-relaxed italic bg-[rgba(0,0,0,0.3)] p-2.5 rounded border-l-2 border-[#E2B05A]">
                          "{activeSpecializationProfile.loreDescription}"
                        </p>

                        {/* Combat Identity & Unlock */}
                        <div className="space-y-1.5">
                          <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                            Combat Identity & Unlock Path
                          </div>
                          <div className="p-2 bg-[rgba(0,0,0,0.25)] rounded border border-[#5A4B38]/30 space-y-1">
                            <div className="text-[11px] text-[#F2ECE1]">
                              <span className="text-[#B5AC9A]">Focus: </span>
                              {activeSpecializationProfile.combatIdentity}
                            </div>
                            <div className="text-[10px] font-mono text-[#E2B05A]">
                              <span className="text-[#B5AC9A]">Requirement: </span>
                              {activeSpecializationProfile.unlockRequirements}
                            </div>
                          </div>
                        </div>

                        {/* Equipment Compatibility */}
                        <div className="space-y-1.5">
                          <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                            Equipment Compatibility
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {activeSpecializationProfile.equipmentCompatibility.map((eq, idx) => (
                              <span
                                key={idx}
                                className="text-[10px] font-mono bg-[#111613] text-[#B5AC9A] border border-[#5A4B38]/40 px-2 py-0.5 rounded"
                              >
                                {eq}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Signature Skill */}
                        <div className="space-y-1.5 pt-1 border-t border-[#5A4B38]/40">
                          <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                            Signature Specialization Skill
                          </div>
                          <div className="p-2.5 bg-[rgba(226,176,90,0.08)] border border-[#E2B05A]/40 rounded space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-serif font-bold text-xs text-[#F2ECE1]">
                                {activeSpecializationProfile.signatureSkill.name}
                              </span>
                              <span className="text-[9px] font-mono text-[#E2B05A]">
                                {activeSpecializationProfile.signatureSkill.apCost} AP · Range {activeSpecializationProfile.signatureSkill.range} · {activeSpecializationProfile.signatureSkill.element}
                              </span>
                            </div>
                            <p className="text-[11px] text-[#B5AC9A] leading-relaxed">
                              {activeSpecializationProfile.signatureSkill.summary}
                            </p>
                          </div>
                        </div>

                        {/* Progression Abilities Roadmap */}
                        <div className="space-y-1.5 pt-1 border-t border-[#5A4B38]/40">
                          <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                            Progression Abilities Roadmap
                          </div>
                          <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                            {activeSpecializationProfile.specializationAbilities.map((ab) => (
                              <div
                                key={ab.id}
                                className="p-2 bg-[rgba(0,0,0,0.25)] rounded border border-[#5A4B38]/30 space-y-0.5"
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-serif font-medium text-[#F2ECE1] text-[11px]">
                                    {ab.name}
                                  </span>
                                  <span className="text-[9px] font-mono text-[#B5AC9A]">
                                    Unlocks Lv.{ab.level}
                                  </span>
                                </div>
                                <p className="text-[10px] text-[#B5AC9A] leading-relaxed">{ab.summary}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* COMPARE VIEW */}
                    {subclassViewTab === 'compare' && (
                      <div className="p-4 bg-[rgba(17,22,19,0.92)] border border-[#5A4B38] rounded space-y-3 text-xs">
                        <div className="border-b border-[#5A4B38]/50 pb-2">
                          <h4 className="font-serif text-sm font-bold text-[#F2ECE1]">
                            Specialization Comparison Matrix
                          </h4>
                          <p className="text-[10px] font-mono text-[#B5AC9A] mt-0.5">
                            Evaluating compatible specialization paths for {activeClassProfile.name}
                          </p>
                        </div>

                        {compatibleSpecializations.map((spec) => (
                          <div
                            key={spec.id}
                            className={`p-3 rounded border space-y-2 ${
                              characterBuild.subclassId === spec.id
                                ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.1)]'
                                : 'border-[#5A4B38]/50 bg-[rgba(0,0,0,0.25)]'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <span>{spec.icon}</span>
                                <span className="font-serif font-bold text-[#F2ECE1] text-xs">{spec.name}</span>
                                <span className="text-[10px] text-[#E2B05A] italic">({spec.comparison.coreIdentity})</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleSelectSubclass(spec.id)}
                                className={`text-[9px] font-mono uppercase px-2 py-0.5 rounded border transition cursor-pointer ${
                                  characterBuild.subclassId === spec.id
                                    ? 'border-[#E2B05A] bg-[#E2B05A] text-[#111613] font-bold'
                                    : 'border-[#5A4B38] text-[#B5AC9A] hover:border-[#E2B05A]'
                                }`}
                              >
                                {characterBuild.subclassId === spec.id ? 'Selected' : 'Select'}
                              </button>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-[10px]">
                              <div>
                                <span className="text-[#E2B05A] font-mono block">Combat Role:</span>
                                <span className="text-[#F2ECE1]">{spec.comparison.combatRole}</span>
                              </div>
                              <div>
                                <span className="text-[#E2B05A] font-mono block">Skill Themes:</span>
                                <span className="text-[#B5AC9A]">{spec.comparison.skillThemes.join(', ')}</span>
                              </div>
                            </div>

                            <div className="space-y-1 text-[10px] border-t border-[#5A4B38]/30 pt-1.5">
                              <div>
                                <span className="text-[#7E9C82] font-mono font-medium">Defensive: </span>
                                <span className="text-[#B5AC9A]">{spec.comparison.defensiveStrengths}</span>
                              </div>
                              <div>
                                <span className="text-[#B85349] font-mono font-medium">Offensive: </span>
                                <span className="text-[#B5AC9A]">{spec.comparison.offensiveStrengths}</span>
                              </div>
                              <div>
                                <span className="text-[#6d8ca3] font-mono font-medium">Utility: </span>
                                <span className="text-[#B5AC9A]">{spec.comparison.utilityStrengths}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 08: DEFINE YOUR ABILITIES (ATTRIBUTES)                    */}
                {/* =============================================================== */}
                {currentScreen === 'attributes' && (
                  <div className="space-y-4">
                    {/* Points Budget Banner */}
                    <div className="p-3 bg-[rgba(226,176,90,0.12)] border border-[#E2B05A] rounded flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider text-[#F2ECE1]">
                        Unallocated Ability Points
                      </span>
                      <span className="text-lg font-mono font-bold text-[#E2B05A]">
                        {remainingPoints}
                      </span>
                    </div>

                    {/* 4 Attributes Cards */}
                    <div className="space-y-2.5">
                      {ATTRIBUTE_METADATA.map((attr) => {
                        const totalScore = preview.stats[attr.key];
                        const modifier = getD20Modifier(totalScore);
                        const currentAlloc = allocatedPoints[attr.key];
                        const isRecommended = activeClassProfile.primaryAttributes.includes(attr.short);

                        return (
                          <div
                            key={attr.key}
                            className={`p-3 rounded border bg-[rgba(17,22,19,0.7)] ${
                              isRecommended ? 'border-[#E2B05A]/60' : 'border-[#5A4B38]/60'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <span className="font-serif font-semibold text-sm text-[#F2ECE1]">
                                  {attr.name}
                                </span>
                                <span className="text-xs font-mono text-[#B5AC9A]">
                                  ({attr.short})
                                </span>
                                {isRecommended && (
                                  <span className="text-[9px] font-mono uppercase bg-[#E2B05A]/20 text-[#E2B05A] px-1.5 py-0.5 rounded">
                                    Primary
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center space-x-3">
                                {/* D20 Modifier */}
                                <div className="text-right">
                                  <div className="text-base font-mono font-bold text-[#F2ECE1]">
                                    {totalScore}
                                  </div>
                                  <div
                                    className={`text-[10px] font-mono font-semibold ${
                                      modifier > 0
                                        ? 'text-[#7E9C82]'
                                        : modifier < 0
                                        ? 'text-[#B85349]'
                                        : 'text-[#B5AC9A]'
                                    }`}
                                  >
                                    Mod: {formatD20Modifier(modifier)}
                                  </div>
                                </div>

                                {/* Increments */}
                                <div className="flex space-x-1">
                                  <button
                                    type="button"
                                    disabled={currentAlloc <= 0}
                                    onClick={() => handleStatChange(attr.key, -1)}
                                    className="w-7 h-7 rounded border border-[#5A4B38] bg-[#1a221d] text-xs font-mono text-[#F2ECE1] disabled:opacity-40 disabled:cursor-not-allowed hover:border-[#E2B05A] transition"
                                  >
                                    -
                                  </button>
                                  <button
                                    type="button"
                                    disabled={remainingPoints <= 0 || currentAlloc >= MAX_ALLOC_PER_STAT}
                                    onClick={() => handleStatChange(attr.key, 1)}
                                    className="w-7 h-7 rounded border border-[#5A4B38] bg-[#1a221d] text-xs font-mono text-[#E2B05A] disabled:opacity-40 disabled:cursor-not-allowed hover:border-[#E2B05A] transition"
                                  >
                                    +
                                  </button>
                                </div>
                              </div>
                            </div>

                            <p className="text-[11px] text-[#B5AC9A] mt-2 line-clamp-2">
                              {attr.description}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 09: PREPARE FOR THE JOURNEY (COMBAT IDENTITY)            */}
                {/* =============================================================== */}
                {currentScreen === 'combat_identity' && (
                  <div className="space-y-4">
                    {/* Starting Skills */}
                    <div className="space-y-2">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Starting Combat Skills
                      </label>
                      {activeClassProfile.startingAbilities.map((ab) => (
                        <div
                          key={ab.id}
                          className="p-3 bg-[rgba(17,22,19,0.8)] border border-[#5A4B38] rounded space-y-1"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-serif font-medium text-xs text-[#F2ECE1]">
                              {ab.name}
                            </span>
                            <span className="text-[10px] font-mono text-[#7E9C82] uppercase">
                              Active Skill
                            </span>
                          </div>
                          <p className="text-[11px] text-[#B5AC9A]">{ab.summary}</p>
                        </div>
                      ))}
                    </div>

                    {/* Specialization Roadmap */}
                    <div className="space-y-2 pt-2 border-t border-[#5A4B38]/50">
                      <label className="text-xs font-mono text-[#E2B05A] uppercase tracking-wider block">
                        Future Specialization Paths (Level 3)
                      </label>
                      <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                        {SPECIALIZATION_ROADMAP.filter((spec) =>
                          spec.archetypes.includes(archetypeClass)
                        ).map((spec) => (
                          <div
                            key={spec.id}
                            className="p-2.5 bg-[rgba(17,22,19,0.7)] border border-[#5A4B38]/60 rounded space-y-1 text-xs"
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-serif font-medium text-[#E2B05A]">
                                {spec.name}
                              </span>
                              <span className="text-[10px] font-mono text-[#B5AC9A]">
                                Unlocks Lv.{spec.unlockLevel}
                              </span>
                            </div>
                            <div className="text-[11px] text-[#F2ECE1] font-mono">
                              {spec.roleTitle}
                            </div>
                            <p className="text-[10px] text-[#B5AC9A]">{spec.lore}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* =============================================================== */}
                {/* SCREEN 10: THE OATH BEGINS (FINAL REVIEW)                       */}
                {/* =============================================================== */}
                {currentScreen === 'review' && (
                  <div className="space-y-3.5 text-xs">
                    {/* Identity Summary */}
                    <div className="p-3 bg-[rgba(17,22,19,0.85)] border border-[#5A4B38] rounded space-y-1">
                      <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                        Protagonist Identity
                      </div>
                      <div className="text-sm font-serif font-semibold text-[#F2ECE1]">
                        {commanderName}
                      </div>
                      <div className="text-[#B5AC9A]">
                        {RACE_EXTENDED_DETAILS[characterBuild.raceId]?.name} · {activeBackground.name} · {activePersonality.name}
                      </div>
                    </div>

                    {/* Class & Combat Role */}
                    <div className="p-3 bg-[rgba(17,22,19,0.85)] border border-[#5A4B38] rounded space-y-1">
                      <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                        Combat Class & Role
                      </div>
                      <div className="text-sm font-serif font-semibold text-[#F2ECE1]">
                        {activeClassProfile.name}
                      </div>
                      <div className="text-[#B5AC9A]">{activeClassProfile.combatRole}</div>
                    </div>

                    {/* Chosen Specialization Path */}
                    <div className="p-3 bg-[rgba(17,22,19,0.85)] border border-[#5A4B38] rounded space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                          Specialization Path
                        </div>
                        <span className="text-[9px] font-mono text-[#B5AC9A]">
                          Unlocks at Level 3
                        </span>
                      </div>
                      <div className="text-sm font-serif font-semibold text-[#F2ECE1] flex items-center space-x-1.5">
                        <span>{activeSpecializationProfile.icon}</span>
                        <span>{activeSpecializationProfile.name}</span>
                      </div>
                      <div className="text-[#B5AC9A] text-[11px]">{activeSpecializationProfile.shortIdentity}</div>
                    </div>

                    {/* Attributes with Modifiers */}
                    <div className="p-3 bg-[rgba(17,22,19,0.85)] border border-[#5A4B38] rounded space-y-1.5">
                      <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                        Ability Scores & D20 Modifiers
                      </div>
                      <div className="grid grid-cols-4 gap-2 text-center">
                        {(['str', 'dex', 'int', 'cha'] as const).map((key) => {
                          const total = preview.stats[key];
                          const mod = getD20Modifier(total);
                          return (
                            <div key={key} className="p-1.5 bg-[#111613] rounded border border-[#5A4B38]/50">
                              <div className="text-[10px] font-mono text-[#B5AC9A] uppercase">{key}</div>
                              <div className="text-sm font-mono font-bold text-[#F2ECE1]">{total}</div>
                              <div className="text-[10px] font-mono text-[#7E9C82]">{formatD20Modifier(mod)}</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Starting Skills */}
                    <div className="p-3 bg-[rgba(17,22,19,0.85)] border border-[#5A4B38] rounded space-y-1">
                      <div className="text-[10px] font-mono text-[#E2B05A] uppercase tracking-wider">
                        Prepared Starting Skills
                      </div>
                      <div className="text-[#B5AC9A] space-y-0.5">
                        {activeClassProfile.startingAbilities.map((ab) => (
                          <div key={ab.id} className="flex justify-between">
                            <span className="text-[#F2ECE1] font-medium">{ab.name}</span>
                            <span className="text-[#7E9C82] font-mono">Active</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Nav / Actions inside Right Panel for Screen 10 */}
              {currentScreen === 'review' && (
                <div className="pt-4 border-t border-[#5A4B38] space-y-2">
                  <button
                    type="button"
                    onClick={handleFinalizeAndBeginAdventure}
                    className="w-full py-3 bg-[#E2B05A] text-[#111613] font-mono text-xs uppercase tracking-wider font-semibold rounded hover:bg-[#c99a4a] transition shadow-lg cursor-pointer"
                  >
                    Confirm Character & Begin Oath
                  </button>
                  <button
                    type="button"
                    onClick={handleRandomizeAppearance}
                    className="w-full py-2 border border-[#5A4B38] text-[#B5AC9A] font-mono text-xs uppercase tracking-wider rounded hover:text-[#F2ECE1] transition"
                  >
                    Randomize Appearance
                  </button>
                </div>
              )}
            </aside>
          </div>

          {/* ------------------------------------------------------------------- */}
          {/* BOTTOM NAVIGATION BAR (Screens 01 - 09)                             */}
          {/* ------------------------------------------------------------------- */}
          {currentScreen !== 'review' && (
            <footer className="h-16 border-t border-[#5A4B38] bg-[rgba(17,22,19,0.96)] px-8 flex items-center justify-between z-20 backdrop-blur-sm">
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={handleBack}
                  className="px-4 py-2 border border-[#5A4B38] text-[#B5AC9A] font-mono text-xs uppercase tracking-wider rounded hover:border-[#E2B05A] hover:text-[#F2ECE1] transition"
                >
                  Back
                </button>

                {currentScreen !== 'begin' && (
                  <>
                    <button
                      type="button"
                      onClick={handleRandomizeAppearance}
                      className="px-3 py-2 text-xs font-mono text-[#B5AC9A] hover:text-[#E2B05A] transition"
                    >
                      Randomize Look
                    </button>
                    <button
                      type="button"
                      onClick={handleResetAppearance}
                      className="px-3 py-2 text-xs font-mono text-[#B5AC9A] hover:text-[#B85349] transition"
                    >
                      Reset Category
                    </button>
                  </>
                )}
              </div>

              <div>
                <button
                  type="button"
                  onClick={handleContinue}
                  className="px-6 py-2 bg-[#E2B05A] text-[#111613] font-mono text-xs uppercase tracking-wider font-semibold rounded hover:bg-[#c99a4a] transition shadow cursor-pointer"
                >
                  {currentScreen === 'class'
                    ? 'Continue to Specialization →'
                    : currentScreen === 'subclass'
                    ? 'Continue to Attributes →'
                    : currentScreen === 'combat_identity'
                    ? 'Review Character Oath →'
                    : 'Continue →'}
                </button>
              </div>
            </footer>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. LOADING AND INTRODUCTION CINEMATIC SCREEN                              */}
      {/* ========================================================================= */}
      {currentScreen === 'loading_intro' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center p-8 bg-[radial-gradient(ellipse_at_center,rgba(22,28,24,0.95)_0%,#111613_100%)]">
          <div className="w-full max-w-lg space-y-6 text-center">
            <h2 className="text-2xl font-serif tracking-widest text-[#F2ECE1] uppercase">
              The Shattered Oath Awakes
            </h2>
            <p className="text-xs font-mono tracking-widest text-[#E2B05A] uppercase">
              Entering Hearth Square · Gloamrest
            </p>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-[#1b221d] border border-[#5A4B38] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#E2B05A] transition-all duration-300"
                style={{ width: `${loadingProgress}%` }}
              />
            </div>

            {/* Gameplay Tip */}
            <div className="p-4 bg-[rgba(22,28,24,0.7)] border border-[#5A4B38]/60 rounded text-xs text-[#B5AC9A] italic">
              &quot;{CREATION_GAMEPLAY_TIPS[loadingTipIndex]}&quot;
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. LOAD GAME MODAL                                                        */}
      {/* ========================================================================= */}
      {currentScreen === 'load_game' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center p-8 bg-[#111613]/90">
          <div className="w-full max-w-2xl bg-[rgba(22,28,24,0.96)] border border-[#5A4B38] rounded p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#5A4B38]/60 pb-3">
              <h2 className="text-lg font-serif text-[#F2ECE1] uppercase tracking-wider">
                Saved Adventures
              </h2>
              <button
                type="button"
                onClick={() => navigateToScreen('main_menu')}
                className="text-xs font-mono text-[#B5AC9A] hover:text-[#E2B05A]"
              >
                Close [ESC]
              </button>
            </div>

            <div className="space-y-2 max-h-80 overflow-y-auto">
              {saveSlots.length === 0 ? (
                <div className="p-6 text-center text-xs font-mono text-[#B5AC9A]">
                  No saved adventures discovered.
                </div>
              ) : (
                saveSlots.map((slot) => {
                  const isSelected = selectedSaveId === slot.id;
                  return (
                    <div
                      key={slot.id}
                      onClick={() => setSelectedSaveId(slot.id)}
                      className={`p-3.5 rounded border flex items-center justify-between cursor-pointer transition ${
                        isSelected
                          ? 'border-[#E2B05A] bg-[rgba(226,176,90,0.12)]'
                          : 'border-[#5A4B38]/50 bg-[#111613]/60 hover:border-[#E2B05A]/50'
                      }`}
                    >
                      <div>
                        <div className="font-serif font-medium text-sm text-[#F2ECE1]">
                          {slot.commanderName} · Lv.{slot.level}
                        </div>
                        <div className="text-xs text-[#B5AC9A] mt-0.5 font-mono">
                          {slot.locationLabel || 'Gloamrest'} · {slot.saveDate}
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onLoadSavedSlot) onLoadSavedSlot(slot);
                          }}
                          className="px-3 py-1 bg-[#E2B05A] text-[#111613] font-mono text-xs uppercase font-semibold rounded hover:bg-[#c99a4a]"
                        >
                          Load
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            const next = saveSlots.filter((s) => s.id !== slot.id);
                            setSaveSlots(next);
                            persistSavedSlots(next);
                          }}
                          className="px-2 py-1 border border-[#5A4B38] text-[#B85349] font-mono text-xs rounded hover:border-[#B85349]"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. SETTINGS MODAL                                                         */}
      {/* ========================================================================= */}
      {currentScreen === 'settings' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center p-8 bg-[#111613]/90">
          <div className="w-full max-w-2xl bg-[rgba(22,28,24,0.96)] border border-[#5A4B38] rounded p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#5A4B38]/60 pb-3">
              <h2 className="text-lg font-serif text-[#F2ECE1] uppercase tracking-wider">
                System Settings
              </h2>
              <button
                type="button"
                onClick={() => navigateToScreen('main_menu')}
                className="text-xs font-mono text-[#B5AC9A] hover:text-[#E2B05A]"
              >
                Close [ESC]
              </button>
            </div>

            <div className="flex space-x-2 border-b border-[#5A4B38]/50 pb-2">
              {(['Graphics', 'Audio', 'Controls', 'Gameplay'] as SettingsTabId[]).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setActiveSettingsTab(tab)}
                  className={`px-3 py-1 text-xs font-mono uppercase tracking-wider rounded ${
                    activeSettingsTab === tab
                      ? 'bg-[#E2B05A] text-[#111613] font-semibold'
                      : 'text-[#B5AC9A] hover:bg-[#202922]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="space-y-4 py-2">
              {activeSettingsTab === 'Graphics' && (
                <div className="space-y-3 text-xs">
                  <div className="flex justify-between items-center">
                    <span>Ambient Dust Particles</span>
                    <input
                      type="checkbox"
                      checked={settings.graphics.ambientParticles}
                      onChange={(e) =>
                        setSettings((prev) => ({
                          ...prev,
                          graphics: { ...prev.graphics, ambientParticles: e.target.checked },
                        }))
                      }
                      className="accent-[#E2B05A]"
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Show Live FPS Overlay</span>
                    <input
                      type="checkbox"
                      checked={settings.graphics.showFpsCounter}
                      onChange={(e) =>
                        setSettings((prev) => ({
                          ...prev,
                          graphics: { ...prev.graphics, showFpsCounter: e.target.checked },
                        }))
                      }
                      className="accent-[#E2B05A]"
                    />
                  </div>
                </div>
              )}

              {activeSettingsTab === 'Audio' && (
                <div className="space-y-3 text-xs">
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span>Master Volume</span>
                      <span className="font-mono text-[#E2B05A]">{settings.audio.masterVolume}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={settings.audio.masterVolume}
                      onChange={(e) =>
                        setSettings((prev) => ({
                          ...prev,
                          audio: { ...prev.audio, masterVolume: parseInt(e.target.value, 10) },
                        }))
                      }
                      className="w-full accent-[#E2B05A] bg-[#111613] h-1.5 rounded cursor-pointer"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-[#5A4B38]/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  try {
                    window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
                  } catch {
                    // Ignore
                  }
                  navigateToScreen('main_menu');
                }}
                className="px-5 py-2 bg-[#E2B05A] text-[#111613] font-mono text-xs uppercase font-semibold rounded hover:bg-[#c99a4a]"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. CREDITS MODAL                                                          */}
      {/* ========================================================================= */}
      {currentScreen === 'credits' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center p-8 bg-[#111613]/90">
          <div className="w-full max-w-xl bg-[rgba(22,28,24,0.96)] border border-[#5A4B38] rounded p-6 space-y-4 text-center shadow-2xl">
            <h2 className="text-xl font-serif text-[#F2ECE1] uppercase tracking-widest">
              Dimraeth: The Shattered Oath
            </h2>
            <div className="w-16 h-px bg-[#5A4B38] mx-auto" />
            <p className="text-xs text-[#B5AC9A] leading-relaxed">
              Developed by the Dimraeth Core Team.
              <br />
              Inspired by the depth and majesty of classical tactical fantasy RPGs.
            </p>
            <button
              type="button"
              onClick={() => navigateToScreen('main_menu')}
              className="mt-4 px-6 py-2 border border-[#5A4B38] text-xs font-mono text-[#E2B05A] rounded hover:border-[#E2B05A]"
            >
              Back to Menu
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. EXIT GAME CONFIRMATION MODAL                                           */}
      {/* ========================================================================= */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-[rgba(22,28,24,0.98)] border border-[#5A4B38] rounded p-5 space-y-4 text-center shadow-2xl">
            <h3 className="text-sm font-serif text-[#F2ECE1] uppercase tracking-wider">
              Exit Dimraeth
            </h3>
            <p className="text-xs text-[#B5AC9A]">
              Are you certain you wish to depart from the shattered realm?
            </p>
            <div className="flex justify-center space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setShowExitConfirm(false)}
                className="px-4 py-1.5 border border-[#5A4B38] text-xs font-mono text-[#B5AC9A] rounded hover:text-[#F2ECE1]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowExitConfirm(false);
                  window.close();
                }}
                className="px-4 py-1.5 bg-[#B85349] text-white text-xs font-mono rounded hover:bg-[#a1443b]"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
