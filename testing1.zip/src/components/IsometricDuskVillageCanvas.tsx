import React, { useEffect, useRef } from 'react';

interface IsometricDuskVillageCanvasProps {
  enableParticles?: boolean;
  reducedMotion?: boolean;
}

interface FallingLeaf {
  x: number;
  y: number;
  vx: number;
  vy: number;
  phase: number;
  color: string;
}

interface FogBand {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  alpha: number;
}

interface ChimneyPuff {
  x: number;
  y: number;
  age: number;
  maxAge: number;
}

/**
 * Renders a 2D pixel-art isometric fantasy village at dusk (320x180 native pixel canvas)
 * with warm glowing windows, distant mountains & pine forest, twilight sky,
 * drifting fog, chimney smoke, and falling leaves.
 */
export const IsometricDuskVillageCanvas: React.FC<IsometricDuskVillageCanvasProps> = ({
  enableParticles = true,
  reducedMotion = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 320;
    const H = 180;
    canvas.width = W;
    canvas.height = H;
    ctx.imageSmoothingEnabled = false;

    // Deterministic stars in upper twilight sky
    const stars = [
      { x: 28, y: 14, phase: 0.2 },
      { x: 64, y: 9, phase: 1.4 },
      { x: 105, y: 18, phase: 2.1 },
      { x: 148, y: 11, phase: 0.8 },
      { x: 192, y: 16, phase: 3.0 },
      { x: 236, y: 8, phase: 1.9 },
      { x: 274, y: 15, phase: 2.7 },
      { x: 302, y: 10, phase: 0.5 },
      { x: 170, y: 24, phase: 1.1 },
      { x: 255, y: 22, phase: 2.4 },
    ];

    // Falling leaves
    const leafColors = ['#9c6b3b', '#b88446', '#7d5233', '#6b7d57'];
    const leaves: FallingLeaf[] = Array.from({ length: 16 }, (_, i) => ({
      x: (i * 23) % W,
      y: (i * 17) % H,
      vx: -0.18 - (i % 3) * 0.05,
      vy: 0.22 + (i % 4) * 0.04,
      phase: i * 0.7,
      color: leafColors[i % leafColors.length],
    }));

    // Drifting fog bands
    const fogBands: FogBand[] = [
      { x: 10, y: 86, width: 96, height: 6, speed: 0.08, alpha: 0.14 },
      { x: 140, y: 94, width: 120, height: 7, speed: 0.06, alpha: 0.16 },
      { x: 70, y: 132, width: 110, height: 8, speed: 0.1, alpha: 0.12 },
      { x: 200, y: 146, width: 105, height: 7, speed: 0.07, alpha: 0.15 },
    ];

    // Chimney smoke puffs
    const puffs: ChimneyPuff[] = Array.from({ length: 6 }, (_, i) => ({
      x: 211,
      y: 74 - i * 6,
      age: i * 20,
      maxAge: 120,
    }));

    // Helper: draw crisp pixel-art isometric diamond tile
    const drawIsoTile = (
      cx: number,
      cy: number,
      halfW: number,
      halfH: number,
      fill: string,
      border?: string
    ) => {
      ctx.fillStyle = fill;
      for (let dy = -halfH; dy <= halfH; dy++) {
        const span = Math.round((1 - Math.abs(dy) / halfH) * halfW);
        ctx.fillRect(Math.round(cx - span), Math.round(cy + dy), span * 2, 1);
      }
      if (border) {
        ctx.fillStyle = border;
        ctx.fillRect(Math.round(cx - halfW), Math.round(cy), 1, 1);
        ctx.fillRect(Math.round(cx + halfW - 1), Math.round(cy), 1, 1);
      }
    };

    // Helper: draw isometric cottage building
    const drawIsometricCottage = (
      bx: number,
      by: number,
      w: number,
      d: number,
      wallH: number,
      roofH: number,
      flicker: number,
      hasChimney: boolean
    ) => {
      // Ground shadow
      ctx.fillStyle = 'rgba(10, 13, 12, 0.45)';
      ctx.fillRect(bx - w - 3, by + 1, (w + d) + 6, Math.round((w + d) / 2) + 3);

      // Left wall (warm shadowed stone & timber)
      ctx.fillStyle = '#33312d';
      for (let x = 0; x < w; x++) {
        const yOff = Math.floor(x / 2);
        ctx.fillRect(bx - w + x, by - wallH + yOff, 1, wallH + Math.floor(w / 2) - yOff);
      }

      // Right wall (slightly darker dusk-facing wall)
      ctx.fillStyle = '#272623';
      for (let x = 0; x < d; x++) {
        const yOff = Math.floor(x / 2);
        ctx.fillRect(bx + x, by - wallH + Math.floor(w / 2) - yOff, 1, wallH + yOff);
      }

      // Timber framing beams
      ctx.fillStyle = '#1e1b18';
      ctx.fillRect(bx - w, by - wallH, 1, wallH);
      ctx.fillRect(bx, by - wallH + Math.floor(w / 2), 1, wallH);
      ctx.fillRect(bx + d - 1, by - wallH + Math.floor(w / 2) - Math.floor(d / 2), 1, wallH);

      // Pitched Roof (Left slope & Right overhang)
      for (let ry = 0; ry < roofH; ry++) {
        const inset = Math.floor((ry / roofH) * (w * 0.65));
        ctx.fillStyle = ry % 3 === 0 ? '#2a3338' : '#323c42';
        ctx.fillRect(
          bx - w - 2 + inset,
          by - wallH - ry,
          w + 3 - inset,
          2
        );
        ctx.fillStyle = '#20272b';
        ctx.fillRect(
          bx,
          by - wallH + Math.floor(w / 2) - ry - 2,
          d + 2 - Math.floor(inset * 0.6),
          2
        );
      }

      // Chimney
      if (hasChimney) {
        ctx.fillStyle = '#3a3532';
        ctx.fillRect(bx - 5, by - wallH - roofH - 4, 4, 7);
        ctx.fillStyle = '#262220';
        ctx.fillRect(bx - 5, by - wallH - roofH - 4, 4, 1);
      }

      // Glowing windows on left & right walls
      const winCore = flicker > 0.5 ? '#f3c66f' : '#e6b156';
      const winEdge = '#b87632';

      // Left wall windows
      const lwX = bx - Math.floor(w * 0.65);
      const lwY = by - Math.floor(wallH * 0.55);
      ctx.fillStyle = 'rgba(232, 168, 76, 0.16)';
      ctx.fillRect(lwX - 2, lwY - 2, 8, 9);
      ctx.fillStyle = winEdge;
      ctx.fillRect(lwX, lwY, 4, 5);
      ctx.fillStyle = winCore;
      ctx.fillRect(lwX + 1, lwY + 1, 2, 3);

      // Second window on wider cottages
      if (w >= 24) {
        const lwX2 = bx - Math.floor(w * 0.3);
        const lwY2 = lwY + 3;
        ctx.fillStyle = 'rgba(232, 168, 76, 0.15)';
        ctx.fillRect(lwX2 - 2, lwY2 - 2, 8, 9);
        ctx.fillStyle = winEdge;
        ctx.fillRect(lwX2, lwY2, 4, 5);
        ctx.fillStyle = winCore;
        ctx.fillRect(lwX2 + 1, lwY2 + 1, 2, 3);
      }

      // Right wall window
      const rwX = bx + Math.floor(d * 0.42);
      const rwY = by - Math.floor(wallH * 0.48);
      ctx.fillStyle = 'rgba(232, 168, 76, 0.14)';
      ctx.fillRect(rwX - 2, rwY - 2, 7, 8);
      ctx.fillStyle = winEdge;
      ctx.fillRect(rwX, rwY, 3, 4);
      ctx.fillStyle = winCore;
      ctx.fillRect(rwX + 1, rwY + 1, 1, 2);
    };

    // Helper: draw pixel pine/oak tree
    const drawTree = (tx: number, ty: number, scale: number, shade: string, highlight: string) => {
      // Trunk
      ctx.fillStyle = '#29211c';
      ctx.fillRect(tx - 1, ty - 4, 2, 5);
      // Layered foliage
      const tiers = 3;
      for (let t = 0; t < tiers; t++) {
        const radius = Math.max(2, Math.round((tiers - t) * 2.5 * scale));
        const cy = ty - 5 - t * Math.round(3.5 * scale);
        ctx.fillStyle = shade;
        ctx.fillRect(tx - radius, cy, radius * 2, Math.round(3 * scale));
        ctx.fillStyle = highlight;
        ctx.fillRect(tx - radius + 1, cy - 1, Math.max(1, radius), 2);
      }
    };

    let animId = 0;
    let lastTime = performance.now();
    let elapsedSeconds = 0;

    const render = () => {
      const now = performance.now();
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;
      elapsedSeconds += dt;
      // Normalizes tick to a consistent 60fps baseline regardless of 60Hz-360Hz refresh rate
      const dtScale = dt * 60;
      const tick = elapsedSeconds * 60 * (reducedMotion ? 0.2 : 1);

      // 1. TWILIGHT / DUSK SKY BANDS (Warm muted fantasy sunset)
      const skyBands = [
        { y: 0, h: 18, color: '#141920' },
        { y: 18, h: 16, color: '#1b222b' },
        { y: 34, h: 14, color: '#262b36' },
        { y: 48, h: 12, color: '#37343e' },
        { y: 60, h: 10, color: '#4d3d42' },
        { y: 70, h: 10, color: '#644843' },
        { y: 80, h: 8, color: '#785546' },
      ];
      for (const band of skyBands) {
        ctx.fillStyle = band.color;
        ctx.fillRect(0, band.y, W, band.h);
      }

      // Warm dusk horizon glow on the right-center valley
      ctx.fillStyle = 'rgba(214, 148, 86, 0.14)';
      ctx.fillRect(145, 58, 150, 22);
      ctx.fillStyle = 'rgba(230, 176, 104, 0.10)';
      ctx.fillRect(175, 64, 100, 14);

      // Subtle twilight stars
      for (const st of stars) {
        const twinkle = Math.sin(tick * 0.03 + st.phase);
        ctx.fillStyle = twinkle > 0.2 ? '#d8d0c0' : '#7f7c78';
        ctx.fillRect(st.x, st.y, 1, 1);
      }

      // 2. DISTANT MOUNTAINS (Layered pixel silhouettes)
      const farPeaks = [
        { x: 0, h: 28 },
        { x: 35, h: 38 },
        { x: 78, h: 26 },
        { x: 120, h: 42 },
        { x: 168, h: 31 },
        { x: 215, h: 46 },
        { x: 268, h: 35 },
        { x: 310, h: 25 },
      ];
      ctx.fillStyle = '#20262c';
      for (let x = 0; x < W; x++) {
        const seg = Math.floor(x / 45);
        const p1 = farPeaks[seg % farPeaks.length];
        const p2 = farPeaks[(seg + 1) % farPeaks.length];
        const t = (x % 45) / 45;
        const mh = Math.round(p1.h * (1 - t) + p2.h * t);
        ctx.fillRect(x, 84 - mh, 1, mh + 6);
      }

      // Closer mountain ridge
      ctx.fillStyle = '#192022';
      for (let x = 0; x < W; x++) {
        const ridgeH = Math.round(
          16 + Math.sin(x * 0.045) * 7 + Math.cos(x * 0.02) * 5
        );
        ctx.fillRect(x, 88 - ridgeH, 1, ridgeH + 6);
      }

      // 3. ISOMETRIC FANTASY VALLEY & VILLAGE GROUNDS
      ctx.fillStyle = '#18201c';
      ctx.fillRect(0, 86, W, H - 86);

      // Isometric terraced grass & mossy stone tiles
      for (let gx = 0; gx < 14; gx++) {
        for (let gz = 0; gz < 10; gz++) {
          const isoX = 175 + (gx - gz) * 14;
          const isoY = 88 + (gx + gz) * 7;
          const isPath =
            (gz === 4 && gx >= 2 && gx <= 10) ||
            (gx === 6 && gz >= 2 && gz <= 8);
          const tileFill = isPath
            ? (gx + gz) % 2 === 0
              ? '#3b3831'
              : '#33302a'
            : (gx + gz) % 2 === 0
            ? '#1d2721'
            : '#1a231e';
          drawIsoTile(isoX, isoY, 14, 7, tileFill);
        }
      }

      // Distant pine forest line along the ridge
      for (let i = 0; i < 24; i++) {
        const tx = 12 + i * 13;
        const ty = 87 + (i % 3) * 2;
        drawTree(tx, ty, 0.9, '#151e1a', '#1f2b25');
      }

      // 4. MEDIEVAL HOMESTEAD BUILDINGS (Right-center composition to balance left-center menu)
      const flickerA = 0.5 + 0.5 * Math.sin(tick * 0.06);
      const flickerB = 0.5 + 0.5 * Math.cos(tick * 0.045 + 1.2);

      // Back cottage (granary / watch house)
      drawIsometricCottage(242, 108, 20, 16, 15, 11, flickerB, false);

      // Main homestead inn / cottage with chimney
      drawIsometricCottage(215, 124, 28, 20, 18, 13, flickerA, true);

      // Lower workshop / smithy cottage
      drawIsometricCottage(262, 136, 22, 16, 15, 10, flickerB, false);

      // Warm ground light spills outside cottage windows & doorway
      ctx.fillStyle = 'rgba(226, 176, 90, 0.14)';
      drawIsoTile(196, 132, 12, 6, 'rgba(226, 176, 90, 0.14)');
      drawIsoTile(248, 142, 10, 5, 'rgba(226, 176, 90, 0.11)');

      // Village lantern post along stone path
      const lanternX = 180;
      const lanternY = 136;
      ctx.fillStyle = '#2d2823';
      ctx.fillRect(lanternX, lanternY - 11, 2, 11);
      ctx.fillRect(lanternX - 1, lanternY - 11, 4, 1);
      // Warm flickering lantern glow
      ctx.fillStyle = 'rgba(232, 176, 88, 0.18)';
      ctx.fillRect(lanternX - 6, lanternY - 15, 12, 12);
      ctx.fillStyle = flickerA > 0.35 ? '#f5cb78' : '#dfa84e';
      ctx.fillRect(lanternX - 2, lanternY - 10, 2, 2);

      // Foreground trees framing the village
      drawTree(146, 124, 1.15, '#16201b', '#223028');
      drawTree(160, 150, 1.25, '#141d18', '#1f2c24');
      drawTree(292, 126, 1.2, '#141d18', '#202d25');
      drawTree(304, 152, 1.35, '#121a16', '#1c2821');

      // 5. CHIMNEY SMOKE PUFFS
      if (enableParticles) {
        ctx.fillStyle = 'rgba(185, 180, 170, 0.18)';
        for (const puff of puffs) {
          if (!reducedMotion) {
            puff.age += 0.45;
            if (puff.age >= puff.maxAge) {
              puff.age = 0;
            }
          }
          const progress = puff.age / puff.maxAge;
          const px = Math.round(210 + progress * 12 + Math.sin(progress * 5) * 2);
          const py = Math.round(92 - progress * 26);
          const sz = progress < 0.5 ? 2 : 3;
          ctx.fillRect(px, py, sz, sz);
        }
      }

      // 6. DRIFTING FOG BANDS
      for (const fog of fogBands) {
        if (!reducedMotion) {
          fog.x += fog.speed * dtScale;
          if (fog.x > W + 20) fog.x = -fog.width - 10;
        }
        ctx.fillStyle = `rgba(176, 188, 178, ${fog.alpha})`;
        ctx.fillRect(Math.round(fog.x), fog.y, fog.width, fog.height);
        ctx.fillRect(Math.round(fog.x + 8), fog.y - 2, fog.width - 16, 2);
      }

      // 7. FALLING DUSK LEAVES
      if (enableParticles) {
        for (const leaf of leaves) {
          if (!reducedMotion) {
            leaf.x += (leaf.vx + Math.sin(tick * 0.03 + leaf.phase) * 0.08) * dtScale;
            leaf.y += leaf.vy * dtScale;
            if (leaf.x < -4) leaf.x = W + 2;
            if (leaf.y > H + 4) {
              leaf.y = -2;
              leaf.x = (leaf.x + 67) % W;
            }
          }
          ctx.fillStyle = leaf.color;
          ctx.fillRect(Math.round(leaf.x), Math.round(leaf.y), 2, 1);
        }
      }

      animId = window.requestAnimationFrame(render);
    };

    render();
    return () => window.cancelAnimationFrame(animId);
  }, [enableParticles, reducedMotion]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      data-testid="pixel-village-background"
      className="fixed inset-0 w-full h-full object-cover pointer-events-none"
      style={{ imageRendering: 'pixelated' }}
    />
  );
};
