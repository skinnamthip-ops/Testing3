import React, { useState, useEffect } from 'react';
import {
  performanceManager,
  PerformanceMetrics,
  TargetFpsMode,
  TARGET_FPS_OPTIONS,
} from '../game/performanceManager';

export const PerformanceOverlay: React.FC = () => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>(() =>
    performanceManager.getCurrentMetrics()
  );
  const [visible, setVisible] = useState<boolean>(() =>
    performanceManager.isHudVisible()
  );
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  useEffect(() => {
    const unsubMetrics = performanceManager.subscribe((newMetrics) => {
      setMetrics(newMetrics);
    });
    const unsubVis = performanceManager.subscribeVisibility((newVis) => {
      setVisible(newVis);
    });

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F3' && !e.ctrlKey && !e.altKey && !e.metaKey) {
        e.preventDefault();
        performanceManager.toggleHudVisible();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      unsubMetrics();
      unsubVis();
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  if (!visible) return null;

  const isSmooth = metrics.onePercentLowFps >= (metrics.currentFps * 0.85);
  const dotColor =
    metrics.currentFps >= 200
      ? '#38BDF8'
      : isSmooth
      ? '#4ADE80'
      : '#F59E0B';

  return (
    <div
      role="region"
      aria-label="Performance HUD"
      data-testid="performance-hud-overlay"
      style={{
        position: 'fixed',
        top: '12px',
        right: '12px',
        zIndex: 9999,
        pointerEvents: 'auto',
        fontFamily: 'JetBrains Mono, monospace',
        userSelect: 'none',
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(23, 27, 25, 0.92)',
          border: '1px solid #5A4B38',
          borderRadius: '6px',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.75), inset 0 0 16px rgba(226, 176, 90, 0.05)',
          backdropFilter: 'blur(6px)',
          padding: '6px 12px',
          display: 'flex',
          flexDirection: 'column',
          gap: '6px',
          minWidth: '180px',
        }}
      >
        {/* Main Bar: Live FPS, Frame Time & Toggle Button */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '10px',
            cursor: 'pointer',
          }}
          onClick={() => setIsExpanded(!isExpanded)}
          title="Click to change Target FPS [Hotkey: F3]"
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span
              style={{
                width: '7px',
                height: '7px',
                borderRadius: '50%',
                backgroundColor: dotColor,
                display: 'inline-block',
                boxShadow: `0 0 6px ${dotColor}`,
              }}
            />
            <span
              style={{
                fontSize: '13px',
                fontWeight: 700,
                color: '#F2ECE1',
                letterSpacing: '0.5px',
              }}
            >
              {metrics.currentFps}{' '}
              <span style={{ fontSize: '10px', color: '#B5AC9A', fontWeight: 400 }}>FPS</span>
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span
              style={{
                fontSize: '11px',
                color: '#E2B05A',
                fontWeight: 600,
              }}
            >
              {metrics.frameTimeMs.toFixed(1)}ms
            </span>
            <span
              style={{
                fontSize: '9px',
                color: '#77796F',
                transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)',
                transition: 'transform 0.15s ease',
              }}
            >
              ▼
            </span>
          </div>
        </div>

        {/* Expanded Mode: VRR Details & Target FPS Switcher */}
        {isExpanded && (
          <div
            style={{
              paddingTop: '6px',
              borderTop: '1px solid #3A3324',
              display: 'flex',
              flexDirection: 'column',
              gap: '6px',
              fontSize: '10px',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', color: '#B5AC9A' }}>
              <span>1% Low:</span>
              <span style={{ color: '#F2ECE1', fontWeight: 600 }}>{metrics.onePercentLowFps} FPS</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', color: '#B5AC9A' }}>
              <span>Refresh Mode:</span>
              <span style={{ color: '#38BDF8', fontWeight: 600 }}>{metrics.smoothnessRating}</span>
            </div>

            <div style={{ marginTop: '4px' }}>
              <div
                style={{
                  fontSize: '9px',
                  color: '#E2B05A',
                  letterSpacing: '0.8px',
                  fontWeight: 700,
                  marginBottom: '4px',
                }}
              >
                TARGET FRAME RATE:
              </div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '4px',
                }}
              >
                {TARGET_FPS_OPTIONS.map((opt) => {
                  const isSelected = metrics.targetMode === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        performanceManager.setTargetMode(opt.id);
                      }}
                      style={{
                        padding: '3px 4px',
                        backgroundColor: isSelected ? '#3A3324' : '#1C211E',
                        border: isSelected ? '1px solid #E2B05A' : '1px solid #3A3324',
                        borderRadius: '3px',
                        color: isSelected ? '#F59E0B' : '#B5AC9A',
                        fontSize: '9px',
                        fontWeight: isSelected ? 700 : 500,
                        cursor: 'pointer',
                        textAlign: 'center',
                      }}
                      title={opt.desc}
                    >
                      {opt.id === 'native' ? 'VRR' : opt.id.toUpperCase()}
                    </button>
                  );
                })}
              </div>
            </div>

            <div
              style={{
                fontSize: '8.5px',
                color: '#77796F',
                textAlign: 'center',
                marginTop: '2px',
              }}
            >
              Toggle overlay anytime with [F3]
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
