import React, { useMemo, useState } from 'react';
import {
  Ability,
  CharacterCreationBuild,
  CombatUnit,
  CompanionId,
  CompanionRelationship,
  GridTile,
  TacticalEnvObject,
  WorldReactivityState,
} from '../game/rules';
import {
  buildSkillDetailViewModel,
  getUnitClassIdentity,
  getUnitSkillCatalog,
  SkillSlotVisualState,
} from '../game/skillSystemUi';
import {
  CharacterPortraitSvg,
  StatusEffectChipWithTooltip,
  StatusEffectIconSvg,
} from './PortraitsAndIcons';
import { SkillIconSvg } from './SkillIcons';
import { SkillTooltipAnchor } from './SkillTooltip';

interface CombatSkillBarProps {
  activeUnit: CombatUnit;
  allUnits: CombatUnit[];
  grid: GridTile[][];
  envObjects: TacticalEnvObject[];
  relationships: Record<CompanionId, CompanionRelationship>;
  worldState: WorldReactivityState;
  characterBuild: CharacterCreationBuild;
  ghostHpPct: number;
  selectedAbilityKey: '1' | '2' | '3' | '4' | null;
  isSkillMenuOpen: boolean;
  onSelectAbilityKey: (key: '1' | '2' | '3' | '4' | null) => void;
  onUnavailableFeedback: (reason: string) => void;
  onToggleSkillMenu: () => void;
  onEndTurn: () => void;
}

const HeartStatIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" className="w-3.5 h-3.5 shrink-0" aria-hidden="true">
    <path
      d="M8 13.8L6.9 12.8C3.2 9.5 1.2 7.6 1.2 5.1C1.2 3.1 2.8 1.6 4.7 1.6C5.9 1.6 7 2.2 8 3.2C9 2.2 10.1 1.6 11.3 1.6C13.2 1.6 14.8 3.1 14.8 5.1C14.8 7.6 12.8 9.5 9.1 12.8L8 13.8Z"
      fill="#7E9C82"
    />
  </svg>
);

const ShieldStatIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" className="w-3.5 h-3.5 shrink-0" aria-hidden="true">
    <path
      d="M8 1.5L13.5 3.4V7.6C13.5 11 11.1 13.5 8 14.6C4.9 13.5 2.5 11 2.5 7.6V3.4L8 1.5Z"
      fill="#292E29"
      stroke="#B5AC9A"
      strokeWidth="1.5"
    />
  </svg>
);

const ApDiamondIcon: React.FC<{ filled?: boolean; danger?: boolean }> = ({
  filled = true,
  danger = false,
}) => (
  <svg viewBox="0 0 14 14" className="w-3 h-3 shrink-0" aria-hidden="true">
    <polygon
      points="7,1.2 12.8,7 7,12.8 1.2,7"
      fill={danger ? '#B85349' : filled ? '#E2B05A' : '#171B19'}
      stroke={danger ? '#E58B82' : filled ? '#F2ECE1' : '#5A4B38'}
      strokeWidth="1.3"
    />
  </svg>
);

const SkillBookIcon: React.FC<{ highlighted?: boolean }> = ({ highlighted = false }) => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0" aria-hidden="true">
    <path
      d="M4 5.5C4 4.4 4.9 3.5 6 3.5H11.5V19.5H6C4.9 19.5 4 20.2 4 21V5.5Z"
      fill={highlighted ? '#3A3324' : '#222722'}
      stroke="#E2B05A"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <path
      d="M20 5.5C20 4.4 19.1 3.5 18 3.5H12.5V19.5H18C19.1 19.5 20 20.2 20 21V5.5Z"
      fill={highlighted ? '#3A3324' : '#222722'}
      stroke="#E2B05A"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <polygon points="8,8 9.6,10.8 8,13.6 6.4,10.8" fill="#E2B05A" />
    <line x1="14.5" y1="8.5" x2="17.8" y2="8.5" stroke="#B5AC9A" strokeWidth="1.4" />
    <line x1="14.5" y1="12" x2="17.8" y2="12" stroke="#B5AC9A" strokeWidth="1.4" />
  </svg>
);

const LockBadgeIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" className="w-3.5 h-3.5 shrink-0" aria-hidden="true">
    <rect x="3.5" y="7" width="9" height="6.8" rx="1.2" fill="#222722" stroke="#B5AC9A" strokeWidth="1.3" />
    <path d="M5.5 7V5.2C5.5 3.8 6.6 2.7 8 2.7C9.4 2.7 10.5 3.8 10.5 5.2V7" stroke="#B5AC9A" strokeWidth="1.3" fill="none" />
  </svg>
);

export const CombatSkillBar: React.FC<CombatSkillBarProps> = ({
  activeUnit,
  allUnits,
  grid,
  envObjects,
  relationships,
  worldState,
  characterBuild,
  ghostHpPct,
  selectedAbilityKey,
  isSkillMenuOpen,
  onSelectAbilityKey,
  onUnavailableFeedback,
  onToggleSkillMenu,
  onEndTurn,
}) => {
  const [nudgedSlotKey, setNudgedSlotKey] = useState<string | null>(null);
  const [activatedSlotKey, setActivatedSlotKey] = useState<string | null>(null);

  const identity = useMemo(
    () => getUnitClassIdentity(activeUnit, characterBuild),
    [activeUnit, characterBuild]
  );

  const catalog = useMemo(
    () => getUnitSkillCatalog(activeUnit, worldState, characterBuild),
    [activeUnit, worldState, characterBuild]
  );

  const slotDetails = useMemo(() => {
    const orderedKeys: ('1' | '2' | '3' | '4')[] = ['1', '2', '3', '4'];
    return orderedKeys
      .map((slotKey) => {
        const ab: Ability | undefined = activeUnit.abilities.find((a) => a.key === slotKey);
        if (!ab) return null;
        const catEntry =
          catalog.find((c) => c.ability.id === ab.id) ?? {
            ability: ab,
            classId: identity.classId,
            className: identity.className,
            primaryCategoryLabel: 'Attack' as const,
            specialtyLabel: ab.roleClue,
            categories: ['all' as const, 'equipped' as const],
            equippedSlotKey: slotKey,
            isLocked: false,
          };
        return {
          slotKey,
          detail: buildSkillDetailViewModel(
            activeUnit,
            catEntry,
            allUnits,
            relationships,
            worldState,
            grid,
            envObjects,
            selectedAbilityKey
          ),
        };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null);
  }, [
    activeUnit,
    catalog,
    identity,
    allUnits,
    relationships,
    worldState,
    grid,
    envObjects,
    selectedAbilityKey,
  ]);

  // Effective AC factoring active Warded (+2) and Sundered (-2)
  const effectiveAc =
    activeUnit.armorClass +
    (activeUnit.statuses.some((s) => s.type === 'warded') ? 2 : 0) -
    (activeUnit.statuses.some((s) => s.type === 'sundered') ? 2 : 0);

  const hpPct = Math.max(
    0,
    Math.min(100, Math.round((activeUnit.hp / Math.max(1, activeUnit.maxHp)) * 100))
  );

  const handleSlotClick = (
    slotKey: '1' | '2' | '3' | '4',
    state: SkillSlotVisualState,
    canSelect: boolean,
    reason: string | null
  ) => {
    if (!canSelect) {
      setNudgedSlotKey(slotKey);
      window.setTimeout(() => setNudgedSlotKey((cur) => (cur === slotKey ? null : cur)), 200);
      if (reason) onUnavailableFeedback(reason);
      return;
    }

    const nextKey = selectedAbilityKey === slotKey ? null : slotKey;
    if (nextKey !== null) {
      setActivatedSlotKey(slotKey);
      window.setTimeout(() => setActivatedSlotKey((cur) => (cur === slotKey ? null : cur)), 230);
      if (state === 'out_of_range' && reason) {
        onUnavailableFeedback(reason);
      }
    }
    onSelectAbilityKey(nextKey);
  };

  return (
    <section
      aria-label="Combat Tactical Skill Bar"
      data-testid="combat-skill-bar"
      style={{
        backgroundColor: '#171B19',
        borderColor: '#5A4B38',
      }}
      className="pointer-events-auto rounded-lg border px-3.5 py-2.5 shadow-[0_14px_38px_rgba(0,0,0,0.86)] flex flex-col lg:flex-row items-center gap-3 lg:gap-3.5 max-w-full"
    >
      {/* ==================== LEFT: CHARACTER STATUS PANEL ==================== */}
      <div
        data-testid="skillbar-character-status"
        style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
        className="w-full lg:w-[278px] rounded-md border px-2.5 py-2 flex items-center gap-2.5 shrink-0"
      >
        <div className="relative shrink-0" data-testid="active-unit-portrait">
          <CharacterPortraitSvg
            id={activeUnit.companionId ?? activeUnit.archetype ?? 'inquisitor'}
            className="w-[52px] h-[52px] rounded border border-[#5A4B38] shrink-0"
          />
          {activeUnit.statuses.length > 0 && (
            <div
              data-testid="active-portrait-status-icons"
              style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
              className="absolute -bottom-1 -right-1 flex items-center gap-0.5 px-1 py-0.5 rounded border shadow"
            >
              {activeUnit.statuses.map((s, sIdx) => (
                <StatusEffectIconSvg
                  key={`${s.type}-${sIdx}`}
                  type={s.type}
                  turnsLeft={s.turnsLeft}
                  tooltipPlacement="top"
                  testId={`active-portrait-status-icon-${s.type}`}
                  className="w-3.5 h-3.5"
                />
              ))}
            </div>
          )}
        </div>

        <div className="min-w-0 flex-1 space-y-1">
          {/* Name & Class/Subclass */}
          <div className="leading-tight">
            <p
              data-testid="skillbar-character-name"
              style={{ color: '#F2ECE1' }}
              className="font-display font-bold text-[13px] tracking-wide uppercase truncate"
            >
              {activeUnit.name}
            </p>
            <p
              data-testid="skillbar-character-lineage"
              style={{ color: '#B5AC9A' }}
              className="text-[11px] truncate"
            >
              {activeUnit.faction === 'party'
                ? `${identity.shortClassName} — ${identity.shortSubclassName}`
                : activeUnit.title}
            </p>
          </div>

          {/* HP + Trailing Bar */}
          <div className="space-y-0.5">
            <div className="flex items-center justify-between gap-2 font-mono text-[11px] tabular-nums">
              <span className="inline-flex items-center gap-1" style={{ color: '#F2ECE1' }}>
                <HeartStatIcon />
                <span>
                  HP {Math.round(activeUnit.hp)} / {activeUnit.maxHp}
                </span>
                {activeUnit.tempHp > 0 && (
                  <span style={{ color: '#7E9C82' }}>(+{activeUnit.tempHp})</span>
                )}
              </span>

              <span
                className="inline-flex items-center gap-1"
                style={{ color: '#B5AC9A' }}
                title="Effective Armor Class"
              >
                <ShieldStatIcon />
                <span>AC {effectiveAc}</span>
              </span>
            </div>

            <div
              className="relative w-full h-1.5 rounded-sm overflow-hidden border"
              style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
            >
              <div
                className="absolute inset-y-0 left-0 transition-all duration-300"
                style={{
                  width: `${ghostHpPct}%`,
                  backgroundColor: 'rgba(226, 176, 90, 0.42)',
                }}
              />
              <div
                className="relative h-full transition-all duration-150"
                style={{
                  width: `${hpPct}%`,
                  backgroundColor: activeUnit.faction === 'party' ? '#7E9C82' : '#B85349',
                }}
              />
            </div>
          </div>

          {/* Remaining AP + Active Buffs/Statuses */}
          <div className="flex flex-wrap items-center justify-between gap-1.5 pt-0.5">
            <div
              className="inline-flex items-center gap-1 font-mono text-[11px] tabular-nums"
              style={{ color: '#E2B05A' }}
              title="Remaining Action Points"
            >
              <span>
                AP {activeUnit.ap} / {activeUnit.maxAp}
              </span>
              <span className="inline-flex items-center gap-0.5 ml-0.5">
                {Array.from({ length: activeUnit.maxAp }).map((_, idx) => (
                  <ApDiamondIcon key={idx} filled={idx < activeUnit.ap} />
                ))}
              </span>
            </div>

            {activeUnit.statuses.length > 0 && (
              <div className="flex flex-wrap items-center gap-1">
                {activeUnit.statuses.slice(0, 2).map((s, sIdx) => (
                  <StatusEffectChipWithTooltip
                    key={`${s.type}-chip-${sIdx}`}
                    type={s.type}
                    turnsLeft={s.turnsLeft}
                    tooltipPlacement="top"
                    testId={`active-dock-status-${s.type}`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Ornamental Separator */}
      <div
        aria-hidden="true"
        className="hidden lg:flex flex-col items-center justify-center self-stretch py-1"
      >
        <div className="w-px flex-1 bg-[#5A4B38]/65" />
        <div className="w-1.5 h-1.5 rotate-45 border border-[#E2B05A]/75 my-1" />
        <div className="w-px flex-1 bg-[#5A4B38]/65" />
      </div>

      {/* ==================== CENTER: FOUR EQUIPPED SKILL SLOTS ==================== */}
      <div
        role="group"
        aria-label="Equipped Combat Abilities"
        className="grid grid-cols-2 sm:grid-cols-4 gap-2 shrink-0"
      >
        {slotDetails.map(({ slotKey, detail }) => {
          const { entry, slotEvaluation } = detail;
          const { ability } = entry;
          const { state, cooldownRemaining, canSelect, restrictionReason } = slotEvaluation;

          const isSelected = state === 'selected';
          const isInsufficientAp = state === 'insufficient_ap';
          const isCooldown = state === 'cooldown';
          const isLocked = state === 'locked';
          const isOutOfRange = state === 'out_of_range';
          const isDisabled = state === 'disabled';

          const bgHex = isSelected
            ? '#3A3324'
            : isInsufficientAp || isCooldown || isLocked || isDisabled
            ? '#1E221F'
            : '#292E29';

          const borderHex = isSelected
            ? '#E2B05A'
            : isOutOfRange
            ? '#B85349'
            : '#5A4B38';

          return (
            <SkillTooltipAnchor
              key={`${slotKey}-${ability.id}`}
              detail={detail}
              placement="top"
              delayMs={140}
            >
              <button
                type="button"
                data-testid={`ability-slot-${slotKey}`}
                data-slot-state={state}
                aria-pressed={isSelected}
                aria-disabled={!canSelect}
                onClick={() =>
                  handleSlotClick(slotKey, state, canSelect, restrictionReason)
                }
                style={{
                  backgroundColor: bgHex,
                  borderColor: borderHex,
                }}
                className={`relative w-[118px] h-[88px] rounded-md border px-2 py-1.5 flex flex-col items-center justify-between text-center transition-colors duration-125 ${
                  canSelect
                    ? 'cursor-pointer hover:border-[#E2B05A]'
                    : 'cursor-not-allowed'
                } ${nudgedSlotKey === slotKey ? 'dim-unavailable-nudge' : ''} ${
                  activatedSlotKey === slotKey ? 'dim-skill-activate-flash' : ''
                }`}
              >
                {/* Selected top golden diamond pip */}
                {isSelected && (
                  <span
                    aria-hidden="true"
                    style={{ backgroundColor: '#E2B05A', borderColor: '#171B19' }}
                    className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rotate-45 border"
                  />
                )}

                {/* Top Corner Row: Keyboard Shortcut [1..4] + Availability / Warning Indicator */}
                <div className="w-full flex items-center justify-between leading-none pointer-events-none">
                  <span
                    className="font-mono text-[10px] font-bold tabular-nums"
                    style={{ color: isSelected ? '#E2B05A' : '#B5AC9A' }}
                  >
                    [{slotKey}]
                  </span>

                  {isLocked ? (
                    <LockBadgeIcon />
                  ) : isOutOfRange ? (
                    <span
                      data-testid={`slot-range-warning-${slotKey}`}
                      title="No target currently in range"
                      style={{
                        backgroundColor: 'rgba(184, 83, 73, 0.24)',
                        borderColor: '#B85349',
                        color: '#E2B05A',
                      }}
                      className="font-mono text-[9px] font-bold px-1 py-0.5 rounded border leading-none"
                    >
                      RNG
                    </span>
                  ) : isCooldown ? (
                    <span
                      className="font-mono text-[10px] font-bold tabular-nums"
                      style={{ color: '#B85349' }}
                    >
                      {cooldownRemaining}T
                    </span>
                  ) : (
                    <span
                      aria-hidden="true"
                      style={{
                        backgroundColor: isSelected
                          ? '#E2B05A'
                          : state === 'available'
                          ? '#7E9C82'
                          : isInsufficientAp
                          ? '#B85349'
                          : '#77796F',
                      }}
                      className="w-1.5 h-1.5 rounded-full"
                    />
                  )}
                </div>

                {/* Primary Visual Focus: 44x44 Standalone Skill Icon */}
                <div className="relative w-[44px] h-[44px] rounded overflow-hidden border border-[#5A4B38]/80 shrink-0 -mt-1">
                  <SkillIconSvg
                    skillId={ability.id}
                    skillName={ability.name}
                    className={`w-full h-full transition-all duration-150 ${
                      isDisabled || isLocked
                        ? 'grayscale brightness-50'
                        : isCooldown || isInsufficientAp
                        ? 'brightness-45 saturate-50'
                        : 'brightness-100'
                    }`}
                  />

                  {/* Cooldown Dark Overlay + Remaining Turns */}
                  {isCooldown && (
                    <div
                      data-testid={`slot-cooldown-overlay-${slotKey}`}
                      style={{ backgroundColor: 'rgba(18, 21, 19, 0.78)' }}
                      className="absolute inset-0 flex items-center justify-center font-mono text-base font-bold tabular-nums text-[#F2ECE1]"
                    >
                      {cooldownRemaining}
                    </div>
                  )}

                  {/* Locked Overlay */}
                  {isLocked && (
                    <div
                      style={{ backgroundColor: 'rgba(18, 21, 19, 0.74)' }}
                      className="absolute inset-0 flex items-center justify-center"
                    >
                      <LockBadgeIcon />
                    </div>
                  )}
                </div>

                {/* Skill Name + Golden AP Cost */}
                <div className="w-full leading-none space-y-0.5">
                  <p
                    data-testid={`slot-skill-name-${slotKey}`}
                    style={{
                      color: isSelected
                        ? '#E2B05A'
                        : isDisabled || isLocked
                        ? '#77796F'
                        : '#F2ECE1',
                    }}
                    className="font-display font-semibold text-[10.5px] leading-[1.1] tracking-tight"
                  >
                    {ability.name}
                  </p>
                  <div className="inline-flex items-center justify-center gap-1 font-mono text-[10.5px] font-bold tabular-nums">
                    <ApDiamondIcon
                      filled={!isInsufficientAp}
                      danger={isInsufficientAp}
                    />
                    <span
                      style={{
                        color: isInsufficientAp
                          ? '#B85349'
                          : isDisabled || isLocked
                          ? '#77796F'
                          : '#E2B05A',
                      }}
                    >
                      {ability.apCost} AP
                    </span>
                  </div>
                </div>
              </button>
            </SkillTooltipAnchor>
          );
        })}
      </div>

      {/* Ornamental Separator */}
      <div
        aria-hidden="true"
        className="hidden lg:flex flex-col items-center justify-center self-stretch py-1"
      >
        <div className="w-px flex-1 bg-[#5A4B38]/65" />
        <div className="w-1.5 h-1.5 rotate-45 border border-[#E2B05A]/75 my-1" />
        <div className="w-px flex-1 bg-[#5A4B38]/65" />
      </div>

      {/* ==================== RIGHT: SKILL MENU [K] & END TURN [SPACE] ==================== */}
      <div className="flex sm:flex-row lg:flex-row items-center gap-2 shrink-0">
        {/* Dedicated SKILLS [K] Button */}
        <button
          type="button"
          data-testid="open-skill-menu-btn"
          aria-expanded={isSkillMenuOpen}
          onClick={onToggleSkillMenu}
          style={{
            backgroundColor: isSkillMenuOpen ? '#3A3324' : '#222722',
            borderColor: isSkillMenuOpen ? '#E2B05A' : '#5A4B38',
            color: isSkillMenuOpen ? '#E2B05A' : '#F2ECE1',
          }}
          className="h-[88px] w-[88px] rounded-md border px-2 py-2 flex flex-col items-center justify-between transition-colors duration-125 hover:border-[#E2B05A] cursor-pointer"
          title="Open Tactical Skill Tome [K] — Inspect, compare, and assign abilities without spending AP"
        >
          <span
            className="font-mono text-[10px] font-bold"
            style={{ color: isSkillMenuOpen ? '#E2B05A' : '#B5AC9A' }}
          >
            [K]
          </span>
          <SkillBookIcon highlighted={isSkillMenuOpen} />
          <span className="font-display font-bold text-[11px] tracking-wider uppercase">
            Skills
          </span>
        </button>

        {/* Restrained Dark-Fantasy End Turn CTA */}
        <button
          type="button"
          data-testid="end-turn-btn"
          disabled={activeUnit.faction !== 'party'}
          onClick={onEndTurn}
          style={{
            backgroundColor: activeUnit.faction === 'party' ? '#3A3324' : '#222722',
            borderColor: activeUnit.faction === 'party' ? '#E2B05A' : '#5A4B38',
            color: activeUnit.faction === 'party' ? '#F2ECE1' : '#77796F',
          }}
          className="h-[88px] w-[104px] rounded-md border px-2.5 py-2 flex flex-col items-center justify-between transition-colors duration-125 hover:bg-[#493F2B] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          <span
            className="font-mono text-[10px] font-semibold"
            style={{ color: '#B5AC9A' }}
          >
            [Space]
          </span>
          <svg
            viewBox="0 0 24 24"
            className="w-5 h-5 shrink-0"
            aria-hidden="true"
          >
            <polygon
              points="12,3 20,12 12,21 4,12"
              fill="none"
              stroke="#E2B05A"
              strokeWidth="1.6"
            />
            <polygon points="10,8.5 16,12 10,15.5" fill="#E2B05A" />
          </svg>
          <span
            className="font-display font-bold text-[11px] tracking-wider uppercase"
            style={{ color: activeUnit.faction === 'party' ? '#E2B05A' : '#77796F' }}
          >
            End Turn
          </span>
        </button>
      </div>
    </section>
  );
};
