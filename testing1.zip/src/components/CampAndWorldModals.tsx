import React, { useState } from 'react';
import {
  CompanionId,
  CompanionRelationship,
  WorldReactivityState,
  getRelationshipTier,
  getCompanionSynergyBonus,
  STAGES,
} from '../game/rules';
import { CharacterPortraitSvg } from './PortraitsAndIcons';
import { soundEngine } from '../game/audio';

interface CompanionCampModalProps {
  relationships: Record<CompanionId, CompanionRelationship>;
  onCampChoice: (
    companionId: CompanionId,
    convoId: string,
    approvalDelta: number,
    chronicleNote: string
  ) => void;
  onRestAndHealParty: () => void;
  onClose: () => void;
}

const CAMP_CONVERSATIONS: Record<
  CompanionId,
  {
    prompt: string;
    options: {
      id: string;
      label: string;
      delta: number;
      reply: string;
      chronicle: string;
    }[];
  }
> = {
  seraphina: {
    prompt:
      '“When I broke my oath to the Silver Covenant, I thought the Dawnlight would abandon me forever. Yet beside you at the Astral Spire, my blade burns brighter than it ever did in their cathedral.”',
    options: [
      {
        id: 'sera_honor',
        label: '“True oaths are sworn to the living, Seraphina—not to corrupt Prelates.”',
        delta: 16,
        reply:
          '“Thank you. For the first time since Dimraeth fell, my shield feels weightless. I will stand as your vanguard until the last star fades.”',
        chronicle: 'Swore an unspoken vigil with Seraphina Vane by the campfire.',
      },
      {
        id: 'sera_power',
        label: '“Use their betrayal as fuel. Let vengeance sharpen your strikes.”',
        delta: 10,
        reply:
          '“Righteous fury has its place. Let the Inquisitors tremble when they see our banner.”',
        chronicle: 'Stoked Seraphina’s righteous wrath against the Silver Covenant.',
      },
    ],
  },
  kaelen: {
    prompt:
      '“The Blood-Weave isn’t mere corruption—it’s the primordial language that bound the planes before the gods built their cages. Help me transcribe the Reliquary’s sigils, and no adversary will withstand us.”',
    options: [
      {
        id: 'kael_study',
        label: '“Share your notes with me, Kaelen. We’ll master the Astral harmonic together.”',
        delta: 18,
        reply:
          '“Ha! I knew you had the mind of a true Savant. Watch how our spells arc across the battlefield now!”',
        chronicle: 'Studied the forbidden Astral harmonics with Kaelen Vos.',
      },
      {
        id: 'kael_caution',
        label: '“Wield the Weave’s power, but don’t let the Rift hollow out your soul.”',
        delta: 12,
        reply:
          '“A fair warning, my friend. With you anchoring me to the mortal plane, I won’t lose myself to the abyss.”',
        chronicle: 'Anchored Kaelen Vos against the pull of the Astral Rift.',
      },
    ],
  },
  thorne: {
    prompt:
      '“Listen to the wind through the iron-pines... The Whispering Vale remembers every footstep we take. Heal the Briar’s roots, and the forest itself will turn its arrows upon our foes.”',
    options: [
      {
        id: 'thorne_vow',
        label: '“We will purge the Void-blight from every grove in Thornwood, Thorne.”',
        delta: 17,
        reply:
          '“By the First Leaf, I knew my bow found the right company. My eyes and arrows are yours.”',
        chronicle: 'Pledged to restore the Heart-Briar groves alongside Thorne Ironbough.',
      },
      {
        id: 'thorne_scout',
        label: '“Teach our party how to read the high-ground wind currents in battle.”',
        delta: 12,
        reply:
          '“Take the elevated bastions whenever you can. From above, no shield can hide their weak points.”',
        chronicle: 'Practiced elevated precision marksmanship with Thorne Ironbough.',
      },
    ],
  },
};

export const CompanionCampModal: React.FC<CompanionCampModalProps> = ({
  relationships,
  onCampChoice,
  onRestAndHealParty,
  onClose,
}) => {
  const [activeId, setActiveId] = useState<CompanionId>('seraphina');
  const [replyText, setReplyText] = useState<string | null>(null);
  const [restedMessage, setRestedMessage] = useState<string | null>(null);

  const comp = relationships[activeId];
  const tier = getRelationshipTier(comp.approval);
  const syn = getCompanionSynergyBonus(comp.approval);
  const convo = CAMP_CONVERSATIONS[activeId];

  const handleSelectComp = (id: CompanionId) => {
    setActiveId(id);
    setReplyText(null);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="camp-modal-heading"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(7, 6, 12, 0.78)' }}
    >
      <div
        className="w-full max-w-4xl rounded-xl border border-amber-500/40 p-6 shadow-2xl text-[#ede8dc]"
        style={{ backgroundColor: 'rgba(16, 14, 24, 0.97)' }}
      >
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-amber-500/20">
          <div>
            <p className="text-xs font-medium text-amber-400">Expedition Sanctuary & Companion Bonds</p>
            <h2 id="camp-modal-heading" className="text-2xl font-display font-bold text-amber-100">
              Campfire Council of Dimraeth
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playHealBless();
                onRestAndHealParty();
                setRestedMessage('Long Rest Completed: All companions restored to full HP & Action Points!');
              }}
              className="px-4 py-2 text-xs font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Take Long Rest (Restore Full HP)
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 text-xs font-medium text-stone-300 hover:text-white border border-stone-700 rounded-lg hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0"
            >
              Return to Arena [C]
            </button>
          </div>
        </div>

        {restedMessage && (
          <div className="mt-3 px-4 py-2 rounded-lg border border-emerald-500/40 text-xs text-emerald-200 font-medium" style={{ backgroundColor: 'rgba(6, 78, 59, 0.45)' }}>
            {restedMessage}
          </div>
        )}

        {/* Companion Selector Tabs */}
        <div className="grid grid-cols-3 gap-3 my-5">
          {(['seraphina', 'kaelen', 'thorne'] as CompanionId[]).map((id) => {
            const c = relationships[id];
            const cTier = getRelationshipTier(c.approval);
            const isSelected = id === activeId;
            return (
              <button
                key={id}
                type="button"
                onClick={() => handleSelectComp(id)}
                className={`p-3 rounded-lg border text-left transition-colors flex items-center gap-3 ${
                  isSelected
                    ? 'border-amber-400 bg-amber-500/15'
                    : 'border-stone-800 hover:border-stone-600 bg-stone-900/60'
                }`}
              >
                <CharacterPortraitSvg id={id} className="w-12 h-12 rounded shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-display font-bold text-amber-100 truncate">{c.name}</p>
                  <p className="text-xs text-stone-400 truncate">{c.title}</p>
                  <p className="text-xs font-mono tabular-nums text-amber-300 mt-0.5">
                    {cTier} · {c.approval}/100
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Companion Details + Dialogue */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2">
          <div className="md:col-span-5 space-y-3 p-4 rounded-lg border border-stone-800" style={{ backgroundColor: 'rgba(22, 19, 32, 0.92)' }}>
            <div className="flex items-center justify-between">
              <span className="text-xs text-stone-400">{comp.raceClass}</span>
              <span className="text-xs font-mono tabular-nums text-amber-300 font-semibold">
                Tier: {tier}
              </span>
            </div>

            {/* Approval Bar */}
            <div>
              <div className="flex justify-between text-xs font-mono tabular-nums mb-1">
                <span className="text-stone-300">Relationship Approval</span>
                <span className="text-amber-300">{comp.approval} / 100</span>
              </div>
              <div className="w-full h-2.5 bg-stone-900 rounded-full overflow-hidden border border-stone-700">
                <div
                  className="h-full bg-amber-400 transition-transform duration-200 origin-left"
                  style={{ transform: `scaleX(${Math.min(1, Math.max(0, comp.approval / 100))})` }}
                />
              </div>
            </div>

            <div className="pt-2 border-t border-stone-800">
              <p className="text-xs font-semibold text-amber-200">{comp.synergyName}</p>
              <p className="text-xs text-stone-300 mt-0.5">{comp.synergyDescription}</p>
              <p className="text-xs font-mono tabular-nums text-emerald-300 mt-1.5">
                Active Combat Bonus: +{syn.attackBonus} Attack · +{syn.damageBonus} DMG · Crit {syn.critThreshold}-20
              </p>
            </div>

            <div className="pt-2 border-t border-stone-800">
              <p className="text-xs font-semibold text-stone-300">Personal Quest</p>
              <p className="text-xs text-stone-400 mt-0.5">{comp.personalQuestStage}</p>
            </div>
          </div>

          <div className="md:col-span-7 flex flex-col justify-between p-4 rounded-lg border border-stone-800" style={{ backgroundColor: 'rgba(22, 19, 32, 0.92)' }}>
            <div>
              <p className="text-xs font-semibold text-amber-300 mb-2">
                Intimate Campfire Counsel with {comp.name}:
              </p>
              <p className="text-sm text-stone-100 leading-relaxed italic mb-4">{convo.prompt}</p>

              {replyText && (
                <div className="p-3.5 rounded-lg border border-emerald-500/35 mb-4 text-sm text-emerald-100" style={{ backgroundColor: 'rgba(6, 78, 59, 0.35)' }}>
                  {replyText}
                </div>
              )}
            </div>

            <div className="space-y-2">
              {convo.options.map((opt) => {
                const alreadyDone = comp.campConversationsCompleted.includes(opt.id);
                return (
                  <button
                    key={opt.id}
                    type="button"
                    disabled={alreadyDone}
                    onClick={() => {
                      soundEngine.playHealBless();
                      setReplyText(opt.reply);
                      onCampChoice(activeId, opt.id, opt.delta, opt.chronicle);
                    }}
                    className={`w-full text-left p-3 rounded-lg border transition-colors flex items-center justify-between gap-3 ${
                      alreadyDone
                        ? 'border-stone-800 text-stone-500 bg-stone-900/40 cursor-not-allowed'
                        : 'border-amber-500/30 hover:border-amber-400 text-stone-100 bg-stone-900/90'
                    }`}
                  >
                    <span className="text-xs sm:text-sm">{opt.label}</span>
                    <span className="text-xs font-mono tabular-nums text-emerald-300 shrink-0 whitespace-nowrap">
                      {alreadyDone ? 'Bonded' : `+${opt.delta} Approval`}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface WorldChronicleModalProps {
  stageId: number;
  highestReachedStage: number;
  worldState: WorldReactivityState;
  onSelectStage: (stageIdx: number) => void;
  onClose: () => void;
}

export const WorldChronicleModal: React.FC<WorldChronicleModalProps> = ({
  stageId,
  highestReachedStage,
  worldState,
  onSelectStage,
  onClose,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="chronicle-modal-heading"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(7, 6, 12, 0.78)' }}
    >
      <div
        className="w-full max-w-3xl rounded-xl border border-amber-500/40 p-6 shadow-2xl text-[#ede8dc]"
        style={{ backgroundColor: 'rgba(16, 14, 24, 0.97)' }}
      >
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-amber-500/20">
          <div>
            <p className="text-xs font-medium text-amber-400">Dynamic World Reactivity & Expedition Map</p>
            <h2 id="chronicle-modal-heading" className="text-2xl font-display font-bold text-amber-100">
              Chronicle of the Whispering Vale
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-medium text-stone-300 hover:text-white border border-stone-700 rounded-lg hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0"
          >
            Close Chronicle [J]
          </button>
        </div>

        {/* World Alignment & Reactivity Summary */}
        <div className="grid grid-cols-3 gap-4 my-5">
          <div className="p-3.5 rounded-lg border border-stone-800" style={{ backgroundColor: 'rgba(24, 21, 35, 0.92)' }}>
            <p className="text-xs text-stone-400">Oath Alignment</p>
            <p className="text-lg font-display font-bold text-amber-300 mt-0.5">
              Path of {worldState.oathAlignment}
            </p>
            <p className="text-xs text-stone-400 mt-1">
              {worldState.oathAlignment === 'Mercy'
                ? '+3 Healing & Purified Sanctum Ground'
                : worldState.oathAlignment === 'Dominion'
                ? '+3 Blood-Weave Spell & Strike DMG'
                : 'Balanced Tactical Resonance'}
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-stone-800" style={{ backgroundColor: 'rgba(24, 21, 35, 0.92)' }}>
            <p className="text-xs text-stone-400">Astral Rift Corruption</p>
            <p className="text-lg font-mono font-bold tabular-nums text-rose-300 mt-0.5">
              {worldState.corruptionLevel}%
            </p>
            <p className="text-xs text-stone-400 mt-1">
              {worldState.corruptionLevel < 35
                ? 'Obelisk shines with purified starlight'
                : worldState.corruptionLevel > 60
                ? 'Crimson Rift surges across the sky'
                : 'Twilight equilibrium holds'}
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-stone-800" style={{ backgroundColor: 'rgba(24, 21, 35, 0.92)' }}>
            <p className="text-xs text-stone-400">Active World Mutations</p>
            <p className="text-lg font-mono font-bold tabular-nums text-emerald-300 mt-0.5">
              {worldState.flags.length} Active
            </p>
            <p className="text-xs text-stone-400 mt-1 truncate">
              {worldState.flags.length > 0
                ? worldState.flags.map((f) => f.replace(/_/g, ' ')).join(' · ')
                : 'Awaiting decisive oaths'}
            </p>
          </div>
        </div>

        {/* Expedition Acts / Stage Selector */}
        <div className="mb-5">
          <p className="text-xs font-semibold text-amber-300 mb-2">
            Expedition Regions (Unlocks as Encounters are Cleared):
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {STAGES.map((st) => {
              const isLocked = st.id > highestReachedStage;
              const isCurrent = st.id === stageId;
              return (
                <button
                  key={st.id}
                  type="button"
                  disabled={isLocked}
                  onClick={() => {
                    onSelectStage(st.id);
                    onClose();
                  }}
                  className={`p-3.5 rounded-lg border text-left transition-colors ${
                    isCurrent
                      ? 'border-amber-400 bg-amber-500/15'
                      : isLocked
                      ? 'border-stone-800/70 bg-stone-900/30 opacity-50 cursor-not-allowed'
                      : 'border-stone-700 hover:border-amber-400/60 bg-stone-900/80'
                  }`}
                >
                  <p className="text-xs font-mono text-amber-400">{st.chapterLabel}</p>
                  <p className="text-sm font-display font-bold text-stone-100 mt-0.5">{st.name}</p>
                  <p className="text-xs text-stone-400 mt-1">{st.subtitle}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Chronicle Decision Log */}
        <div className="p-4 rounded-lg border border-stone-800 max-h-40 overflow-y-auto" style={{ backgroundColor: 'rgba(20, 17, 30, 0.92)' }}>
          <p className="text-xs font-semibold text-amber-200 mb-2">Recorded Decisions & Consequences:</p>
          <ul className="space-y-1.5 text-xs text-stone-300">
            {worldState.chronicleLog.map((entry, idx) => (
              <li key={idx}>
                {idx + 1}. {entry}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
