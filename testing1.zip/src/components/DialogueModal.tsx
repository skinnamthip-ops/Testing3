import React, { useState } from 'react';
import {
  CompanionId,
  CompanionRelationship,
  CombatUnit,
  DialogueChoice,
  DialogueNode,
  SkillCheckResult,
  resolveSkillCheck,
  getStatModifier,
  getCompanionSynergyBonus,
} from '../game/rules';
import { CharacterPortraitSvg, D20DieSvg } from './PortraitsAndIcons';
import { soundEngine } from '../game/audio';

interface DialogueModalProps {
  node: DialogueNode;
  units: CombatUnit[];
  relationships: Record<CompanionId, CompanionRelationship>;
  onRollSkillCheck?: (choice: DialogueChoice, rollResult: SkillCheckResult) => void;
  onCompleteChoice: (choice: DialogueChoice, rollResult: SkillCheckResult) => void;
  onClose: () => void;
}

export const DialogueModal: React.FC<DialogueModalProps> = ({
  node,
  units,
  relationships,
  onRollSkillCheck,
  onCompleteChoice,
  onClose,
}) => {
  const [selectedChoice, setSelectedChoice] = useState<DialogueChoice | null>(null);
  const [rollResult, setRollResult] = useState<SkillCheckResult | null>(null);

  const handleSelectChoice = (choice: DialogueChoice) => {
    const result = resolveSkillCheck(choice, units, relationships);
    soundEngine.playDiceRoll(result.success);
    setSelectedChoice(choice);
    setRollResult(result);
    onRollSkillCheck?.(choice, result);
  };

  const handleConfirmOutcome = () => {
    if (!selectedChoice || !rollResult) return;
    onCompleteChoice(selectedChoice, rollResult);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="dialogue-speaker-heading"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(7, 6, 12, 0.78)' }}
    >
      <div
        className="w-full max-w-3xl rounded-xl border border-amber-500/40 p-6 shadow-2xl text-[#ede8dc]"
        style={{ backgroundColor: 'rgba(16, 14, 24, 0.97)' }}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-amber-500/20">
          <div className="flex items-center gap-4">
            <CharacterPortraitSvg
              id={node.speakerPortrait}
              className="w-16 h-16 rounded-lg border border-amber-400/50 shrink-0"
            />
            <div>
              <p className="text-xs font-medium text-amber-400/90 tracking-wide">
                {node.locationTitle}
              </p>
              <h2
                id="dialogue-speaker-heading"
                className="text-2xl font-display font-bold text-amber-100"
              >
                {node.speakerName}
              </h2>
              <p className="text-xs text-stone-400">{node.speakerTitle}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-medium text-stone-300 hover:text-white border border-stone-700 rounded-md hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0"
          >
            Close Parley [Esc]
          </button>
        </div>

        {/* Main Narrative Prose */}
        <div className="my-5">
          <p className="text-base leading-relaxed text-stone-100 max-w-[68ch] font-sans">
            {node.text}
          </p>
        </div>

        {/* Companion Interjections */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
          {node.companionInterjections.map((inter) => {
            const comp = relationships[inter.companionId];
            return (
              <div
                key={inter.companionId}
                className="p-3 rounded-lg border border-stone-800"
                style={{ backgroundColor: 'rgba(24, 21, 35, 0.92)' }}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <CharacterPortraitSvg id={inter.companionId} className="w-7 h-7 rounded shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-amber-200 truncate">{comp.name}</p>
                    <p className="text-[11px] text-stone-400 font-mono tabular-nums">
                      Approval {comp.approval}/100
                    </p>
                  </div>
                </div>
                <p className="text-xs text-stone-300 leading-snug italic">{inter.quote}</p>
              </div>
            );
          })}
        </div>

        {/* Branching Choices OR D20 Roll Resolution Panel */}
        {!selectedChoice || !rollResult ? (
          <div className="space-y-2.5">
            <p className="text-xs font-semibold text-amber-300/90 mb-2">
              Choose Your Response (Shapes Companion Approval & Battlefield Reactivity):
            </p>
            {node.choices.map((choice, idx) => {
              const sc = choice.skillCheck;
              let bonusPreview = '';
              if (sc) {
                const speakerUnit = units.find((u) => u.companionId === sc.speakerId);
                const statMod = speakerUnit ? getStatModifier(speakerUnit.stats[sc.stat]) : 2;
                const synMod = getCompanionSynergyBonus(relationships[sc.speakerId].approval).attackBonus;
                const totalMod = statMod + synMod;
                bonusPreview = `DC ${sc.dc} · ${totalMod >= 0 ? `+${totalMod}` : totalMod} Bonus`;
              }

              return (
                <button
                  key={choice.id}
                  type="button"
                  onClick={() => handleSelectChoice(choice)}
                  className="w-full text-left p-3.5 rounded-lg border border-amber-500/25 hover:border-amber-400 transition-colors flex items-center justify-between gap-4 group"
                  style={{ backgroundColor: 'rgba(28, 24, 42, 0.92)' }}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <span className="font-mono text-xs font-bold text-amber-400 mt-0.5 shrink-0">
                      {idx + 1}.
                    </span>
                    <span className="text-sm text-stone-100 group-hover:text-amber-100 transition-colors">
                      {choice.text}
                    </span>
                  </div>
                  {sc && (
                    <span className="text-xs font-mono tabular-nums text-amber-300 shrink-0 whitespace-nowrap">
                      {bonusPreview}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ) : (
          <div
            className="p-5 rounded-lg border border-amber-500/40"
            style={{ backgroundColor: 'rgba(24, 20, 36, 0.96)' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              {/* D20 Roll Breakdown */}
              <div className="flex items-center gap-4">
                <D20DieSvg value={rollResult.d20Roll} className="w-16 h-16 shrink-0" />
                <div>
                  <p className="text-xs text-stone-400">
                    {selectedChoice.skillCheck
                      ? `${selectedChoice.skillCheck.skillName} Check (DC ${rollResult.dc})`
                      : 'Decisive Action'}
                  </p>
                  <p
                    className={`text-xl font-display font-bold ${
                      rollResult.success ? 'text-emerald-300' : 'text-rose-400'
                    }`}
                  >
                    {rollResult.critical
                      ? 'Critical Success! (Natural 20)'
                      : rollResult.success
                      ? `Check Succeeded (${rollResult.total} vs DC ${rollResult.dc})`
                      : `Check Resisted (${rollResult.total} vs DC ${rollResult.dc})`}
                  </p>
                  {selectedChoice.skillCheck && (
                    <p className="text-xs font-mono tabular-nums text-stone-300 mt-0.5">
                      D20 ({rollResult.d20Roll}) + Stat ({rollResult.statMod >= 0 ? `+${rollResult.statMod}` : rollResult.statMod}) + Bond ({rollResult.synergyMod >= 0 ? `+${rollResult.synergyMod}` : rollResult.synergyMod}) = {rollResult.total}
                    </p>
                  )}
                </div>
              </div>

              {/* Companion Approval Shifts */}
              <div className="flex flex-wrap items-center gap-3 text-xs font-mono tabular-nums">
                {Object.entries(selectedChoice.approvalDeltas).map(([compId, delta]) => {
                  if (!delta) return null;
                  const cName = relationships[compId as CompanionId]?.name.split(' ')[0];
                  return (
                    <span
                      key={compId}
                      className={delta > 0 ? 'text-emerald-300' : 'text-rose-300'}
                    >
                      {cName} {delta > 0 ? `+${delta}` : delta}
                    </span>
                  );
                })}
              </div>
            </div>

            <p className="mt-4 text-sm text-amber-100 leading-relaxed border-t border-stone-800 pt-3">
              {rollResult.success
                ? selectedChoice.outcomeSummary
                : 'Your words echo across the sanctum, yet the adversary steels their resolve for battle—though your companions remember the conviction behind your choice.'}
            </p>

            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={handleConfirmOutcome}
                className="px-5 py-2.5 text-sm font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                Commit Choice & Return to Battlefield
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
