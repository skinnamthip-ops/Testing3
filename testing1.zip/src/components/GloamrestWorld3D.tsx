import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  BUILDING_EXTERIORS,
  BuildingExteriorSpec,
  GLOAMREST_INTERIORS,
  InteriorFurnitureProp,
  InteriorId,
  TOWN_GRID_SIZE,
  TOWN_TILE_WORLD_SIZE,
  TownInteractiveObject,
  TownSceneId,
  TownTile,
  findTownPath,
  generateGloamrestExteriorGrid,
  generateInteriorGrid,
} from '../game/gloamrestMapAndInteriors';
import { GloamrestSaveState } from '../game/gloamrestEngineTypes';
import {
  getActiveSceneNpcs,
  getSceneInteractiveObjects,
} from '../game/gloamrestEngine';
import { GloamrestNpcDefinition } from '../game/gloamrestNpcsAndDialogue';
import { CharacterCreationBuild } from '../game/rules';
import { soundEngine } from '../game/audio';
import {
  performanceManager,
  exponentialDamp,
  clampDeltaTime,
} from '../game/performanceManager';
import {
  resolve8DirectionalInput,
  canMove8Directional,
  smoothRotateAngle,
  computeWarrior8DirStance,
  Direction8,
  getDirection8FromAngle,
} from '../game/eightDirectionalMovement';

export interface NearbyInteractionPrompt {
  kind: 'npc' | 'object';
  id: string;
  name: string;
  promptLabel: string;
  roleOrSubtitle?: string;
}

interface GloamrestWorld3DProps {
  gloamrestState: GloamrestSaveState;
  characterBuild: CharacterCreationBuild;
  cameraPreset: 'tactical' | 'close' | 'overhead';
  isUiModalOpen: boolean;
  onPlayerMove: (x: number, z: number, facingRad: number) => void;
  onInteractNpc: (npcId: string) => void;
  onInteractObject: (objectId: string) => void;
  onNearbyPromptChange: (prompt: NearbyInteractionPrompt | null) => void;
}

function tileToWorld(
  gx: number,
  gz: number,
  gridW: number,
  gridD: number,
  elev = 0
): [number, number, number] {
  const wx = (gx - (gridW - 1) / 2) * TOWN_TILE_WORLD_SIZE;
  const wz = (gz - (gridD - 1) / 2) * TOWN_TILE_WORLD_SIZE;
  const wy = elev * 0.55;
  return [wx, wy, wz];
}

function buildTownHumanoidMesh(options: {
  primaryHex: number;
  secondaryHex: number;
  accentHex: number;
  skinHex: number;
  hairHex: number;
  headgear?: GloamrestNpcDefinition['visual']['headgear'];
  heldProp?: GloamrestNpcDefinition['visual']['heldProp'];
  ringColorHex: number;
}): {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  ringMesh: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  bladeGroup?: THREE.Group;
  shieldGroup?: THREE.Group;
} {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  // Contact shadow
  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.55, 20),
    new THREE.MeshBasicMaterial({
      color: 0x050606,
      transparent: true,
      opacity: 0.48,
      depthWrite: false,
    })
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;
  root.add(shadow);

  // Selection / Proximity ring
  const ringMesh = new THREE.Mesh(
    new THREE.RingGeometry(0.56, 0.72, 28),
    new THREE.MeshBasicMaterial({
      color: options.ringColorHex,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.25,
      depthWrite: false,
    })
  );
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.035;
  root.add(ringMesh);

  const primaryMat = new THREE.MeshStandardMaterial({
    color: options.primaryHex,
    roughness: 0.68,
    metalness: 0.22,
  });
  const secondaryMat = new THREE.MeshStandardMaterial({
    color: options.secondaryHex,
    roughness: 0.76,
    metalness: 0.12,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: options.accentHex,
    roughness: 0.35,
    metalness: 0.65,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: options.skinHex,
    roughness: 0.72,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: options.hairHex,
    roughness: 0.82,
  });

  // Boots & legs
  const legGeo = new THREE.CylinderGeometry(0.11, 0.1, 0.56, 8);
  const legL = new THREE.Mesh(legGeo, secondaryMat);
  legL.position.set(-0.14, 0.28, 0);
  const legR = new THREE.Mesh(legGeo, secondaryMat);
  legR.position.set(0.14, 0.28, 0);
  bodyGroup.add(legL, legR);

  // Tunic / Armor Torso
  const torso = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.34, 0.78, 10),
    primaryMat
  );
  torso.position.y = 0.88;
  torso.castShadow = true;
  bodyGroup.add(torso);

  // Cloak /Mantle
  const cloak = new THREE.Mesh(
    new THREE.BoxGeometry(0.56, 0.74, 0.14),
    secondaryMat
  );
  cloak.position.set(0, 0.84, -0.18);
  bodyGroup.add(cloak);

  // Belt & Accent Sash
  const belt = new THREE.Mesh(
    new THREE.CylinderGeometry(0.32, 0.32, 0.1, 10),
    accentMat
  );
  belt.position.y = 0.66;
  bodyGroup.add(belt);

  // Head & Hair
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 12), skinMat);
  head.position.y = 1.48;
  head.castShadow = true;
  bodyGroup.add(head);

  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(0.235, 10, 10, 0, Math.PI * 2, 0, Math.PI * 0.62),
    hairMat
  );
  hair.position.y = 1.5;
  bodyGroup.add(hair);

  // Headgear variations
  if (options.headgear === 'guard_helm') {
    const helm = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.25, 0.22, 10),
      new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.7, roughness: 0.35 })
    );
    helm.position.y = 1.62;
    bodyGroup.add(helm);
  } else if (options.headgear === 'elder_circlet' || options.headgear === 'herbal_wreath') {
    const crown = new THREE.Mesh(
      new THREE.TorusGeometry(0.22, 0.03, 6, 16),
      accentMat
    );
    crown.rotation.x = Math.PI / 2;
    crown.position.y = 1.6;
    bodyGroup.add(crown);
  } else if (
    options.headgear === 'tricorne_hat' ||
    options.headgear === 'merchant_cap'
  ) {
    const brim = new THREE.Mesh(
      new THREE.CylinderGeometry(0.36, 0.36, 0.05, 8),
      secondaryMat
    );
    brim.position.y = 1.64;
    bodyGroup.add(brim);
  } else if (
    options.headgear === 'hood' ||
    options.headgear === 'scout_cloak' ||
    options.headgear === 'mitre_cowl'
  ) {
    const hood = new THREE.Mesh(
      new THREE.ConeGeometry(0.28, 0.36, 8),
      secondaryMat
    );
    hood.position.set(0, 1.66, -0.03);
    bodyGroup.add(hood);
  }

  let bladeGroup: THREE.Group | undefined;
  let shieldGroup: THREE.Group | undefined;

  // Held Prop Silhouette
  if (options.heldProp === 'staff') {
    const staff = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.035, 1.75, 6),
      new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 })
    );
    staff.position.set(0.36, 0.9, 0.12);
    bodyGroup.add(staff);
  } else if (options.heldProp === 'sword_shield') {
    // 1. Authentic Warrior Longsword (Right hand)
    bladeGroup = new THREE.Group();
    const bladeMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.065, 0.92, 0.024),
      new THREE.MeshStandardMaterial({
        color: 0xe2e8f0,
        metalness: 0.86,
        roughness: 0.2,
      })
    );
    bladeMesh.position.y = 0.46;
    bladeMesh.castShadow = true;

    const crossguard = new THREE.Mesh(
      new THREE.BoxGeometry(0.25, 0.045, 0.055),
      accentMat
    );
    crossguard.position.y = 0.02;

    const hiltGrip = new THREE.Mesh(
      new THREE.CylinderGeometry(0.025, 0.028, 0.22, 8),
      new THREE.MeshStandardMaterial({ color: 0x3d271d, roughness: 0.8 })
    );
    hiltGrip.position.y = -0.11;

    const pommel = new THREE.Mesh(
      new THREE.SphereGeometry(0.042, 8, 8),
      accentMat
    );
    pommel.position.y = -0.22;

    bladeGroup.add(bladeMesh, crossguard, hiltGrip, pommel);
    bladeGroup.position.set(0.38, 0.98, 0.16);
    bladeGroup.rotation.set(0.12, 0.08, -0.06);
    bodyGroup.add(bladeGroup);

    // 2. Heater Shield (Left forearm)
    shieldGroup = new THREE.Group();
    const shieldPlate = new THREE.Mesh(
      new THREE.BoxGeometry(0.06, 0.64, 0.46),
      primaryMat
    );
    shieldPlate.castShadow = true;

    const shieldTrim = new THREE.Mesh(
      new THREE.BoxGeometry(0.068, 0.66, 0.48),
      accentMat
    );
    shieldTrim.scale.set(0.96, 0.98, 0.96);

    const shieldBoss = new THREE.Mesh(
      new THREE.SphereGeometry(0.065, 8, 8),
      accentMat
    );
    shieldBoss.position.x = -0.035;

    shieldGroup.add(shieldPlate, shieldTrim, shieldBoss);
    shieldGroup.position.set(-0.36, 0.94, 0.22);
    shieldGroup.rotation.set(0.18, 0.22, 0.04);
    bodyGroup.add(shieldGroup);
  } else if (options.heldProp === 'lantern') {
    const lantern = new THREE.Mesh(
      new THREE.BoxGeometry(0.16, 0.22, 0.16),
      new THREE.MeshStandardMaterial({
        color: 0xfbbf24,
        emissive: 0xd97706,
        emissiveIntensity: 0.85,
      })
    );
    lantern.position.set(0.36, 0.82, 0.2);
    bodyGroup.add(lantern);
  } else if (options.heldProp === 'hammer' || options.heldProp === 'saw') {
    const tool = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.45, 0.14),
      new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.65 })
    );
    tool.position.set(0.35, 0.86, 0.16);
    bodyGroup.add(tool);
  } else if (options.heldProp === 'bow') {
    const bow = new THREE.Mesh(
      new THREE.TorusGeometry(0.36, 0.03, 6, 12, Math.PI),
      new THREE.MeshStandardMaterial({ color: 0x92400e })
    );
    bow.position.set(-0.34, 0.96, 0.12);
    bodyGroup.add(bow);
  }

  return { root, bodyGroup, ringMesh, legL, legR, bladeGroup, shieldGroup };
}

function buildExteriorBuildingGroup(
  spec: BuildingExteriorSpec,
  gridW: number,
  gridD: number
): THREE.Group {
  const group = new THREE.Group();
  const minW = tileToWorld(spec.footprint.minX, spec.footprint.minZ, gridW, gridD);
  const maxW = tileToWorld(spec.footprint.maxX, spec.footprint.maxZ, gridW, gridD);

  const cx = (minW[0] + maxW[0]) / 2;
  const cz = (minW[2] + maxW[2]) / 2;
  const widthWorld =
    (spec.footprint.maxX - spec.footprint.minX + 1) * TOWN_TILE_WORLD_SIZE - 0.18;
  const depthWorld =
    (spec.footprint.maxZ - spec.footprint.minZ + 1) * TOWN_TILE_WORLD_SIZE - 0.18;

  group.position.set(cx, 0, cz);

  const stoneMat = new THREE.MeshStandardMaterial({
    color: spec.style === 'abandoned_manor' ? 0x2d2c33 : 0x45433e,
    roughness: 0.88,
  });
  const timberWallMat = new THREE.MeshStandardMaterial({
    color:
      spec.style === 'herbalist_cottage'
        ? 0x424d3d
        : spec.style === 'abandoned_manor'
        ? 0x352f33
        : 0x5c4c3c,
    roughness: 0.82,
  });
  const darkBeamMat = new THREE.MeshStandardMaterial({
    color: 0x261d16,
    roughness: 0.86,
  });
  const roofMat = new THREE.MeshStandardMaterial({
    color:
      spec.style === 'tavern_stag'
        ? 0x4b2e22
        : spec.style === 'chapel_stone'
        ? 0x28323e
        : spec.style === 'herbalist_cottage'
        ? 0x29422e
        : spec.style === 'forge_workshop'
        ? 0x2f2926
        : spec.style === 'abandoned_manor'
        ? 0x232028
        : 0x3b3228,
    roughness: 0.78,
  });
  const warmWindowMat = new THREE.MeshStandardMaterial({
    color: spec.style === 'abandoned_manor' ? 0x1e2229 : 0xfbbf24,
    emissive: spec.style === 'abandoned_manor' ? 0x0f172a : 0xd97706,
    emissiveIntensity: spec.style === 'abandoned_manor' ? 0.1 : 0.85,
    roughness: 0.3,
  });

  // Stone Foundation
  const foundation = new THREE.Mesh(
    new THREE.BoxGeometry(widthWorld + 0.2, 0.55, depthWorld + 0.2),
    stoneMat
  );
  foundation.position.y = 0.275;
  foundation.castShadow = true;
  foundation.receiveShadow = true;
  group.add(foundation);

  const wallHeight =
    spec.style === 'tavern_stag' || spec.style === 'abandoned_manor'
      ? 4.4
      : spec.style === 'chapel_stone'
      ? 4.2
      : spec.style === 'gatehouse'
      ? 4.8
      : 3.1;

  // Main Body
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(
      widthWorld,
      wallHeight,
      depthWorld
    ),
    spec.style === 'chapel_stone' ||
      spec.style === 'barracks_watchtower' ||
      spec.style === 'gatehouse'
      ? stoneMat
      : timberWallMat
  );
  body.position.y = 0.55 + wallHeight / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  // Corner Timber Pillars
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const post = new THREE.Mesh(
        new THREE.BoxGeometry(0.24, wallHeight + 0.1, 0.24),
        darkBeamMat
      );
      post.position.set(
        sx * (widthWorld / 2 - 0.08),
        0.55 + wallHeight / 2,
        sz * (depthWorld / 2 - 0.08)
      );
      group.add(post);
    }
  }

  // Pitched Roof (unless flat crenelated gatehouse)
  if (spec.style !== 'gatehouse') {
    const roofHeight = spec.style === 'chapel_stone' ? 2.4 : 1.75;
    const roofCone = new THREE.Mesh(
      new THREE.ConeGeometry(Math.max(widthWorld, depthWorld) * 0.76, roofHeight, 4),
      roofMat
    );
    roofCone.rotation.y = Math.PI / 4;
    roofCone.scale.set(
      widthWorld / Math.max(widthWorld, depthWorld),
      1,
      depthWorld / Math.max(widthWorld, depthWorld)
    );
    roofCone.position.y = 0.55 + wallHeight + roofHeight / 2 - 0.05;
    roofCone.castShadow = true;
    group.add(roofCone);
  }

  // Warm Windows on Front & Sides
  for (const offset of [-widthWorld * 0.26, widthWorld * 0.26]) {
    const winS = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.85, 0.12),
      warmWindowMat
    );
    winS.position.set(offset, 2.1, depthWorld / 2 + 0.03);
    group.add(winS);
  }

  // Bespoke Architectural Landmarks per Building Style!
  if (spec.style === 'tavern_stag') {
    // Chimney + Hanging Stag Signboard on South Front
    const chimney = new THREE.Mesh(
      new THREE.BoxGeometry(0.95, 2.8, 0.95),
      stoneMat
    );
    chimney.position.set(-widthWorld * 0.32, wallHeight + 1.1, -depthWorld * 0.22);
    group.add(chimney);

    const signArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.14, 1.3),
      darkBeamMat
    );
    signArm.position.set(0, 3.1, depthWorld / 2 + 0.6);
    const stagBoard = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 0.85, 0.1),
      new THREE.MeshStandardMaterial({
        color: 0xd97706,
        emissive: 0x78350f,
        emissiveIntensity: 0.35,
      })
    );
    stagBoard.position.set(0, 2.55, depthWorld / 2 + 1.0);
    group.add(signArm, stagBoard);
  } else if (spec.style === 'forge_workshop') {
    // Tall Smoking Brick Furnace Chimney & Glowing Hearth Mouth
    const furnaceStack = new THREE.Mesh(
      new THREE.BoxGeometry(1.5, 4.8, 1.5),
      new THREE.MeshStandardMaterial({ color: 0x4a2c24, roughness: 0.9 })
    );
    furnaceStack.position.set(widthWorld * 0.3, 3.1, -depthWorld * 0.2);
    furnaceStack.castShadow = true;
    const forgeGlow = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 1.0, 0.22),
      new THREE.MeshStandardMaterial({
        color: 0xf97316,
        emissive: 0xea580c,
        emissiveIntensity: 1.4,
      })
    );
    forgeGlow.position.set(widthWorld * 0.26, 1.3, depthWorld / 2 + 0.05);
    group.add(furnaceStack, forgeGlow);
  } else if (spec.style === 'chapel_stone') {
    // Tall Narrow Stone Bell Tower Landmark
    const bellTower = new THREE.Mesh(
      new THREE.BoxGeometry(2.1, 7.6, 2.1),
      stoneMat
    );
    bellTower.position.set(-widthWorld * 0.32, 4.1, depthWorld * 0.24);
    bellTower.castShadow = true;
    const spire = new THREE.Mesh(new THREE.ConeGeometry(1.65, 2.6, 4), roofMat);
    spire.rotation.y = Math.PI / 4;
    spire.position.set(-widthWorld * 0.32, 9.1, depthWorld * 0.24);
    group.add(bellTower, spire);
  } else if (spec.style === 'barracks_watchtower') {
    // Tall Crenelated Northern Stone Watchtower
    const tower = new THREE.Mesh(
      new THREE.CylinderGeometry(1.65, 1.85, 7.4, 8),
      stoneMat
    );
    tower.position.set(widthWorld * 0.32, 3.9, -depthWorld * 0.18);
    tower.castShadow = true;
    const brazierTop = new THREE.Mesh(
      new THREE.SphereGeometry(0.45, 8, 8),
      new THREE.MeshStandardMaterial({
        color: 0xfbbf24,
        emissive: 0xf59e0b,
        emissiveIntensity: 1.2,
      })
    );
    brazierTop.position.set(widthWorld * 0.32, 7.8, -depthWorld * 0.18);
    group.add(tower, brazierTop);
  } else if (spec.style === 'herbalist_cottage') {
    // Climbing Green Ivy & Glasshouse Lean-to
    const ivy = new THREE.Mesh(
      new THREE.BoxGeometry(widthWorld + 0.16, 1.8, depthWorld * 0.55),
      new THREE.MeshStandardMaterial({ color: 0x2f5e39, roughness: 0.9 })
    );
    ivy.position.set(0, 1.6, 0);
    group.add(ivy);
  } else if (spec.style === 'abandoned_manor') {
    // Collapsed Tilted Timber Balcony on Front North Facade
    const brokenBalcony = new THREE.Mesh(
      new THREE.BoxGeometry(widthWorld * 0.55, 0.28, 1.3),
      darkBeamMat
    );
    brokenBalcony.rotation.z = -0.22;
    brokenBalcony.position.set(-0.6, 2.75, -depthWorld / 2 - 0.5);
    group.add(brokenBalcony);
  }

  // Highlighted Doorway Frame if building has an interior entrance
  if (spec.linkedInteriorId && spec.doorFacing) {
    const doorFrame = new THREE.Mesh(
      new THREE.BoxGeometry(1.25, 2.15, 0.26),
      new THREE.MeshStandardMaterial({
        color: spec.style === 'abandoned_manor' ? 0x3f2e26 : 0x78472a,
        roughness: 0.65,
      })
    );
    if (spec.doorFacing === 'south') {
      doorFrame.position.set(0, 1.5, depthWorld / 2 + 0.06);
    } else if (spec.doorFacing === 'north') {
      doorFrame.position.set(0, 1.5, -depthWorld / 2 - 0.06);
    } else if (spec.doorFacing === 'west') {
      doorFrame.rotation.y = Math.PI / 2;
      doorFrame.position.set(-widthWorld / 2 - 0.06, 1.5, 0);
    } else if (spec.doorFacing === 'east') {
      doorFrame.rotation.y = Math.PI / 2;
      doorFrame.position.set(widthWorld / 2 + 0.06, 1.5, 0);
    }
    group.add(doorFrame);
  }

  return group;
}

function buildInteriorFurnitureMesh(
  prop: InteriorFurnitureProp,
  gridW: number,
  gridD: number
): THREE.Group {
  const grp = new THREE.Group();
  const minW = tileToWorld(prop.minX, prop.minZ, gridW, gridD);
  const maxW = tileToWorld(prop.maxX, prop.maxZ, gridW, gridD);
  const cx = (minW[0] + maxW[0]) / 2;
  const cz = (minW[2] + maxW[2]) / 2;
  const w = (prop.maxX - prop.minX + 1) * TOWN_TILE_WORLD_SIZE - 0.35;
  const d = (prop.maxZ - prop.minZ + 1) * TOWN_TILE_WORLD_SIZE - 0.35;
  grp.position.set(cx, 0, cz);

  const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3d28, roughness: 0.78 });
  const stoneMat = new THREE.MeshStandardMaterial({ color: 0x474542, roughness: 0.86 });
  const ironMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    metalness: 0.68,
    roughness: 0.35,
  });

  if (prop.kind === 'hearth_fire' || prop.kind === 'forge_furnace') {
    const base = new THREE.Mesh(new THREE.BoxGeometry(w, 2.5, d), stoneMat);
    base.position.y = 1.25;
    const fire = new THREE.Mesh(
      new THREE.SphereGeometry(0.55, 10, 10),
      new THREE.MeshStandardMaterial({
        color: 0xf97316,
        emissive: 0xea580c,
        emissiveIntensity: 1.5,
      })
    );
    fire.position.set(0, 0.75, d * 0.35);
    grp.add(base, fire);
  } else if (prop.kind === 'anvil') {
    const block = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.5, 0.6, 8), woodMat);
    block.position.y = 0.3;
    const anvil = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.42, 0.45), ironMat);
    anvil.position.y = 0.8;
    grp.add(block, anvil);
  } else if (prop.kind === 'chapel_altar') {
    const dais = new THREE.Mesh(new THREE.BoxGeometry(w, 1.15, d), stoneMat);
    dais.position.y = 0.58;
    const chalice = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.18, 0.45, 10),
      new THREE.MeshStandardMaterial({
        color: 0xe2b05a,
        emissive: 0xd97706,
        emissiveIntensity: 0.6,
        metalness: 0.8,
      })
    );
    chalice.position.y = 1.38;
    grp.add(dais, chalice);
  } else if (prop.kind === 'astral_crystal') {
    const shard = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.68, 0),
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 1.4,
        roughness: 0.2,
      })
    );
    shard.scale.set(0.8, 1.8, 0.8);
    shard.position.y = 1.25;
    grp.add(shard);
  } else if (
    prop.kind === 'potion_shelf' ||
    prop.kind === 'archive_shelf' ||
    prop.kind === 'dusty_bookshelf' ||
    prop.kind === 'weapon_rack'
  ) {
    const rack = new THREE.Mesh(new THREE.BoxGeometry(w, 2.35, d), woodMat);
    rack.position.y = 1.18;
    grp.add(rack);
  } else if (prop.kind === 'greenhouse_planter') {
    const box = new THREE.Mesh(new THREE.BoxGeometry(w, 0.65, d), woodMat);
    box.position.y = 0.32;
    const foliage = new THREE.Mesh(
      new THREE.BoxGeometry(w * 0.85, 0.65, d * 0.85),
      new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.85 })
    );
    foliage.position.y = 0.85;
    grp.add(box, foliage);
  } else if (prop.kind === 'bed' || prop.kind === 'bunk_bed') {
    const frame = new THREE.Mesh(new THREE.BoxGeometry(w, 0.55, d), woodMat);
    frame.position.y = 0.28;
    const blanket = new THREE.Mesh(
      new THREE.BoxGeometry(w * 0.9, 0.2, d * 0.85),
      new THREE.MeshStandardMaterial({ color: 0x7c2d12, roughness: 0.9 })
    );
    blanket.position.y = 0.62;
    grp.add(frame, blanket);
  } else {
    const tableH = prop.kind === 'family_crest_hearth' ? 2.4 : 0.92;
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(w, tableH, d),
      prop.kind === 'family_crest_hearth' ? stoneMat : woodMat
    );
    mesh.position.y = tableH / 2;
    grp.add(mesh);
  }

  return grp;
}

export const GloamrestWorld3D: React.FC<GloamrestWorld3DProps> = ({
  gloamrestState,
  characterBuild,
  cameraPreset,
  isUiModalOpen,
  onPlayerMove,
  onInteractNpc,
  onInteractObject,
  onNearbyPromptChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Live mutable refs so the 60fps animation & input loop never recreates the WebGL context unnecessarily
  const stateRef = useRef(gloamrestState);
  stateRef.current = gloamrestState;
  const modalOpenRef = useRef(isUiModalOpen);
  modalOpenRef.current = isUiModalOpen;
  const cameraPresetRef = useRef(cameraPreset);
  cameraPresetRef.current = cameraPreset;

  const callbacksRef = useRef({
    onPlayerMove,
    onInteractNpc,
    onInteractObject,
    onNearbyPromptChange,
  });
  callbacksRef.current = {
    onPlayerMove,
    onInteractNpc,
    onInteractObject,
    onNearbyPromptChange,
  };

  // Continuous player sub-tile position & active click-to-walk path
  const livePosRef = useRef<{ x: number; z: number; facing: number }>({
    x: gloamrestState.playerPos.x,
    z: gloamrestState.playerPos.z,
    facing: gloamrestState.playerFacingRad,
  });
  const targetFacingRef = useRef<number>(gloamrestState.playerFacingRad);
  const pathQueueRef = useRef<{ x: number; z: number }[]>([]);
  const pendingArrivalActionRef = useRef<
    { type: 'npc'; id: string } | { type: 'object'; id: string } | null
  >(null);
  const pressedKeysRef = useRef<Set<string>>(new Set());
  const lastReportedTileRef = useRef<string>('');
  const lastPromptKeyRef = useRef<string>('');
  const footstepTimerRef = useRef<number>(0);

  // Sync livePosRef when scene transitions or external teleport/load happens
  useEffect(() => {
    const dx = Math.abs(livePosRef.current.x - gloamrestState.playerPos.x);
    const dz = Math.abs(livePosRef.current.z - gloamrestState.playerPos.z);
    if (dx > 1.35 || dz > 1.35) {
      livePosRef.current = {
        x: gloamrestState.playerPos.x,
        z: gloamrestState.playerPos.z,
        facing: gloamrestState.playerFacingRad,
      };
      targetFacingRef.current = gloamrestState.playerFacingRad;
      pathQueueRef.current = [];
      pendingArrivalActionRef.current = null;
    }
  }, [
    gloamrestState.currentSceneId,
    gloamrestState.playerPos.x,
    gloamrestState.playerPos.z,
    gloamrestState.playerFacingRad,
  ]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const currentScene: TownSceneId = gloamrestState.currentSceneId;
    const activeGrid: TownTile[][] =
      currentScene === 'exterior'
        ? generateGloamrestExteriorGrid()
        : generateInteriorGrid(currentScene as InteriorId);
    const gridW = activeGrid.length;
    const gridD = activeGrid[0]?.length ?? 10;

    // Reset path queue on scene rebuild
    livePosRef.current = {
      x: stateRef.current.playerPos.x,
      z: stateRef.current.playerPos.z,
      facing: stateRef.current.playerFacingRad,
    };
    targetFacingRef.current = stateRef.current.playerFacingRad;
    pathQueueRef.current = [];
    pendingArrivalActionRef.current = null;

    // 1. Scene, Renderer & Camera (with Software WebGL detection per `threejs` skill)
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const scene = new THREE.Scene();
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const camera = new THREE.PerspectiveCamera(
      36,
      (container.clientWidth || window.innerWidth) /
        Math.max(1, container.clientHeight || window.innerHeight),
      0.5,
      240
    );

    // 2. Lighting & Atmospheric Fog (Dynamic per TimeOfDay + ThreatPhase)
    const hemiLight = new THREE.HemisphereLight(0xcbd5e1, 0x26231d, 0.72);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfde68a, 1.35);
    sunLight.position.set(26, 38, 22);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.camera.near = 2;
    sunLight.shadow.camera.far = 130;
    const dCam = currentScene === 'exterior' ? 46 : 18;
    sunLight.shadow.camera.left = -dCam;
    sunLight.shadow.camera.right = dCam;
    sunLight.shadow.camera.top = dCam;
    sunLight.shadow.camera.bottom = -dCam;
    scene.add(sunLight);

    const fog = new THREE.FogExp2(0x131715, 0.012);
    scene.fog = fog;
    scene.background = new THREE.Color(0x111513);

    // 3. Instanced Terrain Tiles + Raycast Ground Plane
    const tileCount = gridW * gridD;
    const tileGeo = new THREE.BoxGeometry(
      TOWN_TILE_WORLD_SIZE * 0.99,
      0.32,
      TOWN_TILE_WORLD_SIZE * 0.99
    );
    const tileMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.88,
      metalness: 0.06,
    });
    const instancedTiles = new THREE.InstancedMesh(tileGeo, tileMat, tileCount);
    instancedTiles.receiveShadow = true;

    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    let idx = 0;

    const treePositions: [number, number, number][] = [];
    const riverTiles: [number, number, number][] = [];

    for (let x = 0; x < gridW; x++) {
      for (let z = 0; z < gridD; z++) {
        const t = activeGrid[x][z];
        const [wx, wy, wz] = tileToWorld(x, z, gridW, gridD, t.elevation);
        dummy.position.set(wx, wy - 0.16, wz);
        dummy.scale.set(1, t.terrain === 'wall_stone' ? 7.5 : 1, 1);
        if (t.terrain === 'wall_stone') {
          dummy.position.y = 1.05;
        }
        dummy.updateMatrix();
        instancedTiles.setMatrixAt(idx, dummy.matrix);

        if (currentScene !== 'exterior') {
          const theme = GLOAMREST_INTERIORS[currentScene as InteriorId].floorTheme;
          if (t.terrain === 'wall_stone') {
            color.setHex(0x2a2723);
          } else if (theme === 'timber_warm') {
            color.setHex((x + z) % 2 === 0 ? 0x463325 : 0x3f2d20);
          } else if (theme === 'botanical_wood') {
            color.setHex((x + z) % 2 === 0 ? 0x354032 : 0x2f392c);
          } else if (theme === 'astral_vault') {
            color.setHex((x + z) % 2 === 0 ? 0x1e2836 : 0x17202b);
          } else if (theme === 'dusty_ruin') {
            color.setHex((x + z) % 2 === 0 ? 0x2f2b30 : 0x282529);
          } else {
            color.setHex((x + z) % 2 === 0 ? 0x383734 : 0x31302d);
          }
        } else {
          switch (t.terrain) {
            case 'cobble_plaza':
              color.setHex((x + z) % 2 === 0 ? 0x4a463f : 0x423e38);
              break;
            case 'main_road':
              color.setHex((x + z) % 2 === 0 ? 0x464037 : 0x3e3931);
              break;
            case 'dirt_path':
            case 'alley':
              color.setHex(0x473a2c);
              break;
            case 'stone_bridge':
              color.setHex(0x57534e);
              break;
            case 'wooden_bridge':
              color.setHex(0x5c4028);
              break;
            case 'river_water':
              color.setHex(0x163847);
              riverTiles.push([wx, wy + 0.04, wz]);
              break;
            case 'garden_soil':
              color.setHex(0x2d3b24);
              break;
            case 'training_sand':
              color.setHex(0x5c4d38);
              break;
            case 'cemetery_ground':
              color.setHex(0x28302b);
              break;
            case 'wall_stone':
              color.setHex(0x3a3834);
              break;
            case 'rocky_hill':
              color.setHex(0x272a28);
              break;
            case 'forest_floor':
              color.setHex(0x1c2b1f);
              if (!t.walkable || ((x * 17 + z * 31) % 7 === 0 && z > 4 && x < 36)) {
                if ((x * 13 + z * 7) % 3 === 0) {
                  treePositions.push([wx, wy, wz]);
                }
              }
              break;
            default:
              color.setHex((x + z) % 2 === 0 ? 0x263828 : 0x223324);
              if (
                t.walkable &&
                !t.districtId &&
                (x * 19 + z * 23) % 19 === 0
              ) {
                treePositions.push([wx, wy, wz]);
              }
              break;
          }
        }
        instancedTiles.setColorAt(idx, color);
        idx++;
      }
    }
    instancedTiles.instanceMatrix.needsUpdate = true;
    if (instancedTiles.instanceColor) instancedTiles.instanceColor.needsUpdate = true;
    scene.add(instancedTiles);

    // Invisible click plane for smooth raycasting
    const clickPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(gridW * TOWN_TILE_WORLD_SIZE, gridD * TOWN_TILE_WORLD_SIZE),
      new THREE.MeshBasicMaterial({ visible: false })
    );
    clickPlane.rotation.x = -Math.PI / 2;
    scene.add(clickPlane);

    // 4. Exterior Landmarks, River Shimmer, Woodland Pines & Buildings OR Interior Props
    let wellGlowMesh: THREE.Mesh | null = null;
    let wellPointLight: THREE.PointLight | null = null;
    const lanternLights: THREE.PointLight[] = [];
    const barricadeGroup = new THREE.Group();
    scene.add(barricadeGroup);

    if (currentScene === 'exterior') {
      // Woodland Pine Trees (Instanced)
      if (treePositions.length > 0) {
        const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3f2b1d, roughness: 0.9 });
        const foliageMat = new THREE.MeshStandardMaterial({ color: 0x1b3b26, roughness: 0.85 });
        const trunks = new THREE.InstancedMesh(
          new THREE.CylinderGeometry(0.18, 0.26, 1.5, 6),
          trunkMat,
          treePositions.length
        );
        const crowns = new THREE.InstancedMesh(
          new THREE.ConeGeometry(1.15, 3.2, 7),
          foliageMat,
          treePositions.length
        );
        crowns.castShadow = true;
        treePositions.forEach(([tx, ty, tz], i) => {
          const s = 0.85 + ((i * 37) % 35) / 100;
          dummy.position.set(tx, ty + 0.75 * s, tz);
          dummy.scale.set(s, s, s);
          dummy.updateMatrix();
          trunks.setMatrixAt(i, dummy.matrix);

          dummy.position.set(tx, ty + 2.5 * s, tz);
          dummy.scale.set(s, s, s);
          dummy.updateMatrix();
          crowns.setMatrixAt(i, dummy.matrix);
        });
        scene.add(trunks, crowns);
      }

      // Buildings
      for (const bldg of BUILDING_EXTERIORS) {
        scene.add(buildExteriorBuildingGroup(bldg, gridW, gridD));
      }

      // Hearth Square Central Landmark: Ancient Circular Stone Well (24, 25)
      const [wellX, , wellZ] = tileToWorld(24, 25, gridW, gridD);
      const wellGroup = new THREE.Group();
      wellGroup.position.set(wellX, 0, wellZ);
      const wellRim = new THREE.Mesh(
        new THREE.CylinderGeometry(1.15, 1.25, 0.95, 18),
        new THREE.MeshStandardMaterial({ color: 0x57534e, roughness: 0.85 })
      );
      wellRim.position.y = 0.48;
      wellRim.castShadow = true;
      wellGlowMesh = new THREE.Mesh(
        new THREE.CircleGeometry(0.88, 18),
        new THREE.MeshStandardMaterial({
          color: 0x38bdf8,
          emissive: 0x0284c7,
          emissiveIntensity: 0.45,
          roughness: 0.15,
        })
      );
      wellGlowMesh.rotation.x = -Math.PI / 2;
      wellGlowMesh.position.y = 0.78;
      const wellRoof = new THREE.Mesh(
        new THREE.ConeGeometry(1.35, 1.0, 4),
        new THREE.MeshStandardMaterial({ color: 0x3b2c20, roughness: 0.85 })
      );
      wellRoof.rotation.y = Math.PI / 4;
      wellRoof.position.y = 2.45;
      for (const sx of [-0.85, 0.85]) {
        const post = new THREE.Mesh(
          new THREE.BoxGeometry(0.14, 1.6, 0.14),
          new THREE.MeshStandardMaterial({ color: 0x2e2118 })
        );
        post.position.set(sx, 1.45, 0);
        wellGroup.add(post);
      }
      wellPointLight = new THREE.PointLight(0x38bdf8, 0.8, 11);
      wellPointLight.position.set(0, 1.4, 0);
      wellGroup.add(wellRim, wellGlowMesh, wellRoof, wellPointLight);
      scene.add(wellGroup);

      // Market Stall Canopy in Hearth Square (21, 26)
      const [stallX, , stallZ] = tileToWorld(20, 26, gridW, gridD);
      const stallCanopy = new THREE.Mesh(
        new THREE.BoxGeometry(2.4, 0.22, 1.8),
        new THREE.MeshStandardMaterial({ color: 0x7c5832, roughness: 0.8 })
      );
      stallCanopy.position.set(stallX, 2.2, stallZ);
      scene.add(stallCanopy);

      // Street Lantern Posts along Hearth Square, Bridges & Whispering Gate
      const lanternCoords: [number, number][] = [
        [22, 22],
        [27, 22],
        [22, 28],
        [27, 28],
        [15, 25],
        [29, 24],
        [36, 8],
        [24, 41],
      ];
      const postMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.6 });
      const bulbMat = new THREE.MeshStandardMaterial({
        color: 0xfde68a,
        emissive: 0xf59e0b,
        emissiveIntensity: 1.35,
      });
      lanternCoords.forEach(([lx, lz], i) => {
        const [wx, , wz] = tileToWorld(lx, lz, gridW, gridD);
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 2.5, 6), postMat);
        post.position.set(wx, 1.25, wz);
        const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.35, 0.28), bulbMat);
        bulb.position.set(wx, 2.55, wz);
        scene.add(post, bulb);
        if (i < 5) {
          const pLight = new THREE.PointLight(0xf59e0b, 1.3, 14);
          pLight.position.set(wx, 2.8, wz);
          scene.add(pLight);
          lanternLights.push(pLight);
        }
      });

      // Threat-Reactive Gate Barricades (visible once MQ03 / town threat rises!)
      const spikeMat = new THREE.MeshStandardMaterial({ color: 0x5c4028, roughness: 0.85 });
      for (const [bx, bz] of [
        [36, 6],
        [40, 6],
        [27, 14],
      ]) {
        const [wx, , wz] = tileToWorld(bx, bz, gridW, gridD);
        const stake = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.1, 0.5), spikeMat);
        stake.position.set(wx, 0.55, wz);
        stake.rotation.x = -0.35;
        barricadeGroup.add(stake);
      }
    } else {
      // Interior Furniture Props & Warm Hearth Point Light
      const interiorDef = GLOAMREST_INTERIORS[currentScene as InteriorId];
      for (const prop of interiorDef.props) {
        scene.add(buildInteriorFurnitureMesh(prop, gridW, gridD));
      }
      const roomLightColor =
        interiorDef.ambientPreset === 'basement'
          ? 0x38bdf8
          : interiorDef.ambientPreset === 'forge'
          ? 0xf97316
          : 0xfbbf24;
      const roomLight = new THREE.PointLight(roomLightColor, 2.1, 26);
      roomLight.position.set(0, 4.5, 0);
      scene.add(roomLight);
    }

    // 5. Interactive Object Markers & Props Group
    const objectMarkersGroup = new THREE.Group();
    scene.add(objectMarkersGroup);
    const objectMeshMap = new Map<
      string,
      { group: THREE.Group; ring: THREE.Mesh; hitMesh: THREE.Mesh }
    >();

    // Cache interactive objects to eliminate per-frame allocations in 60-360fps loops
    let cachedSceneInteractiveObjects = getSceneInteractiveObjects(stateRef.current);

    const rebuildInteractiveObjects = () => {
      while (objectMarkersGroup.children.length > 0) {
        objectMarkersGroup.remove(objectMarkersGroup.children[0]);
      }
      objectMeshMap.clear();

      cachedSceneInteractiveObjects = getSceneInteractiveObjects(stateRef.current);
      const liveObjects = cachedSceneInteractiveObjects;
      for (const obj of liveObjects) {
        const grp = new THREE.Group();
        const [wx, , wz] = tileToWorld(obj.x, obj.z, gridW, gridD);
        grp.position.set(wx, 0, wz);

        const isHarvested = stateRef.current.lootedOrHarvestedIds.includes(obj.id);
        const isDoor =
          obj.kind === 'door_enter' ||
          obj.kind === 'door_exit' ||
          obj.kind === 'secret_stairs' ||
          obj.kind === 'wilderness_gate';

        const ringColor = isDoor
          ? 0xe2b05a
          : obj.kind === 'herb_patch' || obj.kind === 'blight_herb_patch'
          ? 0x4ade80
          : 0x93c5fd;

        const ring = new THREE.Mesh(
          new THREE.RingGeometry(0.45, 0.64, 24),
          new THREE.MeshBasicMaterial({
            color: ringColor,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: isHarvested ? 0.06 : 0.42,
            depthWrite: false,
          })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.y = 0.04;
        grp.add(ring);

        // Distinct 3D prop for interactive world objects
        let visualProp: THREE.Mesh;
        if (obj.kind === 'herb_patch' || obj.kind === 'blight_herb_patch') {
          visualProp = new THREE.Mesh(
            new THREE.ConeGeometry(0.38, isHarvested ? 0.12 : 0.55, 7),
            new THREE.MeshStandardMaterial({
              color: obj.kind === 'blight_herb_patch' ? 0x38bdf8 : 0x22c55e,
              emissive: obj.kind === 'blight_herb_patch' ? 0x1d4ed8 : 0x14532d,
              emissiveIntensity: isHarvested ? 0.05 : 0.55,
            })
          );
          visualProp.position.y = 0.28;
        } else if (
          obj.kind === 'chest' ||
          obj.kind === 'roadside_cache' ||
          obj.kind === 'garden_crypt'
        ) {
          visualProp = new THREE.Mesh(
            new THREE.BoxGeometry(0.85, 0.58, 0.58),
            new THREE.MeshStandardMaterial({
              color: isHarvested ? 0x3f3f46 : 0x78472a,
              metalness: 0.35,
              roughness: 0.65,
            })
          );
          visualProp.position.y = 0.3;
        } else if (obj.kind === 'damaged_cart') {
          visualProp = new THREE.Mesh(
            new THREE.BoxGeometry(1.75, 0.72, 1.15),
            new THREE.MeshStandardMaterial({ color: 0x5c3d28, roughness: 0.85 })
          );
          visualProp.rotation.z = 0.18;
          visualProp.position.y = 0.45;
        } else if (obj.kind === 'training_dummy') {
          visualProp = new THREE.Mesh(
            new THREE.CylinderGeometry(0.28, 0.22, 1.55, 8),
            new THREE.MeshStandardMaterial({ color: 0x7c5836, roughness: 0.8 })
          );
          visualProp.position.y = 0.78;
        } else if (obj.kind === 'movable_barrel') {
          visualProp = new THREE.Mesh(
            new THREE.CylinderGeometry(0.42, 0.42, 0.88, 12),
            new THREE.MeshStandardMaterial({ color: 0x6b4226, roughness: 0.78 })
          );
          visualProp.position.y = 0.44;
        } else if (obj.kind === 'notice_board') {
          visualProp = new THREE.Mesh(
            new THREE.BoxGeometry(1.15, 1.45, 0.16),
            new THREE.MeshStandardMaterial({ color: 0x6b4c32, roughness: 0.8 })
          );
          visualProp.position.y = 0.85;
        } else {
          // Subtle glowing diamond beacon for doors, stairs, clues, altars
          visualProp = new THREE.Mesh(
            new THREE.OctahedronGeometry(0.22, 0),
            new THREE.MeshStandardMaterial({
              color: 0xe2b05a,
              emissive: 0xd97706,
              emissiveIntensity: 0.85,
            })
          );
          visualProp.position.y = 1.05;
        }
        visualProp.userData = { interactKind: 'object', interactId: obj.id };
        grp.add(visualProp);

        // Generous invisible hit cylinder for effortless clicking
        const hitMesh = new THREE.Mesh(
          new THREE.CylinderGeometry(0.85, 0.85, 2.2, 8),
          new THREE.MeshBasicMaterial({ visible: false })
        );
        hitMesh.position.y = 1.1;
        hitMesh.userData = { interactKind: 'object', interactId: obj.id };
        grp.add(hitMesh);

        objectMarkersGroup.add(grp);
        objectMeshMap.set(obj.id, { group: grp, ring, hitMesh });
      }
    };
    rebuildInteractiveObjects();

    // 6. Player Commander Mesh
    const isWarriorOrPaladin =
      characterBuild.classId === 'paladin' ||
      (characterBuild as any).classId === 'warrior' ||
      (characterBuild as any).archetypeId === 'warrior';

    const playerPrimaryHex = isWarriorOrPaladin
      ? 0x475569
      : characterBuild.classId === 'arcanist'
      ? 0x6b1d24
      : 0x1e462b;
    const playerHeldProp = isWarriorOrPaladin
      ? 'sword_shield'
      : characterBuild.classId === 'arcanist'
      ? 'staff'
      : 'bow';
    const playerRig = buildTownHumanoidMesh({
      primaryHex: playerPrimaryHex,
      secondaryHex: 0x5a4b38,
      accentHex: 0xe2b05a,
      skinHex: 0xe0bfa8,
      hairHex: 0xd8d0c5,
      headgear: 'elder_circlet',
      heldProp: playerHeldProp,
      ringColorHex: 0xe2b05a,
    });
    (playerRig.ringMesh.material as THREE.MeshBasicMaterial).opacity = 0.72;
    scene.add(playerRig.root);

    // 7. Scheduled NPCs in Current Scene
    const npcGroup = new THREE.Group();
    scene.add(npcGroup);
    const npcRigs = new Map<
      string,
      {
        npc: GloamrestNpcDefinition;
        root: THREE.Group;
        bodyGroup: THREE.Group;
        ringMesh: THREE.Mesh;
        hitMesh: THREE.Mesh;
        curX: number;
        curZ: number;
        targetX: number;
        targetZ: number;
      }
    >();

    const syncNpcsForTime = (walkTick: number) => {
      const scheduled = getActiveSceneNpcs(stateRef.current, walkTick);
      const activeIds = new Set(scheduled.map((s) => s.npc.id));

      for (const [id, rig] of npcRigs.entries()) {
        if (!activeIds.has(id)) {
          npcGroup.remove(rig.root);
          npcRigs.delete(id);
        }
      }

      for (const entry of scheduled) {
        const existing = npcRigs.get(entry.npc.id);
        if (existing) {
          existing.targetX = entry.x;
          existing.targetZ = entry.z;
        } else {
          const built = buildTownHumanoidMesh({
            ...entry.npc.visual,
            ringColorHex: entry.npc.isCompanion ? 0x38bdf8 : 0x7e9c82,
          });
          const hitMesh = new THREE.Mesh(
            new THREE.CylinderGeometry(0.8, 0.8, 2.3, 8),
            new THREE.MeshBasicMaterial({ visible: false })
          );
          hitMesh.position.y = 1.15;
          hitMesh.userData = { interactKind: 'npc', interactId: entry.npc.id };
          built.root.add(hitMesh);

          const [wx, , wz] = tileToWorld(entry.x, entry.z, gridW, gridD);
          built.root.position.set(wx, 0, wz);
          npcGroup.add(built.root);
          npcRigs.set(entry.npc.id, {
            npc: entry.npc,
            root: built.root,
            bodyGroup: built.bodyGroup,
            ringMesh: built.ringMesh,
            hitMesh,
            curX: entry.x,
            curZ: entry.z,
            targetX: entry.x,
            targetZ: entry.z,
          });
        }
      }
    };
    syncNpcsForTime(0);

    // Periodic NPC schedule patrol waypoint ticker (every 4.5s)
    let walkTick = 0;
    const scheduleTicker = window.setInterval(() => {
      walkTick++;
      syncNpcsForTime(walkTick);
      rebuildInteractiveObjects();
    }, 4500);

    // 8. Keyboard & Pointer Input Listeners
    const onKeyDown = (e: KeyboardEvent) => {
      if (modalOpenRef.current) {
        pressedKeysRef.current.clear();
        return;
      }
      if (
        e.code === 'KeyW' ||
        e.code === 'KeyA' ||
        e.code === 'KeyS' ||
        e.code === 'KeyD' ||
        e.code === 'ArrowUp' ||
        e.code === 'ArrowDown' ||
        e.code === 'ArrowLeft' ||
        e.code === 'ArrowRight'
      ) {
        pressedKeysRef.current.add(e.code);
        pathQueueRef.current = [];
        pendingArrivalActionRef.current = null;
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      pressedKeysRef.current.delete(e.code);
    };

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const onPointerDown = (ev: MouseEvent) => {
      if (modalOpenRef.current || ev.button !== 0) return;
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      // Check NPC & Interactive Object hits first
      const interactHits: THREE.Object3D[] = [];
      npcRigs.forEach((r) => interactHits.push(r.hitMesh));
      objectMeshMap.forEach((o) => interactHits.push(o.hitMesh));

      const hitInteract = raycaster.intersectObjects(interactHits, false)[0];
      if (hitInteract) {
        const { interactKind, interactId } = hitInteract.object.userData as {
          interactKind: 'npc' | 'object';
          interactId: string;
        };
        let tx = Math.round(livePosRef.current.x);
        let tz = Math.round(livePosRef.current.z);

        if (interactKind === 'npc') {
          const rig = npcRigs.get(interactId);
          if (rig) {
            tx = Math.round(rig.curX);
            tz = Math.round(rig.curZ);
          }
        } else {
          const obj = getSceneInteractiveObjects(stateRef.current).find(
            (o) => o.id === interactId
          );
          if (obj) {
            tx = obj.x;
            tz = obj.z;
          }
        }

        const dist = Math.hypot(livePosRef.current.x - tx, livePosRef.current.z - tz);
        if (dist <= 2.35) {
          if (interactKind === 'npc') {
            callbacksRef.current.onInteractNpc(interactId);
          } else {
            callbacksRef.current.onInteractObject(interactId);
            window.setTimeout(rebuildInteractiveObjects, 60);
          }
          return;
        }

        // Otherwise pathfind right up to the clicked NPC or Object and interact on arrival!
        const path = findTownPath(
          activeGrid,
          Math.round(livePosRef.current.x),
          Math.round(livePosRef.current.z),
          tx,
          tz
        );
        if (path.length > 0) {
          pathQueueRef.current = path;
          pendingArrivalActionRef.current = { type: interactKind, id: interactId };
        }
        return;
      }

      // Otherwise click-to-move on ground plane
      const groundHit = raycaster.intersectObject(clickPlane, false)[0];
      if (groundHit) {
        const gx = Math.round(
          groundHit.point.x / TOWN_TILE_WORLD_SIZE + (gridW - 1) / 2
        );
        const gz = Math.round(
          groundHit.point.z / TOWN_TILE_WORLD_SIZE + (gridD - 1) / 2
        );
        if (gx >= 0 && gx < gridW && gz >= 0 && gz < gridD) {
          const path = findTownPath(
            activeGrid,
            Math.round(livePosRef.current.x),
            Math.round(livePosRef.current.z),
            gx,
            gz
          );
          if (path.length > 0) {
            pathQueueRef.current = path;
            pendingArrivalActionRef.current = null;
          }
        }
      }
    };

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    renderer.domElement.addEventListener('mousedown', onPointerDown);
    window.addEventListener('resize', onResize);

    // 9. Main 60fps to 360fps High-Refresh Simulation & Render Loop
    let rafId = 0;
    let prevTime = performance.now();

    // Pre-allocated scratch objects to ensure zero memory allocations during 60-360fps loops
    const _desiredCamPos = new THREE.Vector3();
    const _sceneBgColor = new THREE.Color(0x161d19);
    scene.background = _sceneBgColor;
    let lastAtmosphereKey = '';

    const canStandOn = (nx: number, nz: number): boolean => {
      const rx = Math.round(nx);
      const rz = Math.round(nz);
      if (rx < 0 || rx >= gridW || rz < 0 || rz >= gridD) return false;
      if (!activeGrid[rx]?.[rz]?.walkable) return false;
      const blockingObj = cachedSceneInteractiveObjects.some(
        (o) => o.blocksMovement && o.x === rx && o.z === rz
      );
      return !blockingObj;
    };

    let disposed = false;
    function afterDraw(cb: (t: number) => void) {
      if (disposed) return;
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          rafId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          rafId = window.setTimeout(() => cb(performance.now()), 80);
        }
      };
      rafId = window.setTimeout(poll, 5);
    }

    const animate = (now: number) => {
      if (disposed) return;

      // Frame Rate Target Throttle (supports Native VRR, 60, 120, 144, 240, 360, Uncapped)
      if (performanceManager.shouldThrottle(now, prevTime)) {
        if (isSoftwareGl) {
          afterDraw(animate);
        } else {
          rafId = window.requestAnimationFrame(animate);
        }
        return;
      }
      performanceManager.recordFrame(now);

      const dt = clampDeltaTime((now - prevTime) / 1000, 0.05);
      prevTime = now;
      const elapsed = now * 0.001;

      const curState = stateRef.current;

      // Update Atmosphere per TimeOfDay & ThreatPhase (cached to eliminate per-frame allocations)
      if (currentScene === 'exterior') {
        const tod = curState.timeOfDay;
        const threat = curState.townThreatPhase;
        const atmoKey = `${tod}_${threat}`;
        if (atmoKey !== lastAtmosphereKey) {
          lastAtmosphereKey = atmoKey;
          if (tod === 'morning') {
            sunLight.intensity = 1.3;
            sunLight.color.setHex(0xfde68a);
            hemiLight.intensity = 0.78;
            _sceneBgColor.setHex(0x161d19);
            fog.color.setHex(0x18211c);
            fog.density = threat === 'fortified' ? 0.016 : 0.01;
          } else if (tod === 'afternoon') {
            sunLight.intensity = 1.45;
            sunLight.color.setHex(0xfef3c7);
            hemiLight.intensity = 0.85;
            _sceneBgColor.setHex(0x19201c);
            fog.color.setHex(0x1b231e);
            fog.density = threat === 'fortified' ? 0.015 : 0.009;
          } else if (tod === 'evening') {
            sunLight.intensity = 0.85;
            sunLight.color.setHex(0xf59e0b);
            hemiLight.intensity = 0.55;
            _sceneBgColor.setHex(0x131618);
            fog.color.setHex(0x15181b);
            fog.density = threat === 'fortified' ? 0.018 : 0.013;
          } else {
            sunLight.intensity = 0.36;
            sunLight.color.setHex(0x60a5fa);
            hemiLight.intensity = 0.38;
            _sceneBgColor.setHex(0x0b0f14);
            fog.color.setHex(0x0c1117);
            fog.density = threat === 'fortified' ? 0.02 : 0.015;
          }
          barricadeGroup.visible = threat !== 'peaceful';
        }

        if (wellGlowMesh && wellPointLight) {
          const resonanceBoost =
            threat === 'astral_resonance' || threat === 'fortified' ? 1.8 : 0.55;
          const nightBoost = tod === 'night' || tod === 'evening' ? 1.35 : 0.8;
          wellPointLight.intensity =
            resonanceBoost * nightBoost + Math.sin(elapsed * 2.8) * 0.25;
          (wellGlowMesh.material as THREE.MeshStandardMaterial).emissiveIntensity =
            0.35 + resonanceBoost * 0.65;
        }
      }

      // Player Movement (8-Directional Normalized Locomotion & Diagonal Corner Prevention)
      let isMoving = false;
      let isRunning = false;
      let speed = 5.4; // tiles per second (~10.8 world units/sec)

      if (!modalOpenRef.current) {
        const inputState = resolve8DirectionalInput(pressedKeysRef.current);
        if (inputState.isMoving) {
          isRunning = inputState.isRunning;
          speed = isRunning ? 7.6 : 5.4;
          const vx = inputState.moveX * speed * dt;
          const vz = inputState.moveZ * speed * dt;

          let movedX = 0;
          let movedZ = 0;

          if (inputState.rawX !== 0 && inputState.rawZ !== 0) {
            // Diagonal movement: corner-cutting and destination validation
            const canMoveDiag =
              canStandOn(livePosRef.current.x + vx, livePosRef.current.z + vz) &&
              canStandOn(livePosRef.current.x + vx, livePosRef.current.z) &&
              canStandOn(livePosRef.current.x, livePosRef.current.z + vz);

            if (canMoveDiag) {
              livePosRef.current.x += vx;
              livePosRef.current.z += vz;
              movedX = vx;
              movedZ = vz;
              isMoving = true;
            } else {
              // Wall sliding: check if one orthogonal axis is open
              if (canStandOn(livePosRef.current.x + vx, livePosRef.current.z)) {
                livePosRef.current.x += vx;
                movedX = vx;
                isMoving = true;
              }
              if (canStandOn(livePosRef.current.x, livePosRef.current.z + vz)) {
                livePosRef.current.z += vz;
                movedZ = vz;
                isMoving = true;
              }
            }
          } else {
            // Orthogonal movement
            if (canStandOn(livePosRef.current.x + vx, livePosRef.current.z + vz)) {
              livePosRef.current.x += vx;
              livePosRef.current.z += vz;
              movedX = vx;
              movedZ = vz;
              isMoving = true;
            }
          }

          if (movedX !== 0 || movedZ !== 0) {
            targetFacingRef.current = Math.atan2(movedX, movedZ);
          }
        }
      }

      if (!isMoving && !modalOpenRef.current && pathQueueRef.current.length > 0) {
        const nextWp = pathQueueRef.current[0];
        const dx = nextWp.x - livePosRef.current.x;
        const dz = nextWp.z - livePosRef.current.z;
        const dist = Math.hypot(dx, dz);
        if (dist <= speed * dt * 1.15) {
          livePosRef.current.x = nextWp.x;
          livePosRef.current.z = nextWp.z;
          pathQueueRef.current.shift();
          isMoving = true;

          if (pathQueueRef.current.length === 0 && pendingArrivalActionRef.current) {
            const act = pendingArrivalActionRef.current;
            pendingArrivalActionRef.current = null;
            if (act.type === 'npc') {
              callbacksRef.current.onInteractNpc(act.id);
            } else {
              callbacksRef.current.onInteractObject(act.id);
              window.setTimeout(rebuildInteractiveObjects, 60);
            }
          }
        } else {
          const moveStep = Math.min(dist, speed * dt);
          livePosRef.current.x += (dx / dist) * moveStep;
          livePosRef.current.z += (dz / dist) * moveStep;
          targetFacingRef.current = Math.atan2(dx, dz);
          isMoving = true;
        }
      }

      if (isMoving) {
        footstepTimerRef.current += dt;
        const footstepInterval = isRunning ? 0.22 : 0.34;
        if (footstepTimerRef.current >= footstepInterval) {
          footstepTimerRef.current = 0;
          soundEngine.playFootstep();
        }
      }

      // Smooth shortest-arc rotation towards target movement facing
      livePosRef.current.facing = smoothRotateAngle(
        livePosRef.current.facing,
        targetFacingRef.current,
        14.0,
        dt
      );

      // Report rounded tile changes back to React state cleanly
      const rx = Math.round(livePosRef.current.x);
      const rz = Math.round(livePosRef.current.z);
      const tileKey = `${rx},${rz}`;
      if (tileKey !== lastReportedTileRef.current) {
        lastReportedTileRef.current = tileKey;
        callbacksRef.current.onPlayerMove(rx, rz, livePosRef.current.facing);
      }

      // Position Player Mesh & Apply 8-Directional Warrior Stance
      const curElev = activeGrid[rx]?.[rz]?.elevation ?? 0;
      const [pwx, pwy, pwz] = tileToWorld(
        livePosRef.current.x,
        livePosRef.current.z,
        gridW,
        gridD,
        curElev
      );

      const stance = computeWarrior8DirStance(
        livePosRef.current.facing,
        isMoving,
        isRunning,
        elapsed,
        speed / 5.4
      );

      playerRig.root.position.set(pwx, pwy, pwz);
      playerRig.bodyGroup.rotation.y = livePosRef.current.facing;
      playerRig.bodyGroup.rotation.x = stance.torsoPitch;
      playerRig.bodyGroup.rotation.z = stance.torsoRoll;
      playerRig.bodyGroup.position.y = stance.bodyBobY;

      playerRig.legL.rotation.x = stance.legLeftRotX;
      playerRig.legR.rotation.x = stance.legRightRotX;

      if (playerRig.bladeGroup) {
        playerRig.bladeGroup.position.set(...stance.swordPos);
        playerRig.bladeGroup.rotation.set(...stance.swordRot);
      }
      if (playerRig.shieldGroup) {
        playerRig.shieldGroup.position.set(...stance.shieldPos);
        playerRig.shieldGroup.rotation.set(...stance.shieldRot);
      }

      // Update Scheduled NPCs (Smooth walk between patrol waypoints + face nearby player)
      let nearestPrompt: NearbyInteractionPrompt | null = null;
      let nearestDist = 2.35;

      npcRigs.forEach((rig) => {
        const ndx = rig.targetX - rig.curX;
        const ndz = rig.targetZ - rig.curZ;
        const ndist = Math.hypot(ndx, ndz);
        const npcMoving = ndist > 0.04;
        if (npcMoving) {
          const step = Math.min(ndist, 1.8 * dt);
          rig.curX += (ndx / ndist) * step;
          rig.curZ += (ndz / ndist) * step;
          rig.bodyGroup.rotation.y = Math.atan2(ndx, ndz);
        } else {
          // Gently face player when nearby
          const pdx = livePosRef.current.x - rig.curX;
          const pdz = livePosRef.current.z - rig.curZ;
          if (Math.hypot(pdx, pdz) < 3.5) {
            rig.bodyGroup.rotation.y = Math.atan2(pdx, pdz);
          }
        }

        const nElev =
          activeGrid[Math.round(rig.curX)]?.[Math.round(rig.curZ)]?.elevation ?? 0;
        const [nwx, nwy, nwz] = tileToWorld(rig.curX, rig.curZ, gridW, gridD, nElev);
        rig.root.position.set(nwx, nwy, nwz);
        rig.bodyGroup.position.y = npcMoving
          ? Math.abs(Math.sin(elapsed * 7.5)) * 0.08
          : Math.sin(elapsed * 2.0 + rig.curX) * 0.03;

        const dToPlayer = Math.hypot(
          livePosRef.current.x - rig.curX,
          livePosRef.current.z - rig.curZ
        );
        const isClosest = dToPlayer < nearestDist;
        (rig.ringMesh.material as THREE.MeshBasicMaterial).opacity =
          dToPlayer < 2.35 ? 0.85 : 0.24;

        if (isClosest) {
          nearestDist = dToPlayer;
          nearestPrompt = {
            kind: 'npc',
            id: rig.npc.id,
            name: rig.npc.name,
            promptLabel: `Speak with ${rig.npc.name} [E]`,
            roleOrSubtitle: rig.npc.role,
          };
        }
      });

      // Check proximity to Interactive Objects using cached objects (zero memory allocation)
      for (const obj of cachedSceneInteractiveObjects) {
        const entry = objectMeshMap.get(obj.id);
        if (entry) {
          entry.group.children.forEach((ch) => {
            if (ch !== entry.ring && ch !== entry.hitMesh && obj.kind.includes('door')) {
              ch.rotation.y = elapsed * 1.4;
            }
          });
        }
        const dObj = Math.hypot(livePosRef.current.x - obj.x, livePosRef.current.z - obj.z);
        if (entry) {
          (entry.ring.material as THREE.MeshBasicMaterial).opacity =
            dObj < 2.35 ? 0.9 : 0.35;
        }
        if (dObj < nearestDist) {
          nearestDist = dObj;
          nearestPrompt = {
            kind: 'object',
            id: obj.id,
            name: obj.name,
            promptLabel: obj.promptLabel,
          };
        }
      }

      const promptKey = nearestPrompt
        ? `${nearestPrompt.kind}:${nearestPrompt.id}`
        : '';
      if (promptKey !== lastPromptKeyRef.current) {
        lastPromptKeyRef.current = promptKey;
        callbacksRef.current.onNearbyPromptChange(nearestPrompt);
      }

      // Smooth Isometric Follow Camera with Frame-Rate Independent Exponential Dampening
      const preset = cameraPresetRef.current;
      const offsetScale =
        currentScene !== 'exterior'
          ? preset === 'close'
            ? 0.72
            : 0.88
          : preset === 'close'
          ? 0.72
          : preset === 'overhead'
          ? 1.42
          : 1.0;

      _desiredCamPos.set(
        pwx + 15.5 * offsetScale,
        pwy + 18.5 * offsetScale,
        pwz + 15.5 * offsetScale
      );
      const camDamp = exponentialDamp(7.5, dt);
      camera.position.lerp(_desiredCamPos, camDamp);
      camera.lookAt(pwx, pwy + 0.9, pwz);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(animate);
      } else {
        rafId = window.requestAnimationFrame(animate);
      }
    };

    rafId = window.requestAnimationFrame(animate);

    return () => {
      disposed = true;
      window.cancelAnimationFrame(rafId);
      window.clearTimeout(rafId);
      window.clearInterval(scheduleTicker);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      renderer.domElement.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
    };
  }, [gloamrestState.currentSceneId, characterBuild.classId]);

  return (
    <div
      ref={containerRef}
      data-testid="gloamrest-3d-viewport"
      data-scene={gloamrestState.currentSceneId}
      className="fixed inset-0 z-0 w-screen h-screen overflow-hidden cursor-pointer"
    />
  );
};
