import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { SkillDetailViewModel } from '../game/skillSystemUi';

interface SkillTooltipAnchorProps {
  detail: SkillDetailViewModel;
  delayMs?: number;
  disabled?: boolean;
  placement?: 'top' | 'right';
  children: React.ReactNode;
  className?: string;
}

export const SkillTooltipAnchor: React.FC<SkillTooltipAnchorProps> = ({
  detail,
  delayMs = 140,
  disabled = false,
  placement = 'top',
  children,
  className = '',
}) => {
  const anchorRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number | null>(null);
  const [visible, setVisible] = useState(false);
  const [coords, setCoords] = useState<{ left: number; top: number }>({ left: 16, top: 16 });

  const clearTimer = () => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  useEffect(() => {
    if (disabled) {
      clearTimer();
      setVisible(false);
    }
    return clearTimer;
  }, [disabled]);

  const handleEnter = () => {
    if (disabled) return;
    clearTimer();
    timerRef.current = window.setTimeout(() => {
      setVisible(true);
    }, delayMs);
  };

  const handleLeave = () => {
    clearTimer();
    setVisible(false);
  };

  useLayoutEffect(() => {
    if (!visible || !anchorRef.current || !tooltipRef.current) return;
    const aRect = anchorRef.current.getBoundingClientRect();
    const tRect = tooltipRef.current.getBoundingClientRect();
    const margin = 12;

    let left = aRect.left + aRect.width / 2 - tRect.width / 2;
    let top = aRect.top - tRect.height - 10;

    if (placement === 'right') {
      left = aRect.right + 10;
      top = aRect.top + aRect.height / 2 - tRect.height / 2;
      if (left + tRect.width > window.innerWidth - margin) {
        left = aRect.left - tRect.width - 10;
      }
    } else if (top < margin) {
      top = aRect.bottom + 10;
    }

    left = Math.max(margin, Math.min(window.innerWidth - tRect.width - margin, left));
    top = Math.max(margin, Math.min(window.innerHeight - tRect.height - margin, top));

    setCoords({ left, top });
  }, [visible, placement, detail.entry.ability.id, detail.slotEvaluation.state]);

  const { entry, slotEvaluation, combatStats } = detail;
  const { ability } = entry;
  const damageStat = combatStats.find((s) => s.label === 'Damage' || s.label === 'Healing');
  const targetStat = combatStats.find((s) => s.label === 'Target');

  return (
    <div
      ref={anchorRef}
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
      onFocus={handleEnter}
      onBlur={handleLeave}
      className={className}
    >
      {children}
      {visible &&
        typeof document !== 'undefined' &&
        createPortal(
          <div
            ref={tooltipRef}
            role="tooltip"
            data-testid={`skill-tooltip-${ability.id}`}
            style={{
              left: `${coords.left}px`,
              top: `${coords.top}px`,
              backgroundColor: '#171B19',
              borderColor: '#E2B05A',
              color: '#F2ECE1',
            }}
            className="fixed z-[90] w-[284px] rounded-md border px-3.5 py-3 shadow-[0_14px_34px_rgba(0,0,0,0.88)] pointer-events-none select-none"
          >
            {/* 1 & 2: Skill Name & Skill Category */}
            <div className="flex items-start justify-between gap-2 pb-2 border-b border-[#5A4B38]/75">
              <div className="min-w-0">
                <p
                  className="font-display font-bold text-sm leading-snug"
                  style={{ color: '#F2ECE1' }}
                >
                  {ability.name}
                </p>
                <p
                  className="text-[11px] uppercase tracking-wider font-medium mt-0.5"
                  style={{ color: '#E2B05A' }}
                >
                  {entry.primaryCategoryLabel} · {entry.specialtyLabel}
                </p>
              </div>
              {entry.equippedSlotKey && (
                <span
                  className="font-mono text-[11px] px-1.5 py-0.5 rounded border shrink-0"
                  style={{
                    backgroundColor: '#222722',
                    borderColor: '#5A4B38',
                    color: '#E2B05A',
                  }}
                >
                  [{entry.equippedSlotKey}]
                </span>
              )}
            </div>

            {/* 3, 4, 5: AP Cost, Cooldown, Range & Required Target */}
            <div className="grid grid-cols-3 gap-1.5 py-2 border-b border-[#5A4B38]/60 font-mono text-xs tabular-nums">
              <div>
                <span className="block text-[10px] uppercase" style={{ color: '#77796F' }}>
                  Cost
                </span>
                <span
                  className="font-bold"
                  style={{
                    color:
                      slotEvaluation.state === 'insufficient_ap' ? '#B85349' : '#E2B05A',
                  }}
                >
                  ◆ {ability.apCost} AP
                </span>
              </div>
              <div>
                <span className="block text-[10px] uppercase" style={{ color: '#77796F' }}>
                  Cooldown
                </span>
                <span
                  className="font-semibold"
                  style={{
                    color: slotEvaluation.cooldownRemaining > 0 ? '#B85349' : '#F2ECE1',
                  }}
                >
                  {slotEvaluation.cooldownRemaining > 0
                    ? `${slotEvaluation.cooldownRemaining}t Left`
                    : ability.cooldown > 0
                    ? `${ability.cooldown} Turns`
                    : 'At-Will'}
                </span>
              </div>
              <div>
                <span className="block text-[10px] uppercase" style={{ color: '#77796F' }}>
                  Range
                </span>
                <span
                  className="font-semibold"
                  style={{
                    color: slotEvaluation.state === 'out_of_range' ? '#E2B05A' : '#F2ECE1',
                  }}
                >
                  {ability.targetType === 'self' ? 'Self' : `${ability.range} Tiles`}
                </span>
              </div>
            </div>

            {/* 6: Output & Main Effect + Target */}
            <div className="pt-2 space-y-1.5 text-xs">
              {damageStat && (
                <div className="flex items-baseline justify-between gap-2 font-mono">
                  <span style={{ color: '#B5AC9A' }}>{damageStat.label}:</span>
                  <span
                    className="font-bold text-right"
                    style={{
                      color: damageStat.label === 'Healing' ? '#7E9C82' : '#F2ECE1',
                    }}
                  >
                    {damageStat.value.split(' (')[0]}
                  </span>
                </div>
              )}
              {targetStat && (
                <div className="flex items-baseline justify-between gap-2 font-mono text-[11px]">
                  <span style={{ color: '#B5AC9A' }}>Target:</span>
                  <span style={{ color: '#F2ECE1' }}>{targetStat.value}</span>
                </div>
              )}
              <p className="leading-relaxed pt-0.5" style={{ color: '#B5AC9A' }}>
                {ability.uniqueMechanicLabel ?? ability.roleClue}
              </p>
            </div>

            {/* 7: Restrictions / Availability Explanation */}
            {slotEvaluation.restrictionReason && (
              <div
                className="mt-2.5 pt-2 border-t text-[11px] font-medium leading-snug flex items-start gap-1.5"
                style={{
                  borderColor: 'rgba(184, 83, 73, 0.45)',
                  color:
                    slotEvaluation.state === 'out_of_range' ? '#E2B05A' : '#E58B82',
                }}
              >
                <span aria-hidden="true" className="font-mono font-bold shrink-0">
                  !
                </span>
                <span>{slotEvaluation.restrictionReason}</span>
              </div>
            )}
          </div>,
          document.body
        )}
    </div>
  );
};
